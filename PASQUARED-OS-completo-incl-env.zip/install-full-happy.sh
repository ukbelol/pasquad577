#!/usr/bin/env bash
# =============================================================================
# install-full-happy.sh — PASQUARED-OS · Deploy completo para Debian 12 + Apache + SSL
#
# Instala e configura, de ponta a ponta, o PASQUARED-OS:
#   - Node.js 20 LTS + pnpm
#   - PostgreSQL 15 local (com usuário/banco próprios)
#   - Build da aplicação Next.js + variáveis de ambiente
#   - Serviço systemd (pasquared) rodando a app na porta 13000
#   - Apache 2.4 como proxy reverso com HTTPS válido (Let's Encrypt / certbot)
#     para o domínio app.pasquared.space
#
# Uso:  sudo bash install-full-happy.sh
#
# Requisitos: Debian 12, domínio app.pasquared.space apontado para esta máquina
#             (registro A/DNS já propagado), porta 80 e 443 abertas no firewall.
# Considerações de segurança: backup do .env gerado; senhas nunca mostradas em
# texto puro; ACL restritiva nos arquivos de segredo.
# =============================================================================

set -euo pipefail

# ------------------------------------------------------------------ configuração
APP_DIR="/opt/pasquared"
APP_USER="pasquared"
APP_PORT="13000"
APP_HOST="app.pasquared.space"
SECURITY_EMAIL="rogermei577@gmail.com"
DB_NAME="pasquared"
DB_USER="pasquared"
NODE_MAJOR="20"

log()  { printf '\n\033[1;32m[PASQUARED]\033[0m %s\n' "$*"; }
warn() { printf '\n\033[1;33m[AVISO]\033[0m %s\n' "$*"; }
die()  { printf '\n\033[1;31m[ERRO]\033[0m %s\n' "$*" >&2; exit 1; }

[[ "$(id -u)" -eq 0 ]] || die "Execute com sudo: sudo bash install-full-happy.sh"

# --------------------------------------------------------------- pré-verificações
source /etc/os-release
[[ "$ID" == "debian" ]] || warn "Distro detectada: $PRETTY_NAME (o script é otimizado p/ Debian 12)"
command -v curl >/dev/null || { log "Instalando curl..."; apt-get update -qq && apt-get install -y -qq curl; }
command -v git >/dev/null || { log "Instalando git..."; apt-get install -y -qq git; }

# --------------------------------------------------------------- 1. Node + pnpm
if ! command -v node >/dev/null; then
  log "Instalando Node.js $NODE_MAJOR via NodeSource..."
  curl -fsSL "https://deb.nodesource.com/setup_$NODE_MAJOR.x" | bash -
  apt-get install -y -qq nodejs
fi
if ! command -v pnpm >/dev/null; then
  log "Instalando pnpm..."
  corepack enable 2>/dev/null || npm install -g pnpm@9
fi
log "Node: $(node -v) | pnpm: $(pnpm --version 2>/dev/null || echo n/a)"

# --------------------------------------------------------------- 2. PostgreSQL
if ! command -v psql >/dev/null; then
  log "Instalando PostgreSQL 15..."
  apt-get install -y -qq postgresql postgresql-contrib
fi
log "Garantindo servidor PostgreSQL ativo..."
systemctl enable --now postgresql >/dev/null 2>&1 || true
pg_isready -q 2>/dev/null || die "PostgreSQL não respondeu. Verifique: systemctl status postgresql"

DB_PASS="$(openssl rand -hex 24)"
log "Criando banco '$DB_NAME' e usuário '$DB_USER'..."
su - postgres -c "psql -tAc \"SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'\"" | grep -q 1 \
  || su - postgres -c "psql -c \"CREATE ROLE $DB_USER LOGIN PASSWORD '$DB_PASS'\""
su - postgres -c "psql -tAc \"SELECT 1 FROM pg_database WHERE datname='$DB_NAME'\"" | grep -q 1 \
  || su - postgres -c "psql -c \"CREATE DATABASE $DB_NAME OWNER $DB_USER\""
su - postgres -c "psql -c \"GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER\""
DATABASE_URL="postgres://$DB_USER:$DB_PASS@127.0.0.1:5432/$DB_NAME"

# --------------------------------------------------------------- 3. Usuário do app
if ! id "$APP_USER" >/dev/null 2>&1; then
  log "Criando usuário de sistema '$APP_USER'..."
  useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin "$APP_USER"
fi
mkdir -p "$APP_DIR/uploads"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

# --------------------------------------------------------------- 4. Código-fonte
log "Copia de código para $APP_DIR..."
SRC="/home/ubuntu/workspace/project"
if [[ -d "$SRC" ]]; then
  rsync -a --delete --exclude='.next' --exclude='node_modules' --exclude='.git' \
    --exclude='uploads' "$SRC"/ "$APP_DIR"/ 2>/dev/null \
    || ( die "rsync não disponível. Rode: apt-get install -y rsync" )
else
  [[ -z "${REPO_URL:-}" ]] && die "Defina REPO_URL com o repositório git do projeto."
  git clone "$REPO_URL" "$APP_DIR"
fi

# --------------------------------------------------------------- 5. .env seguro
AUTH_SECRET="$(openssl rand -hex 32)"
env_secret="$APP_DIR/.env"
cat > "$env_secret" <<EOF
DATABASE_URL=$DATABASE_URL
AUTH_SECRET=$AUTH_SECRET
# (opcional) Chave do gateway BTL/LLM para fallback de IA:
BTY_LLM_SERVER_API_KEY=
EOF
chown "$APP_USER":"$APP_USER" "$env_secret"
chmod 600 "$env_secret"
log "Arquivo de ambiente criado em $env_secret (permissões 600)."
warn "Preencha BTY_LLM_SERVER_API_KEY e configure a Microsoft Foundry no painel super admin."

# --------------------------------------------------------------- 6. Dependências + build
log "Instalando dependências e fazendo build (porta $APP_PORT)..."
cd "$APP_DIR"
su -s /bin/bash "$APP_USER" -c "cd '$APP_DIR' && corepack enable 2>/dev/null || true"
sudo -u "$APP_USER" env PATH="$PATH" HOME="$APP_DIR" pnpm install --frozen-lockfile 2>/dev/null \
  || sudo -u "$APP_USER" env PATH="$PATH" HOME="$APP_DIR" pnpm install
sudo -u "$APP_USER" env PATH="$PATH" HOME="$APP_DIR" pnpm db:migrate >/dev/null 2>&1 \
  || warn "Migração via drizzle falhou — rode manualmente: cd $APP_DIR && pnpm db:migrate"
sudo -u "$APP_USER" env PATH="$PATH" HOME="$APP_DIR" pnpm build

# Regenera o zip do código-fonte a partir da árvore de produção (já com o .env
# local), garantindo que o download no painel super admin reflita o deploy atual.
log "Regenerando arquivo ZIP do código-fonte..."
command -v zip >/dev/null 2>&1 || apt-get install -y -qq zip
rm -f "$APP_DIR"/releases/PASQUARED-OS-completo-incl-env.zip
mkdir -p "$APP_DIR/releases"
cd "$APP_DIR"
zip -rq "$APP_DIR/releases/PASQUARED-OS-completo-incl-env.zip" . \
  -x "node_modules/*" ".next/*" ".git/*" "releases/*" "*.tsbuildinfo" "*.zip" \
  -x "logs/*" "uploads/*" "src/*" 2>/dev/null \
  || warn "Não foi possível gerar o ZIP (instale 'zip')."
chown "$APP_USER":"$APP_USER" "$APP_DIR/releases/PASQUARED-OS-completo-incl-env.zip"
chmod 600 "$APP_DIR/releases/PASQUARED-OS-completo-incl-env.zip"

# --------------------------------------------------------------- 7. systemd
log "Criando serviço systemd 'pasquared'..."
cat > /etc/systemd/system/pasquared.service <<EOF
[Unit]
Description=PASQUARED-OS (Next.js)
After=network.target postgresql.service

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
Environment=NODE_ENV=production
Environment=PORT=$APP_PORT
ExecStart=/usr/bin/node node_modules/next/dist/bin/next start -p $APP_PORT
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now pasquared
sleep 4
curl -fsS "http://127.0.0.1:$APP_PORT/api/health" >/dev/null \
  && log "Serviço PASQUARED no ar ✔" \
  || warn "Aguardando/serviço ainda inicializando. Verifique: systemctl status pasquared"

# --------------------------------------------------------------- 8. Apache + SSL
log "Instalando Apache e certbot..."
apt-get install -y -qq apache2 certbot python3-certbot-apache
a2enmod proxy proxy_http headers ssl rewrite >/dev/null 2>&1 || true
cat > /etc/apache2/sites-available/pasquared.conf <<EOF
<VirtualHost *:80>
    ServerName  $APP_HOST
    ServerAdmin $SECURITY_EMAIL

    ProxyPreserveHost On
    ProxyRequests Off
    ProxyPass         / http://127.0.0.1:$APP_PORT/
    ProxyPassReverse  / http://127.0.0.1:$APP_PORT/

    # Limite de upload para mídia da anamnese (30MB)
    RequestReadTimeout header=60 body=$((30 * 1024))0000
</VirtualHost>
EOF
a2ensite pasquared >/dev/null 2>&1 || a2dissite 000-default
systemctl reload apache2
log "Emitindo certificado Let's Encrypt para $APP_HOST..."
certbot --apache --redirect -d "$APP_HOST" -m "$SECURITY_EMAIL" --agree-tos -n
log "Renovação automática de certificados ativa:"
systemctl enable --now certbot.timer >/dev/null 2>&1 || true

# --------------------------------------------------------------- fim
log "Deploy concluído em:  https://$APP_HOST"
log "   - Aplicação:        https://$APP_HOST"
log "   - Caminho uploads:  $APP_DIR/uploads (ownership $APP_USER)"
warn "Anote o .env gerado em $APP_DIR/.env (inclui DATABASE_URL e AUTH_SECRET)."
warn "Super admin: use o painel em /admin/login e configure a Microsoft Foundry lá."
