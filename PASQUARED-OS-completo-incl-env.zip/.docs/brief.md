# PASQUARED-OS
- One-line positioning: Sistema cognitivo médico de anamnese assistida por IA, onde o algoritmo PASQUARED é o controlador de fluxo e a IA Microsoft Foundry gera as perguntas.
- Target users: Pacientes (PA), Médicos (DR) e um Super Admin técnico.
- Core features:
  1. Login/cadastro pacientes e médicos com busca de endereço via CEP.
  2. Anamnese assistida (PASQUARED controla fluxo, MS Foundry gera perguntas), upload de arquivos salvos para avaliação.
  3. Painel do médico: busca consulta por CPF, reproduz áudio/vídeo e vê imagens/textos.
  4. Área restrita do Super Admin (gestão de tudo + configuração da API Microsoft Foundry).
- Device strategy: adaptive
- Design style: @theme:aurora-dark
- Technical constraints: Debian 12 + Apache + SSL válido (app.pasquared.space), instalar via install-full-happy.sh.
- Completed: base Next.js + DB provisionado; schema, auth, anamnese, painéis e script de deploy em construção.
- Current iteration: construção completa do sistema.
