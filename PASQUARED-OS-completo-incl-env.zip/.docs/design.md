# Design: aurora-dark
- Fundo preto absoluto (#000), texto branco ultra-ultra leve.
- Blobs de aurora esmeralda (#00FF87), violeta e teal, grandes e desfocados, animação lenta ambiental.
- Superfícies translúcidas (rgba(255,255,255,0.03)), bordas fracas (0.08), soft glow no lugar de cards pesados.
- Tipografia Inter, hero weight 300; JetBrains Mono para labels técnicos/estatísticas.
- CTA primária com glow esmeralda no hover; hover luminoso, sem transições saltitantes.
