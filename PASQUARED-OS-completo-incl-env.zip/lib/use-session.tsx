'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiClient } from '@/lib/request'

export type SessionUser = {
  id: string
  role: 'patient' | 'doctor' | 'superadmin'
  email: string
  firstName: string
  lastName: string
}

type State =
  | { status: 'loading' }
  | { status: 'unauthenticated' }
  | { status: 'authenticated'; user: SessionUser }

export function useSession(allowed: SessionUser['role'][] = []): State {
  const router = useRouter()
  const [state, setState] = useState<State>({ status: 'loading' })

  useEffect(() => {
    apiClient
      .get<{ user: SessionUser | null }>('/api/auth/me')
      .then((res) => {
        const user = res.success ? res.data.user : null
        if (!user) {
          setState({ status: 'unauthenticated' })
          router.replace('/')
          return
        }
        if (allowed.length && !allowed.includes(user.role)) {
          router.replace(
            user.role === 'doctor'
              ? '/medico/dashboard'
              : user.role === 'superadmin'
                ? '/admin/dashboard'
                : '/paciente/dashboard'
          )
          return
        }
        setState({ status: 'authenticated', user })
      })
      .catch(() => {
        setState({ status: 'unauthenticated' })
        router.replace('/')
      })
  }, [allowed, router])

  return state
}

export function LogoutButton({ className }: { className?: string }) {
  const router = useRouter()
  return (
    <button
      onClick={() => {
        apiClient.post('/api/auth/logout', {}).then(() => router.push('/'))
      }}
      className={
        className ||
        'px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white'
      }
    >
      Sair
    </button>
  )
}
