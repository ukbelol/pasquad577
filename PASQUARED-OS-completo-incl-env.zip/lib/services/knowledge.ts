import 'server-only'
import { eq } from 'drizzle-orm'
import { db } from '@/db'
import {
  knowledgeBases,
  knowledgeNodes,
  type KnowledgeBaseRow,
  type KnowledgeNodeRow,
} from '@/db/schemas/schema'
import { AppError } from '@/lib/errors'
import { offlineKnowledgeProfiles } from './knowledge-profiles'

/**
 * Registro canônico das bases de conhecimento de saúde das Américas.
 * São repositórios oficiais (órgãos de saúde) dos países das Américas.
 */
export const AMERICAS_KB_CATALOG = [
  {
    code: 'paho',
    name: 'PAHO / OMS Américas',
    country: 'Regional',
    region: 'Americas',
    focus: 'Pan American Health Organization — vigilância em saúde, guias de doenças infecciosas, emergências sanitárias.',
    officialUrl: 'https://www.paho.org/',
    connectorType: 'hosted',
  },
  {
    code: 'who',
    name: 'WHO (World Health Organization)',
    country: 'Global',
    region: 'Americas',
    focus: 'Classificação Internacional de Doenças (CID), guias clínicos e normas sanitárias internacionais.',
    officialUrl: 'https://www.who.int/',
    connectorType: 'hosted',
  },
  {
    code: 'cdc',
    name: 'CDC (Estados Unidos)',
    country: 'EUA',
    region: 'Americas',
    focus: 'Centers for Disease Control and Prevention — guias de prevenção, surtos, imunização e saúde pública.',
    officialUrl: 'https://www.cdc.gov/',
    connectorType: 'hosted',
  },
  {
    code: 'openfda',
    name: 'OpenFDA (EUA)',
    country: 'EUA',
    region: 'Americas',
    focus: 'API pública da FDA com bulas, rótulos de medicamentos, eventos adversos e recalls.',
    officialUrl: 'https://open.fda.gov/',
    connectorType: 'http-json',
  },
  {
    code: 'nih',
    name: 'NIH / MedlinePlus (EUA)',
    country: 'EUA',
    region: 'Americas',
    focus: 'National Institutes of Health — MedlinePlus: saúde do paciente, sintomas, medicamentos e testes.',
    officialUrl: 'https://medlineplus.gov/',
    connectorType: 'hosted',
  },
  {
    code: 'anvisa',
    name: 'ANVISA (Brasil)',
    country: 'Brasil',
    region: 'Americas',
    focus: 'Agência Nacional de Vigilância Sanitária — bulas, vigilância de medicamentos e eventos adversos.',
    officialUrl: 'https://www.gov.br/anvisa/',
    connectorType: 'hosted',
  },
  {
    code: 'mo_canada',
    name: 'Health Canada / Santé Canada',
    country: 'Canadá',
    region: 'Americas',
    focus: 'Health Canada — medicamentos, produtos naturais, eventos adversos e guias de saúde.',
    officialUrl: 'https://www.canada.ca/en/health-canada.html',
    connectorType: 'hosted',
  },
  {
    code: 'usda',
    name: 'USDA FoodData Central (EUA)',
    country: 'EUA',
    region: 'Americas',
    focus: 'Composição nutricional de alimentos — apoio à anamnese de hábitos dietéticos.',
    officialUrl: 'https://fdc.nal.usda.gov/',
    connectorType: 'hosted',
  },
] as const

/** Povoa o catálogo de bases (idempotente) na primeira execução. */
export async function ensureKnowledgeCatalog(): Promise<void> {
  const existing = new Set(
    (await db.select({ code: knowledgeBases.code }).from(knowledgeBases)).map(
      (r) => r.code
    )
  )
  for (const kb of AMERICAS_KB_CATALOG) {
    if (existing.has(kb.code)) continue
    await db.insert(knowledgeBases).values({ ...kb, status: 'disabled' })
  }
}

export async function listKnowledgeBases(): Promise<KnowledgeBaseRow[]> {
  await ensureKnowledgeCatalog()
  const rows = await db
    .select()
    .from(knowledgeBases)
    .orderBy(knowledgeBases.name)
  return rows
}

async function getBaseById(id: string): Promise<KnowledgeBaseRow> {
  const rows = await db
    .select()
    .from(knowledgeBases)
    .where(eq(knowledgeBases.id, id))
    .limit(1)
  if (!rows.length) throw new AppError('Base de conhecimento não encontrada.', 404)
  return rows[0]
}

async function setCountAndStatus(
  id: string,
  status: KnowledgeBaseRow['status'],
  lastSyncAt: boolean
): Promise<void> {
  const count = await db.$count(knowledgeNodes, eq(knowledgeNodes.baseId, id))
  await db
    .update(knowledgeBases)
    .set({
      status: status as KnowledgeBaseRow['status'],
      nodeCount: count,
      lastSyncAt: lastSyncAt ? new Date() : null,
    })
    .where(eq(knowledgeBases.id, id))
}

/**
 * Conecta uma base e ingere seus nós de conhecimento disponíveis para o PASQUARED.
 * A ingestão usa o perfil curado (fatos verificáveis). Em ambiente com rede
 * aberta, um conector http-json poderia buscar em tempo real; aqui é resiliente
 * e nunca quebra offline.
 */
export async function connectKnowledgeBase(id: string): Promise<KnowledgeBaseRow> {
  const base = await getBaseById(id)
  await db
    .update(knowledgeBases)
    .set({ status: 'syncing' })
    .where(eq(knowledgeBases.id, id))

  try {
    await db.delete(knowledgeNodes).where(eq(knowledgeNodes.baseId, id))

    const profile = offlineKnowledgeProfiles[base.code]
    if (profile && profile.nodes.length) {
      await db.insert(knowledgeNodes).values(
        profile.nodes.map((n) => ({
          baseId: id,
          source: n.source ?? base.name,
          title: n.title,
          snippet: n.snippet,
          topic: n.topic ?? profile.defaultTopic,
          weight: n.weight ?? 55,
          nodeType: n.nodeType ?? 'fact',
        }))
      )
    } else {
      await db.insert(knowledgeNodes).values({
        baseId: id,
        source: base.name,
        title: 'Fonte de conhecimento conectada',
        snippet: `Base ${base.name} conectada como fonte de contexto para o PASQUARED.`,
        topic: base.focus?.slice(0, 120) || 'general',
        weight: 40,
        nodeType: 'fact',
      })
    }

    await setCountAndStatus(id, 'connected', true)
    return await getBaseById(id)
  } catch (error) {
    await db
      .update(knowledgeBases)
      .set({ status: 'error' })
      .where(eq(knowledgeBases.id, id))
    throw error
  }
}

/** Desconecta a base (remove os nós ingeridos). */
export async function disconnectKnowledgeBase(id: string): Promise<KnowledgeBaseRow> {
  await getBaseById(id)
  await db.delete(knowledgeNodes).where(eq(knowledgeNodes.baseId, id))
  await db
    .update(knowledgeBases)
    .set({ status: 'disabled', nodeCount: 0, lastSyncAt: null })
    .where(eq(knowledgeBases.id, id))
  return await getBaseById(id)
}

/** Re-sincroniza (re-ingerir) uma base conectada. */
export async function syncKnowledgeBase(id: string): Promise<KnowledgeBaseRow> {
  return connectKnowledgeBase(id)
}

/**
 * Busca nós de conhecimento conectados relevantes a um tema (grounding).
 * Usado pelo PASQUARED ao montar perguntas e validar hipóteses.
 */
export async function queryKnowledge(
  topic: string,
  limit = 4
): Promise<KnowledgeNodeRow[]> {
  let nodes: KnowledgeNodeRow[] = []
  try {
    nodes = await db
      .select()
      .from(knowledgeNodes)
      .where(eq(knowledgeNodes.topic, topic))
      .orderBy(knowledgeNodes.createdAt)
      .limit(Math.max(2, Math.min(8, limit)))
  } catch {
    nodes = []
  }
  if (nodes.length) return nodes
  return db
    .select()
    .from(knowledgeNodes)
    .orderBy(knowledgeNodes.createdAt)
    .limit(3)
}

/** Número total de nós disponíveis (grounding habilitado). */
export async function connectedNodeCount(): Promise<number> {
  try {
    return await db.$count(knowledgeNodes)
  } catch {
    return 0
  }
}

export async function connectedBaseCount(): Promise<number> {
  try {
    return await db.$count(
      knowledgeBases,
      eq(knowledgeBases.status, 'connected')
    )
  } catch {
    return 0
  }
}
