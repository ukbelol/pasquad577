import 'server-only'
import { getFoundryConfig, getGatewayConfig } from '@/lib/services/settings'
import { queryKnowledge } from '@/lib/services/knowledge'

/**
 * Serviço de IA da anamnese.
 *
 * O controlador de fluxo é o PASQUARED (lib/cognitive/pasquared.ts); a
 * "criadora de perguntas" é a IA. Ordem de resolução:
 *   1. Microsoft Foundry (Azure OpenAI) se configurado pelo Super Admin.
 *   2. Gateway LLM da plataforma (fallback).
 *   3. Determinístico guiado pelo PASQUARED (nunca quebra o fluxo).
 */

export type QuestionResult = {
  question: string
  source: 'foundry' | 'gateway' | 'pasquared'
  model?: string
}

const ANAMNESIS_SYSTEM = `Você é a "criadora de perguntas" de um sistema de anamnese médica chamado PASQUARED-OS. O controlador de fluxo (algoritmo PASQUARED) já coletou as UCI (Unidades Cognitivas de Informação) e hipóteses iniciais. Seu papel: fazer EXATAMENTE UMA pergunta de cada vez, em português, clara e empática, para aprofundar a investigação da queixa relatada pelo paciente.
Regras:
- Faça sempre UMA única pergunta por resposta.
- Seja curta, direta e humana (máx 40 palavras).
- Considere o histórico do paciente (idade/sexo) e as queixas já relatadas.
- Não dê diagnóstico nem tratamento. Apenas pergunte.
- Priorize sinais de alerta/gravidade, cronologia, intensidade, fatores que aliviam/pioram, e sintomas associados.
- Responda apenas com o texto da pergunta, sem aspas e sem prefácio.`

export function buildSystemPrompt(grounding: string[] = []): string {
  const kb =
    grounding.length > 0
      ? `

[Conhecimento de bases de saúde das Américas — use como fundamentação, sem citar ao paciente]
${grounding.map((s) => `- ${s}`).join('\n')}`
      : ''
  return ANAMNESIS_SYSTEM + kb
}

/**
 * Busca nós conectados das bases de conhecimento das Américas e monta um bloco
 * de grounding conciso para a IA fundamentar a próxima pergunta.
 */
export async function buildGroundingSection(
  topics: string[],
  max = 5
): Promise<string[]> {
  const known = new Set<string>()
  const out: string[] = []
  try {
    for (const t of topics.slice(0, 3)) {
      const nodes = await queryKnowledge(t, 3)
      for (const n of nodes) {
        if (n && n.snippet && !known.has(n.snippet)) {
          known.add(n.snippet)
          out.push(`[${n.source || 'base'}] ${n.snippet}`)
          if (out.length >= max) return out
        }
      }
    }
  } catch {
    // grounding é opcional; nunca quebra a pergunta
  }
  return out
}

/** Montar o corpo da mensagem para o Foundry / OpenAI. */
function buildUserPrompt(
  patientContext: string,
  transcript: { role: string; content: string }[],
  hypothesisLine: string
): string {
  const history = transcript
    .filter((m) => m.role === 'user' || m.role === 'assistant')
    .slice(-8)
    .map((m) => `${m.role === 'user' ? 'Paciente' : 'IA'}: ${m.content}`)
    .join('\n')

  return `[Contexto do paciente]\n${patientContext}\n\n[Hipóteses PASQUARED]\n${hypothesisLine}\n\n[Histórico da conversa]\n${
    history || 'Nenhuma queixa relatada ainda.'
  }\n\nCom base nisso, faça a próxima pergunta (uma, curta) para investigar a anamnese.`
}

/** Chamada HTTP básica (streaming desligado por simplicidade de robustez). */
async function postJson(url: string, headers: Record<string, string>, body: unknown): Promise<unknown> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...headers },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(40000),
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`AI provider ${res.status}: ${text.slice(0, 300)}`)
  }
  return res.json()
}

function extractOpenAiText(json: unknown): string {
  const j = json as {
    choices?: { message?: { content?: string } }[]
  }
  const content = j.choices?.[0]?.message?.content
  return (content || '').trim()
}

/** Chamar Microsoft Foundry (Azure OpenAI). */
async function askFoundry(
  system: string,
  user: string
): Promise<QuestionResult> {
  const cfg = await getFoundryConfig()
  if (!cfg.enabled || !cfg.endpoint || !cfg.apiKey) {
    throw new Error('Foundry não configurado')
  }
  const base = cfg.endpoint.replace(/\/$/, '')
  const deployment = encodeURIComponent(cfg.deploymentName || 'gpt-4o-mini')
  const url = `${base}/openai/deployments/${deployment}/chat/completions?api-version=${encodeURIComponent(
    cfg.apiVersion || '2024-10-21'
  )}`
  const json = await postJson(
    url,
    { 'api-key': cfg.apiKey, ...cfg.extraHeaders },
    {
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      max_tokens: 120,
      temperature: 0.5,
    }
  )
  const text = extractOpenAiText(json)
  if (!text) throw new Error('Foundry retornou resposta vazia')
  return { question: text, source: 'foundry', model: cfg.deploymentName }
}

/** Chamar o gateway LLM da plataforma (fallback). */
async function askGateway(
  system: string,
  user: string
): Promise<QuestionResult> {
  const gw = getGatewayConfig()
  if (!gw.apiKey) throw new Error('Gateway sem credenciais')
  const url = `${gw.baseUrl}/chat/completions`
  const json = await postJson(
    url,
    {
      Authorization: `Bearer ${gw.apiKey}`,
      'x-bty-business': 'ReActUs',
      'x-bty-workspace': 'default',
    },
    {
      model: process.env.HAPPYSEEDS_AVAILABLE_MODELS?.split(',')
        .find((m) => m.includes('claude') || m.includes('sonnet') || m.includes('gpt-4'))
        ? gw.defaultModel
        : gw.defaultModel,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      max_tokens: 120,
      temperature: 0.5,
    }
  )
  const text = extractOpenAiText(json)
  if (!text) throw new Error('Gateway retornou resposta vazia')
  return { question: text, source: 'gateway', model: gw.defaultModel }
}

/** Banco de perguntas determinísticas guiadas pelo PASQUARED (fallback final). */
const DETERMINISTIC_QUESTIONS = [
  'Há quanto tempo esse sintoma começou?',
  'Em uma escala de 0 a 10, qual a intensidade do seu sintoma agora?',
  'Existe algo que melhora ou piora o seu sintoma?',
  'Você sente mais algum sintoma associado, como febre, fraqueza ou fadiga?',
  'Esse sintoma interfere nas suas atividades diárias ou no seu sono?',
  'Você já passou por esse tipo de situação antes? Como foi?',
  'Você está tomando algum medicamento atualmente? Se sim, qual?',
  'Você tem alguma condição de saúde conhecida ou alergia?',
  'Sente dor em repouso ou apenas ao se movimentar?',
  'Há algo mais que gostaria de me contar sobre como está se sentindo?',
]

export function deterministicQuestion(cycle: number): string {
  const i = Math.min(DETERMINISTIC_QUESTIONS.length - 1, Math.max(0, cycle))
  return DETERMINISTIC_QUESTIONS[i]
}

/**
 * Gerar a próxima pergunta da anamnese.
 * Tenta Foundry → Gateway → determinístico.
 */
export async function nextQuestion(input: {
  patientContext: string
  transcript: { role: string; content: string }[]
  hypothesisLine: string
  cycle: number
  topics?: string[]
}): Promise<QuestionResult> {
  const grounding = await buildGroundingSection(input.topics || [])
  const system = buildSystemPrompt(grounding)
  const user = buildUserPrompt(
    input.patientContext,
    input.transcript,
    input.hypothesisLine
  ) + (grounding.length ? `\n\n[Fundamentação de bases conectadas]\n${grounding.join('\n')}` : '')

  if (await foundryEnabled()) {
    try {
      return await askFoundry(system, user)
    } catch (err) {
      console.error('[AI] Foundry falhou, tentando gateway:', err)
    }
  }

  try {
    return await askGateway(system, user)
  } catch (err) {
    console.error('[AI] Gateway falhou, usando determinístico:', err)
    return {
      question: deterministicQuestion(input.cycle),
      source: 'pasquared',
    }
  }
}

async function foundryEnabled(): Promise<boolean> {
  const cfg = await getFoundryConfig()
  return !!cfg.enabled && !!cfg.endpoint && !!cfg.apiKey
}
