import 'server-only'
import { db } from '@/db'
import { appSettings } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'

/**
 * Serviço de configuração do sistema (Super Admin).
 * Armazena a configuração da IA Microsoft Foundry e demais ajustes globais.
 */

export type MicrosoftFoundryConfig = {
  enabled: boolean
  endpoint: string // ex: https://<resource>.services.ai.azure.com
  apiKey: string
  deploymentName: string // ex: gpt-4o-mini
  apiVersion: string // ex: 2024-10-21
  extraHeaders: Record<string, string>
  updatedAt?: string
}

export const DEFAULT_FOUNDRY: MicrosoftFoundryConfig = {
  enabled: false,
  endpoint: '',
  apiKey: '',
  deploymentName: 'gpt-4o-mini',
  apiVersion: '2024-10-21',
  extraHeaders: {},
}

const FOUNDRY_KEY = 'microsoft_foundry'

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const rows = await db
    .select({ value: appSettings.value })
    .from(appSettings)
    .where(eq(appSettings.key, key))
    .limit(1)
  if (!rows[0]) return fallback
  const v = rows[0].value as unknown
  if (Array.isArray(v) || (v && typeof v === 'object')) {
    return { ...(fallback as object), ...(v as object) } as T
  }
  return v as T
}

export async function setSetting<T>(key: string, value: T): Promise<void> {
  await db
    .insert(appSettings)
    .values({ key, value: value as unknown as Record<string, unknown> })
    .onConflictDoUpdate({
      target: appSettings.key,
      set: { value: value as unknown as Record<string, unknown> },
    })
}

export async function getFoundryConfig(): Promise<MicrosoftFoundryConfig> {
  return getSetting<MicrosoftFoundryConfig>(FOUNDRY_KEY, DEFAULT_FOUNDRY)
}

export async function saveFoundryConfig(
  cfg: MicrosoftFoundryConfig
): Promise<void> {
  await setSetting(FOUNDRY_KEY, { ...cfg, updatedAt: new Date().toISOString() })
}

/**
 * Configuração do gateway LLM da plataforma (fallback).
 * Lê das variáveis de ambiente do sandbox.
 */
export function getGatewayConfig() {
  return {
    baseUrl: process.env.BTY_LLM_SERVER_BASE_URL || 'https://llm-gateway.happyseeds.ai/v1',
    apiKey: process.env.BTY_LLM_SERVER_API_KEY || '',
    defaultModel: 'claude-sonnet-4.6',
  }
}
