import 'server-only'

/**
 * Perfis offline (curados) para as bases de conhecimento das Américas.
 * Cada perfil traz nós de conhecimento reais e verificáveis (fatos públicos)
 * que alimentam o PASQUARED como memória externa/grounding quando a base é
 * conectada. No ambiente do sandbox, serve como fonte confiável sem depender
 * de rede; em produção pode ser substituído por ingestão via API.
 */

export type NodeSeed = {
  title: string
  snippet: string
  topic?: string
  source?: string
  weight?: number
  nodeType?: 'fact' | 'guideline' | 'drug' | 'surveillance'
}

export type Profile = {
  defaultTopic: string
  nodes: NodeSeed[]
}

export const offlineKnowledgeProfiles: Record<string, Profile> = {
  paho: {
    defaultTopic: 'saude-publica',
    nodes: [
      {
        title: 'Vigilância de doenças transmissíveis (PAHO)',
        snippet:
          'A PAHO sustenta redes regionais de vigilância de doenças transmissíveis e coordena protocolos de resposta a emergências sanitárias nas Américas, incluindo vetores como dengue e arboviroses.',
        topic: 'infectologia',
        nodeType: 'surveillance',
        weight: 70,
      },
      {
        title: 'Linhas de cuidado para doenças não transmissíveis',
        snippet:
          'Hipertensão e diabetes figuram entre as principais doenças não transmissíveis nas Américas; a detecção precoce e o controle dos fatores de risco são recomendações centrais da PAHO.',
        topic: 'cardiologia',
        nodeType: 'guideline',
        weight: 75,
      },
      {
        title: 'Imunização regional',
        snippet:
          'A PAHO coordena o programa regional de imunização, recomendando esquemas de vacinação ao longo da vida para prevenir doenças preveníveis por vacina.',
        topic: 'imunização',
        nodeType: 'guideline',
        weight: 65,
      },
    ],
  },
  who: {
    defaultTopic: 'diagnostico',
    nodes: [
      {
        title: 'Classificação Internacional de Doenças (CID)',
        snippet:
          'A WHO mantém a CID, padrão internacional para codificação e relato de condições clínicas, usado nos prontuários para padronizar os diagnósticos.',
        topic: 'codificacao',
        nodeType: 'fact',
        weight: 80,
      },
      {
        title: 'Sinais de alarme em saúde',
        snippet:
          'A WHO recomenda a triagem sistematizada de sinais vitais e sinais de alarme (febre prolongada, dispnéia, rebaixamento do nível de consciência) na avaliação inicial do paciente.',
        topic: 'emergencia',
        nodeType: 'guideline',
        weight: 70,
      },
    ],
  },
  cdc: {
    defaultTopic: 'saude-publica',
    nodes: [
      {
        title: 'Guia de prevenção de infecções',
        snippet:
          'O CDC preconiza higienização das mãos, etiqueta respiratória e isolamento para reduzir a transmissão de infecções respiratórias em serviços de saúde.',
        topic: 'infectologia',
        nodeType: 'guideline',
        weight: 72,
      },
      {
        title: 'Vigilância de surtos',
        snippet:
          'O CDC mantém sistema de notificação e vigilância de surtos, com definições de casos para doenças de notificação obrigatória.',
        topic: 'saude-publica',
        nodeType: 'surveillance',
        weight: 68,
      },
    ],
  },
  openfda: {
    defaultTopic: 'farmacovigilancia',
    nodes: [
      {
        title: 'Base de rótulos de medicamentos (OpenFDA/FDA)',
        snippet:
          'O OpenFDA expõe dados públicos de rótulos aprovados pela FDA, com indicações, contraindicações, reações adversas e posologia — útil para conferência de bula.',
        topic: 'farmacologia',
        nodeType: 'drug',
        weight: 85,
      },
      {
        title: 'Relatos de eventos adversos',
        snippet:
          'Dados de eventos adversos relatados à FDA ajudam a ponderar o perfil de segurança de um medicamento durante a anamnese farmacológica.',
        topic: 'farmacovigilancia',
        nodeType: 'surveillance',
        weight: 80,
      },
      {
        title: 'Recalls de medicamentos',
        snippet:
          'A FDA publica recalls de medicamentos; checar o histórico do item em uso pode revelar lotes com risco de segurança.',
        topic: 'farmacovigilancia',
        nodeType: 'surveillance',
        weight: 70,
      },
    ],
  },
  nih: {
    defaultTopic: 'educacao-saude',
    nodes: [
      {
        title: 'MedlinePlus — informação ao paciente',
        snippet:
          'O MedlinePlus (NIH) oferece conteúdo em linguagem acessível sobre sintomas, doenças, medicamentos e exames, apoiando a comunicação médica com o paciente.',
        topic: 'educacao-saude',
        nodeType: 'fact',
        weight: 74,
      },
      {
        title: 'Sintomas frequentes e triagem',
        snippet:
          'Como fonte de saúde pública, o NIH estrutura roteiros de perguntas-chave sobre sintomas que complementam a anamnese dirigida.',
        topic: 'anamnese',
        nodeType: 'guideline',
        weight: 65,
      },
    ],
  },
  anvisa: {
    defaultTopic: 'farmacovigilancia',
    nodes: [
      {
        title: 'Bulário da ANVISA (Brasil)',
        snippet:
          'O bulário eletrônico da ANVISA reúne bulas de medicamentos registrados no Brasil, com posologia, advertências e reações adversas.',
        topic: 'farmacologia',
        nodeType: 'drug',
        weight: 82,
      },
      {
        title: 'Vigimed — eventos adversos',
        snippet:
          'A ANVISA opera a notificação de suspeitas de eventos adversos de medicamentos, componente da farmacovigilância nacional.',
        topic: 'farmacovigilancia',
        nodeType: 'surveillance',
        weight: 72,
      },
    ],
  },
  mo_canada: {
    defaultTopic: 'medicamentos',
    nodes: [
      {
        title: 'Banco de dados de medicamentos (Health Canada)',
        snippet:
          'O Health Canada publica informações de produtos de saúde aprovados no Canadá, incluindo monografias de medicamentos e produtos naturais.',
        topic: 'farmacologia',
        nodeType: 'drug',
        weight: 70,
      },
      {
        title: 'Relatos de reações adversas canadianos',
        snippet:
          'O Health Canada mantém registros públicos de reações adversas, úteis para perfil de segurança comparado entre regiões.',
        topic: 'farmacovigilancia',
        nodeType: 'surveillance',
        weight: 66,
      },
    ],
  },
  usda: {
    defaultTopic: 'nutricao',
    nodes: [
      {
        title: 'Composição nutricional (FoodData Central)',
        snippet:
          'O FoodData Central (USDA) traz dados de composição de alimentos, macronutrientes e micronutrientes — apoio objetivo à avaliação dietética na anamnese.',
        topic: 'nutricao',
        nodeType: 'fact',
        weight: 70,
      },
      {
        title: 'Guias alimentares',
        snippet:
          'As diretrizes dietéticas americanas (DGA) recomendam padrões alimentares ricos em vegetais, grãos integrais e proteínas magras para prevenção de doenças crônicas.',
        topic: 'nutricao',
        nodeType: 'guideline',
        weight: 68,
      },
    ],
  },
}
