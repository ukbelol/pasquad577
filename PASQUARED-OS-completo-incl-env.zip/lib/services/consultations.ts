import 'server-only'
import { eq, and, desc } from 'drizzle-orm'
import { promises as fs } from 'fs'
import path from 'path'
import { db } from '@/db'
import {
  consultations,
  messages,
  users,
  type ConsultationRow,
  type MessageRow,
} from '@/db/schemas/schema'
import { AppError } from '@/lib/errors'
import type { CognitiveState } from '@/lib/cognitive/pasquared'

/**
 * Camada de persistência das consultas (anamneses) e seus arquivos.
 * Arquivos são salvos no disco em ./uploads/<consulta>/ e referenciados no DB.
 */

const UPLOAD_ROOT = path.join(process.cwd(), 'uploads')

export function uploadRoot() {
  return UPLOAD_ROOT
}

export async function ensureUploadDir() {
  await fs.mkdir(UPLOAD_ROOT, { recursive: true })
}

/** Abrir uma nova anamnese (consultation) para um paciente. */
export async function createConsultation(patientId: string) {
  const rows = await db
    .insert(consultations)
    .values({ patientId, status: 'open' })
    .returning()
  return rows[0]
}

/** Buscar consulta e seus arquivos por id, validando dono. */
export async function getConsultation(id: string) {
  const rows = await db
    .select()
    .from(consultations)
    .where(eq(consultations.id, id))
    .limit(1)
  if (!rows[0]) throw new AppError('Consulta não encontrada.', 404)
  return rows[0]
}

export async function listConsultationsByPatient(patientId: string) {
  return db
    .select()
    .from(consultations)
    .where(eq(consultations.patientId, patientId))
    .orderBy(desc(consultations.startedAt))
}

export async function listMessages(consultationId: string) {
  return db
    .select()
    .from(messages)
    .where(eq(messages.consultationId, consultationId))
    .orderBy(messages.createdAt)
}

export async function addMessage(input: {
  consultationId: string
  role: string
  contentType?: string
  content: string
  uciWeight?: number
  uciContext?: string
  uciType?: string
  fileName?: string
  filePath?: string
  fileMime?: string
  fileSize?: number
}) {
  const rows = await db.insert(messages).values(input).returning()
  return rows[0]
}

export async function updateCognitiveState(
  consultationId: string,
  state: CognitiveState,
  completed = false
) {
  await db
    .update(consultations)
    .set({
      cognitiveState: state as unknown as Record<string, unknown>,
      abstractionIndex: state.iga,
      convergence: state.iga,
      summary: state.memory.slice(-3).join('\n'),
      updatedAt: new Date(),
      completedAt: completed ? new Date() : undefined,
      status: completed ? 'completed' : 'open',
      finalReport: completed
        ? state.memory.join('\n')
        : undefined,
    })
    .where(eq(consultations.id, consultationId))
}

/** Buscar consultas abertas de um paciente (para continuar anamnese). */
export async function getOpenConsultation(patientId: string) {
  const rows = await db
    .select()
    .from(consultations)
    .where(
      and(
        eq(consultations.patientId, patientId),
        eq(consultations.status, 'open')
      )
    )
    .orderBy(desc(consultations.updatedAt))
    .limit(1)
  return rows[0] ?? null
}

/** Associar um médico a uma consulta. */
export async function assignDoctor(consultationId: string, doctorId: string) {
  await db
    .update(consultations)
    .set({ doctorId, status: 'reviewed', updatedAt: new Date() })
    .where(eq(consultations.id, consultationId))
}

/** Buscar consultas de um médico. */
export async function listConsultationsByDoctor(doctorId: string) {
  return db
    .select()
    .from(consultations)
    .where(eq(consultations.doctorId, doctorId))
    .orderBy(desc(consultations.startedAt))
}

/** Consulta + paciente para o painel do médico (busca por CPF). */
export async function findConsultationByCpf(cpf: string) {
  const normalized = cpf.replace(/\D/g, '')
  const patient = await db
    .select()
    .from(users)
    .where(eq(users.cpf, normalized))
    .limit(1)
  if (!patient[0]) throw new AppError('Nenhum paciente encontrado para este CPF.', 404)
  const consults = await db
    .select()
    .from(consultations)
    .where(eq(consultations.patientId, patient[0].id))
    .orderBy(desc(consultations.startedAt))
  return { patient: patient[0], consultations: consults }
}

export type { ConsultationRow, MessageRow }
