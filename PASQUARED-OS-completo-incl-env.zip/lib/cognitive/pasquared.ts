import 'server-only'

/**
 * ============================================================================
 * PASQUARED Cognitive Kernel (PCK) — controlador de fluxo da anamnese.
 *
 * Implementa o ciclo cognitivo descrito na especificação:
 *  Receber informações → Criar UCIs → Organizar UCIs → Criar relações
 *  → Construir grafo → Gerar hipóteses → Calcular probabilidades
 *  → Validar hipóteses → Selecionar interpretação → Atualizar memória → Encerrar.
 *
 * Ontologia: P = (O, U, C, M, R, I, V, S)
 *   O = Observador (paciente/médico), U = UCIs, C = Contexto, M = Memória,
 *   R = Relações, I = Inferência, V = Validação, S = Significado.
 * ============================================================================
 */

export type UciType =
  | 'text'
  | 'image'
  | 'sound'
  | 'smell'
  | 'memory'
  | 'emotion'
  | 'symbol'
  | 'concept'
  | 'event'
  | 'file'

export type RelationKind =
  | 'causal'
  | 'temporal'
  | 'semantic'
  | 'emotional'
  | 'spatial'
  | 'symbolic'
  | 'logical'

/** Unidade Cognitiva de Informação: Ui = (T, F, W, Ct). */
export interface UCI {
  id: string
  type: UciType
  source: string
  /** peso cognitivo 0-100 */
  weight: number
  context: string
  text: string
}

/** Relação Rij = (Ui, Uj, w). */
export interface Relation {
  from: string
  to: string
  kind: RelationKind
  /** força da relação 0-100 */
  weight: number
}

export interface CognitiveState {
  /** estado interno do kernel (READY → … → RESPONDING → READY) */
  phase: string
  ucis: UCI[]
  relations: Relation[]
  /** memória acumulada da sessão (insights + hipóteses validadas) */
  memory: string[]
  hypotheses: string[]
  /** Índice Global de Abstração 0-100 */
  iga: number
  /** Índice de Consistência Interpretativa 0-100 */
  ici: number
  /** variação de convergência ΔI */
  convergence: number
  /** número de ciclos */
  cycles: number
  /** domínios/clusters acionados */
  domains: string[]
  converged: boolean
}

export const INITIAL_STATE: CognitiveState = {
  phase: 'READY',
  ucis: [],
  relations: [],
  memory: [],
  hypotheses: [],
  iga: 0,
  ici: 0,
  convergence: 100,
  cycles: 0,
  domains: [],
  converged: false,
}

const PHASES = [
  'READY',
  'RECEIVING',
  'NORMALIZING',
  'CLASSIFYING',
  'CONSULTING',
  'ABSTRACTING',
  'VALIDATING',
  'LEARNING',
  'RESPONDING',
]

function phaseTurn(phase: string): string {
  const i = PHASES.indexOf(phase)
  if (i === -1) return 'RECEIVING'
  return PHASES[(i + 1) % PHASES.length]
}

function nextPhase(state: CognitiveState): string {
  // Após RECEIVING seguimos o fluxo canônico: NORMALIZING → CLASSIFYING → ...
  if (state.phase === 'READY') return 'RECEIVING'
  return phaseTurn(state.phase)
}

/** Identificar domínios/clusters a partir do texto (POKO roteamento leve). */
function detectDomains(text: string): string[] {
  const t = text.toLowerCase()
  const map: [RegExp, string][] = [
    [/\b(dor|febre|gripe|tosse|diarré|náusea|vômito|press[ãa]o|cardíac|coraç[ãa]o)\b/, 'Medicina Geral'],
    [/\b(coraç[ãa]o|cardíac|palpita)\b/, 'Cardiologia'],
    [/\b(diab|insulina|aç[úu]car|tireoide|hormôn)\b/, 'Endocrinologia'],
    [/\b(alerg|urtic|coceira|rash)\b/, 'Imunologia'],
    [/\b(ansiedade|depress[ãa]o|insônia|estresse|pânico)\b/, 'Psiquiatria'],
    [/\b(gastro|estômag|intestino| fígado|fecerr)\b/, 'Gastroenterologia'],
    [/\b(neurolog|enxaqueca|convuls|tontur)\b/, 'Neurologia'],
    [/\b(pulm|respirat|falt[ãa] de ar|asma|bronqui)\b/, 'Pneumologia'],
    [/\b(rim|urina|renal)\b/, 'Nefrologia'],
  ]
  const found: string[] = []
  for (const [re, domain] of map) {
    if (re.test(t) && !found.includes(domain)) found.push(domain)
  }
  if (found.length === 0) found.push('Medicina Geral')
  return found.slice(0, 3)
}

/** Fragmentar texto em UCIs agrupadas por sentença/palavra-chave. */
function buildUcis(text: string, source: string, context: string): UCI[] {
  const sentences = text
    .split(/[.;!?\n]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 2)
    .slice(0, 12)

  const medicalTerms =
    /dor|febre|to sse|coração|pressão|diab|alerg|ansiedade|insônia|tontura|náusea|vômito|asma|renal|fadiga|peso|apetite/i

  return sentences.map((sentence, i) => {
    let type: UciType = 'text'
    let weight = 45
    if (medicalTerms.test(sentence)) {
      type = 'concept'
      weight = 80
    } else if (/lembro|recordo|memóri/i.test(sentence)) {
      type = 'memory'
      weight = 70
    } else if (/sinto|sent|medo|preocupado|triste|irritad/i.test(sentence)) {
      type = 'emotion'
      weight = 65
    }
    return {
      id: `u${Date.now().toString(36)}_${i}`,
      type,
      source,
      weight,
      context,
      text: sentence,
    }
  })
}

/** Grafo cognitivo: relações semânticas entre UCIs com força baseada em peso/tema. */
function buildRelations(ucis: UCI[]): Relation[] {
  const rels: Relation[] = []
  for (let i = 0; i < ucis.length; i++) {
    for (let j = i + 1; j < ucis.length; j++) {
      const a = ucis[i]
      const b = ucis[j]
      const sameType = a.type === b.type ? 30 : 0
      const relevance = Math.round(
        55 + sameType + (a.weight + b.weight) / 2 * 0.3
      )
      const weight = Math.min(99, relevance)
      const kind: RelationKind =
        a.type === 'concept' || b.type === 'concept' ? 'causal' : 'semantic'
      rels.push({ from: a.id, to: b.id, kind, weight })
      // limite de arestas para controle de O(n²)
      if (rels.length > 40) return rels
    }
  }
  return rels
}

/** Inferência: gerar hipóteses a partir do grafo e das UCIs dominantes. */
function inferHypotheses(ucis: UCI[], domains: string[]): string[] {
  const top = [...ucis].sort((a, b) => b.weight - a.weight).slice(0, 3)
  const domainLine = domains.join(', ')
  const hyp: string[] = []
  if (top.length) {
    hyp.push(
      `Hipótese primária: queixa central em "${top[0].text.slice(0, 60)}" (peso ${top[0].weight}%), domínio: ${domainLine}.`
    )
  }
  if (top.length > 1) {
    hyp.push(
      `Hipótese associada: possível relação causal entre "${top[0].text.slice(0, 40)}" e "${top[1].text.slice(0, 40)}".`
    )
  }
  return hyp
}

/**
 * MPAC + IGA: Normalizações e cálculo do Índice Global de Abstração.
 * IGA = λ1p + λ2c + λ3m + λ4e + λ5l  (λ = 0.2 cada).
 */
function computeIga(ucis: UCI[]): number {
  if (ucis.length === 0) return 0
  let p = 0 // percepção
  let c = 0 // contexto
  let m = 0 // memória
  let e = 0 // emoção
  let l = 0 // lógica

  ucis.forEach((u) => {
    const w = u.weight / 100
    p += w
    c += u.context ? 0.8 : 0.4
    m += u.type === 'memory' ? w : 0.5
    e += u.type === 'emotion' ? w : 0.4
    // coerência lógica: mais alta p/ conceitos e eventos
    l += u.type === 'concept' || u.type === 'event' ? w : 0.55
  })
  const n = ucis.length
  p = p / n
  c = c / n
  m = m / n
  e = e / n
  l = l / n
  const iga =
    0.2 * p + 0.2 * c + 0.2 * m + 0.2 * e + 0.2 * l
  return Math.round(iga * 100)
}

/** ICI: média do grau de atendimento dos critérios de validação (0-100). */
function computeIci(relations: Relation[]): number {
  if (relations.length === 0) return 60
  const criteria = relations.map((r) => r.weight / 100)
  const v = criteria.reduce((s, x) => s + x, 0) / criteria.length
  return Math.round(v * 100)
}

/**
 * Executar um ciclo completo do kernel PASQUARED a partir de um novo texto.
 * Retorna os UCI gerados, o novo estado e se o processo convergiu.
 */
export function runCycle(
  inputText: string,
  prevState: CognitiveState,
  source = 'patient',
  context = 'anamnese'
): { state: CognitiveState; ucis: UCI[]; responseTrack: string[] } {
  const text = (inputText || '').trim()

  // Estágio 1: RECEIVING — receber informações
  const phase = nextPhase(prevState)

  // Estágio 2: NORMALIZING/CLASSIFYING — UCIs + domínios
  const ucis = text ? buildUcis(text, source, context) : []
  const allUcis = [...prevState.ucis, ...ucis].slice(-40)
  const domains = detectDomains(text || prevState.memory.join(' '))

  // Estágio 3: construir grafo (relações)
  const relations = text
    ? buildRelations(ucis)
    : prevState.relations

  // Estágio 4: inferência — hipóteses
  const hypotheses = text
    ? inferHypotheses(ucis, domains)
    : prevState.hypotheses

  // Estágio 5: validação + índices
  const iga = computeIga(allUcis)
  const ici = computeIci(relations)
  const newConvergence = Math.abs(iga - prevState.iga)

  // Atualizar memória (LEARNING)
  const memory = [...prevState.memory]
  for (const h of hypotheses) {
    if (!memory.includes(h)) memory.push(h)
  }
  memory.push(...domains.filter((d) => !memory.includes(d)))

  const converged = Boolean(text && newConvergence < 5 && prevState.cycles >= 2)

  const domainsAll = Array.from(
    new Set([...prevState.domains, ...domains])
  ).slice(0, 5)

  const state: CognitiveState = {
    phase: text ? 'RESPONDING' : phase,
    ucis: allUcis,
    relations: relations.slice(0, 40),
    memory,
    hypotheses,
    iga,
    ici,
    convergence: newConvergence,
    cycles: prevState.cycles + 1,
    domains: domainsAll,
    converged,
  }

  const responseTrack = [
    `🔬 PASQUARED ciclo #${state.cycles}: Recebida UCI (${ucis.length}) → grafo (${relations.length} relações) → ${
      hypotheses.length
    } hipótese(s) → IGA ${iga}/100 · ICI ${ici}/100 · ΔI ${newConvergence}`,
  ]

  return { state, ucis, responseTrack }
}

/** Encerrar a sessão interpretativa: estado final + report. */
export function settleState(prev: CognitiveState): {
  state: CognitiveState
  finalIga: number
  finalConvergence: number
} {
  const finalIga = prev.iga
  const finalConvergence = prev.convergence
  return {
    state: { ...prev, phase: 'READY' },
    finalIga,
    finalConvergence,
  }
}
