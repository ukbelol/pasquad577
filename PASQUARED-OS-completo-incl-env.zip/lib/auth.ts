import 'server-only'
import { SignJWT, jwtVerify } from 'jose'
import bcrypt from 'bcryptjs'
import { cookies } from 'next/headers'
import { eq } from 'drizzle-orm'
import { db } from '@/db'
import { users } from '@/db/schemas/schema'
import { AppError } from '@/lib/errors'

const SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || 'pasquared-os-dev-secret-change-me'
)
const SESSION_COOKIE = 'pasquared_session'
const SESSION_KEY = 'pasquared_session_key'
const SESSION_DAYS = 7

export type SessionUser = {
  id: string
  role: 'patient' | 'doctor' | 'superadmin'
  email: string
  firstName: string
  lastName: string
}

/** Criar o JWT de sessão e gravar nos cookies. */
export async function createSession(user: SessionUser) {
  const token = await new SignJWT({ ...user })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(SECRET)

  const csrf = crypto.randomUUID()
  const store = await cookies()
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * SESSION_DAYS,
    secure: process.env.NODE_ENV === 'production',
  })
  store.set(SESSION_KEY, csrf, {
    httpOnly: false,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * SESSION_DAYS,
    secure: process.env.NODE_ENV === 'production',
  })
}

export async function destroySession() {
  const store = await cookies()
  store.delete(SESSION_COOKIE)
  store.delete(SESSION_KEY)
}

/** Validar o token e retornar a sessão do usuário, ou null se inválido. */
export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (!token) return null
  try {
    const { payload } = await jwtVerify(token, SECRET)
    const user = payload as unknown as SessionUser
    if (!user?.id || !user?.role) return null
    return user
  } catch {
    return null
  }
}

/** Exige que a sessão exista; lança AppError 401 caso contrário. */
export async function requireUser() {
  const user = await getSessionUser()
  if (!user) {
    throw new AppError('Não autenticado. Faça login para continuar.', 401)
  }
  return user
}

/** Exige um papel específico (ou um conjunto deles). */
export async function requireRole(...roles: SessionUser['role'][]) {
  const user = await requireUser()
  if (!roles.includes(user.role)) {
    throw new AppError('Acesso negado: permissão insuficiente.', 403)
  }
  return user
}

/** Hash + compare de senhas usando bcrypt. */
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12)
}

export async function verifyPassword(
  plain: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(plain, hash)
}

/** Buscar usuário por e-mail (para login). */
export async function findUserByEmail(email: string) {
  const normalized = email.trim().toLowerCase()
  const rows = await db
    .select()
    .from(users)
    .where(eq(users.email, normalized))
    .limit(1)
  return rows[0] ?? null
}

export async function findUserByCpf(cpf: string) {
  const normalized = cpf.replace(/\D/g, '')
  const rows = await db
    .select()
    .from(users)
    .where(eq(users.cpf, normalized))
    .limit(1)
  return rows[0] ?? null
}

export function toSession(user: {
  id: string
  role: string
  email: string
  firstName: string
  lastName: string
}): SessionUser {
  return {
    id: user.id,
    role: user.role as SessionUser['role'],
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
  }
}
