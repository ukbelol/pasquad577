CREATE TABLE "knowledge_bases" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"code" varchar(60) NOT NULL,
	"name" varchar(160) NOT NULL,
	"country" varchar(120),
	"region" varchar(40) DEFAULT 'Americas' NOT NULL,
	"focus" text,
	"official_url" text,
	"connector_type" varchar(40) DEFAULT 'static' NOT NULL,
	"status" varchar(24) DEFAULT 'disabled' NOT NULL,
	"meta" jsonb,
	"last_sync_at" timestamp with time zone,
	"node_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "knowledge_nodes" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"base_id" text NOT NULL,
	"source" text,
	"title" text NOT NULL,
	"snippet" text NOT NULL,
	"topic" varchar(120),
	"weight" integer DEFAULT 50 NOT NULL,
	"node_type" varchar(32) DEFAULT 'fact' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "knowledge_nodes" ADD CONSTRAINT "knowledge_nodes_base_id_knowledge_bases_id_fk" FOREIGN KEY ("base_id") REFERENCES "public"."knowledge_bases"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "kb_code_idx" ON "knowledge_bases" USING btree ("code");--> statement-breakpoint
CREATE INDEX "kb_status_idx" ON "knowledge_bases" USING btree ("status");--> statement-breakpoint
CREATE INDEX "kn_base_idx" ON "knowledge_nodes" USING btree ("base_id");--> statement-breakpoint
CREATE INDEX "kn_topic_idx" ON "knowledge_nodes" USING btree ("topic");