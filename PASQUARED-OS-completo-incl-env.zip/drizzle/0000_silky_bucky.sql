CREATE TABLE "app_settings" (
	"key" varchar(120) PRIMARY KEY NOT NULL,
	"value" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "consultations" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"patient_id" text NOT NULL,
	"doctor_id" text,
	"status" varchar(24) DEFAULT 'open' NOT NULL,
	"chief_complaint" text,
	"cognitive_state" jsonb,
	"abstraction_index" integer,
	"convergence" integer,
	"summary" text,
	"final_report" text,
	"assistant_model" varchar(120),
	"started_at" timestamp with time zone DEFAULT now() NOT NULL,
	"completed_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "messages" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"consultation_id" text NOT NULL,
	"role" varchar(24) NOT NULL,
	"content_type" varchar(32) DEFAULT 'text' NOT NULL,
	"content" text NOT NULL,
	"uci_weight" integer,
	"uci_context" varchar(255),
	"uci_type" varchar(32) DEFAULT 'text',
	"file_name" varchar(255),
	"file_path" text,
	"file_mime" varchar(160),
	"file_size" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"role" varchar(16) DEFAULT 'patient' NOT NULL,
	"first_name" varchar(120) NOT NULL,
	"last_name" varchar(120) NOT NULL,
	"birth_date" varchar(20),
	"cpf" varchar(14),
	"phone" varchar(30),
	"email" varchar(160) NOT NULL,
	"password_hash" varchar(255) NOT NULL,
	"cep" varchar(10),
	"street" varchar(255),
	"number" varchar(40),
	"complement" varchar(255),
	"neighborhood" varchar(160),
	"city" varchar(160),
	"state" varchar(2),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "consultations" ADD CONSTRAINT "consultations_patient_id_users_id_fk" FOREIGN KEY ("patient_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "consultations" ADD CONSTRAINT "consultations_doctor_id_users_id_fk" FOREIGN KEY ("doctor_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_consultation_id_consultations_id_fk" FOREIGN KEY ("consultation_id") REFERENCES "public"."consultations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "app_settings_key_idx" ON "app_settings" USING btree ("key");--> statement-breakpoint
CREATE INDEX "consultations_patient_idx" ON "consultations" USING btree ("patient_id");--> statement-breakpoint
CREATE INDEX "consultations_doctor_idx" ON "consultations" USING btree ("doctor_id");--> statement-breakpoint
CREATE INDEX "messages_consultation_idx" ON "messages" USING btree ("consultation_id");--> statement-breakpoint
CREATE INDEX "messages_role_idx" ON "messages" USING btree ("role");--> statement-breakpoint
CREATE UNIQUE INDEX "users_email_idx" ON "users" USING btree ("email");--> statement-breakpoint
CREATE UNIQUE INDEX "users_cpf_idx" ON "users" USING btree ("cpf");--> statement-breakpoint
CREATE INDEX "users_role_idx" ON "users" USING btree ("role");