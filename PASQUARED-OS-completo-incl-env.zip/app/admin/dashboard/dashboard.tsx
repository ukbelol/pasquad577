'use client'

import { Component, useEffect, useState, type ReactNode } from 'react'
import { apiClient } from '@/lib/request'
import { toast } from 'sonner'
import { DashboardNav } from '@/components/dashboard-nav'

type SessionUser = {
  id: string
  role: 'patient' | 'doctor' | 'superadmin'
  email: string
  firstName: string
  lastName: string
}

type FoundryCfg = {
  enabled: boolean
  endpoint: string
  apiKey: string
  deploymentName: string
  apiVersion: string
}

type KnowledgeBase = {
  id: string
  code: string
  name: string
  country: string | null
  region: string
  focus: string | null
  officialUrl: string | null
  connectorType: string
  status: string
  lastSyncAt: string | null
  nodeCount: number
}

type Monitor = {
  status: string
  database: { connected: boolean; latencyMs: number }
  ai: { configured: boolean; provider: string; endpoint: string | null }
  entities: {
    users: number
    consultations: number
    messages: number
    connectedBases: number
    knowledgeNodes: number
    averageIGA: number | null
  }
  modules: { key: string; name: string; status: string }[]
}

/* ------------------------------------------- UI helpers (aurora-dark) */

const panel = 'weightless-panel p-6'
const inputCls =
  'mt-1 w-full rounded-xl bg-[rgba(255,255,255,0.04)] border border-[var(--border)] px-3.5 py-2.5 text-[15px] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]'
const btnOutline =
  'px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white disabled:opacity-40'
const btnPrimary =
  'luminous-cta px-5 py-2.5 text-sm font-medium inline-flex items-center gap-2 disabled:opacity-40'

function Badge({ status }: { status: string }) {
  const map: Record<string, string> = {
    connected: 'bg-[rgba(0,255,135,0.12)] text-[var(--primary)]',
    active: 'bg-[rgba(0,255,135,0.12)] text-[var(--primary)]',
    syncing: 'bg-[rgba(0,212,255,0.12)] text-[var(--accent)]',
    disabled: 'bg-[rgba(255,255,255,0.07)] text-[var(--muted-foreground)]',
    idle: 'bg-[rgba(255,255,255,0.07)] text-[var(--muted-foreground)]',
    error: 'bg-[rgba(255,0,90,0.15)] text-[#ff3b5c]',
  }
  const cls = map[status] || map.disabled
  return (
    <span className={`text-[11px] px-2 py-0.5 rounded-full font-normal ${cls}`}>
      {status === 'connected' || status === 'active'
        ? 'Ativo'
        : status === 'syncing'
          ? 'Conectando…'
          : status === 'error'
            ? 'Erro'
            : 'Inativo'}
    </span>
  )
}

function StatCard({
  label,
  value,
  hint,
}: {
  label: string
  value: ReactNode
  hint?: string
}) {
  return (
    <div className={panel}>
      <p className="text-[11px] uppercase tracking-wide text-[var(--muted-foreground)]">
        {label}
      </p>
      <p className="mt-2 text-3xl font-light text-white">{value}</p>
      {hint ? (
        <p className="mt-1 text-[11px] font-light text-[var(--muted-foreground)]">{hint}</p>
      ) : null}
    </div>
  )
}

function SectionTitle({ title, desc }: { title: string; desc?: string }) {
  return (
    <div className="mb-5">
      <h2 className="text-xl font-light">{title}</h2>
      {desc ? (
        <p className="mt-1 text-sm font-light text-[var(--muted-foreground)] max-w-2xl">{desc}</p>
      ) : null}
    </div>
  )
}

function TabButton({
  active,
  label,
  onClick,
}: {
  active: boolean
  label: string
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm rounded-xl transition ${
        active
          ? 'text-[#00150c] bg-[var(--primary)] font-medium'
          : 'text-[var(--muted-foreground)] hover:text-white border border-[var(--border)]'
      }`}
    >
      {label}
    </button>
  )
}

/* ------------------------------------------------ error boundary (anti-branco) */

class Boundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null }
  static getDerivedStateFromError(error: Error) {
    return { error }
  }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex items-center justify-center px-6">
          <div className="weightless-panel p-7 max-w-xl w-full">
            <h1 className="text-xl font-light text-[#ff3b5c]">Erro na interface do super admin</h1>
            <p className="mt-3 font-mono text-[12px] text-[var(--muted-foreground)] break-words">
              {this.state.error.message || String(this.state.error)}
            </p>
            <p className="mt-4 text-sm font-light text-[var(--muted-foreground)]">
              Ocorreu um erro ao renderizar. Atualize a página; se persistir, informe o desenvolvedor com a mensagem acima.
            </p>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

/* ---------------------------------------------------- aba: Visão Geral */

function OverviewView({ monitor }: { monitor: Monitor | null }) {
  if (!monitor) {
    return (
      <div className={panel + ' text-sm font-light text-[var(--muted-foreground)] animate-pulse'}>
        Carregando estado do sistema…
      </div>
    )
  }
  const e = monitor.entities
  return (
    <section className="space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard label="Usuários" value={e.users} />
        <StatCard label="Consultas" value={e.consultations} />
        <StatCard label="Mensagens" value={e.messages} />
        <StatCard label="Bases conectadas" value={e.connectedBases} />
        <StatCard label="Nós de conhecimento" value={e.knowledgeNodes} />
        <StatCard label="IGA médio" value={e.averageIGA != null ? `${e.averageIGA}%` : '—'} hint="Índice de abstração PASQUARED" />
      </div>

      <div className={panel}>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-light">Estado do banco de dados</h3>
            <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
              {monitor.database.connected ? 'PostgreSQL conectado' : 'Sem conexão'} · latência ~{monitor.database.latencyMs}ms
            </p>
          </div>
          <span className="text-[var(--primary)]">●</span>
        </div>
      </div>

      <div className={panel}>
        <h3 className="font-light mb-4">Módulos do algoritmo PASQUARED</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {monitor.modules.map((m) => (
            <div
              key={m.key}
              className="flex items-center justify-between rounded-xl border border-[var(--border)] px-4 py-3"
            >
              <span className="text-sm font-light">{m.name}</span>
              <Badge status={m.status} />
            </div>
          ))}
        </div>
      </div>

      <div className={`${panel} border border-[var(--primary)]/20`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-light">Backup — código-fonte completo</h3>
            <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
              Pacote completo do sistema (app, lib, componentes, schema do banco e scripts), já com o arquivo .env. Acesso restrito ao super admin.
            </p>
          </div>
          <a href="/api/admin/download" className={btnPrimary} download>
            Baixar código-fonte completo (.zip)
          </a>
        </div>
        <p className="mt-3 font-mono text-[11px] text-[var(--muted-foreground)]">
          PASQUARED-OS-completo-incl-env.zip
        </p>
      </div>
    </section>
  )
}

/* ---------------------------------------- aba: Bases de conhecimento */

function KnowledgeView({
  bases,
  loading,
  onAction,
  busyId,
}: {
  bases: KnowledgeBase[]
  loading: boolean
  onAction: (id: string, action: string) => void
  busyId: string | null
}) {
  if (loading) {
    return (
      <div className={panel + ' text-sm font-light text-[var(--muted-foreground)] animate-pulse'}>
        Carregando bases de conhecimento…
      </div>
    )
  }
  return (
    <section>
      <div className="flex flex-wrap items-center justify-between mb-5 gap-3">
        <SectionTitle
          title="Bases de conhecimento de saúde das Américas"
          desc="Conecte repositórios oficiais de saúde dos países das Américas. As informações ingeridas alimentam o PASQUARED como memória externa (grounding) durante a geração de perguntas da anamnese."
        />
      </div>

      <div className="space-y-3">
        {bases.map((b) => {
          const busy = busyId === b.id
          return (
            <div key={b.id} className={panel + ' flex flex-col md:flex-row md:items-center gap-4'}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3">
                  <h3 className="font-light">{b.name}</h3>
                  <Badge status={b.status} />
                </div>
                <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
                  {b.country ? `${b.country} · ` : ''}Base de conhecimento de saúde | {b.nodeCount} nós ingeridos
                </p>
                {b.focus ? (
                  <p className="mt-1 text-xs font-light text-[var(--muted-foreground)] line-clamp-2">{b.focus}</p>
                ) : null}
                {b.lastSyncAt ? (
                  <p className="mt-1 font-mono text-[10px] text-[var(--muted-foreground)]">
                    Última sincronização: {new Date(b.lastSyncAt).toLocaleString('pt-BR')}
                  </p>
                ) : null}
              </div>

              <div className="flex items-center gap-2 shrink-0 flex-wrap">
                {b.status !== 'connected' && (
                  <button disabled={busy} onClick={() => onAction(b.id, 'connect')} className={btnPrimary}>
                    {busy ? 'Conectando…' : 'Conectar'}
                  </button>
                )}
                {b.status === 'connected' && (
                  <>
                    <button disabled={busy} onClick={() => onAction(b.id, 'sync')} className={btnOutline}>
                      {busy ? 'Sincronizando…' : 'Sincronizar'}
                    </button>
                    <button disabled={busy} onClick={() => onAction(b.id, 'disconnect')} className={btnOutline}>
                      Desconectar
                    </button>
                  </>
                )}
                {b.officialUrl ? (
                  <a href={b.officialUrl} target="_blank" rel="noopener noreferrer" className={btnOutline}>
                    Site oficial ↗
                  </a>
                ) : null}
              </div>
            </div>
          )
        })}
        {bases.length === 0 && (
          <div className={panel + ' text-sm font-light text-[var(--muted-foreground)]'}>
            Nenhuma base disponível.
          </div>
        )}
      </div>
    </section>
  )
}

/* --------------------------------------------- aba: Microsoft Foundry */

function FoundryView({
  cfg,
  loading,
  onSave,
  onToggle,
  busy,
  rev,
}: {
  cfg: FoundryCfg
  loading: boolean
  onSave: (cfg: FoundryCfg) => void
  onToggle: (enabled: boolean) => void
  busy: boolean
  rev: number
}) {
  const [local, setLocal] = useState<FoundryCfg>(cfg)

  useEffect(() => {
    if (loading) return
    setLocal(cfg)
  }, [rev, loading]) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <section>
      <SectionTitle
        title="Microsoft Azure AI Foundry — integração ao PASQUARED"
        desc="Configure o modelo de IA que atua como 'criadora de perguntas' da anamnese. O controlador de fluxo continua sendo o algoritmo PASQUARED."
      />

      <form onSubmit={(e) => { e.preventDefault(); onSave(local); }} className={panel + ' space-y-4'}>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-sm font-light">
            <input
              type="checkbox"
              checked={local.enabled}
              onChange={(e) => setLocal((s) => ({ ...s, enabled: e.target.checked }))}
              className="accent-[var(--primary)] w-4 h-4"
            />
            Ativar API da Microsoft Foundry
          </label>
          <span className={`text-[11px] ${local.enabled ? 'text-[var(--primary)]' : 'text-[var(--muted-foreground)]'}`}>
            {local.enabled ? 'Ativa' : 'Inativa — usando gateway padrão'}
          </span>
        </div>

        <div>
          <label className="text-[13px] text-[var(--muted-foreground)]">Endpoint (Azure AI Foundry)</label>
          <input
            className={inputCls}
            value={local.endpoint}
            onChange={(e) => setLocal((s) => ({ ...s, endpoint: e.target.value }))}
            placeholder="https://seu-recurso.services.ai.azure.com"
          />
        </div>
        <div>
          <label className="text-[13px] text-[var(--muted-foreground)]">Chave de API (API Key)</label>
          <input
            className={inputCls}
            type="password"
            value={local.apiKey}
            onChange={(e) => setLocal((s) => ({ ...s, apiKey: e.target.value }))}
            placeholder="••••••••••••••••"
          />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-[13px] text-[var(--muted-foreground)]">Deployment (modelo)</label>
            <input
              className={inputCls}
              value={local.deploymentName}
              onChange={(e) => setLocal((s) => ({ ...s, deploymentName: e.target.value }))}
              placeholder="gpt-4o-mini"
            />
          </div>
          <div>
            <label className="text-[13px] text-[var(--muted-foreground)]">Versão da API</label>
            <input
              className={inputCls}
              value={local.apiVersion}
              onChange={(e) => setLocal((s) => ({ ...s, apiVersion: e.target.value }))}
              placeholder="2024-10-21"
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-3 pt-2">
          <button type="submit" disabled={busy} className={btnPrimary}>
            {busy ? 'Salvando…' : 'Salvar alterações da API'}
          </button>
          <button type="button" disabled={busy || !local.enabled} onClick={() => onToggle(false)} className={btnOutline}>
            Desativar API
          </button>
          <button type="button" disabled={busy || local.enabled} onClick={() => onToggle(true)} className={btnOutline}>
            Ativar API
          </button>
        </div>

        <p className="font-mono text-[11px] text-[var(--muted-foreground)]">
          Modelo ativo: {local.enabled ? local.deploymentName : 'gateway padrão (claude-sonnet-4.6)'}
          {local.enabled ? ' · Microsoft Foundry' : ''}
        </p>
      </form>
    </section>
  )
}

/* ------------------------------------------- aba: Backup / código-fonte */

function BackupView() {
  return (
    <section>
      <SectionTitle
        title="Backup do código-fonte completo"
        desc="Baixe um dump completo do sistema (app, lib, componentes, schema do banco e scripts), incluindo o arquivo .env com as credenciais. Trate o download com segurança."
      />
      <div className={panel}>
        <div className="flex flex-wrap items-center gap-4">
          <a href="/api/admin/download" className={btnPrimary}>
            Baixar backup do código-fonte (.zip)
          </a>
          <span className="font-mono text-[11px] text-[var(--muted-foreground)]">
            PASQUARED-OS-completo-incl-env.zip
          </span>
        </div>
        <p className="mt-5 text-[11px] font-light text-[var(--muted-foreground)]">
          Acesso restrito: apenas o super admin autenticado pode baixar este arquivo.
        </p>
      </div>
    </section>
  )
}

/* ----------------------------------------------------------- dashboard */

export default function AdminDashboard({ user }: { user: SessionUser }) {
  const [tab, setTab] = useState<'overview' | 'knowledge' | 'foundry' | 'backup'>('overview')

  const [monitor, setMonitor] = useState<Monitor | null>(null)
  const [cfg, setCfg] = useState<FoundryCfg>({
    enabled: false, endpoint: '', apiKey: '', deploymentName: 'gpt-4o-mini', apiVersion: '2024-10-21',
  })
  const [cfgLoading, setCfgLoading] = useState(true)
  const [cfgRev, setCfgRev] = useState(0)

  const [bases, setBases] = useState<KnowledgeBase[]>([])
  const [kbLoading, setKbLoading] = useState(true)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [busyCfg, setBusyCfg] = useState(false)

  useEffect(() => {
    apiClient.get<Monitor>('/api/admin/monitor').then((r) => r.success && setMonitor(r.data))
    apiClient.get<FoundryCfg>('/api/admin/foundry').then((r) => {
      if (r.success) setCfg(r.data)
    }).finally(() => setCfgLoading(false))
    apiClient.get<KnowledgeBase[]>('/api/admin/knowledge').then((r) => {
      if (r.success) setBases(r.data)
    }).finally(() => setKbLoading(false))
  }, [])

  const kbAction = async (id: string, action: string) => {
    setBusyId(id)
    const res = await apiClient.post<KnowledgeBase>(`/api/admin/knowledge/${id}`, { action })
    if (!res.success) return toast.error(res.error)
    setBases((prev) => prev.map((b) => (b.id === id ? res.data : b)))
    apiClient.get<Monitor>('/api/admin/monitor').then((r) => r.success && setMonitor(r.data))
    toast.success(action === 'connect' ? 'Base conectada e alimentando o PASQUARED!' : action === 'sync' ? 'Base sincronizada!' : 'Base desconectada.')
    setBusyId(null)
  }

  const salvarFoundry = async (c: FoundryCfg) => {
    if (!c.endpoint) return toast.error('Informe o endpoint do Azure AI Foundry.')
    if (!c.apiKey) return toast.error('Informe a chave da API.')
    setBusyCfg(true)
    const res = await apiClient.post('/api/admin/foundry', c)
    setBusyCfg(false)
    if (!res.success) return toast.error(res.error)
    setCfg(c)
    setCfgRev((v) => v + 1)
    toast.success('Configuração da Microsoft Foundry salva e integrada ao PASQUARED!')
  }

  const toggleFoundry = async (enabled: boolean) => {
    if (enabled) {
      if (!cfg.endpoint) {
        toast.error('Salve primeiro o endpoint e a chave para ativar a API.')
        return
      }
      const next = { ...cfg, enabled: true }
      setBusyCfg(true)
      const res = await apiClient.post('/api/admin/foundry', next)
      setBusyCfg(false)
      if (!res.success) return toast.error(res.error)
      setCfg(next)
      setCfgRev((v) => v + 1)
      toast.success('API da Microsoft Foundry ativada!')
    } else {
      const next = { ...cfg, enabled: false }
      setBusyCfg(true)
      const res = await apiClient.post('/api/admin/foundry', next)
      setBusyCfg(false)
      if (!res.success) return toast.error(res.error)
      setCfg(next)
      setCfgRev((v) => v + 1)
      toast.success('API da Microsoft Foundry desativada.')
    }
  }

  return (
    <main className="min-h-screen px-6 py-10 max-w-6xl mx-auto fade-in-up">
      <DashboardNav userName={`Super Admin · ${user.firstName} ${user.lastName}`} homeHref="/admin/dashboard" />
      <header className="mb-6">
        <h1 className="text-3xl font-light">Painel do Super Admin</h1>
        <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
          Dashboard de gestão do PASQUARED-OS
        </p>
      </header>

      <div className="flex flex-wrap gap-2 mb-8">
        <TabButton active={tab === 'overview'} label="Dashboard" onClick={() => setTab('overview')} />
        <TabButton active={tab === 'knowledge'} label="Bases de conhecimento" onClick={() => setTab('knowledge')} />
        <TabButton active={tab === 'foundry'} label="IA Microsoft Foundry" onClick={() => setTab('foundry')} />
        <TabButton active={tab === 'backup'} label="Backup" onClick={() => setTab('backup')} />
      </div>

      {tab === 'overview' && <OverviewView monitor={monitor} />}

      {tab === 'knowledge' && (
        <KnowledgeView bases={bases} loading={kbLoading} onAction={kbAction} busyId={busyId} />
      )}

      {tab === 'foundry' && (
        <FoundryView rev={cfgRev} cfg={cfg} loading={cfgLoading} onSave={salvarFoundry} onToggle={toggleFoundry} busy={busyCfg} />
      )}

      {tab === 'backup' && <BackupView />}
    </main>
  )
}

export function WithBoundary({ user }: { user: SessionUser }) {
  return (
    <Boundary>
      <AdminDashboard user={user} />
    </Boundary>
  )
}
