import { redirect } from 'next/navigation'
import { requireRole, toSession } from '@/lib/auth'
import { WithBoundary } from './dashboard'

/**
 * Server Component que protege o painel do super admin.
 * Autentica server-side (cookie httpOnly) e redireciona quem não tem
 * permissão, evitando tela em branco por falha de sessão no cliente.
 */
export default async function AdminDashboardPage() {
  let user
  try {
    user = await requireRole('superadmin')
  } catch {
    redirect('/auth/login?role=superadmin')
    return
  }
  return <WithBoundary user={toSession(user)} />
}
