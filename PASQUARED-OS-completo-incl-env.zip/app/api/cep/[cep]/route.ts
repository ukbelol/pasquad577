import { NextResponse } from 'next/server'
import { AppError } from '@/lib/errors'
import { handleApiError } from '@/lib/api-error-response'

type ViaCepResponse = {
  cep?: string
  logradouro?: string
  bairro?: string
  localidade?: string
  uf?: string
  erro?: boolean
}

/**
 * Busca de endereço via API pública do ViaCEP a partir do CEP.
 * O usuário informa apenas o CEP e o número do logradouro.
 */
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ cep: string }> }
) {
  try {
    const { cep } = await params
    const normalized = cep.replace(/\D/g, '')
    if (normalized.length !== 8) {
      throw new AppError('CEP inválido. Informe 8 dígitos.', 400)
    }

    const res = await fetch(`https://viacep.com.br/ws/${normalized}/json/`, {
      signal: AbortSignal.timeout(15000),
    })
    if (!res.ok) throw new AppError('Falha ao consultar o CEP.', 502)

    const data = (await res.json()) as ViaCepResponse
    if (data.erro || !data.cep) {
      throw new AppError('CEP não encontrado.', 404)
    }

    return NextResponse.json({
      success: true,
      data: {
        cep: data.cep,
        street: data.logradouro || '',
        neighborhood: data.bairro || '',
        city: data.localidade || '',
        state: data.uf || '',
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
