import { NextResponse } from 'next/server'
import { promises as fs } from 'fs'
import path from 'path'
import { requireRole } from '@/lib/auth'
import { uploadRoot } from '@/lib/services/consultations'

const MIME: Record<string, string> = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif',
  mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4', mp4: 'video/mp4',
  webm: 'video/webm', mov: 'video/quicktime', avi: 'video/x-msvideo',
  pdf: 'application/pdf', txt: 'text/plain', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  bin: 'application/octet-stream',
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ path: string[] }> }
) {
  try {
    // Autentica para não expor arquivos de anamnese publicamente
    await requireRole('patient', 'doctor', 'superadmin')

    const { path: segs } = await params
    const rel = segs.join(path.sep)
    const root = uploadRoot()
    const full = path.join(root, rel)
    // Proteção contra path traversal
    if (!full.startsWith(root)) {
      return new NextResponse('Forbidden', { status: 403 })
    }
    const buf = await fs.readFile(full)
    const ext = path.extname(full).replace('.', '').toLowerCase()
    const type = MIME[ext] || 'application/octet-stream'
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'Content-Type': type,
        'Cache-Control': 'private, max-age=3600',
      },
    })
  } catch {
    return new NextResponse('Not found', { status: 404 })
  }
}
