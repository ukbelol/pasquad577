import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { AppError } from '@/lib/errors'
import { requireRole } from '@/lib/auth'
import { findConsultationByCpf } from '@/lib/services/consultations'

export async function POST(req: Request) {
  try {
    await requireRole('doctor', 'superadmin')
    const body = await req.json()
    const cpf = (body.cpf || '').replace(/\D/g, '')
    if (cpf.length !== 11) throw new AppError('CPF inválido.', 400)

    const { patient, consultations } = await findConsultationByCpf(cpf)
    return NextResponse.json({
      success: true,
      data: {
        patient: {
          id: patient.id,
          firstName: patient.firstName,
          lastName: patient.lastName,
          birthDate: patient.birthDate,
          phone: patient.phone,
          email: patient.email,
          cep: patient.cep,
          city: patient.city,
          state: patient.state,
        },
        consultations,
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
