import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { requireRole } from '@/lib/auth'
import { listConsultationsByPatient } from '@/lib/services/consultations'

export async function GET() {
  try {
    const user = await requireRole('patient')
    const consults = await listConsultationsByPatient(user.id)
    return NextResponse.json({ success: true, data: consults })
  } catch (error) {
    return handleApiError(error)
  }
}
