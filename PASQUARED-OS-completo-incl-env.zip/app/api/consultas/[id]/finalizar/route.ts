import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { AppError } from '@/lib/errors'
import { requireRole } from '@/lib/auth'
import {
  getConsultation,
  updateCognitiveState,
  listMessages,
} from '@/lib/services/consultations'
import { settleState } from '@/lib/cognitive/pasquared'
import type { CognitiveState } from '@/lib/cognitive/pasquared'
import { db } from '@/db'
import { consultations } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireRole('patient')
    const { id } = await params
    const consult = await getConsultation(id)
    if (consult.patientId !== user.id) throw new AppError('Acesso negado.', 403)

    const messages = await listMessages(id)
    const state = (consult.cognitiveState as CognitiveState) || null

    const settled = settleState(
      state || {
        phase: 'READY',
        ucis: [],
        relations: [],
        memory: [],
        hypotheses: [],
        iga: 0,
        ici: 0,
        convergence: 100,
        cycles: 0,
        domains: [],
        converged: false,
      }
    )

    const queue = messages.filter((m) => m.role === 'user').map((m) => m.content)
    const memory = [...settled.state.memory]
    if (queue.length && !queue.every((q) => memory.includes(q))) {
      for (const q of queue) if (!memory.includes(q)) memory.push(q)
    }

    await db
      .update(consultations)
      .set({
        status: 'completed',
        finalReport: `Anamnese concluída. IGA final: ${settled.finalIga}% · ICI: ${settled.state.ici}% · Ciclos: ${settled.state.cycles}.\n\nResumo:\n${memory.join('\n')}`,
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(consultations.id, id))

    await updateCognitiveState(id, { ...settled.state, converged: true }, true)

    return NextResponse.json({ success: true, data: 'anamnese concluída' })
  } catch (error) {
    return handleApiError(error)
  }
}
