import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { AppError } from '@/lib/errors'
import { requireUser } from '@/lib/auth'
import { db } from '@/db'
import { users, consultations } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'
import { assignDoctor } from '@/lib/services/consultations'

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireUser()
    const { id } = await params

    const cons = await db
      .select()
      .from(consultations)
      .where(eq(consultations.id, id))
      .limit(1)
      .then((r) => r[0])
    if (!cons) throw new AppError('Consulta não encontrada.', 404)

    // Paciente pode ver apenas as próprias consultas.
    if (user.role === 'patient' && cons.patientId !== user.id) {
      throw new AppError('Acesso negado a esta consulta.', 403)
    }
    if (user.role === 'superadmin') {
      // ok
    } else if (user.role === 'doctor') {
      if (cons.doctorId && cons.doctorId !== user.id) {
        throw new AppError('Acesso negado a esta consulta.', 403)
      }
      if (!cons.doctorId) {
        await assignDoctor(cons.id, user.id)
        cons.doctorId = user.id
      }
    }

    const patient = await db
      .select()
      .from(users)
      .where(eq(users.id, cons.patientId))
      .limit(1)
      .then((r) => r[0])

    const { listMessages } = await import('@/lib/services/consultations')
    const messages = await listMessages(id)

    return NextResponse.json({
      success: true,
      data: { consultation: cons, patient, messages },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
