import { NextResponse } from 'next/server'
import { promises as fs } from 'fs'
import path from 'path'
import { handleApiError } from '@/lib/api-error-response'
import { AppError } from '@/lib/errors'
import { requireRole } from '@/lib/auth'
import {
  getConsultation,
  addMessage,
  listMessages,
  updateCognitiveState,
  uploadRoot,
  ensureUploadDir,
} from '@/lib/services/consultations'
import { runCycle } from '@/lib/cognitive/pasquared'
import { nextQuestion } from '@/lib/services/ai'
import { getFoundryConfig } from '@/lib/services/settings'
import { db } from '@/db'
import { users } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'
import type { CognitiveState } from '@/lib/cognitive/pasquared'

const MAX_FILE = 30 * 1024 * 1024 // 30MB

function saveExt(mime: string, name: string): string {
  const fromName = path.extname(name).replace('.', '')
  if (fromName && fromName.length <= 6) return fromName
  const map: Record<string, string> = {
    'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif',
    'audio/mpeg': 'mp3', 'audio/mp3': 'mp3', 'audio/wav': 'wav', 'audio/ogg': 'ogg',
    'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov',
    'application/pdf': 'pdf', 'text/plain': 'txt',
  }
  return map[mime] || 'bin'
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireRole('patient')
    const { id } = await params
    const consult = await getConsultation(id)
    if (consult.patientId !== user.id) {
      throw new AppError('Acesso negado a esta consulta.', 403)
    }
    if (consult.status === 'completed') {
      throw new AppError('Esta anamnese já foi concluída.', 400)
    }

    const contentType = req.headers.get('content-type') || ''

    let text = ''
    let file: { fileName: string; filePath: string; fileMime: string; fileSize: number; uciType: string } | null = null

    if (contentType.includes('multipart/form-data')) {
      const form = await req.formData()
      text = (form.get('text') as string) || ''
      const f = form.get('file')
      if (f && typeof (f as File).name === 'string') {
        const fileObj = f as File
        const size = fileObj.size
        if (size > MAX_FILE) throw new AppError('Arquivo muito grande (máx 30MB).', 400)
        const mime = fileObj.type
        const cleanName = fileObj.name.replace(/[^\w.\- ]+/g, '_').replace(/\s+/g, '_')
        await ensureUploadDir()
        const dir = path.join(uploadRoot(), id)
        await fs.mkdir(dir, { recursive: true })
        const ext = saveExt(mime, cleanName)
        const fileName = `${Date.now()}_${cleanName.slice(0, 60)}${ext ? '.' + ext : ''}`
        const relPath = path.join(dir, fileName)
        const buf = Buffer.from(await fileObj.arrayBuffer())
        await fs.writeFile(relPath, buf)
        const fileBase = `/uploads/${id}/${fileName}`
        let uciType = 'file'
        if (mime.startsWith('image/')) uciType = 'image'
        else if (mime.startsWith('audio/')) uciType = 'sound'
        else if (mime.startsWith('video/')) uciType = 'event'
        file = { fileName: cleanName, filePath: fileBase, fileMime: mime, fileSize: size, uciType }
      }
    } else {
      const body = await req.json()
      text = (body.text || '') as string
    }

    if (!text.trim() && !file) {
      throw new AppError('Envie uma mensagem ou um arquivo.', 400)
    }

    // 0) Registrar a resposta do paciente (UCI de entrada)
    const patientMsg = await addMessage({
      consultationId: id,
      role: 'user',
      contentType: file ? file.uciType : 'text',
      content: text.trim() || `[Arquivo enviado: ${file!.fileName}]`,
      uciWeight: 80,
      uciContext: 'paciente',
      uciType: file ? file.uciType : 'text',
      fileName: file?.fileName,
      filePath: file?.filePath,
      fileMime: file?.fileMime,
      fileSize: file?.fileSize,
    })

    // 1) Rodar o ciclo PASQUARED com a entrada
    const prev = (consult.cognitiveState as CognitiveState) || {
      phase: 'READY', ucis: [], relations: [], memory: [],
      hypotheses: [], iga: 0, ici: 0, convergence: 100, cycles: 0,
      domains: [], converged: false,
    }
    const { state, responseTrack } = runCycle(
      text.trim() || `Arquivo ${file?.fileName}`,
      prev,
      'paciente',
      'anamnese'
    )

    // 2) Recuperar as mensagens até aqui para dar contexto à IA
    const messages = await listMessages(id)
    const transcript = messages.map((m) => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.content,
    }))

    const patient = await db
      .select({ firstName: users.firstName, lastName: users.lastName, birthDate: users.birthDate, phone: users.phone, role: users.role })
      .from(users)
      .where(eq(users.id, consult.patientId))
      .limit(1).then((r) => r[0])

    const foundry = await getFoundryConfig()
    const patientContext = `Paciente: ${patient.firstName} ${patient.lastName}${patient.birthDate ? ' · Nascimento ' + patient.birthDate : ''}${patient.phone ? ' · Tel ' + patient.phone : ''}\nModelo de IA: ${foundry.enabled && foundry.deploymentName ? foundry.deploymentName : 'gateway'}`
    const hypothesisLine = state.hypotheses.join('\n') || 'Nenhuma hipótese ainda.'

    // 3) IA gera a próxima pergunta (com grounding das bases de conhecimento
    //    das Américas conectadas no super admin)
    const ai = await nextQuestion({
      patientContext,
      transcript,
      hypothesisLine,
      cycle: state.cycles,
      topics: state.domains?.length ? state.domains : undefined,
    })

    // 4) Registrar a pergunta da IA
    const assistantMsg = await addMessage({
      consultationId: id,
      role: 'assistant',
      contentType: 'text',
      content: ai.question,
      uciWeight: ai.source === 'pasquared' ? 60 : 75,
      uciContext: ai.source,
      uciType: 'text',
    })

    // 5) Persistir estado cognitivo
    const converged = state.converged || state.cycles >= 6
    const finalState = converged ? { ...state, phase: 'READY', converged: true } : state
    await updateCognitiveState(id, finalState, converged)

    return NextResponse.json({
      success: true,
      data: {
        patientMessage: patientMsg,
        assistantMessage: assistantMsg,
        cognitive: responseTrack,
        converged,
        iga: finalState.iga,
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
