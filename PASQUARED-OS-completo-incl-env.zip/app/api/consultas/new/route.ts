import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { requireRole } from '@/lib/auth'
import {
  createConsultation,
  updateCognitiveState,
} from '@/lib/services/consultations'
import { INITIAL_STATE } from '@/lib/cognitive/pasquared'

export async function POST() {
  try {
    const user = await requireRole('patient')
    const cons = await createConsultation(user.id)
    await updateCognitiveState(cons.id, INITIAL_STATE)
    return NextResponse.json({ success: true, data: { id: cons.id } }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
