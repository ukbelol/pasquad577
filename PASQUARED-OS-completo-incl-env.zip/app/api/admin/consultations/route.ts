import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { requireRole } from '@/lib/auth'
import { db } from '@/db'
import { consultations, users } from '@/db/schemas/schema'
import { desc, count, inArray } from 'drizzle-orm'

export async function GET() {
  try {
    await requireRole('superadmin')
    const all = await db
      .select()
      .from(consultations)
      .orderBy(desc(consultations.startedAt))
      .limit(200)

    const patientIds = all.map((c) => c.patientId)
    const doctorIds = all
      .map((c) => c.doctorId)
      .filter((v): v is string => Boolean(v))

    const ids = [...new Set([...patientIds, ...doctorIds])]
    const people = ids.length
      ? await db.select().from(users).where(inArray(users.id, ids))
      : []

    const withNames = all.map((c) => {
      const patient = people.find((p) => p.id === c.patientId)
      const doctor = c.doctorId ? people.find((p) => p.id === c.doctorId) : null
      return {
        id: c.id,
        patientName: patient ? `${patient.firstName} ${patient.lastName}` : '?',
        patientCpf: patient?.cpf ?? null,
        doctorName: doctor ? `${doctor.firstName} ${doctor.lastName}` : 'Não atribuído',
        status: c.status,
        complaint: c.chiefComplaint,
        iga: c.abstractionIndex,
        startedAt: c.startedAt,
        completedAt: c.completedAt,
      }
    })

    const total = await db.select({ value: count() }).from(consultations)
    return NextResponse.json({
      success: true,
      data: {
        consultations: withNames,
        total: total[0]?.value ?? 0,
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
