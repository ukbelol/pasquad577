import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { requireRole } from '@/lib/auth'
import { db } from '@/db'
import { users } from '@/db/schemas/schema'
import { desc } from 'drizzle-orm'

export async function GET(_req: Request) {
  try {
    await requireRole('superadmin')
    const rows = await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(200)
    const safe = rows.map((u) => ({
      id: u.id,
      role: u.role,
      firstName: u.firstName,
      lastName: u.lastName,
      email: u.email,
      cpf: u.cpf,
      phone: u.phone,
      city: u.city,
      state: u.state,
      createdAt: u.createdAt,
    }))
    return NextResponse.json({ success: true, data: safe })
  } catch (error) {
    return handleApiError(error)
  }
}
