import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { requireRole } from '@/lib/auth'
import { listKnowledgeBases } from '@/lib/services/knowledge'

// GET /api/admin/knowledge — lista todas as bases de conhecimento das Américas
// com estado de conexão, contagem de nós ingeridos e último sync.
export async function GET() {
  try {
    await requireRole('superadmin')
    const bases = await listKnowledgeBases()
    return NextResponse.json({ success: true, data: bases })
  } catch (error) {
    return handleApiError(error)
  }
}
