import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { AppError } from '@/lib/errors'
import { requireRole } from '@/lib/auth'
import {
  connectKnowledgeBase,
  disconnectKnowledgeBase,
  syncKnowledgeBase,
} from '@/lib/services/knowledge'

type Props = { params: Promise<{ id: string }> }

// POST /api/admin/knowledge/[id]  body: { action: 'connect' | 'disconnect' | 'sync' }
export async function POST(req: Request, { params }: Props) {
  try {
    await requireRole('superadmin')
    const { id } = await params
    const body = await req.json()
    const action = (body.action || '').toString()
    if (!['connect', 'disconnect', 'sync'].includes(action)) {
      throw new AppError('Ação inválida.', 400)
    }
    let data
    if (action === 'connect') data = await connectKnowledgeBase(id)
    else if (action === 'disconnect') data = await disconnectKnowledgeBase(id)
    else data = await syncKnowledgeBase(id)
    return NextResponse.json({ success: true, data })
  } catch (error) {
    return handleApiError(error)
  }
}
