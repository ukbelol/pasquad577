import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { AppError } from '@/lib/errors'
import { requireRole } from '@/lib/auth'
import { db } from '@/db'
import { appSettings } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'
import { saveFoundryConfig, getFoundryConfig } from '@/lib/services/settings'

export async function GET() {
  try {
    await requireRole('superadmin')
    const cfg = await getFoundryConfig()
    const safe = { ...cfg, apiKey: cfg.apiKey ? '••••••••' : '' }
    return NextResponse.json({ success: true, data: safe })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(req: Request) {
  try {
    await requireRole('superadmin')
    const body = await req.json()
    const endpoint = (body.endpoint || '').trim()
    const apiKey = (body.apiKey || '').trim()
    const deploymentName = (body.deploymentName || 'gpt-4o-mini').trim()
    const apiVersion = (body.apiVersion || '2024-10-21').trim()
    const enabled = !!body.enabled

    if (!/^https?:\/\//.test(endpoint)) {
      throw new AppError('Endpoint inválido. Use uma URL https://', 400)
    }
    if (!apiKey) throw new AppError('Informe a chave de API.', 400)

    const existing = await getFoundryConfig()
    await saveFoundryConfig({
      enabled,
      endpoint,
      apiKey,
      deploymentName,
      apiVersion,
      extraHeaders: existing.extraHeaders || {},
    })
    return NextResponse.json({ success: true, data: 'Configuração salva' })
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE para desativar (limpa credenciais)
export async function DELETE() {
  try {
    await requireRole('superadmin')
    await db
      .update(appSettings)
      .set({ value: { enabled: false, endpoint: '', apiKey: '' } })
      .where(eq(appSettings.key, 'microsoft_foundry'))
    return NextResponse.json({ success: true, data: 'Configuração removida' })
  } catch (error) {
    return handleApiError(error)
  }
}
