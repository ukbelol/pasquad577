import { NextResponse } from 'next/server'
import { promises as fs } from 'fs'
import path from 'path'
import { handleApiError } from '@/lib/api-error-response'
import { AppError } from '@/lib/errors'
import { requireRole } from '@/lib/auth'

const ZIP_FILE = 'PASQUARED-OS-completo-incl-env.zip'

// Locais candidatos para o arquivo do código-fonte (em ordem de prioridade):
//  - releases/ na raiz do projeto (modo dev / local)
//  - caminho absoluto aguardado em produção (/opt/pasquared/releases)
const CANDIDATES = [
  path.join(process.cwd(), 'releases', ZIP_FILE),
  '/opt/pasquared/releases/' + ZIP_FILE,
]

async function resolveZip(): Promise<string> {
  for (const p of CANDIDATES) {
    try {
      const st = await fs.stat(p)
      if (st.isFile() && st.size > 0) return p
    } catch {
      // segue para o próximo candidato
    }
  }
  throw new AppError(
    'Arquivo de código-fonte não encontrado no servidor. Coloque-o em releases/ na raiz do projeto.',
    404
  )
}

// GET /api/admin/download — baixa o código-fonte (zip) da área do super admin.
// Somente usuários com papel 'superadmin' autenticados podem baixar.
export async function GET() {
  try {
    await requireRole('superadmin')
    const filePath = await resolveZip()
    const buf = await fs.readFile(filePath)
    const st = await fs.stat(filePath)

    return new NextResponse(new Uint8Array(buf), {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Length': String(st.size),
        'Content-Disposition': `attachment; filename="${ZIP_FILE}"`,
        'Cache-Control': 'private, no-store',
        'X-Content-Type-Options': 'nosniff',
        // Evita buffering ao atravessar o Apache/proxy:
        'X-Accel-Buffering': 'no',
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
