import { NextResponse } from 'next/server'
import { AppError } from '@/lib/errors'
import { handleApiError } from '@/lib/api-error-response'
import { findUserByEmail, verifyPassword, createSession, toSession } from '@/lib/auth'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const email = (body.email || '').trim().toLowerCase()
    const password = (body.password || '') as string

    const user = await findUserByEmail(email)
    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      throw new AppError('E-mail ou senha incorretos.', 401)
    }

    await createSession(toSession(user))
    return NextResponse.json({
      success: true,
      data: {
        id: user.id,
        email: user.email,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
