import { NextResponse } from 'next/server'
import { AppError } from '@/lib/errors'
import { handleApiError } from '@/lib/api-error-response'
import { db } from '@/db'
import { users } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'
import { hashPassword } from '@/lib/auth'

// Validações básicas de CPF (dígitos verificadores).
export function isValidCpf(cpf: string): boolean {
  const c = cpf.replace(/\D/g, '')
  if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false
  const calc = (len: number) => {
    let sum = 0
    for (let i = 0; i < len; i++) sum += parseInt(c[i]) * (len + 1 - i)
    const d = 11 - (sum % 11)
    return d >= 10 ? 0 : d
  }
  return calc(9) === parseInt(c[9]) && calc(10) === parseInt(c[10])
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const role = body.role === 'doctor' ? 'doctor' : body.role === 'superadmin' ? 'superadmin' : 'patient'
    const email = (body.email || '').trim().toLowerCase()
    const password = (body.password || '') as string

    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      throw new AppError('E-mail inválido.', 400)
    }
    if (password.length < 8) {
      throw new AppError('A senha deve ter no mínimo 8 caracteres.', 400)
    }
    if (!body.firstName || !body.lastName) {
      throw new AppError('Informe nome e sobrenome.', 400)
    }

    if (role === 'doctor') {
      const cpf = (body.cpf || '').replace(/\D/g, '')
      if (!isValidCpf(cpf)) {
        throw new AppError('CPF inválido.', 400)
      }
    }

    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1)
    if (existing[0]) {
      throw new AppError('Já existe uma conta com este e-mail.', 409)
    }

    const cpf = body.cpf ? (body.cpf as string).replace(/\D/g, '') : null
    if (cpf) {
      const dup = await db.select().from(users).where(eq(users.cpf, cpf)).limit(1)
      if (dup[0]) throw new AppError('CPF já cadastrado.', 409)
    }

    const passwordHash = await hashPassword(password)
    const rows = await db
      .insert(users)
      .values({
        role,
        firstName: body.firstName,
        lastName: body.lastName,
        birthDate: body.birthDate || null,
        cpf,
        phone: body.phone || null,
        email,
        passwordHash,
        cep: body.cep || null,
        street: body.street || null,
        number: body.number || null,
        complement: body.complement || null,
        neighborhood: body.neighborhood || null,
        city: body.city || null,
        state: body.state || null,
      })
      .returning()

    return NextResponse.json(
      { success: true, data: { id: rows[0].id, email: rows[0].email, role: rows[0].role } },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
