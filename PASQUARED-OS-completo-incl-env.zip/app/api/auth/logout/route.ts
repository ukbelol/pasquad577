import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { destroySession } from '@/lib/auth'

export async function POST() {
  try {
    await destroySession()
    return NextResponse.json({ success: true, data: 'logged out' })
  } catch (error) {
    return handleApiError(error)
  }
}
