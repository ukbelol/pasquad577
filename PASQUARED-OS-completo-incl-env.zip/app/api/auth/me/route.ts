import { NextResponse } from 'next/server'
import { handleApiError } from '@/lib/api-error-response'
import { getSessionUser } from '@/lib/auth'

export async function GET() {
  try {
    const user = await getSessionUser()
    return NextResponse.json({ success: true, data: { user } })
  } catch (error) {
    return handleApiError(error)
  }
}
