'use client'

import { useSearchParams, useRouter } from 'next/navigation'
import { Suspense, useEffect, useState } from 'react'
import { apiClient } from '@/lib/request'
import { toast } from 'sonner'

function LoginForm() {
  const params = useSearchParams()
  const router = useRouter()
  const role = (params.get('role') || 'patient') as 'patient' | 'doctor' | 'superadmin'
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPwd, setShowPwd] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (role === 'patient') setEmail('')
  }, [role])

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password) return toast.error('Preencha e-mail e senha.')
    setBusy(true)
    const res = await apiClient.post<{
      role: string
      firstName: string
      lastName: string
    }>('/api/auth/login', { email, password })
    setBusy(false)
    if (!res.success) return toast.error(res.error)
    toast.success(`Bem-vindo(a), ${res.data.firstName}!`)
    const r = res.data.role
    const destino =
      r === 'superadmin'
        ? '/admin/dashboard'
        : r === 'doctor'
          ? '/medico/dashboard'
          : '/paciente/dashboard'
    // Navegação completa (window.location) para forçar o servidor a ler o cookie
    // de sessão recém-criado e evitar que o redirect do guard volte ao login.
    window.location.assign(destino)
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-md fade-in-up">
        <div className="text-center mb-8">
          <img src="/logo.png" alt="PASQUARED-OS" className="w-14 h-14 mx-auto rounded-xl mb-4" />
          <h1 className="text-3xl font-light">Entrar</h1>
          <p className="mt-2 text-sm font-light text-[var(--muted-foreground)]">
            {role === 'doctor'
              ? 'Acesso restrito do médico'
              : role === 'superadmin'
                ? 'Acesso do Super Admin'
                : 'Área do paciente — acesse sua anamnese'}
          </p>
        </div>

        <form onSubmit={submit} className="weightless-panel p-7 space-y-4">
          <div>
            <label className="text-[13px] text-[var(--muted-foreground)]">E-mail</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={role === 'superadmin' ? 'roger577@pasquared.space' : 'seu@email.com'}
              className="mt-2 w-full rounded-xl bg-[rgba(255,255,255,0.04)] border border-[var(--border)] px-4 py-3 text-[15px] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]"
            />
          </div>
          <div>
            <label className="text-[13px] text-[var(--muted-foreground)]">Senha</label>
            <div className="relative mt-2">
              <input
                type={showPwd ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl bg-[rgba(255,255,255,0.04)] border border-[var(--border)] px-4 py-3 pr-16 text-[15px] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]"
              />
              <button
                type="button"
                onClick={() => setShowPwd((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--muted-foreground)] hover:text-white"
              >
                {showPwd ? 'Ocultar' : 'Ver'}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={busy}
            className="luminous-cta w-full py-3 text-sm font-medium disabled:opacity-50"
          >
            {busy ? 'Entrando…' : 'Entrar'}
          </button>

          {role !== 'superadmin' && (
            <p className="pt-2 text-center text-sm font-light text-[var(--muted-foreground)]">
              Ainda não tem conta?{' '}
              <button
                type="button"
                onClick={() => router.push(`/auth/cadastro?role=${role}`)}
                className="text-[var(--primary)] font-normal"
              >
                Criar cadastro
              </button>
            </p>
          )}
        </form>

        <button
          onClick={() => router.push('/')}
          className="mt-6 w-full text-center text-sm font-light text-[var(--muted-foreground)] hover:text-white"
        >
          ← Voltar ao início
        </button>
      </div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <main>
      <Suspense fallback={null}>
        <LoginForm />
      </Suspense>
    </main>
  )
}
