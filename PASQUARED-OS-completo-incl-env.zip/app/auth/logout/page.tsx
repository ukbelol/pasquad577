'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { apiClient } from '@/lib/request'

export default function LogoutPage() {
  const router = useRouter()
  useEffect(() => {
    apiClient.post('/api/auth/logout', {}).finally(() => router.push('/'))
  }, [router])
  return (
    <main className="min-h-screen flex items-center justify-center">
      <p className="text-sm font-light text-[var(--muted-foreground)]">Saindo…</p>
    </main>
  )
}
