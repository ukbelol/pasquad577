'use client'

import { useSearchParams, useRouter } from 'next/navigation'
import { Suspense, useState } from 'react'
import { apiClient } from '@/lib/request'
import { toast } from 'sonner'

function CadastroForm() {
  const params = useSearchParams()
  const router = useRouter()
  const role = (params.get('role') || 'patient') as 'patient' | 'doctor'

  const [f, setF] = useState({
    firstName: '',
    lastName: '',
    birthDate: '',
    cpf: '',
    phone: '',
    email: '',
    password: '',
    cep: '',
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
  })
  const [buscandoCep, setBuscandoCep] = useState(false)
  const [busy, setBusy] = useState(false)

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setF((s) => ({ ...s, [k]: e.target.value }))

  const mascaraCep = (v: string) => {
    const d = v.replace(/\D/g, '').slice(0, 8)
    return d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d
  }
  const mascaraCpf = (v: string) => {
    const d = v.replace(/\D/g, '').slice(0, 11)
    return d
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
  }
  const mascaraTel = (v: string) => {
    const d = v.replace(/\D/g, '').slice(0, 11)
    return d.length > 6
      ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`
      : d.length > 2
        ? `(${d.slice(0, 2)}) ${d.slice(2)}`
        : d.replace(/(\d{1,2})/, '($1')
  }

  const buscarCep = async (cep: string) => {
    const clean = cep.replace(/\D/g, '')
    if (clean.length !== 8) return
    setBuscandoCep(true)
    const res = await apiClient.get<{
      cep: string
      street: string
      neighborhood: string
      city: string
      state: string
    }>(`/api/cep/${clean}`)
    setBuscandoCep(false)
    if (!res.success) return toast.error(res.error)
    setF((s) => ({
      ...s,
      cep: res.data.cep,
      street: res.data.street,
      neighborhood: res.data.neighborhood,
      city: res.data.city,
      state: res.data.state,
    }))
    toast.success('Endereço encontrado! Informe o número.')
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!f.firstName || !f.lastName || !f.email || !f.password) {
      return toast.error('Preencha nome, sobrenome, e-mail e senha.')
    }
    if (role === 'doctor' && f.cpf.replace(/\D/g, '').length !== 11) {
      return toast.error('Informe um CPF válido.')
    }
    if (f.cep.replace(/\D/g, '').length === 8 && !f.number) {
      return toast.error('Informe o número do logradouro.')
    }
    setBusy(true)
    const payload = { ...f, role }
    const res = await apiClient.post<{ id: string }>('/api/auth/cadastro', payload)
    setBusy(false)
    if (!res.success) return toast.error(res.error)
    toast.success('Cadastro criado! Agora faça login.')
    router.push(`/auth/login?role=${role}`)
  }

  const inputCls =
    'mt-1 w-full rounded-xl bg-[rgba(255,255,255,0.04)] border border-[var(--border)] px-3.5 py-2.5 text-[15px] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]'

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-lg fade-in-up">
        <div className="text-center mb-8">
          <img src="/logo.png" alt="PASQUARED-OS" className="w-14 h-14 mx-auto rounded-xl mb-4" />
          <h1 className="text-3xl font-light">Criar cadastro</h1>
          <p className="mt-2 text-sm font-light text-[var(--muted-foreground)]">
            {role === 'doctor' ? 'Cadastro do médico (DR)' : 'Cadastro do paciente (PA)'}
          </p>
        </div>

        <form onSubmit={submit} className="weightless-panel p-7 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[13px] text-[var(--muted-foreground)]">Nome *</label>
              <input className={inputCls} value={f.firstName} onChange={set('firstName')} placeholder="Nome" />
            </div>
            <div>
              <label className="text-[13px] text-[var(--muted-foreground)]">Sobrenome *</label>
              <input className={inputCls} value={f.lastName} onChange={set('lastName')} placeholder="Sobrenome" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[13px] text-[var(--muted-foreground)]">Data de nascimento</label>
              <input type="date" className={inputCls} value={f.birthDate} onChange={set('birthDate')} />
            </div>
            <div>
              <label className="text-[13px] text-[var(--muted-foreground)]">Telefone</label>
              <input className={inputCls} value={f.phone} onChange={(e) => setF((s) => ({ ...s, phone: mascaraTel(e.target.value) }))} placeholder="(00) 00000-0000" inputMode="tel" />
            </div>
          </div>

          {role === 'doctor' && (
            <div>
              <label className="text-[13px] text-[var(--muted-foreground)]">CPF do médico *</label>
              <input className={inputCls} value={f.cpf} onChange={(e) => setF((s) => ({ ...s, cpf: mascaraCpf(e.target.value) }))} placeholder="000.000.000-00" inputMode="numeric" />
            </div>
          )}

          <div>
            <label className="text-[13px] text-[var(--muted-foreground)]">E-mail *</label>
            <input type="email" className={inputCls} value={f.email} onChange={set('email')} placeholder="seu@email.com" />
          </div>
          <div>
            <label className="text-[13px] text-[var(--muted-foreground)]">Senha *</label>
            <input type="password" className={inputCls} value={f.password} onChange={set('password')} placeholder="mín. 8 caracteres" />
          </div>

          {/* Endereço via CEP */}
          <div className="pt-2 border-t border-[var(--border)]">
            <p className="text-[13px] text-[var(--muted-foreground)] mb-3">
              Endereço — informe o CEP para o endereço ser preenchido automaticamente
            </p>
            <div className="grid grid-cols-[1fr_1.1fr] gap-3">
              <div>
                <label className="text-[13px] text-[var(--muted-foreground)]">CEP</label>
                <div className="flex gap-2">
                  <input
                    className={inputCls}
                    value={f.cep}
                    onChange={(e) => {
                      const v = mascaraCep(e.target.value)
                      setF((s) => ({ ...s, cep: v }))
                      if (v.replace(/\D/g, '').length === 8) buscarCep(v)
                    }}
                    placeholder="00000-000"
                    inputMode="numeric"
                  />
                </div>
              </div>
              <div>
                <label className="text-[13px] text-[var(--muted-foreground)]">Número *</label>
                <input className={inputCls} value={f.number} onChange={set('number')} placeholder="000" disabled={buscandoCep} />
              </div>
            </div>
            {buscandoCep && <p className="mt-2 text-xs text-[var(--muted-foreground)] animate-pulse">Buscando endereço…</p>}
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-[13px] text-[var(--muted-foreground)]">Logradouro</label>
                <input className={inputCls} value={f.street} onChange={set('street')} readOnly placeholder="preenchido pelo CEP" />
              </div>
              <div>
                <label className="text-[13px] text-[var(--muted-foreground)]">Bairro</label>
                <input className={inputCls} value={f.neighborhood} onChange={set('neighborhood')} readOnly />
              </div>
              <div>
                <label className="text-[13px] text-[var(--muted-foreground)]">Cidade / UF</label>
                <input className={inputCls} value={`${f.city}${f.state ? ' / ' + f.state : ''}`} readOnly />
              </div>
            </div>
            <div className="mt-3">
              <label className="text-[13px] text-[var(--muted-foreground)]">Complemento</label>
              <input className={inputCls} value={f.complement} onChange={set('complement')} placeholder="apartamento, bloco, referência…" />
            </div>
          </div>

          <button type="submit" disabled={busy} className="luminous-cta w-full py-3 text-sm font-medium disabled:opacity-50">
            {busy ? 'Criando…' : 'Criar cadastro'}
          </button>
        </form>

        <button onClick={() => router.push('/')} className="mt-6 w-full text-center text-sm font-light text-[var(--muted-foreground)] hover:text-white">
          ← Voltar ao início
        </button>
      </div>
    </div>
  )
}

export default function CadastroPage() {
  return (
    <main>
      <Suspense fallback={null}>
        <CadastroForm />
      </Suspense>
    </main>
  )
}
