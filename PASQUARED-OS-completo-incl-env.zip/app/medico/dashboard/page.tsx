'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiClient } from '@/lib/request'
import { useSession } from '@/lib/use-session'
import { toast } from 'sonner'
import { DashboardNav } from '@/components/dashboard-nav'

type PatientResult = {
  patient: {
    id: string
    firstName: string
    lastName: string
    birthDate: string | null
    phone: string | null
    email: string
    city: string | null
    state: string | null
  }
  consultations: {
    id: string
    status: string
    abstractionIndex: number | null
    startedAt: string
  }[]
}

export default function DoctorDashboard() {
  const router = useRouter()
  const session = useSession(['doctor'])
  const [cpf, setCpf] = useState('')
  const [result, setResult] = useState<PatientResult | null>(null)
  const [busy, setBusy] = useState(false)
  const [busca, setBusca] = useState(false)

  const mascaraCpf = (v: string) => {
    const d = v.replace(/\D/g, '').slice(0, 11)
    return d
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
  }

  const buscar = async (e?: React.FormEvent) => {
    e?.preventDefault()
    const clean = cpf.replace(/\D/g, '')
    if (clean.length !== 11) return toast.error('Informe um CPF completo.')
    setBusy(true)
    setResult(null)
    const res = await apiClient.post<PatientResult>('/api/medico/buscar', {
      cpf: clean,
    })
    setBusy(false)
    if (!res.success) {
      setBusca(false)
      return toast.error(res.error)
    }
    setResult(res.data)
    setBusca(true)
  }

  if (session.status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="font-mono text-sm text-[var(--muted-foreground)] animate-pulse">CARREGANDO…</p>
      </div>
    )
  }
  if (session.status !== 'authenticated') return null

  return (
    <main className="min-h-screen px-6 py-10 max-w-4xl mx-auto fade-in-up">
      <DashboardNav userName="Painel do Médico" homeHref="/medico/dashboard" />
      <header className="mb-6">
        <h1 className="text-3xl font-light">Painel do Médico</h1>
        <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
          Busque o paciente pelo CPF para acessar os dados da consulta
        </p>
      </header>

      {/* Menu de tarefas do médico */}
      <section className="weightless-panel p-5 mb-8">
        <h2 className="text-xs uppercase tracking-wide text-[var(--muted-foreground)] mb-3">Atalhos</h2>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => document.getElementById('busca-cpf')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white"
          >
            Buscar paciente por CPF
          </button>
          <button
            onClick={() => router.push('/medico/dashboard')}
            className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white"
          >
            Consultas registradas
          </button>
          <button
            onClick={() => router.push('/')}
            className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white"
          >
            Início
          </button>
        </div>
      </section>

      {/* Busca por CPF */}
      <section id="busca-cpf" className="weightless-panel p-7 mb-8">
        <form onSubmit={buscar} className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <label className="text-[13px] text-[var(--muted-foreground)]">CPF do paciente</label>
            <input
              value={cpf}
              onChange={(e) => setCpf(mascaraCpf(e.target.value))}
              placeholder="000.000.000-00"
              inputMode="numeric"
              className="mt-1 w-full rounded-xl bg-[rgba(255,255,255,0.04)] border border-[var(--border)] px-4 py-3 text-[15px] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="luminous-cta self-end px-6 py-3 text-sm font-medium disabled:opacity-50"
          >
            {busy ? 'Buscando…' : 'Buscar'}
          </button>
        </form>
        {busca && result && (
          <p className="mt-4 font-mono text-[11px] text-[var(--primary)]">
            ✓ Paciente autenticado · retornando dados da consulta
          </p>
        )}
      </section>

      {/* Resultado */}
      {busca && result && (
        <section className="fade-in-up">
          <div className="weightless-panel p-6 mb-4">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h2 className="text-xl font-light">
                  {result.patient.firstName} {result.patient.lastName}
                </h2>
                <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
                  {result.patient.birthDate ? `Nascimento: ${result.patient.birthDate} · ` : ''}
                  {result.patient.email}
                  {result.patient.phone ? ` · ${result.patient.phone}` : ''}
                  {result.patient.city ? ` · ${result.patient.city}/${result.patient.state}` : ''}
                </p>
              </div>
            </div>
          </div>

          {result.consultations.length === 0 ? (
            <div className="weightless-panel p-6 text-sm font-light text-[var(--muted-foreground)]">
              Nenhuma anamnese registrada para este paciente.
            </div>
          ) : (
            <div className="space-y-3">
              <h3 className="text-lg font-light">Consultas registradas</h3>
              {result.consultations.map((c) => (
                <button
                  key={c.id}
                  onClick={() => router.push(`/medico/consulta/${c.id}`)}
                  className="weightless-panel w-full text-left px-5 py-4 hover:bg-[rgba(255,255,255,0.05)] transition"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="font-mono text-[11px] text-[var(--muted-foreground)]">
                        {new Date(c.startedAt).toLocaleString('pt-BR')}
                      </p>
                      <p className="mt-1 text-[15px] font-light">
                        {c.status === 'completed' ? 'Anamnese concluída' : 'Anamnese em andamento'}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      {c.abstractionIndex != null && (
                        <span className="font-mono text-[11px] text-[var(--primary)]">
                          IGA {c.abstractionIndex}%
                        </span>
                      )}
                      <span className="text-[var(--accent)] text-sm">Abrir ›</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>
      )}
    </main>
  )
}
