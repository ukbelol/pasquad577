'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { apiClient } from '@/lib/request'
import { useSession, LogoutButton } from '@/lib/use-session'
import { toast } from 'sonner'

type Msg = {
  id: string
  role: string
  contentType: string
  content: string
  fileName?: string | null
  filePath?: string | null
  fileMime?: string | null
  fileSize?: number | null
  createdAt: string
}

type Patient = {
  firstName: string
  lastName: string
  birthDate: string | null
  phone: string | null
  email: string
  city: string | null
  state: string | null
}

type Consult = {
  id: string
  status: string
  abstractionIndex: number | null
  convergence: number | null
  finalReport: string | null
  createdVia?: string
}

function fileKind(mime?: string | null): 'image' | 'audio' | 'video' | 'pdf' | 'other' {
  if (!mime) return 'other'
  if (mime.startsWith('image/')) return 'image'
  if (mime.startsWith('audio/')) return 'audio'
  if (mime.startsWith('video/')) return 'video'
  if (mime === 'application/pdf') return 'pdf'
  return 'other'
}

export default function MedicoConsultaPage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const session = useSession(['doctor'])
  const [messages, setMessages] = useState<Msg[]>([])
  const [patient, setPatient] = useState<Patient | null>(null)
  const [consult, setConsult] = useState<Consult | null>(null)
  const [loading, setLoading] = useState(true)
  const [tipoFilter, setTipoFilter] = useState<'todos' | 'media' | 'files' | 'text'>('todos')

  useEffect(() => {
    if (session.status !== 'authenticated') return
    apiClient
      .get<{
        consultation: Consult
        patient: Patient
        messages: Msg[]
      }>(`/api/consultas/${id}`)
      .then((res) => {
        if (!res.success) {
          toast.error(res.error)
          router.replace('/medico/dashboard')
          return
        }
        setConsult(res.data.consultation)
        setPatient(res.data.patient)
        setMessages(res.data.messages)
      })
      .finally(() => setLoading(false))
  }, [id, session.status, router])

  if (session.status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="font-mono text-sm text-[var(--muted-foreground)] animate-pulse">CARREGANDO CONSULTA…</p>
      </div>
    )
  }
  if (session.status !== 'authenticated') return null

  const media = messages.filter((m) => {
    const k = fileKind(m.fileMime)
    return m.filePath && (k === 'image' || k === 'audio' || k === 'video')
  })
  const files = messages.filter((m) => m.filePath)

  const filtered = messages.filter((m) => {
    if (tipoFilter === 'media') return m.filePath && media.includes(m)
    if (tipoFilter === 'files') return m.filePath && files.includes(m)
    if (tipoFilter === 'text') return m.role === 'user' || (m.content && !m.filePath)
    return true
  })

  return (
    <main className="min-h-screen px-6 py-10 max-w-5xl mx-auto fade-in-up">
      <header className="flex items-center justify-between mb-8">
        <button onClick={() => router.push('/medico/dashboard')} className="text-sm text-[var(--muted-foreground)] hover:text-white">
          ← Voltar
        </button>
        <LogoutButton />
      </header>

      {/* Paciente header */}
      {patient && (
        <section className="weightless-panel p-6 mb-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="font-mono text-[11px] tracking-widest text-[var(--primary)]">PACIENTE</p>
              <h1 className="mt-1 text-2xl font-light">
                {patient.firstName} {patient.lastName}
              </h1>
              <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
                {patient.birthDate ? `Nascimento ${patient.birthDate} · ` : ''}
                {patient.phone || ''}
                {patient.email ? ` · ${patient.email}` : ''}
                {patient.city ? ` · ${patient.city}/${patient.state || ''}` : ''}
              </p>
            </div>
            <div className="text-right">
              <div className="font-mono text-2xl text-[var(--primary)]">
                {consult?.abstractionIndex ?? '—'}
                <span className="text-sm text-[var(--muted-foreground)]">% IGA</span>
              </div>
              <p className="font-mono text-[11px] text-[var(--muted-foreground)]">
                {consult?.status === 'completed' ? 'Anamnese concluída' : 'Em andamento'}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* Filtros */}
      <div className="flex flex-wrap gap-2 mb-5">
        {[
          { k: 'todos', label: 'Tudo' },
          { k: 'media', label: 'Mídias (áudio/vídeo)' },
          { k: 'files', label: 'Arquivos' },
          { k: 'text', label: 'Textos' },
        ].map((t) => (
          <button
            key={t.k}
            onClick={() => setTipoFilter(t.k as typeof tipoFilter)}
            className={`px-3.5 py-1.5 text-xs rounded-full border transition ${
              tipoFilter === t.k
                ? 'border-[var(--primary)] text-[var(--primary)] bg-[rgba(0,255,135,0.08)]'
                : 'border-[var(--border)] text-[var(--muted-foreground)] hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Cronologia da anamnese */}
      <section className="space-y-4">
        {filtered.length === 0 && (
          <div className="weightless-panel p-6 text-sm font-light text-[var(--muted-foreground)]">
            Nada para exibir neste filtro.
          </div>
        )}
        {filtered.map((m) => {
          const kind = fileKind(m.fileMime)
          const isDoctor = m.role === 'assistant'
          return (
            <div key={m.id} className="flex justify-center">
              <div className="max-w-3xl w-full">
                <div className="flex items-center gap-3 mb-1">
                  <span className="font-mono text-[10px] text-[var(--muted-foreground)]">
                    {new Date(m.createdAt).toLocaleTimeString('pt-BR')}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${isDoctor ? 'bg-[rgba(0,212,255,0.1)] text-[var(--accent)]' : 'bg-[rgba(255,255,255,0.06)] text-[var(--muted-foreground)]'}`}>
                    {isDoctor ? 'IA' : 'Paciente'}
                  </span>
                </div>
                <div
                  className={`weightless-panel px-5 py-4 ${
                    isDoctor ? 'border-l-2 border-l-[var(--accent)]' : 'border-l-2 border-l-[var(--primary)]'
                  }`}
                >
                  {m.content && <p className="text-[15px] font-light whitespace-pre-wrap">{m.content}</p>}
                  {m.filePath && kind === 'image' && (
                    <figure className="mt-3">
                      <img
                        src={`/api${m.filePath}`}
                        alt={m.fileName || 'imagem'}
                        className="max-h-80 rounded-xl border border-[var(--border)]"
                      />
                    </figure>
                  )}
                  {m.filePath && kind === 'audio' && (
                    <div className="mt-3">
                      <audio controls src={`/api${m.filePath}`} className="w-full" />
                    </div>
                  )}
                  {m.filePath && kind === 'video' && (
                    <div className="mt-3">
                      <video controls src={`/api${m.filePath}`} className="max-h-80 rounded-xl border border-[var(--border)]" />
                    </div>
                  )}
                  {m.filePath && (kind === 'pdf' || kind === 'other') && (
                    <a href={`/api${m.filePath}`} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-2 text-[var(--accent)] text-sm">
                      ⬇ {m.fileName || 'Baixar arquivo'}
                    </a>
                  )}
                  {m.filePath && (
                    <p className="mt-2 font-mono text-[10px] text-[var(--muted-foreground)]">
                      {m.contentType} · {(m.fileSize ?? 0) > 0 ? `${(m.fileSize! / 1024 / 1024).toFixed(2)} MB` : ''}
                    </p>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </section>

      {/* Relatório final */}
      {consult?.finalReport && (
        <section className="weightless-panel p-6 mt-8">
          <h3 className="font-mono text-[11px] tracking-widest text-[var(--primary)] mb-2">RELATÓRIO DA ANAMESE</h3>
          <p className="text-[15px] font-light whitespace-pre-wrap">{consult.finalReport}</p>
        </section>
      )}
    </main>
  )
}
