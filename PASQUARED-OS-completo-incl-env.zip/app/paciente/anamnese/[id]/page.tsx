'use client'

import { useEffect, useRef, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { apiClient } from '@/lib/request'
import { useSession } from '@/lib/use-session'
import { toast } from 'sonner'

type Msg = {
  id: string
  role: string
  contentType: string
  content: string
  fileName?: string | null
  filePath?: string | null
  fileMime?: string | null
  fileSize?: number | null
  createdAt: string
}

type State = {
  phase: string
  iga: number
  ici: number
  convergence: number
  cycles: number
  converged: boolean
}

function fileKind(mime?: string | null): 'image' | 'audio' | 'video' | 'pdf' | 'other' {
  if (!mime) return 'other'
  if (mime.startsWith('image/')) return 'image'
  if (mime.startsWith('audio/')) return 'audio'
  if (mime.startsWith('video/')) return 'video'
  if (mime === 'application/pdf') return 'pdf'
  return 'other'
}

const PHASE_HELP: Record<string, string> = {
  READY: 'Pronto para nova entrada',
  RECEIVING: 'Recebendo informações',
  NORMALIZING: 'Normalizando as UCIs',
  CLASSIFYING: 'Classificando domínios',
  CONSULTING: 'Consultando a memória',
  ABSTRACTING: 'Abstraindo o grafo cognitivo',
  VALIDATING: 'Validando hipóteses',
  LEARNING: 'Aprendendo e atualizando memória',
  RESPONDING: 'Gerando resposta',
}

export default function AnamnesePage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const session = useSession(['patient'])
  const [messages, setMessages] = useState<Msg[]>([])
  const [state, setState] = useState<State | null>(null)
  const [text, setText] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [sending, setSending] = useState(false)
  const [loading, setLoading] = useState(true)
  const [preview, setPreview] = useState<string | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  const load = () => {
    setLoading(true)
    apiClient
      .get<{ consultation: { status: string; cognitiveState: State | null }; messages: Msg[] }>(
        `/api/consultas/${id}`
      )
      .then((res) => {
        if (!res.success) {
          toast.error(res.error)
          router.replace('/paciente/dashboard')
          return
        }
        setMessages(res.data.messages)
        setState(res.data.consultation.cognitiveState)
        if (res.data.consultation.status === 'completed') {
          // anamnese ainda precisa de dados — apenas registro
        }
      })
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    if (session.status === 'authenticated') load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session.status])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, sending])

  useEffect(() => {
    if (!file) {
      setPreview(null)
      return
    }
    if (file.type.startsWith('image/')) {
      setPreview(URL.createObjectURL(file))
    } else {
      setPreview(null)
    }
  }, [file])

  const attach = (f: File | undefined) => {
    if (!f) return
    if (f.size > 30 * 1024 * 1024) {
      toast.error('Arquivo muito grande (máx 30MB).')
      return
    }
    setFile(f)
  }

  const send = async (e?: React.FormEvent) => {
    e?.preventDefault()
    if (!text.trim() && !file) return
    setSending(true)
    const form = new FormData()
    form.append('text', text)
    if (file) form.append('file', file)

    try {
      const res = await fetch(`/api/consultas/${id}/message`, {
        method: 'POST',
        body: form,
      })
      const json = await res.json()
      if (!json.success) {
        toast.error(json.error || 'Erro ao enviar.')
        return
      }
      // refresh from server
      await apiClient
        .get<{ consultation: { cognitiveState: State | null }; messages: Msg[] }>(
          `/api/consultas/${id}`
        )
        .then((r) => {
          if (r.success) {
            setMessages(r.data.messages)
            setState(r.data.consultation.cognitiveState)
          }
        })
      setText('')
      setFile(null)
      if (json.data?.cognitive?.length) {
        toast.info(json.data.cognitive[0])
      }
    } finally {
      setSending(false)
    }
  }

  if (session.status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="font-mono text-sm text-[var(--muted-foreground)] animate-pulse">CARREGANDO ANAMESE…</p>
      </div>
    )
  }
  if (session.status !== 'authenticated') return null

  return (
    <main className="min-h-screen flex flex-col px-4 sm:px-6 py-5 max-w-3xl mx-auto fade-in-up">
      <header className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => router.push('/paciente/dashboard')}
            className="text-sm text-[var(--muted-foreground)] hover:text-white"
          >
            ←
          </button>
          <div>
            <h1 className="text-xl font-light">Anamnese assistida</h1>
            <p className="font-mono text-[11px] text-[var(--muted-foreground)]">
              PASQUARED controlador · IA criadora de perguntas
            </p>
          </div>
        </div>
        {state && (
          <div className="hidden sm:flex flex-col items-end">
            <span className="font-mono text-[11px] text-[var(--primary)]">
              IGA {state.iga}% · ICI {state.ici}%
            </span>
            <span className="font-mono text-[10px] text-[var(--muted-foreground)]">
              <span className="inline-block w-2 h-2 rounded-full bg-[var(--primary)] animate-pulse mr-1" />
              {PHASE_HELP[state.phase] || state.phase}
            </span>
          </div>
        )}
      </header>

      {/* pipeline visualization */}
      {state && (
        <div className="weightless-panel px-4 py-3 mb-4 overflow-x-auto">
          <div className="flex items-center gap-1 font-mono text-[10px] text-[var(--muted-foreground)] whitespace-nowrap">
            {[
              'RECEIVING',
              'NORMALIZING',
              'CLASSIFYING',
              'ABSTRACTING',
              'VALIDATING',
              'LEARNING',
            ].map((p, i) => {
              const order = [
                'RECEIVING', 'NORMALIZING', 'CLASSIFYING', 'ABSTRACTING', 'VALIDATING', 'LEARNING',
              ]
              const active = order.indexOf(state.phase) >= 0 && order.indexOf(p) <= order.indexOf(state.phase)
              return (
                <span key={p} className="flex items-center gap-1">
                  <span className={active ? 'text-[var(--primary)]' : ''}>{p}</span>
                  {i < 5 && <span className="mx-0.5 text-white/20">▸</span>}
                </span>
              )
            })}
          </div>
        </div>
      )}

      <div
        ref={scrollRef}
        className="flex-1 space-y-4 overflow-y-auto pr-1 min-h-[380px] max-h-[56vh]"
      >
        {messages.map((m) => {
          const kind = fileKind(m.fileMime)
          return (
            <div
              key={m.id}
              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-[15px] font-light leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-[rgba(0,255,135,0.12)] border border-[rgba(0,255,135,0.25)] text-white'
                    : 'bg-[rgba(255,255,255,0.05)] border border-[var(--border)] text-white'
                }`}
              >
                {m.content && <p className="whitespace-pre-wrap">{m.content}</p>}

                {m.filePath && kind === 'image' && (
                  <img
                    src={`/api${m.filePath}`}
                    alt={m.fileName || 'imagem'}
                    className="mt-3 max-w-full rounded-xl border border-[var(--border)]"
                  />
                )}
                {m.filePath && kind === 'audio' && (
                  <audio controls src={`/api${m.filePath}`} className="mt-3 w-full" />
                )}
                {m.filePath && kind === 'video' && (
                  <video controls src={`/api${m.filePath}`} className="mt-3 max-w-full rounded-xl border border-[var(--border)]" />
                )}
                {m.filePath && kind === 'pdf' && (
                  <a
                    href={`/api${m.filePath}`}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-2 inline-flex items-center gap-2 text-[var(--accent)] text-sm"
                  >
                    📄 {m.fileName || 'PDF'}
                  </a>
                )}
                {m.fileName && (kind === 'other' || (m.content.startsWith('[Arquivo enviado:') && !m.filePath)) && (
                  <p className="mt-2 font-mono text-[11px] text-[var(--muted-foreground)]">
                    📎 {m.fileName}
                  </p>
                )}
              </div>
            </div>
          )
        })}
        {sending && (
          <div className="flex justify-start">
            <div className="bg-[rgba(255,255,255,0.05)] border border-[var(--border)] rounded-2xl px-4 py-3">
              <span className="inline-flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--primary)] animate-pulse" />
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--primary)] animate-pulse" style={{ animationDelay: '0.2s' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--primary)] animate-pulse" style={{ animationDelay: '0.4s' }} />
              </span>
            </div>
          </div>
        )}
      </div>

      {/* input */}
      <form onSubmit={send} className="mt-6">
        {file && (
          <div className="mb-3 flex items-center gap-3 weightless-panel px-3 py-2">
            {preview && (
              <img src={preview} alt="preview" className="w-12 h-12 object-cover rounded-lg" />
            )}
            <div className="min-w-0 flex-1">
              <p className="text-sm truncate">{file.name}</p>
              <p className="font-mono text-[10px] text-[var(--muted-foreground)]">
                {(file.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
            <button type="button" onClick={() => setFile(null)} className="text-[var(--muted-foreground)] hover:text-white text-sm">
              ✕
            </button>
          </div>
        )}
        <div className="flex items-end gap-2 weightless-panel p-2">
          <label className="shrink-0 cursor-pointer p-2 text-[var(--muted-foreground)] hover:text-white">
            <span>📎</span>
            <input
              type="file"
              className="hidden"
              onChange={(e) => attach(e.target.files?.[0])}
            />
          </label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={2}
            placeholder="Descreva seus sintomas ou responda à pergunta…"
            className="flex-1 resize-none bg-transparent px-3 py-2 text-[15px] font-light focus:outline-none placeholder:text-[var(--muted-foreground)]"
          />
          <button
            type="submit"
            disabled={sending || (!text.trim() && !file)}
            className="luminous-cta px-4 py-2 text-sm font-medium shrink-0 disabled:opacity-40"
          >
            Enviar
          </button>
        </div>
      </form>

      <footer className="mt-4 text-center">
        <button
          onClick={async () => {
            const res = await apiClient.post(`/api/consultas/${id}/finalizar`, {})
            if (res.success) toast.success('Anamnese encerrada. Obrigado!')
            router.push('/paciente/dashboard')
          }}
          className="font-mono text-[11px] text-[var(--muted-foreground)] hover:text-white"
        >
          Encerrar anamnese e voltar ao painel
        </button>
      </footer>
    </main>
  )
}
