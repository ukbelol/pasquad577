'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiClient } from '@/lib/request'
import { useSession } from '@/lib/use-session'
import { toast } from 'sonner'
import { DashboardNav } from '@/components/dashboard-nav'

type Consult = {
  id: string
  status: string
  chiefComplaint: string | null
  abstractionIndex: number | null
  convergence: number | null
  startedAt: string
  completedAt: string | null
}

export default function PatientDashboard() {
  const router = useRouter()
  const session = useSession(['patient'])
  const [consults, setConsults] = useState<Consult[]>([])
  const [loading, setLoading] = useState(true)
  const [criando, setCriando] = useState(false)

  const load = () => {
    setLoading(true)
    apiClient
      .get<Consult[]>('/api/consultas/mine')
      .then((res) => res.success && setConsults(res.data))
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    if (session.status === 'authenticated') load()
  }, [session.status])

  const nova = async () => {
    setCriando(true)
    const res = await apiClient.post<{ id: string }>('/api/consultas/new', {})
    setCriando(false)
    if (!res.success) return toast.error(res.error)
    toast.success('Novo atendimento iniciado.')
    router.push(`/paciente/anamnese/${res.data.id}`)
  }

  if (session.status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="font-mono text-sm text-[var(--muted-foreground)] animate-pulse">CARREGANDO…</p>
      </div>
    )
  }
  if (session.status !== 'authenticated') return null

  const firstName = session.user.firstName
  const active = consults.find((c) => c.status === 'open')

  return (
    <main className="min-h-screen px-6 py-10 max-w-4xl mx-auto fade-in-up">
      <DashboardNav userName={`${firstName} · Paciente`} homeHref="/paciente/dashboard" />
      <header className="mb-6">
        <h1 className="text-3xl font-light">Olá, {firstName}</h1>
        <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
          Sua área de anamnese assistida
        </p>
      </header>

      {/* Menu de tarefas do paciente */}
      <section className="weightless-panel p-5 mb-8">
        <h2 className="text-xs uppercase tracking-wide text-[var(--muted-foreground)] mb-3">Menu</h2>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={nova}
            disabled={criando || !!active}
            className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white disabled:opacity-40"
          >
            Nova anamnese
          </button>
          <button
            onClick={() => router.push('/paciente/dashboard')}
            className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white"
          >
            Histórico de consultas
          </button>
          <button
            onClick={() => router.push('/')}
            className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white"
          >
            Início
          </button>
        </div>
      </section>

      {/* CTA nova anamnese */}
      <section className="weightless-panel p-7 mb-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-light">
              {session.user.role === 'patient' ? 'Anamnese' : 'Consulta'}
            </h2>
            <p className="mt-1 text-sm font-light text-[var(--muted-foreground)]">
              Relate suas queixas e envie arquivos para o médico. O PASQUARED conduz a
              investigação com ajuda da IA.
            </p>
          </div>
          {active ? (
            <button
              onClick={() => router.push(`/paciente/anamnese/${active.id}`)}
              className="luminous-cta px-6 py-3 text-sm font-medium whitespace-nowrap"
            >
              Continuar anamnese
            </button>
          ) : (
            <button
              onClick={nova}
              disabled={criando}
              className="luminous-cta px-6 py-3 text-sm font-medium whitespace-nowrap disabled:opacity-50"
            >
              {criando ? 'Iniciando…' : 'Nova anamnese'}
            </button>
          )}
        </div>
      </section>

      {/* Histórico de consultas */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-light">Histórico de consultas</h2>
          <button onClick={load} className="text-xs text-[var(--muted-foreground)] hover:text-white">
            Atualizar
          </button>
        </div>

        {loading ? (
          <div className="weightless-panel p-6 text-sm font-light text-[var(--muted-foreground)] animate-pulse">
            Carregando histórico…
          </div>
        ) : consults.length === 0 ? (
          <div className="weightless-panel p-6 text-sm font-light text-[var(--muted-foreground)]">
            Nenhuma consulta ainda. Inicie sua primeira anamnese.
          </div>
        ) : (
          <div className="space-y-3">
            {consults.map((c) => (
              <button
                key={c.id}
                onClick={() => router.push(`/paciente/anamnese/${c.id}`)}
                className="weightless-panel w-full text-left px-5 py-4 hover:bg-[rgba(255,255,255,0.05)] transition"
              >
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-[15px] font-light line-clamp-1">
                      {c.chiefComplaint || 'Anamnese'}
                    </p>
                    <p className="mt-1 font-mono text-[11px] text-[var(--muted-foreground)]">
                      {new Date(c.startedAt).toLocaleString('pt-BR')}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    {c.abstractionIndex != null && (
                      <span className="font-mono text-[11px] text-[var(--primary)]">
                        IGA {c.abstractionIndex}%
                      </span>
                    )}
                    <span
                      className={`text-[11px] px-2.5 py-1 rounded-full ${
                        c.status === 'completed'
                          ? 'bg-[rgba(0,255,135,0.12)] text-[var(--primary)]'
                          : 'bg-[rgba(0,212,255,0.12)] text-[var(--accent)]'
                      }`}
                    >
                      {c.status === 'completed' ? 'Concluída' : 'Em andamento'}
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>
    </main>
  )
}
