'use client'

import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { apiClient } from '@/lib/request'
import { toast } from 'sonner'

export default function Home() {
  const router = useRouter()
  const [user, setUser] = useState<{
    role: string
    firstName: string
    lastName: string
  } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    apiClient
      .get<{ user: { role: string; firstName: string; lastName: string } | null }>(
        '/api/auth/me'
      )
      .then((res) => setUser(res.success ? res.data.user : null))
      .finally(() => setLoading(false))
  }, [])

  const go = (path: string) => {
    toast.info('Redirecionando…')
    router.push(path)
  }

  const pickRole = (role: 'patient' | 'doctor') => {
    router.push(`/auth/login?role=${role}`)
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 py-20">
      <div className="max-w-3xl w-full text-center fade-in-up">
        <div className="mb-6 flex justify-center">
          <img
            src="/logo.png"
            alt="PASQUARED-OS"
            className="w-20 h-20 rounded-2xl"
          />
        </div>
        <span className="font-mono text-xs tracking-[0.35em] uppercase text-[var(--muted-foreground)]">
          Sistema Cognitivo de Anamnese
        </span>
        <h1 className="mt-4 text-4xl sm:text-6xl font-light leading-tight tracking-tight">
          PASQUARED-OS
        </h1>
        <p className="mt-5 text-base sm:text-lg font-light text-[var(--muted-foreground)] leading-relaxed max-w-2xl mx-auto">
          Anamnese assistida por inteligência artificial. O algoritmo{' '}
          <span className="text-[var(--primary)]">PASQUARED</span> controla o fluxo
          cognitivo enquanto a IA da{' '}
          <span className="text-[var(--accent)]">Microsoft Foundry</span> conduz a
          investigação, transformando queixas, exames e mídias em conhecimento
          clínico estruturado.
        </p>

        {!loading && user ? (
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => router.push(
                user.role === 'patient'
                  ? '/paciente/dashboard'
                  : user.role === 'doctor'
                    ? '/medico/dashboard'
                    : '/admin/dashboard'
              )}
              className="luminous-cta px-8 py-3 text-sm font-medium"
            >
              Ir ao meu painel
            </button>
            <button
              onClick={() => go('/auth/logout')}
              className="px-6 py-3 text-sm font-light rounded-xl border border-[var(--border)]"
            >
              Sair
            </button>
          </div>
        ) : (
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <button onClick={() => pickRole('patient')} className="luminous-cta px-8 py-3 text-sm font-medium">
              Sou Paciente
            </button>
            <button onClick={() => pickRole('doctor')} className="px-8 py-3 text-sm font-light rounded-xl border border-[var(--border)]">
              Sou Médico
            </button>
            <button onClick={() => go('/admin/login')} className="px-6 py-3 text-xs font-light rounded-xl text-[var(--muted-foreground)]">
              Acesso do Super Admin
            </button>
          </div>
        )}

        <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { label: 'IGA', desc: 'Índice Global de Abstração' },
            { label: 'RCI', desc: 'Rede Cognitiva Informacional' },
            { label: 'POKO', desc: 'Ontologia do Conhecimento' },
          ].map((m) => (
            <div key={m.label} className="weightless-panel px-5 py-6">
              <div className="font-mono text-lg text-[var(--primary)]">{m.label}</div>
              <div className="mt-1 text-[13px] font-light text-[var(--muted-foreground)]">{m.desc}</div>
            </div>
          ))}
        </div>

        <p className="mt-12 font-mono text-[11px] tracking-widest text-[var(--muted-foreground)]">
          Ciclo Cognitivo: RECEIVING · NORMALIZING · CLASSIFYING · ABSTRACTING · VALIDATING · LEARNING
        </p>
      </div>
    </main>
  )
}
