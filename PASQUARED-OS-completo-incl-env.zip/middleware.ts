import { NextRequest, NextResponse } from 'next/server'
import { jwtVerify } from 'jose'

/**
 * Auth de borda: valida o cookie de sessão (JWT) e redireciona com base no papel.
 * Roda antes de qualquer rota protegida, garantindo redirecionamentos HTTP
 * determinísticos no servidor (não depende de JS do navegador).
 */
const SESSION_COOKIE = 'pasquared_session'

const SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || 'pasquared-os-dev-secret-change-me'
)

type SessionUser = { id?: string; role?: string }

async function getAuthUser(req: NextRequest): Promise<SessionUser | null> {
  const token = req.cookies.get(SESSION_COOKIE)?.value
  if (!token) return null
  try {
    const { payload } = await jwtVerify(token, SECRET)
    const user = payload as SessionUser
    if (!user?.id || !user?.role) return null
    return user
  } catch {
    return null
  }
}

function dashboardFor(role?: string): string {
  if (role === 'superadmin') return '/admin/dashboard'
  if (role === 'doctor') return '/medico/dashboard'
  return '/paciente/dashboard'
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  const user = await getAuthUser(req)
  const role = user?.role

  // Rotas públicas (sem restrição)
  if (
    pathname === '/' ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/auth') ||
    /\.(png|svg|ico|jpg|jpeg|webp|css|js|woff2?|json)$/.test(pathname)
  ) {
    return NextResponse.next()
  }

  // Protege as áreas administrativas e de atendimento.
  let required: string | null = null
  if (pathname.startsWith('/admin')) required = 'superadmin'
  else if (pathname.startsWith('/medico')) required = 'doctor'
  else if (pathname.startsWith('/paciente')) required = 'patient'

  if (required) {
    if (!role) {
      const url = req.nextUrl.clone()
      url.pathname = '/auth/login'
      url.search = `?role=${required}`
      return NextResponse.redirect(url, 307)
    }
    if (role !== required) {
      const url = req.nextUrl.clone()
      url.pathname = dashboardFor(role)
      url.search = ''
      return NextResponse.redirect(url, 307)
    }
    return NextResponse.next()
  }

  return NextResponse.next()
}

export const config = {
  // Não roda sobre arquivos estáticos nem páginas de auth para evitar loops.
  matcher: ['/((?!_next/static|_next/image|favicon.ico|icons/|logo.png).*)'],
}
