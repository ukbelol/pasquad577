import 'dotenv/config'
import { db } from '../db'
import { users, appSettings } from '../db/schemas/schema'
import { eq } from 'drizzle-orm'
import bcrypt from 'bcryptjs'

async function main() {
  const email = 'roger577@pasquared.space'
  const password = '21121201@Roger'
  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1)
  if (existing[0]) {
    console.log('Super admin já existe.')
  } else {
    const hash = await bcrypt.hash(password, 12)
    await db.insert(users).values({
      role: 'superadmin',
      firstName: 'Roger',
      lastName: 'Super Admin',
      email,
      passwordHash: hash,
    })
    console.log('Super admin criado:', email)
  }
  await db.insert(appSettings).values({ key: 'microsoft_foundry', value: { enabled: false } }).onConflictDoUpdate({ target: appSettings.key, set: { value: { enabled: false } } })
  console.log('Configuração Foundry inicializada.')
  process.exit(0)
}
main().catch((e) => { console.error(e); process.exit(1) })
