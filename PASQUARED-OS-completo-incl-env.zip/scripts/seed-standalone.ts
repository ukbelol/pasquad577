import 'dotenv/config'
import postgres from 'postgres'
import bcrypt from 'bcryptjs'

const sql = postgres(process.env.DATABASE_URL!, { prepare: false })
const email = 'roger577@pasquared.space'
const password = '21121201@Roger'

async function main() {
  const existing = await sql`SELECT id FROM users WHERE email = ${email} LIMIT 1`
  if (existing.length) {
    console.log('Super admin já existe.')
  } else {
    const hash = await bcrypt.hash(password, 12)
    await sql`INSERT INTO users (role, first_name, last_name, email, password_hash) VALUES ('superadmin', 'Roger', 'Super Admin', ${email}, ${hash})`
    console.log('Super admin criado:', email)
  }
  const cfg = await sql`SELECT key FROM app_settings WHERE key = ${'microsoft_foundry'}`
  if (!cfg.length) {
    await sql`INSERT INTO app_settings (key, value) VALUES ('microsoft_foundry', ${JSON.stringify({ enabled: false })}::jsonb)`
    console.log('Configuração Foundry inicializada.')
  }
  await sql.end()
  process.exit(0)
}
main().catch((e) => { console.error(e); process.exit(1) })
