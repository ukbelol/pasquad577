import { sql } from 'drizzle-orm'
import {
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from 'drizzle-orm/pg-core'

/** Shared enum-ish string literal helpers — kept as plain text columns for flexibility. */

/**
 * Sistema de Identidades do PASQUARED-OS.
 * O = Observador: um usuário (Paciente PA, Médico DR ou Super Admin).
 */
export const users = pgTable(
  'users',
  {
    id: text('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    role: varchar('role', { length: 16 }).notNull().default('patient'), // patient | doctor | superadmin
    firstName: varchar('first_name', { length: 120 }).notNull(),
    lastName: varchar('last_name', { length: 120 }).notNull(),
    birthDate: varchar('birth_date', { length: 20 }),
    cpf: varchar('cpf', { length: 14 }),
    phone: varchar('phone', { length: 30 }),
    email: varchar('email', { length: 160 }).notNull(),
    passwordHash: varchar('password_hash', { length: 255 }).notNull(),
    // Address (populated via CEP API)
    cep: varchar('cep', { length: 10 }),
    street: varchar('street', { length: 255 }),
    number: varchar('number', { length: 40 }),
    complement: varchar('complement', { length: 255 }),
    neighborhood: varchar('neighborhood', { length: 160 }),
    city: varchar('city', { length: 160 }),
    state: varchar('state', { length: 2 }),
    createdAt: timestamp('created_at', { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => [
    uniqueIndex('users_email_idx').on(table.email),
    uniqueIndex('users_cpf_idx').on(table.cpf),
    index('users_role_idx').on(table.role),
  ]
)

export type UserRow = typeof users.$inferSelect
export type NewUserRow = typeof users.$inferInsert

/**
 * EKO / Anamnese: uma sessão de consulta (anamnese assistida).
 * No PASQUARED, cada sessão produz um Knowledge EKO (Encapsulated Knowledge Object).
 */
export const consultations = pgTable(
  'consultations',
  {
    id: text('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    patientId: text('patient_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    doctorId: text('doctor_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    status: varchar('status', { length: 24 }).notNull().default('open'), // open | completed | reviewed
    chiefComplaint: text('chief_complaint'),
    // Cognitive state: última rodada de abstração do controlador PASQUARED
    cognitiveState: jsonb('cognitive_state'),
    // IGA / ICI / convergência calculados pelo núcleo cognitivo
    abstractionIndex: integer('abstraction_index'),
    convergence: integer('convergence'),
    summary: text('summary'),
    finalReport: text('final_report'),
    assistantModel: varchar('assistant_model', { length: 120 }),
    startedAt: timestamp('started_at', { withTimezone: true })
      .defaultNow()
      .notNull(),
    completedAt: timestamp('completed_at', { withTimezone: true }),
    updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow(),
  },
  (table) => [
    index('consultations_patient_idx').on(table.patientId),
    index('consultations_doctor_idx').on(table.doctorId),
  ]
)

export type ConsultationRow = typeof consultations.$inferSelect

/**
 * Mensagens / UCIs da anamnese: cada pergunta e cada resposta vira uma
 * Unidade Cognitiva de Informação (UCI) registrada com tipo, peso e contexto.
 */
export const messages = pgTable(
  'messages',
  {
    id: text('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    consultationId: text('consultation_id')
      .notNull()
      .references(() => consultations.id, { onDelete: 'cascade' }),
    role: varchar('role', { length: 24 }).notNull(), // system | assistant | user | doctor
    contentType: varchar('content_type', { length: 32 })
      .notNull()
      .default('text'), // text | audio | video | image | file
    content: text('content').notNull(), // transcripto / descrição
    // UCI attributes
    uciWeight: integer('uci_weight'), // 0-100 peso cognitivo
    uciContext: varchar('uci_context', { length: 255 }),
    uciType: varchar('uci_type', { length: 32 }).default('text'),
    fileName: varchar('file_name', { length: 255 }),
    filePath: text('file_path'),
    fileMime: varchar('file_mime', { length: 160 }),
    fileSize: integer('file_size'),
    createdAt: timestamp('created_at', { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => [
    index('messages_consultation_idx').on(table.consultationId),
    index('messages_role_idx').on(table.role),
  ]
)

export type MessageRow = typeof messages.$inferSelect

/**
 * Configuração global / sistema (Super Admin).
 * Armazena a configuração da IA Microsoft Foundry (Azure AI Foundry) e demais ajustes.
 */
export const appSettings = pgTable(
  'app_settings',
  {
    key: varchar('key', { length: 120 }).primaryKey(),
    // JSON serializado: { value: any }
    value: jsonb('value').notNull(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => [index('app_settings_key_idx').on(table.key)]
)

export type AppSettingRow = typeof appSettings.$inferSelect

/**
 * Repositórios de conhecimento de saúde das Américas conectáveis ao PASQUARED.
 * Ex.: PAHO/OMS, CDC, OpenFDA, NIH/MEDLINE Plus, ANVISA, Health Canada, etc.
 */
export const knowledgeBases = pgTable(
  'knowledge_bases',
  {
    id: text('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    code: varchar('code', { length: 60 }).notNull(), // slug único, ex: paho
    name: varchar('name', { length: 160 }).notNull(),
    country: varchar('country', { length: 120 }),
    region: varchar('region', { length: 40 }).notNull().default('Americas'),
    focus: text('focus'),
    officialUrl: text('official_url'),
    connectorType: varchar('connector_type', { length: 40 })
      .notNull()
      .default('static'), // static | http-json | hosted
    status: varchar('status', { length: 24 }).notNull().default('disabled'), // connected | disabled | error | syncing
    meta: jsonb('meta'), // credenciais/não consideradas sensíveis e endpoints
    lastSyncAt: timestamp('last_sync_at', { withTimezone: true }),
    nodeCount: integer('node_count').notNull().default(0),
    createdAt: timestamp('created_at', { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => [
    uniqueIndex('kb_code_idx').on(table.code),
    index('kb_status_idx').on(table.status),
  ]
)

export type KnowledgeBaseRow = typeof knowledgeBases.$inferSelect
export type NewKnowledgeBaseRow = typeof knowledgeBases.$inferInsert

/**
 * Nós de conhecimento ingeridos das bases conectadas.
 * Cada nó oferece um fato médico conciso que o PASQUARED pode usar como
 * "memória externa" (grounding) ao elaborar perguntas e hipóteses.
 */
export const knowledgeNodes = pgTable(
  'knowledge_nodes',
  {
    id: text('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    baseId: text('base_id')
      .notNull()
      .references(() => knowledgeBases.id, { onDelete: 'cascade' }),
    source: text('source'),
    title: text('title').notNull(),
    snippet: text('snippet').notNull(),
    topic: varchar('topic', { length: 120 }),
    weight: integer('weight').notNull().default(50),
    nodeType: varchar('node_type', { length: 32 })
      .notNull()
      .default('fact'), // fact | guideline | drug | surveillance
    createdAt: timestamp('created_at', { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => [
    index('kn_base_idx').on(table.baseId),
    index('kn_topic_idx').on(table.topic),
  ]
)

export type KnowledgeNodeRow = typeof knowledgeNodes.$inferSelect
