'use client'

import { useRouter } from 'next/navigation'
import { apiClient } from '@/lib/request'

/**
 * Barra de navegação compartilhada dos painéis (super admin / médico / paciente).
 * Mostra a marca, o nome do usuário e o botão de sair, com navegação completa
 * (server-side) garantida pelo middleware de autenticação.
 */
export function DashboardNav({
  userName,
  homeHref,
}: {
  userName: string
  homeHref: string
}) {
  const router = useRouter()
  return (
    <nav className="flex flex-wrap items-center justify-between gap-3 mb-8 rounded-2xl border border-[var(--border)] bg-[rgba(255,255,255,0.03)] px-4 py-3">
      <div className="flex items-center gap-3">
        <img src="/logo.png" alt="PASQUARED-OS" className="w-8 h-8 rounded-lg" />
        <div>
          <p className="text-sm font-medium leading-tight">PASQUARED-OS</p>
          <p className="text-[11px] font-light text-[var(--muted-foreground)] leading-tight">{userName}</p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={() => router.push(homeHref)}
          className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white"
        >
          Painel
        </button>
        <button
          onClick={() => router.push('/')}
          className="px-4 py-2 text-xs font-light rounded-xl border border-[var(--border)] text-[var(--muted-foreground)] hover:text-white"
        >
          Início
        </button>
        <button
          onClick={() => apiClient.post('/api/auth/logout', {}).then(() => router.push('/'))}
          className="px-4 py-2 text-xs font-light rounded-xl border border-[rgba(255,0,90,0.4)] text-[#ff3b5c] hover:text-white hover:border-[#ff3b5c]"
        >
          Sair
        </button>
      </div>
    </nav>
  )
}
