/**
 * AuroraField — fundo atmosférico da aurora (emerald/violet/teal).
 * Blobs grandes e fortemente desfocados, à deriva lenta. Nunca lidos como
 * gradientes duros; permanecem puramente ambientais.
 */
export function AuroraField() {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-black"
    >
      <div
        className="aurora-blob aurora-emerald"
        style={{ width: '55vw', height: '55vw', left: '-12vw', top: '-18vh' }}
      />
      <div
        className="aurora-blob aurora-violet"
        style={{ width: '45vw', height: '45vw', right: '-10vw', top: '8vh', animationDelay: '-9s' }}
      />
      <div
        className="aurora-blob aurora-teal"
        style={{ width: '48vw', height: '48vw', left: '20vw', bottom: '-20vh', animationDelay: '-17s' }}
      />
    </div>
  );
}
