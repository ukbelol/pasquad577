# Manual de Extração de Relatórios & Integração com a API do HubSpot.com
### Guia de Conexão, Engenharia de Prompts e Consultas Cognitivas PASQUARED-OS

Este manual fornece instruções passo a passo para conectar o HubSpot.com ao **PASQUARED-OS**, extrair dados de CRM (Contatos, Empresas e Negócios) via API e utilizar técnicas avançadas de Engenharia de Prompts para gerar relatórios analíticos, responder a perguntas complexas de negócios e automatizar auditorias de funil de vendas.

---

## 1. Visão Geral da Integração

O HubSpot organiza seus dados de CRM utilizando uma arquitetura baseada em objetos (CRM Objects). Os objetos mais comuns para geração de relatórios comerciais são:
* **Deals (Negócios):** Informações sobre vendas, etapas do pipeline, valores e datas de fechamento.
* **Contacts (Contatos):** Leads, clientes e perfis individuais de compradores.
* **Companies (Empresas):** Organizações associadas aos contatos e negócios.
* **Owners (Proprietários):** Membros da equipe de vendas responsáveis pelos registros.

Ao conectar esses dados ao motor de IA do PASQUARED-OS, você pode realizar perguntas em linguagem natural e receber relatórios formatados, análises preditivas, detecções de gargalo de funil e projeções de faturamento.

---

## 2. Como Autenticar e Configurar a Conexão (Tokens de Acesso Privado)

O HubSpot descontinuou as Chaves de API legadas (API Keys) em favor dos **Tokens de Acesso Privado (Private App Access Tokens)**, que fornecem maior segurança e controle de escopo (OAuth).

### Passo a Passo para Obter seu Token no HubSpot:
1. Acesse sua conta do HubSpot como administrador.
2. Clique no ícone de engrenagem **Configurações** (Settings) no canto superior direito.
3. No menu lateral esquerdo, vá para **Integrações (Integrations) > Aplicativos Privados (Private Apps)**.
4. Clique no botão **Criar Aplicativo Privado** (Create Private App).
5. Na aba **Informações Básicas** (Basic Info), dê um nome para o aplicativo (Ex: `PASQUARED-OS Connector`).
6. Na aba **Escopos** (Scopes), selecione as permissões mínimas necessárias para leitura e geração de relatórios:
   * `crm.objects.contacts.read` (Leitura de Contatos)
   * `crm.objects.companies.read` (Leitura de Empresas)
   * `crm.objects.deals.read` (Leitura de Negócios)
   * `crm.schemas.deals.read` (Leitura de Esquemas de Negócios)
   * `crm.objects.owners.read` (Leitura de Proprietários/Vendedores)
7. Clique em **Criar aplicativo** no canto superior direito.
8. Uma janela pop-up exibirá seu **Access Token**. Copie o token (ele começa com `pat-na1-...` ou similar) e guarde-o em segurança.

### Mapeamento do Conector no PASQUARED-OS:
No painel **Gestão de Recursos & Dados TI** > **Conectores de Dados Corporativos**, cadastre o conector do HubSpot com os seguintes parâmetros:
* **Nome Amigável:** `HubSpot API CRM`
* **Tipo de Fonte:** `REST API`
* **Endpoint URL:** `https://api.hubapi.com/crm/v3/objects/`
* **Método de Autenticação:** `Bearer Token`
* **Token / Chave:** `[Insira_o_Token_Obtido_Acima]`
* **Dimensão Cognitiva:** `Evidência (α)` ou `Memória Histórica (γ)`
* **Frequência de Sincronização:** `Tempo Real` ou `1 Hora`

---

## 3. Endpoints Principais para Extração de Dados

Abaixo estão os endpoints fundamentais para consultas do sistema:

### A. Negócios (Deals) - Foco em Faturamento e Funil
* **Endpoint:** `GET https://api.hubapi.com/crm/v3/objects/deals`
* **Parâmetros úteis de query:**
  * `limit=100`: Número de registros por página.
  * `properties=dealname,amount,dealstage,closedate,pipeline`: Especifica quais colunas de dados extrair.
* **Exemplo de URL de requisição:**
  ```http
  GET https://api.hubapi.com/crm/v3/objects/deals?limit=100&properties=dealname,amount,dealstage,closedate,pipeline
  Headers:
    Authorization: Bearer pat-na1-xxxxxx-xxxx-xxxx-xxxx
  ```

### B. Contatos (Contacts) - Foco em Leads e Engajamento
* **Endpoint:** `GET https://api.hubapi.com/crm/v3/objects/contacts`
* **Propriedades úteis:** `firstname,lastname,email,phone,lifecyclestage,createdate`.

### C. Empresas (Companies) - Foco em Contas B2B
* **Endpoint:** `GET https://api.hubapi.com/crm/v3/objects/companies`
* **Propriedades úteis:** `name,domain,industry,annualrevenue,city`.

---

## 4. Engenharia de Prompts para Relatórios de CRM

Ao conversar com o assistente inteligente ou ao configurar os **AI Agents Orquestrados** no PASQUARED-OS, a forma como você estrutura o prompt dita a qualidade, a profundidade matemática e a confiabilidade do relatório de saída.

### A Estrutura do Prompt Perfeito (Contexto + Dados + Tarefa + Formato)
Para extrair análises do HubSpot de forma precisa, use uma abordagem estruturada em quatro pilares:
1. **Persona/Papel:** Defina o papel do agente de IA (Ex: Analista de Inteligência de Negócios e Operações de Vendas - RevOps).
2. **Contexto dos Dados:** Indique quais dados estão conectados (Ex: "A conexão com a API do HubSpot está ativa fornecendo dados estruturados do objeto Deals com faturamento e status").
3. **A Tarefa Analítica:** Descreva o cálculo, comparação ou agrupamento desejado.
4. **Formato de Saída (Output):** Especifique a formatação do relatório (Ex: Tabela markdown, lista de insights prioritários, resumo executivo ou gráficos recomendados).

---

## 5. Modelos de Prompts Prontos para Uso (Perguntas Práticas)

Aqui estão modelos de prompts prontos que você pode copiar, preencher e enviar para o chat do PASQUARED-OS para gerar relatórios:

### Prompt 1: Relatório de Saúde do Funil e Previsão de Faturamento (Forecasting)
> **Prompt:**
> "Aja como um Diretor de RevOps de alta performance. Utilizando os dados brutos extraídos do endpoint `/crm/v3/objects/deals` (com as propriedades `dealname`, `amount`, `dealstage` e `closedate`), elabore um **Relatório de Previsão de Vendas e Saúde do Funil**.
> 
> Calcule e organize as informações nos seguintes tópicos:
> 1. **Faturamento Total sob Negociação:** Soma total de todos os negócios abertos.
> 2. **Negócios por Etapa do Funil:** Distribuição de quantidade e valor em cada `dealstage`.
> 3. **Ticket Médio dos Negócios:** Média de valor por negócio ativo.
> 4. **Previsão Ponderada (Weighted Forecast):** Se possível, estime a probabilidade padrão de fechamento por etapa para prever a receita provável.
> 
> Apresente os resultados em formato de Tabela Markdown clara, seguida de 3 recomendações de ação para acelerar os negócios parados."

### Prompt 2: Análise de Produtividade e Conversão de Leads (Contacts)
> **Prompt:**
> "Aja como um Analista de BI especializado em marketing e vendas. Analise o conjunto de dados retornado por `/crm/v3/objects/contacts` contendo `lifecyclestage`, `createdate` e `industry`.
> 
> Forneça uma análise contendo:
> 1. Uma tabela que agrupa a quantidade de leads por **Lifecycle Stage** (ex: Lead, MQL, SQL, Cliente, Oportunidade).
> 2. O percentual que cada estágio representa sobre o total de leads ativos.
> 3. Identifique quais são os 3 segmentos de mercado (`industry`) mais comuns entre os nossos leads.
> 4. Explique se há alguma inconsistência ou leads 'órfãos' que parecem estar parados na transição de MQL para SQL."

### Prompt 3: Auditoria Forense de Gargalos no Funil (Deals Estagnados)
> **Prompt:**
> "Aja como um Auditor de Processos de Negócio. Analise os dados de vendas do HubSpot focando em riscos de fechamento e negócios estagnados.
> 
> Responda às seguintes perguntas analíticas baseando-se nos dados do CRM:
> 1. Quais são as 5 maiores oportunidades atualmente abertas no pipeline cujo valor (`amount`) está acima do ticket médio, e que ainda não fecharam?
> 2. Como as políticas de governança do PASQUARED-OS (como limites de concessão de desconto ou autorização de crédito) devem atuar nesses 5 negócios?
> 3. Quais métricas estão apontando desvios em relação à nossa meta de faturamento trimestral?
> 
> Apresente a resposta com foco executivo, usando marcadores visuais e um resumo de risco para a diretoria."

---

## 6. Boas Práticas, Limites de Taxa (Rate Limits) & Solução de Problemas

Ao operar relatórios via chamadas constantes à API do HubSpot, atente-se às seguintes diretrizes operacionais para evitar quedas de integração:

### A. Limites de Requisições do HubSpot (Rate Limits)
* **Limite Padrão:** As contas do HubSpot limitam as chamadas de API de aplicativos privados a um máximo de **100 a 150 requisições a cada 10 segundos** (dependendo da assinatura da conta).
* **Solução no PASQUARED-OS:** O Módulo de Conectores do PASQUARED possui controle automático de *Rate Limiting* e mecanismo de retentativa inteligente com recuo exponencial (Exponential Backoff). Não tente atualizar os relatórios em loops de segundos; prefira sincronizações intervaladas de 5 minutos, 1 hora ou diárias.

### B. Paginação para Grandes Volumes de Dados
* Se sua empresa possui mais de 100 contatos ou negócios, o HubSpot não retornará todos de uma vez. O endpoint incluirá um objeto `paging` na resposta JSON contendo um link e um token de continuação:
  ```json
  "paging": {
    "next": {
      "after": "NTg1NjI4MzI=",
      "link": "https://api.hubapi.com/crm/v3/objects/deals?limit=100&after=NTg1NjI4MzI="
    }
  }
  ```
* **Dica de Pergunta ao Assistente:** Se você perceber que dados estão faltando, peça para o assistente:
  * *"Agente, verifique se a extração do HubSpot está paginando corretamente e consolide todos os blocos de dados antes de computar as médias."*

### C. Segurança e LGPD
* Nunca inclua o Token de Acesso Privado do HubSpot diretamente em seus Prompts de conversação! O token deve ser mantido estritamente no cofre de senhas do PASQUARED-OS (Vault de Conectores TI). Os agentes de IA herdam o acesso de forma segura através de variáveis de ambiente do sistema, garantindo conformidade absoluta com a LGPD e GDPR.

---

## 7. Como Acessar a IA no PASQUARED-OS e Guia de Comandos Conversacionais

Para operar as capacidades de Inteligência Artificial do PASQUARED-OS, você possui três principais interfaces de prompt localizadas no Menu Lateral do painel:

### A. Onde Acessar os Módulos de Prompt
1. **AI Gateway (Multi-Model Hub):** No menu lateral, clique em **AI Gateway (Multi-Model)**. Este é o ambiente ideal para consultas rápidas e testes comparativos. Selecione o provedor (Google, OpenAI, etc.), digite seu prompt na caixa de texto e clique em **Enviar Prompt**.
2. **AI Agents Orquestrados:** No menu lateral, clique em **AI Agents Orquestrados**. Este é um canal conversacional guiado com especialistas dedicados (Finanças, Crédito, LGPD, etc.) que geram fluxos interativos de perguntas e respostas antes de entregar o parecer final.
3. **Decision Intelligence:** No menu lateral, clique em **Decision Intelligence**. Este módulo combina seu prompt com o controle fino do **Vetor Cognitivo** $h = (p, c, m, e, l)$. Ajuste os controles deslizantes de viés regulatório e clique em **Iniciar Análise Cognitiva** para obter pareceres ético-legais.

---

## 8. Passo a Passo de Comandos Práticos para Operar a IA

Siga este roteiro de comandos para extrair relatórios perfeitos e insights analíticos diretamente na interface de prompt do seu módulo preferido:

| Comando / Prompt de Entrada | Objetivo Operacional | Resposta Esperada da IA |
| :--- | :--- | :--- |
| `[Definir Persona] Aja como Diretor de RevOps especialista em CRM.` | Iniciar uma sessão analítica de alto nível definindo a autoridade da IA. | A IA responderá adotando a postura e jargões de um analista de RevOps experiente. |
| `[Mapear Conexão] Consolide as fontes de dados do conector do HubSpot para o domínio apps.pasquared.space.` | Forçar o motor de IA a direcionar o raciocínio para os dados integrados do CRM. | A IA confirmará o recebimento e mapeamento estrutural de Deals e Contatos. |
| `[Filtrar Período] Analise os negócios com fechamento previsto para este trimestre.` | Delimitar o escopo temporal para evitar poluição de dados antigos ou irrelevantes. | Isolamento dos dados com propriedades de data (`closedate`) correspondentes. |
| `[Estruturar Tabela] Formate a receita estimada por estágio do funil em tabela Markdown.` | Obter uma representação visual clara dos números para cópia direta. | Uma tabela contendo Estágio, Quantidade de Negócios e Valor Acumulado. |
| `[Auditar Riscos] Identifique anomalias nos negócios marcados como perdidos ou estagnados.` | Fazer auditoria de segurança corporativa sobre o CRM. | Uma listagem com anomalias de transição de status de venda e propostas paradas. |
| `[Gerar PDF] Elabore a síntese final deste relatório no formato de Resumo Executivo para Diretoria.` | Obter uma redação pronta para uso em e-mails corporativos ou atas de reunião. | Um resumo executivo contendo introdução, descobertas-chave e recomendações de governança. |

