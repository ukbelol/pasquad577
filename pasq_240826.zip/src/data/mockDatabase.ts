/**
 * PASQUARED Enterprise AI Governance - Comprehensive Mock Database
 * Multi-tenant seed data, Super Admin credentials, AI Models, Policies, Risks & Clusters
 */

import {
  Tenant,
  User,
  ObserverProfile,
  CognitiveCluster,
  AIGatewayModel,
  AIAgent,
  GovernancePolicy,
  RiskItem,
  ComplianceControl,
  DecisionRecord,
  AutomationWorkflow,
  EKO,
  DynamicInsight,
  KnowledgeBaseSource
} from '../types/pasquared';

// 1. Super Admin default credentials
export const SUPER_ADMIN_CREDENTIALS = {
  email: 'roger577@pasquared.space',
  password: '21121201@Roger',
  name: 'Roger Mei (Super Admin Root & Chief AI Architect)',
  role: 'SuperAdmin' as const
};

// 2. Tenants (Multi-tenancy)
export const INITIAL_TENANTS: Tenant[] = [];

// 3. Current Observer Profiles
export const OBSERVER_PROFILES: ObserverProfile[] = [
  {
    id: 'obs-roger',
    name: 'Roger S. (Super Admin & Epistemologist)',
    role: 'Chief AI Governance Architect',
    P: 0.94,
    E: 0.30,
    K: 0.96,
    B: 0.15,
    domainAffinity: ['Governança de IA', 'Epistemologia', 'Segurança de Modelos', 'Compliance']
  },
  {
    id: 'obs-compliance',
    name: 'Dra. Helena Martins (Compliance Officer)',
    role: 'Head of Regulatory Affairs',
    P: 0.91,
    E: 0.40,
    K: 0.90,
    B: 0.25,
    domainAffinity: ['EU AI Act', 'Direito Civil', 'LGPD/GDPR', 'Bioética']
  },
  {
    id: 'obs-risk',
    name: 'Carlos Mendez (Risk Officer)',
    role: 'Enterprise Risk Manager',
    P: 0.88,
    E: 0.45,
    K: 0.85,
    B: 0.35,
    domainAffinity: ['Finanças', 'Risco Operacional', 'Fraude', 'Auditoria']
  },
  {
    id: 'obs-engineer',
    name: 'Lucas Tanaka (AI Systems Engineer)',
    role: 'Lead MLOps & Cognitive Architect',
    P: 0.95,
    E: 0.20,
    K: 0.92,
    B: 0.10,
    domainAffinity: ['Clusters Kubernetes', 'Algoritmos Cognitivos', 'Model Gateway', 'APIs']
  }
];

// 4. Cognitive Clusters (Kubernetes / Worker Nodes)
export const INITIAL_CLUSTERS: CognitiveCluster[] = [
  {
    id: 'clus-gov',
    name: 'Cluster de Governança & IA Ética',
    domain: 'Governança & Políticas',
    subdomains: ['NIST AI RMF', 'ISO/IEC 42001', 'EU AI Act', 'Auditoria Algorítmica'],
    loadPercentage: 42,
    activeEKOs: 1240,
    accuracyRate: 99.4,
    status: 'online',
    workerNode: 'k8s-worker-node-alpha-us'
  },
  {
    id: 'clus-med',
    name: 'Cluster Médico-Científico & Bioética',
    domain: 'Medicina & Saúde',
    subdomains: ['Cardiologia', 'Farmacologia', 'Bioética', 'Diagnóstico Assistido'],
    loadPercentage: 68,
    activeEKOs: 3820,
    accuracyRate: 98.9,
    status: 'online',
    workerNode: 'k8s-worker-node-beta-med'
  },
  {
    id: 'clus-law',
    name: 'Cluster Jurídico & Regulatório',
    domain: 'Direito & Compliance',
    subdomains: ['Direito Civil', 'Direito do Consumidor', 'Contratos Inteligentes', 'LGPD'],
    loadPercentage: 55,
    activeEKOs: 2190,
    accuracyRate: 99.1,
    status: 'online',
    workerNode: 'k8s-worker-node-gamma-jur'
  },
  {
    id: 'clus-fin',
    name: 'Cluster de Finanças & Matriz de Risco',
    domain: 'Finanças & Economia',
    subdomains: ['Análise de Risco de Crédito', 'Prevenção à Fraude', 'Mercado de Capitais'],
    loadPercentage: 74,
    activeEKOs: 4500,
    accuracyRate: 99.6,
    status: 'online',
    workerNode: 'k8s-worker-node-delta-fin'
  },
  {
    id: 'clus-sec',
    name: 'Cluster de Cibersegurança & PII Guard',
    domain: 'Cibersegurança & Criptografia',
    subdomains: ['Detecção de Vazamentos PII', 'Sanitização de Prompts', 'Assinaturas TEE'],
    loadPercentage: 38,
    activeEKOs: 1980,
    accuracyRate: 99.9,
    status: 'online',
    workerNode: 'k8s-worker-node-epsilon-sec'
  }
];

// 5. AI Gateway Models (Microsoft, IBM, Google, OpenAI, Local)
export const INITIAL_AI_MODELS: AIGatewayModel[] = [
  {
    id: 'model-google-gemini-25',
    name: 'Google Gemini 2.5 Flash',
    provider: 'Google',
    modelFamily: 'Gemini Generative Engine',
    endpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash',
    contextWindow: 1048576,
    latencyMs: 310,
    costPer1kTokens: 0.00015,
    status: 'available',
    isPasquaredProtected: true,
    pasquaredInterceptionRules: ['MVED Validation', 'PII Masking', 'Hallucination Pruning']
  },
  {
    id: 'model-google-gemini-pro',
    name: 'Google Gemini 2.5 Pro (Deep Reasoning)',
    provider: 'Google',
    modelFamily: 'Gemini Pro Multimodal',
    endpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro',
    contextWindow: 2097152,
    latencyMs: 680,
    costPer1kTokens: 0.00125,
    status: 'available',
    isPasquaredProtected: true,
    pasquaredInterceptionRules: ['MVED Validation', 'Hypothesis Elimination', 'SMEE Memory Sync']
  },
  {
    id: 'model-msft-azure-gpt4o',
    name: 'Microsoft Azure OpenAI GPT-4o',
    provider: 'Microsoft',
    modelFamily: 'Azure Foundry / OpenAI Engine',
    endpoint: 'https://pasquared-foundry.openai.azure.com/deployments/gpt-4o',
    contextWindow: 128000,
    latencyMs: 450,
    costPer1kTokens: 0.0025,
    status: 'available',
    isPasquaredProtected: true,
    pasquaredInterceptionRules: ['MVED Validation', 'Zero Data Retention Policy', 'Audit Log PRE']
  },
  {
    id: 'model-ibm-granite',
    name: 'IBM Watsonx Granite 3.0 Enterprise',
    provider: 'IBM',
    modelFamily: 'IBM Watsonx AI Foundation',
    endpoint: 'https://us-south.ml.cloud.ibm.com/v1/deployments/granite-3-8b-instruct',
    contextWindow: 32768,
    latencyMs: 380,
    costPer1kTokens: 0.0004,
    status: 'available',
    isPasquaredProtected: true,
    pasquaredInterceptionRules: ['Enterprise Compliance', 'NIST Governance', 'MVED Check']
  },
  {
    id: 'model-local-llama3',
    name: 'Local Llama-3 70B (Isolated On-Prem Worker)',
    provider: 'Local-Cluster',
    modelFamily: 'Local Private Air-Gapped',
    endpoint: 'http://k8s-cluster.internal:8000/v1/completions',
    contextWindow: 8192,
    latencyMs: 190,
    costPer1kTokens: 0.0,
    status: 'available',
    isPasquaredProtected: true,
    pasquaredInterceptionRules: ['Total Air-Gap Isolation', 'Strict EKO Storage']
  }
];

// 6. AI Agents Orchestrated by PASQUARED
export const INITIAL_AI_AGENTS: AIAgent[] = [
  {
    id: 'agent-credit-analyst',
    tenantId: 'tenant-global',
    name: 'Auditor de Risco de Crédito & Finanças',
    role: 'Financial Decision Analyst',
    description: 'Formula perguntas contextuais sobre perfil do cliente e avalia hipóteses financeiras via PASQUARED MVED',
    modelId: 'model-msft-azure-gpt4o',
    clusterTarget: 'clus-fin',
    systemPrompt: 'Você é um agente bancário de elite. Antes de aprovar qualquer crédito, consulte o PASQUARED Controller.',
    status: 'active',
    governanceLimits: {
      maxTokensPerCall: 4000,
      allowHighRiskActions: false,
      requireHumanApprovalThreshold: 0.70
    },
    totalCalls: 3420,
    avgConfidence: 0.94
  },
  {
    id: 'agent-clinical-validator',
    tenantId: 'tenant-health',
    name: 'Assistente de Validação Clínica & Bioética',
    role: 'Clinical Protocol Evaluator',
    description: 'Analisa prescrições e dosagens, gerando perguntas diagnósticas que são validadas pelo cluster médico do PASQUARED',
    modelId: 'model-google-gemini-pro',
    clusterTarget: 'clus-med',
    systemPrompt: 'Você é um assistente de apoio à decisão médica com foco em bioética e segurança do paciente.',
    status: 'active',
    governanceLimits: {
      maxTokensPerCall: 8000,
      allowHighRiskActions: false,
      requireHumanApprovalThreshold: 0.85
    },
    totalCalls: 1890,
    avgConfidence: 0.98
  },
  {
    id: 'agent-compliance-guard',
    tenantId: 'tenant-global',
    name: 'Guardião de Políticas EU AI Act & ISO 42001',
    role: 'Automated Regulatory Auditor',
    description: 'Inspeção contínua de pipelines de IA para garantir rastreabilidade epistêmica e ausência de vieses ilegais',
    modelId: 'model-ibm-granite',
    clusterTarget: 'clus-gov',
    systemPrompt: 'Você é o guardião de conformidade. Teste todas as saídas contra os artigos do EU AI Act.',
    status: 'active',
    governanceLimits: {
      maxTokensPerCall: 6000,
      allowHighRiskActions: true,
      requireHumanApprovalThreshold: 0.60
    },
    totalCalls: 6710,
    avgConfidence: 0.96
  }
];

// 7. Governance Policies
export const INITIAL_POLICIES: GovernancePolicy[] = [
  {
    id: 'pol-pii-protection',
    tenantId: 'tenant-global',
    name: 'Sanitização Automática de Dados Pessoais (PII & LGPD)',
    description: 'Bloqueia ou anonimiza CPFs, cartões, e-mails e registros de saúde antes do envio ao Model Gateway',
    category: 'Privacy & PII',
    severity: 'critical',
    actionOnViolation: 'block',
    isActive: true,
    violationsCount: 14,
    ruleDefinition: 'IF input CONTAINS [CPF, SSN, CreditCard, MedicalRecord] THEN MASK(token) AND AUDIT_LOG(PRE)'
  },
  {
    id: 'pol-eu-ai-act-risk',
    tenantId: 'tenant-global',
    name: 'Salvaguarda de Alto Risco - EU AI Act Art. 14',
    description: 'Exige supervisão humana para decisões de alto impacto social, financeiro ou clínico',
    category: 'Regulatory',
    severity: 'high',
    actionOnViolation: 'require_approval',
    isActive: true,
    violationsCount: 8,
    ruleDefinition: 'IF decision.impactScore >= 4 AND decision.igaScore < 0.85 THEN PAUSE_WORKFLOW AND REQUEST_HUMAN_APPROVAL'
  },
  {
    id: 'pol-hallucination-pruning',
    tenantId: 'tenant-global',
    name: 'Eliminação de Alucinação Epistemológica (MVED)',
    description: 'Exige que toda afirmação fática possua correspondência em pelo menos 1 EKO ou evidência no SMEE',
    category: 'Hallucination & Grounding',
    severity: 'high',
    actionOnViolation: 're-route',
    isActive: true,
    violationsCount: 29,
    ruleDefinition: 'IF hypothesis.posteriorP < 0.45 OR hypothesis.ici < 0.68 THEN PRUNE_HYPOTHESIS'
  },
  {
    id: 'pol-fairness-bias',
    tenantId: 'tenant-global',
    name: 'Neutralidade Demográfica & Detecção de Viés',
    description: 'Avalia se as probabilidades de ativação cognitiva (PAC) apresentam disparidade estatística injustificada',
    category: 'Bias & Fairness',
    severity: 'medium',
    actionOnViolation: 'warn',
    isActive: true,
    violationsCount: 5,
    ruleDefinition: 'IF biasScoreVariance > 0.05 THEN NOTIFY_COMPLIANCE_OFFICER'
  }
];

// 8. Risk Management Matrix (5x5 Probability x Impact)
export const INITIAL_RISKS: RiskItem[] = [
  {
    id: 'risk-01',
    tenantId: 'tenant-global',
    title: 'Alucinação em Parecer de Crédito com Impacto Financeiro',
    category: 'Model Performance',
    probability: 2,
    impact: 4,
    score: 8,
    status: 'mitigated',
    mitigationPlan: 'Obrigatória passagem pelo PASQUARED Controller com MVED ativo e corte IGA mínimo de 0.80',
    associatedAgentId: 'agent-credit-analyst',
    lastAssessed: '2026-08-18'
  },
  {
    id: 'risk-02',
    tenantId: 'tenant-global',
    title: 'Vazamento Involuntário de PII em Treinamento de Terceiros',
    category: 'Security & Data',
    probability: 1,
    impact: 5,
    score: 5,
    status: 'mitigated',
    mitigationPlan: 'Ativação de Zero Data Retention em Azure e Gemini + Anonimização local pré-UCL',
    lastAssessed: '2026-08-19'
  },
  {
    id: 'risk-03',
    tenantId: 'tenant-global',
    title: 'Não-conformidade com Requisitos de Transparência do EU AI Act',
    category: 'Regulatory',
    probability: 2,
    impact: 5,
    score: 10,
    status: 'assessing',
    mitigationPlan: 'Geração automática de documentação técnica e trilha PRE criptografada para cada decisão',
    associatedAgentId: 'agent-compliance-guard',
    lastAssessed: '2026-08-20'
  },
  {
    id: 'risk-04',
    tenantId: 'tenant-health',
    title: 'Divergência de Dosagem Medicamentosa em Diagnóstico Assistido',
    category: 'Ethical',
    probability: 1,
    impact: 5,
    score: 5,
    status: 'mitigated',
    mitigationPlan: 'Human-in-the-loop obrigatório com assinatura digital médica para qualquer prescrição',
    associatedAgentId: 'agent-clinical-validator',
    lastAssessed: '2026-08-17'
  },
  {
    id: 'risk-05',
    tenantId: 'tenant-fintech',
    title: 'Indisponibilidade ou Latência Excessiva do Model Gateway em Pico',
    category: 'Operational',
    probability: 3,
    impact: 3,
    score: 9,
    status: 'identified',
    mitigationPlan: 'Roteamento inteligente com fallback automático para cluster local Llama-3 On-Prem',
    lastAssessed: '2026-08-15'
  }
];

// 9. Compliance Controls (EU AI Act, ISO 42001, NIST AI RMF, LGPD)
export const INITIAL_COMPLIANCE_CONTROLS: ComplianceControl[] = [
  {
    id: 'comp-eu-09',
    framework: 'EU AI Act',
    controlCode: 'Art. 9 (Risk Management System)',
    title: 'Sistema Contínuo de Gestão de Riscos',
    description: 'Manter sistema iterativo de identificação, análise e mitigação de riscos ao longo do ciclo de vida da IA',
    status: 'compliant',
    evidenceCount: 42,
    lastAuditDate: '2026-08-10'
  },
  {
    id: 'comp-eu-10',
    framework: 'EU AI Act',
    controlCode: 'Art. 10 (Data & Data Governance)',
    title: 'Governança e Qualidade dos Dados de Treinamento e Ingestão',
    description: 'Garantir que os datasets passem por validação ontológica POKO e testes estatísticos de viés',
    status: 'compliant',
    evidenceCount: 28,
    lastAuditDate: '2026-08-12'
  },
  {
    id: 'comp-eu-14',
    framework: 'EU AI Act',
    controlCode: 'Art. 14 (Human Oversight)',
    title: 'Supervisão Humana Efetiva e Capacidade de Intervenção',
    description: 'Interface clara com capacidade de parada de emergência e aprovação de ações críticas',
    status: 'compliant',
    evidenceCount: 56,
    lastAuditDate: '2026-08-15'
  },
  {
    id: 'comp-iso-42001',
    framework: 'ISO/IEC 42001',
    controlCode: 'A.6.2 (AI System Lifecycle)',
    title: 'Trilha de Auditoria e Rastreabilidade do Ciclo de Decisão',
    description: 'Registro criptográfico imutável de todas as transformações de UCIs em EKOs no PRE',
    status: 'compliant',
    evidenceCount: 89,
    lastAuditDate: '2026-08-18'
  },
  {
    id: 'comp-nist-gov',
    framework: 'NIST AI RMF',
    controlCode: 'GOVERN 1.2',
    title: 'Papeis, Responsabilidades e Transparência Organizacional',
    description: 'Definição formal de perfis de Observadores O=(P,E,K,B) e matriz RACI na governança',
    status: 'compliant',
    evidenceCount: 19,
    lastAuditDate: '2026-08-05'
  },
  {
    id: 'comp-lgpd-art6',
    framework: 'LGPD/GDPR',
    controlCode: 'Art. 6 (Finalidade & Necessidade)',
    title: 'Minimização de Dados e Tratamento Estrito ao Contexto',
    description: 'UCL Parser descarta metadados não autorizados e aplica anonimização instantânea',
    status: 'compliant',
    evidenceCount: 37,
    lastAuditDate: '2026-08-14'
  }
];

// 10. Sample EKOs and Knowledge Items
export const INITIAL_EKOS: EKO[] = [
  {
    id: 'eko-fin-001',
    version: '1.2.0',
    title: 'Política de Risco de Crédito Imobiliário com Garantia Real',
    domain: 'Finanças & Economia',
    ucis: ['uci-fin-01', 'uci-fin-02', 'uci-fin-03'],
    hypotheses: [
      {
        id: 'hyp-fin-1',
        statement: 'Aprovar financiamento com taxa bonificada se LTV < 60% e DTI < 30%',
        domain: 'Finanças',
        vector: { p: 0.95, c: 0.90, m: 0.88, e: 0.20, l: 0.98 },
        priorProbability: 0.60,
        likelihood: 0.94,
        posteriorP: 0.92,
        igaScore: 0.91,
        status: 'selected',
        evidences: ['Histórico bancário favorável', 'Garantia com matrícula registrada'],
        counterEvidences: []
      }
    ],
    evidences: ['Resolução BACEN 4.676', 'Histórico de 10 anos de inadimplência < 1.2%'],
    graph: {
      nodes: [
        {
          uid: 'uci-fin-01',
          content: 'LTV (Loan to Value) máximo de 60%',
          type: 'concept',
          source: 'Manual de Risco de Crédito',
          category: 'Finanças',
          theme: 'Garantias',
          group: 'Risco',
          w: 0.95,
          ct: 0.90,
          mi: 0.85,
          ei: 0.10,
          timestamp: '2026-08-01T00:00:00Z',
          confidence: 0.96,
          pac: 0.92
        },
        {
          uid: 'uci-fin-02',
          content: 'DTI (Debt to Income) máximo de 30% da renda líquida familiar',
          type: 'concept',
          source: 'Manual de Risco de Crédito',
          category: 'Finanças',
          theme: 'Capacidade de Pagamento',
          group: 'Risco',
          w: 0.90,
          ct: 0.85,
          mi: 0.80,
          ei: 0.10,
          timestamp: '2026-08-01T00:00:00Z',
          confidence: 0.93,
          pac: 0.88
        }
      ],
      edges: [
        {
          fromUid: 'uci-fin-01',
          toUid: 'uci-fin-02',
          type: 'logical',
          w: 0.88,
          description: 'Relação de solvência e cobertura mútua de risco'
        }
      ]
    },
    confidence: 0.93,
    maturity: 'consolidated',
    insights: [
      {
        insightID: 'ins-fin-001',
        originEkoID: 'eko-fin-001',
        category: 'Finanças',
        theme: 'Crédito Imobiliário',
        group: 'Mitigação de Inadimplência',
        noveltyScore: 0.72,
        confidence: 0.93,
        impact: 'high',
        statement: 'A vinculação estrita de LTV e DTI sob validação MVED reduz o risco de inadimplência em 84% frente ao modelo linear tradicional.',
        derivedClusters: ['clus-fin', 'clus-gov'],
        relatedHypotheses: ['hyp-fin-1'],
        timestamp: '2026-08-02T10:00:00Z'
      }
    ],
    selectedMeaning: 'Aprovação de crédito condicionada estritamente aos parâmetros de segurança LTV e DTI com rastreabilidade auditável.',
    iga: 0.91,
    ici: 0.94,
    timestamp: '2026-08-02T10:00:00Z'
  }
];

// 11. Workflows
export const INITIAL_WORKFLOWS: AutomationWorkflow[] = [
  {
    id: 'wf-high-risk-intercept',
    tenantId: 'tenant-global',
    name: 'Intercepção Automática de Transações com Risco Elevado',
    triggerEvent: 'RISK_THRESHOLD_EXCEEDED',
    steps: [
      '1. Capturar payload via UCL Parser',
      '2. Executar PASQUARED SAC (Níveis 1 a 6)',
      '3. Avaliar Matriz de Risco 5x5',
      '4. Se Risco > 12: Pausar e notificar Risk Officer no Slack/Teams',
      '5. Após aprovação humana: Emitir EKO com assinatura criptográfica TEE'
    ],
    status: 'active',
    executionsCount: 418,
    lastRun: '2026-08-20T13:40:00Z'
  },
  {
    id: 'wf-compliance-nightly',
    tenantId: 'tenant-global',
    name: 'Auditoria Noturna Contínua de Conformidade EU AI Act',
    triggerEvent: 'SCHEDULED_AUDIT',
    steps: [
      '1. Varrer todos os EKOs gerados nas últimas 24 horas',
      '2. Executar PQL: VALIDATE Artigos_EU_AI_Act',
      '3. Calcular índice de consistência global (ICI)',
      '4. Atualizar dashboard de governança executiva'
    ],
    status: 'active',
    executionsCount: 182,
    lastRun: '2026-08-20T03:00:00Z'
  }
];

// 12. Knowledge Bases (Public & Private across all areas)
export const INITIAL_KNOWLEDGE_BASES: KnowledgeBaseSource[] = [
  // Bases Públicas
  {
    id: 'kb-pub-legal-eu',
    name: 'União Europeia • EU AI Act & GDPR Corpus Oficial',
    area: 'Jurídico & Regulatório',
    scope: 'public',
    sourceUrlOrHost: 'https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R1689',
    authMethod: 'public_no_auth',
    recordsCount: 14820,
    lastSyncedAt: '2026-08-20T14:30:00Z',
    status: 'connected',
    description: 'Corpus integral do Regulamento (UE) 2024/1689 (EU AI Act), diretrizes de classificação de risco e obrigações de transparência.',
    mappedDimension: 'Salvaguarda & Risco (δ)',
    autoSync: true,
    format: 'PDF/Docs'
  },
  {
    id: 'kb-pub-fin-bacen',
    name: 'BACEN / CVM • Normativas de Risco, Open Finance & Pix',
    area: 'Financeiro & Bancário',
    scope: 'public',
    sourceUrlOrHost: 'https://www.bcb.gov.br/estabilidadefinanceira/buscanormas',
    authMethod: 'public_no_auth',
    recordsCount: 38400,
    lastSyncedAt: '2026-08-20T16:00:00Z',
    status: 'connected',
    description: 'Resoluções CMN, instruções normativas BACEN para risco de crédito, prevenção à lavagem de dinheiro (PLD-FT) e Basileia III.',
    mappedDimension: 'Evidência (α)',
    autoSync: true,
    format: 'REST Feed'
  },
  {
    id: 'kb-pub-med-pubmed',
    name: 'PubMed / NIH • Diretrizes Clínicas & Farmacopeia Global',
    area: 'Saúde & Medicina',
    scope: 'public',
    sourceUrlOrHost: 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils',
    authMethod: 'public_no_auth',
    recordsCount: 92150,
    lastSyncedAt: '2026-08-19T22:15:00Z',
    status: 'connected',
    description: 'Artigos indexados, interações medicamentosas, ensaios clínicos controlados e protocolos terapêuticos validados pela OMS/ANVISA.',
    mappedDimension: 'Evidência (α)',
    autoSync: true,
    format: 'Ontological Graph'
  },
  {
    id: 'kb-pub-tech-nist',
    name: 'NIST AI RMF & ISO/IEC 42001 Standard Frameworks',
    area: 'Tecnologia & Cibersegurança',
    scope: 'public',
    sourceUrlOrHost: 'https://csrc.nist.gov/publications/detail/white-paper/2023/01/26/ai-risk-management-framework',
    authMethod: 'public_no_auth',
    recordsCount: 8900,
    lastSyncedAt: '2026-08-20T11:00:00Z',
    status: 'connected',
    description: 'Mapas de controles de segurança, mitigação de vieses algorítmicos e frameworks de governança de inteligência artificial.',
    mappedDimension: 'Salvaguarda & Risco (δ)',
    autoSync: true,
    format: 'PDF/Docs'
  },
  {
    id: 'kb-pub-gov-lgpd',
    name: 'ANPD / Planalto • LGPD & Direito Civil Brasileiro',
    area: 'Governança & Risco',
    scope: 'public',
    sourceUrlOrHost: 'https://www.gov.br/anpd/pt-br/assuntos/legislacao-e-normas',
    authMethod: 'public_no_auth',
    recordsCount: 12450,
    lastSyncedAt: '2026-08-20T09:45:00Z',
    status: 'connected',
    description: 'Legislação nacional sobre proteção de dados pessoais (Lei nº 13.709/2018), guias orientativos de legítimo interesse e DPO.',
    mappedDimension: 'Salvaguarda & Risco (δ)',
    autoSync: true,
    format: 'PDF/Docs'
  },

  // Bases Privadas
  {
    id: 'kb-priv-corp-lake',
    tenantId: 'tenant-global',
    name: 'Nexus Corporate Lake • Manuais de Políticas & Dossiês Internos',
    area: 'Tecnologia & Cibersegurança',
    scope: 'private',
    sourceUrlOrHost: 's3://nexus-enterprise-private-lake.s3.sa-east-1.amazonaws.com/policies',
    authMethod: 'bearer_token',
    recordsCount: 54200,
    lastSyncedAt: '2026-08-20T17:10:00Z',
    status: 'connected',
    description: 'Repositório confidencial contendo procedimentos operacionais padrão (POP), políticas de RH, matriz de alçadas e segurança interna.',
    mappedDimension: 'Contexto Local (β)',
    autoSync: true,
    format: 'Vector Embedding'
  },
  {
    id: 'kb-priv-bank-scoring',
    tenantId: 'tenant-fintech',
    name: 'Aethel Credit Score Lake • Histórico de Decisões de Crédito (2020-2026)',
    area: 'Financeiro & Bancário',
    scope: 'private',
    sourceUrlOrHost: 'postgresql://risk_engine_user@db.aethelbank.internal:5432/scoring_lake',
    authMethod: 'mtls',
    recordsCount: 230400,
    lastSyncedAt: '2026-08-20T16:55:00Z',
    status: 'connected',
    description: 'Base privada com 230k deliberações de crédito, índices de inadimplência histórica e performance de garantias hipotecárias.',
    mappedDimension: 'Memória Histórica (γ)',
    autoSync: true,
    format: 'SQL Data Lake'
  },
  {
    id: 'kb-priv-health-protocols',
    tenantId: 'tenant-health',
    name: 'OmniHealth Clínico • Protocolos Hospitalares & Triagem Oncológica',
    area: 'Saúde & Medicina',
    scope: 'private',
    sourceUrlOrHost: 'https://clinical-ehr.omnihealth.internal/api/v2/protocols',
    authMethod: 'api_key',
    recordsCount: 18700,
    lastSyncedAt: '2026-08-20T15:20:00Z',
    status: 'connected',
    description: 'Protocolos de conduta assistencial do corpo clínico, limites de dosagem terapêutica e consentimentos livres e esclarecidos.',
    mappedDimension: 'Contexto Local (β)',
    autoSync: true,
    format: 'PDF/Docs'
  },
  {
    id: 'kb-priv-industry-eng',
    name: 'Atlas Engenharia • Projetos CAD/BIM & Telemetria Industrial IoT',
    area: 'Indústria & Engenharia',
    scope: 'private',
    sourceUrlOrHost: 'https://iot-telemetry.atlas-ind.internal:9443/lake',
    authMethod: 'bearer_token',
    recordsCount: 67300,
    lastSyncedAt: '2026-08-20T12:00:00Z',
    status: 'disconnected',
    description: 'Registros de manutenção preditiva, especificações técnicas de motores e tolerâncias mecânicas de linhas de produção.',
    mappedDimension: 'Evidência (α)',
    autoSync: false,
    format: 'SQL Data Lake'
  }
];

// Aliases for convenient importing
export const initialTenants = INITIAL_TENANTS;
export const initialClusters = INITIAL_CLUSTERS;
export const initialModels = INITIAL_AI_MODELS;
export const initialAgents = INITIAL_AI_AGENTS;
export const initialPolicies = INITIAL_POLICIES;
export const initialRisks = INITIAL_RISKS;
export const initialComplianceControls = INITIAL_COMPLIANCE_CONTROLS;
export const initialEKOs = INITIAL_EKOS;
export const initialWorkflows = INITIAL_WORKFLOWS;
export const initialKnowledgeBases = INITIAL_KNOWLEDGE_BASES;
export const mockObservers = OBSERVER_PROFILES;



