/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar, ActiveModule } from './components/Sidebar';
import { DashboardOverview } from './components/DashboardOverview';
import { PasquaredKernelView } from './components/PasquaredKernelView';
import { PQLConsole } from './components/PQLConsole';
import { SuperAdminMasterDashboardView } from './components/SuperAdminMasterDashboardView';
import { AIGatewayView } from './components/AIGatewayView';
import { AIAgentsView } from './components/AIAgentsView';
import { GovernancePoliciesView } from './components/GovernancePoliciesView';
import { RiskManagementView } from './components/RiskManagementView';
import { ComplianceView } from './components/ComplianceView';
import { DecisionIntelligenceView } from './components/DecisionIntelligenceView';
import { KnowledgeBaseView } from './components/KnowledgeBaseView';
import { WorkflowAutomationView } from './components/WorkflowAutomationView';
import { AuditTrailView } from './components/AuditTrailView';
import { TenantsRbacView } from './components/TenantsRbacView';
import { BillingView } from './components/BillingView';
import { IntegrationsView } from './components/IntegrationsView';
import { EnterpriseResourceManagementView } from './components/EnterpriseResourceManagementView';
import { MarketingLandingView } from './components/MarketingLandingView';
import { ClientAuthPage } from './components/ClientAuthPage';
import { ClientPersonalDashboard } from './components/ClientPersonalDashboard';
import { SystemInstallerModal } from './components/SystemInstallerModal';
import { AuthModal } from './components/AuthModal';
import { CompanyPortalModal } from './components/CompanyPortalModal';
import { CalibrationTuner } from './components/CalibrationTuner';
import { OperationsManualModal } from './components/OperationsManualModal';
import { PasquaredLogo } from './components/PasquaredLogo';

import {
  initialClusters,
  initialModels,
  initialAgents,
  initialPolicies,
  initialRisks,
  initialComplianceControls,
  initialEKOs,
  initialWorkflows,
  mockObservers
} from './data/mockDatabase';
import { Tenant, ObserverProfile, User } from './types/pasquared';

export type MainViewMode = 'landing' | 'client_auth' | 'client_dashboard' | 'superadmin_portal' | 'app_engine';

const defaultFallbackTenant: Tenant = {
  id: 'tenant-fallback',
  name: 'Empresa Demo',
  slug: 'empresa-demo',
  domain: 'demo.com',
  tier: 'Starter',
  createdAt: '2026-08-23',
  status: 'active',
  quotas: {
    monthlyTokens: 5000000,
    usedTokens: 0,
    maxAgents: 5,
    usedAgents: 0,
    maxUsers: 5,
    usedUsers: 1,
    maxStorageGB: 20,
    usedStorageGB: 0
  },
  clusterAllocations: []
};

export default function App() {
  const [tenantsList, setTenantsList] = useState<Tenant[]>([]);
  const [activeModule, setActiveModule] = useState<ActiveModule>('dashboard');
  const [currentTenant, setCurrentTenant] = useState<Tenant>(defaultFallbackTenant);
  const [currentObserver, setCurrentObserver] = useState<ObserverProfile>(mockObservers[0]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Keep track of collaborators for each tenant (multi-tenancy)
  const [collaboratorsMap, setCollaboratorsMap] = useState<Record<string, User[]>>({});
  const [dbLoaded, setDbLoaded] = useState(false);

  // Load database from persistent server storage on mount
  React.useEffect(() => {
    fetch('/api/db')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.db) {
          const db = data.db;
          if (db.tenants) {
            setTenantsList(db.tenants);
            if (db.tenants.length > 0) {
              setCurrentTenant(db.tenants[0]);
            }
          }
          if (db.collaboratorsMap) {
            setCollaboratorsMap(db.collaboratorsMap);
          }
        }
        setDbLoaded(true);
      })
      .catch(err => {
        console.error('Erro ao ler do banco de dados persistente:', err);
        setDbLoaded(true);
      });
  }, []);

  // Save database changes back to persistent server storage automatically on change
  React.useEffect(() => {
    if (!dbLoaded) return;
    fetch('/api/db/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tenants: tenantsList,
        collaboratorsMap: collaboratorsMap
      })
    }).catch(err => console.error('Erro ao atualizar banco de dados persistente:', err));
  }, [tenantsList, collaboratorsMap, dbLoaded]);

  const handleAddTeamMember = (tenantId: string, newMember: User) => {
    setCollaboratorsMap(prev => ({
      ...prev,
      [tenantId]: [...(prev[tenantId] || []), newMember]
    }));
  };

  const handleUpdateTeamMember = (tenantId: string, updatedMember: User) => {
    setCollaboratorsMap(prev => ({
      ...prev,
      [tenantId]: (prev[tenantId] || []).map(m => m.id === updatedMember.id ? updatedMember : m)
    }));
  };

  const handleUpdateTenant = (updatedTenant: Tenant) => {
    setTenantsList(prev => prev.map(t => t.id === updatedTenant.id ? updatedTenant : t));
    setCurrentTenant(prev => prev.id === updatedTenant.id ? updatedTenant : prev);
  };

  const handleUpgradePlan = (tenantId: string, newPlanTier: string) => {
    const isStarter = newPlanTier === 'Starter' || newPlanTier === 'starter';
    const isProfessional = newPlanTier === 'Professional' || newPlanTier === 'professional';
    
    const maxUsers = isStarter ? 5 : (isProfessional ? 25 : 100);
    const monthlyTokens = isStarter ? 500000 : (isProfessional ? 5000000 : 25000000);
    const maxStorageGB = isStarter ? 20 : (isProfessional ? 100 : 250);

    setTenantsList(prev => prev.map(t => {
      if (t.id === tenantId) {
        return {
          ...t,
          planTier: newPlanTier as any,
          quotas: {
            ...t.quotas,
            maxUsers,
            monthlyTokens,
            maxStorageGB
          }
        };
      }
      return t;
    }));

    setCurrentTenant(prev => {
      if (prev.id === tenantId) {
        return {
          ...prev,
          planTier: newPlanTier as any,
          quotas: {
            ...prev.quotas,
            maxUsers,
            monthlyTokens,
            maxStorageGB
          }
        };
      }
      return prev;
    });
  };

  // Top-Level View Router
  const [viewMode, setViewMode] = useState<MainViewMode>('landing');
  const [clientAuthMode, setClientAuthMode] = useState<'login' | 'register'>('login');
  const [selectedPlanTier, setSelectedPlanTier] = useState<string>('enterprise');

  // Modals state
  const [isInstallerOpen, setIsInstallerOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isCompanyPortalOpen, setIsCompanyPortalOpen] = useState(false);
  const [isCalibrationOpen, setIsCalibrationOpen] = useState(false);
  const [isManualOpen, setIsManualOpen] = useState(false);

  // Success notification banner
  const [registrationBanner, setRegistrationBanner] = useState<string | null>(null);

  const handleOpenClientLogin = () => {
    setClientAuthMode('login');
    setViewMode('client_auth');
  };

  const handleOpenClientRegister = (planTier: string = 'enterprise') => {
    setSelectedPlanTier(planTier);
    setClientAuthMode('register');
    setViewMode('client_auth');
  };

  const handleOpenSuperAdminLogin = () => {
    setViewMode('superadmin_portal');
  };

  const handleClientAuthSuccess = (tenant: Tenant, user: User, isNewRegistration: boolean) => {
    if (!tenantsList.some(t => t.id === tenant.id)) {
      setTenantsList(prev => [tenant, ...prev]);
      
      const domain = tenant.domain || `${tenant.slug}.com.br`;
      const prefix = (tenant.name || 'PAS').replace(/[^a-zA-Z0-9]/g, '').substring(0,3).toUpperCase();
      
      setCollaboratorsMap(prev => ({
        ...prev,
        [tenant.id]: [
          {
            id: 'admin',
            tenantId: tenant.id,
            name: tenant.cadastralData?.adminName || user.name || 'Gestor de TI',
            email: tenant.cadastralData?.adminEmail || user.email || `admin@${domain}`,
            role: 'TenantAdmin',
            department: tenant.cadastralData?.adminRole || user.department || 'TI & Governança',
            mfaEnabled: true,
            status: 'active',
            password: '123456',
            permissions: [
              'res-fin-fc', 'res-fin-cp', 'res-fin-dre', 
              'res-rh-fp', 'res-rh-gp', 'res-rh-ad', 
              'res-log-es', 'res-log-rf', 
              'res-ai-gate', 'res-ai-agent', 
              'res-ti-conn', 'res-gov-iga'
            ]
          },
          {
            id: 'usr-mock-1',
            tenantId: tenant.id,
            name: 'Carlos Oliveira',
            email: `carlos.oliveira@${domain}`,
            role: 'ComplianceOfficer',
            department: 'Financeiro',
            mfaEnabled: true,
            status: 'active',
            password: `${prefix}@car11/22/88`,
            permissions: ['res-fin-fc', 'res-fin-cp', 'res-ai-gate']
          },
          {
            id: 'usr-mock-2',
            tenantId: tenant.id,
            name: 'Mariana Souza',
            email: `mariana.souza@${domain}`,
            role: 'RiskManager',
            department: 'Recursos Humanos',
            mfaEnabled: true,
            status: 'active',
            password: `${prefix}@mar04/15/93`,
            permissions: ['res-rh-gp', 'res-rh-fp']
          }
        ]
      }));
    }
    setCurrentTenant(tenant);
    setCurrentUser(user);

    if (isNewRegistration) {
      setRegistrationBanner(
        `Parabéns! A empresa "${tenant.name}" foi cadastrada com sucesso com isolamento criptográfico do Kernel.`
      );
      setTimeout(() => setRegistrationBanner(null), 8000);
    }

    // Go to dedicated personalized client dashboard
    setViewMode('client_dashboard');
  };

  const handleSuperAdminAuthenticated = (adminUser: User) => {
    setCurrentUser(adminUser);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setViewMode('landing');
  };

  // Render 1: Marketing Landing Page
  if (viewMode === 'landing') {
    return (
      <MarketingLandingView
        onOpenClientLogin={handleOpenClientLogin}
        onOpenClientRegister={handleOpenClientRegister}
        onOpenSuperAdminLogin={handleOpenSuperAdminLogin}
        onExploreKernelDemo={() => setViewMode('app_engine')}
        currentUser={currentUser}
        onGoToDashboard={() => {
          if (currentUser?.role === 'SuperAdmin') {
            setViewMode('superadmin_portal');
          } else {
            setViewMode('client_dashboard');
          }
        }}
      />
    );
  }

  // Render 2: Client Auth Page (Login / Register)
  if (viewMode === 'client_auth') {
    return (
      <ClientAuthPage
        mode={clientAuthMode}
        initialPlanTier={selectedPlanTier}
        tenants={tenantsList}
        collaboratorsMap={collaboratorsMap}
        onSuccess={handleClientAuthSuccess}
        onBackToLanding={() => setViewMode('landing')}
        onSwitchToSuperAdmin={() => setViewMode('superadmin_portal')}
      />
    );
  }

  // Render 3: Super Admin Portal
  if (viewMode === 'superadmin_portal') {
    return (
      <div className="flex h-screen bg-[#030712] text-slate-100 overflow-hidden font-sans antialiased quantum-bg-glow flex-col">
        {/* Top Navbar */}
        <header className="h-16 bg-[#030d1a]/95 border-b border-amber-500/20 px-4 sm:px-8 flex items-center justify-between z-30 sticky top-0 shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setViewMode('landing')}
              className="text-xs text-slate-400 hover:text-amber-300 transition p-1.5 rounded-lg hover:bg-slate-900 flex items-center gap-1"
            >
              ← Página Inicial
            </button>
            <PasquaredLogo size="md" />
            <span className="hidden sm:inline-block text-xs font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full">
              PORTAL SUPER ADMIN ROOT
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setViewMode('app_engine')}
              className="text-xs text-cyan-300 hover:text-white font-semibold px-3 py-1.5 rounded-xl border border-cyan-500/30 hover:bg-cyan-950 transition"
            >
              Ver Cockpit do Kernel
            </button>
            {currentUser && (
              <button
                onClick={handleLogout}
                className="text-xs text-rose-400 hover:text-rose-300 font-semibold px-3 py-1.5 rounded-xl border border-rose-500/30 hover:bg-rose-950/40 transition"
              >
                Sair
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto custom-scrollbar">
          <SuperAdminMasterDashboardView
            clusters={initialClusters}
            models={initialModels}
            tenants={tenantsList}
            onUpdateTenants={setTenantsList}
            currentUser={currentUser}
            onOpenInstaller={() => setIsInstallerOpen(true)}
            onAuthenticateSuperAdmin={handleSuperAdminAuthenticated}
            onBackToLanding={() => setViewMode('landing')}
          />
        </main>

        <SystemInstallerModal
          isOpen={isInstallerOpen}
          onClose={() => setIsInstallerOpen(false)}
        />
      </div>
    );
  }

  // Render 4: Personalized Client Dashboard
  if (viewMode === 'client_dashboard') {
    return (
      <div className="flex h-screen bg-[#030712] text-slate-100 overflow-hidden font-sans antialiased quantum-bg-glow flex-col">
        {/* Header */}
        <header className="h-16 bg-[#030d1a]/95 border-b border-cyan-500/20 px-4 sm:px-8 flex items-center justify-between z-30 sticky top-0 shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setViewMode('landing')}
              className="text-xs text-slate-400 hover:text-cyan-300 transition p-1.5 rounded-lg hover:bg-slate-900"
            >
              ← Página Inicial
            </button>
            <span className="text-xs font-mono font-bold text-cyan-300 bg-cyan-500/10 border border-cyan-500/30 px-3 py-1 rounded-full">
              DASHBOARD PERSONALIZADO • {currentTenant.name.toUpperCase()}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setActiveModule('enterprise_feeder');
                setViewMode('app_engine');
              }}
              className="text-xs text-cyan-300 hover:text-white font-semibold px-3 py-1.5 rounded-xl border border-cyan-500/30 hover:bg-cyan-950 transition"
            >
              Gerenciar Conectores TI
            </button>
            <button
              onClick={() => setViewMode('app_engine')}
              className="text-xs text-emerald-300 hover:text-white font-semibold px-3 py-1.5 rounded-xl border border-emerald-500/30 hover:bg-emerald-950 transition"
            >
              Abrir Cockpit do Kernel
            </button>
            <button
              onClick={handleLogout}
              className="text-xs text-rose-400 hover:text-rose-300 font-semibold px-3 py-1.5 rounded-xl border border-rose-500/30 hover:bg-rose-950/40 transition"
            >
              Sair
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto custom-scrollbar">
          {registrationBanner && (
            <div className="m-4 p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-xs text-emerald-200 flex items-center justify-between shadow-[0_0_20px_rgba(16,185,129,0.25)] animate-in fade-in max-w-7xl mx-auto">
              <span>{registrationBanner}</span>
              <button onClick={() => setRegistrationBanner(null)} className="text-emerald-400 font-bold ml-4">✕</button>
            </div>
          )}

          <ClientPersonalDashboard
            tenant={currentTenant}
            currentUser={currentUser}
            observer={currentObserver}
            teamMembers={collaboratorsMap[currentTenant.id] || []}
            onAddTeamMember={(newMember) => handleAddTeamMember(currentTenant.id, newMember)}
            onUpdateTeamMember={(updatedMember) => handleUpdateTeamMember(currentTenant.id, updatedMember)}
            onUpgradePlan={(newPlanTier) => handleUpgradePlan(currentTenant.id, newPlanTier)}
            onUpdateTenant={handleUpdateTenant}
            onNavigateToKernel={() => {
              setActiveModule('kernel');
              setViewMode('app_engine');
            }}
            onNavigateToEnterpriseFeeder={() => {
              setActiveModule('enterprise_feeder');
              setViewMode('app_engine');
            }}
            onNavigateToPQL={() => {
              setActiveModule('pql');
              setViewMode('app_engine');
            }}
            onNavigateToAudit={() => {
              setActiveModule('audit');
              setViewMode('app_engine');
            }}
            onOpenUpgradeModal={() => {
              setActiveModule('billing');
              setViewMode('app_engine');
            }}
            onOpenManual={() => setIsManualOpen(true)}
          />
        </main>
      </div>
    );
  }

  // Render 5: The Full PASQUARED-OS Cockpit Engine (with Sidebar & Kernel Modules)
  return (
    <div className="flex h-screen bg-[#030712] text-slate-100 overflow-hidden font-sans antialiased quantum-bg-glow">
      {/* Global Sidebar */}
      <Sidebar
        activeModule={activeModule}
        onSelectModule={setActiveModule}
        isSuperAdmin={currentUser?.role === 'SuperAdmin'}
        activeRiskCount={initialRisks.filter(r => r.score >= 12).length}
        pendingApprovalsCount={initialPolicies.filter(p => p.actionOnViolation === 'require_approval').length}
        onOpenCompanyPortal={() => setViewMode('client_auth')}
        onOpenManual={() => setIsManualOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <Header
          currentTenant={currentTenant}
          tenants={tenantsList}
          onSelectTenant={setCurrentTenant}
          currentObserver={currentObserver}
          observers={mockObservers}
          onSelectObserver={setCurrentObserver}
          currentUser={currentUser}
          onOpenAuth={() => setViewMode('client_auth')}
          onOpenCompanyPortal={() => setViewMode('client_auth')}
          onOpenInstaller={() => setIsInstallerOpen(true)}
          onOpenPQL={() => setActiveModule('pql')}
          onOpenCalibrator={() => setIsCalibrationOpen(true)}
          onNavigateToEnterpriseFeeder={() => setActiveModule('enterprise_feeder')}
          onNavigateToSuperAdmin={() => setViewMode('superadmin_portal')}
          onOpenManual={() => setIsManualOpen(true)}
          onLogout={handleLogout}
        />

        {/* Top return bar to marketing / personal dashboard */}
        <div className="bg-slate-950/80 border-b border-cyan-500/20 px-4 py-1.5 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('landing')}
              className="text-cyan-400 hover:text-cyan-300 font-semibold"
            >
              ← Ver Propaganda de Marketing
            </button>
            <span>•</span>
            <button
              onClick={() => setViewMode('client_dashboard')}
              className="text-emerald-400 hover:text-emerald-300 font-semibold"
            >
              Dashboard do Cliente ({currentTenant.name})
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('superadmin_portal')}
              className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
            >
              Área Restrita Super Admin →
            </button>
          </div>
        </div>

        {/* Dynamic Route View Body */}
        <main className="flex-1 overflow-y-auto custom-scrollbar">
          {activeModule === 'dashboard' && (
            <DashboardOverview
              currentTenant={currentTenant}
              clusters={initialClusters}
              observer={currentObserver}
              onNavigate={(mod) => setActiveModule(mod as ActiveModule)}
            />
          )}

          {activeModule === 'enterprise_feeder' && (
            <EnterpriseResourceManagementView
              tenant={currentTenant}
              currentUser={currentUser}
              observer={currentObserver}
              onNavigateToKernel={() => setActiveModule('kernel')}
              onNavigateToAudit={() => setActiveModule('audit')}
            />
          )}

          {activeModule === 'kernel' && (
            <PasquaredKernelView observer={currentObserver} />
          )}

          {activeModule === 'pql' && (
            <PQLConsole observer={currentObserver} />
          )}

          {activeModule === 'superadmin' && (
            <SuperAdminMasterDashboardView
              clusters={initialClusters}
              models={initialModels}
              tenants={tenantsList}
              currentUser={currentUser}
              onOpenInstaller={() => setIsInstallerOpen(true)}
              onAuthenticateSuperAdmin={handleSuperAdminAuthenticated}
              onBackToLanding={() => setViewMode('landing')}
            />
          )}

          {activeModule === 'gateway' && (
            <AIGatewayView models={initialModels} />
          )}

          {activeModule === 'agents' && (
            <AIAgentsView agents={initialAgents} observer={currentObserver} />
          )}

          {activeModule === 'policies' && (
            <GovernancePoliciesView policies={initialPolicies} />
          )}

          {activeModule === 'risk' && (
            <RiskManagementView risks={initialRisks} />
          )}

          {activeModule === 'compliance' && (
            <ComplianceView controls={initialComplianceControls} />
          )}

          {activeModule === 'decision' && (
            <DecisionIntelligenceView observer={currentObserver} />
          )}

          {activeModule === 'knowledge' && (
            <KnowledgeBaseView ekos={initialEKOs} observer={currentObserver} />
          )}

          {activeModule === 'workflows' && (
            <WorkflowAutomationView workflows={initialWorkflows} />
          )}

          {activeModule === 'audit' && (
            <AuditTrailView />
          )}

          {activeModule === 'calibration' && (
            <div className="p-6">
              <CalibrationTuner
                isOpen={true}
                onClose={() => setActiveModule('dashboard')}
              />
            </div>
          )}

          {activeModule === 'tenants' && (
            <TenantsRbacView
              tenants={tenantsList}
              currentTenant={currentTenant}
              onSelectTenant={setCurrentTenant}
            />
          )}

          {activeModule === 'billing' && (
            <BillingView tenant={currentTenant} />
          )}

          {activeModule === 'integrations' && (
            <IntegrationsView />
          )}
        </main>
      </div>

      {/* Global Modals */}
      <SystemInstallerModal
        isOpen={isInstallerOpen}
        onClose={() => setIsInstallerOpen(false)}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLogin={(user) => {
          setCurrentUser(user);
          if (user.role === 'SuperAdmin') {
            setViewMode('superadmin_portal');
          } else {
            setViewMode('client_dashboard');
          }
        }}
      />

      <CompanyPortalModal
        isOpen={isCompanyPortalOpen}
        onClose={() => setIsCompanyPortalOpen(false)}
        onSuccess={handleClientAuthSuccess}
      />

      <CalibrationTuner
        isOpen={isCalibrationOpen}
        onClose={() => setIsCalibrationOpen(false)}
      />

      <OperationsManualModal
        isOpen={isManualOpen}
        onClose={() => setIsManualOpen(false)}
      />
    </div>
  );
}
