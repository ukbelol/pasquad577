import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  Brain,
  ShieldCheck,
  Zap,
  TrendingUp,
  AlertTriangle,
  FileCheck2,
  Cpu,
  ArrowRight,
  Play,
  CheckCircle,
  Layers,
  Activity
} from 'lucide-react';
import { Tenant, ObserverProfile, CognitiveCluster, DecisionRecord } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';
import { initialTenants } from '../data/mockDatabase';
import { DashboardWidget } from './DashboardWidget';
import { PasquaredLogo } from './PasquaredLogo';

interface DashboardOverviewProps {
  tenant?: Tenant;
  observer: ObserverProfile;
  clusters: CognitiveCluster[];
  onNavigate?: (module: string) => void;
  onNavigateToKernel?: () => void;
  onNavigateToPQL?: () => void;
  onNavigateToGateway?: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  tenant = initialTenants[0],
  observer,
  clusters,
  onNavigate,
  onNavigateToKernel,
  onNavigateToPQL,
  onNavigateToGateway
}) => {
  const [quickInput, setQuickInput] = useState(
    'Paciente com histórico cardíaco solicitando autorização de cobertura securitária de alta complexidade com urgência clínica.'
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastResult, setLastResult] = useState<any>(null);

  const handleNavigateKernel = onNavigateToKernel || (() => onNavigate?.('kernel'));
  const handleNavigatePQL = onNavigateToPQL || (() => onNavigate?.('pql_console'));
  const handleNavigateGateway = onNavigateToGateway || (() => onNavigate?.('ai_gateway'));

  // Bar chart data for Cluster Load & Performance
  const clusterLoadData = clusters.map(c => ({
    name: c.domain.split('&')[0].trim(),
    load: c.loadPercentage,
    ekos: c.activeEKOs,
    accuracy: c.accuracyRate
  }));

  // Bar chart for Decision Volume by Domain
  const decisionsByDomainData = [
    { domain: 'Finanças & Crédito', aprovadas: 1420, ajustadasMVED: 320, rejeitadas: 85 },
    { domain: 'Medicina & Saúde', aprovadas: 2180, ajustadasMVED: 410, rejeitadas: 42 },
    { domain: 'Direito & Compliance', aprovadas: 980, ajustadasMVED: 190, rejeitadas: 30 },
    { domain: 'Governança de IA', aprovadas: 3400, ajustadasMVED: 520, rejeitadas: 110 },
    { domain: 'Cibersegurança & PII', aprovadas: 1890, ajustadasMVED: 240, rejeitadas: 15 }
  ];

  // AI Provider telemetry data
  const aiProviderData = [
    { provider: 'Google Gemini 2.5', latency: 310, cost: 0.15, throughput: 98 },
    { provider: 'Azure OpenAI GPT-4o', latency: 450, cost: 2.50, throughput: 96 },
    { provider: 'IBM Watsonx Granite', latency: 380, cost: 0.40, throughput: 94 },
    { provider: 'Local Llama-3 70B', latency: 190, cost: 0.00, throughput: 99 },
  ];

  const handleRunQuickTest = async () => {
    setIsProcessing(true);
    try {
      const result = await globalPasquaredEngine.executeSAC(quickInput, observer);
      setLastResult(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 border border-indigo-900/40 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <PasquaredLogo size="lg" showText={false} />
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-semibold px-2.5 py-1 rounded-full">
                  Tenant: {tenant.name} ({tenant.tier})
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  PASQUARED Controller Ativo
                </span>
              </div>
              <h2 className="text-2xl lg:text-3xl font-bold text-white tracking-tight">
                Painel de Controle e Governança Epistemológica
              </h2>
              <p className="text-sm text-slate-300 max-w-3xl leading-relaxed">
                Orquestração de decisões em tempo real via algoritmo PASQUARED-OS. Intercepção com validação MVED, 
                eliminação de hipóteses inconsistentes e rastreabilidade total no protocolo PRE.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleNavigateKernel}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition"
            >
              <Cpu className="w-4 h-4" />
              <span>Ver Núcleo PCK & SAC</span>
            </button>
            <button
              onClick={handleNavigatePQL}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2.5 rounded-xl border border-slate-700 flex items-center gap-2 transition"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Executar PQL Script</span>
            </button>
          </div>
        </div>
      </div>

      {/* Real-time Health Metrics Widget (DashboardWidget) */}
      <DashboardWidget
        tenant={tenant}
        onNavigateToGateway={handleNavigateGateway}
        onNavigateToKernel={handleNavigateKernel}
      />

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Decisões Auditadas (24h)
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white">9,870</span>
            <span className="text-xs text-emerald-400 font-medium flex items-center">
              +14.2% vs ontem
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">100% gravadas com hash no PRE</p>
        </div>

        {/* Card 2 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Índice Global Abstração (IGA)
            </span>
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Brain className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-cyan-400">0.892</span>
            <span className="text-xs text-cyan-300 font-mono">ΔI = 0.008 &lt; ε</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">Convergência epistêmica excelente</p>
        </div>

        {/* Card 3 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Eliminação Alucinações (MVED)
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-400">99.7%</span>
            <span className="text-xs text-slate-400">Hipóteses filtradas</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">1,680 hipóteses inválidas podadas</p>
        </div>

        {/* Card 4 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Consumo de Tokens
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white">
              {(tenant.quotas.usedTokens / 1000000).toFixed(1)}M
            </span>
            <span className="text-xs text-slate-400">
              / {(tenant.quotas.monthlyTokens / 1000000).toFixed(0)}M cota
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div 
              className="bg-amber-500 h-full rounded-full" 
              style={{ width: `${(tenant.quotas.usedTokens / tenant.quotas.monthlyTokens) * 100}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Main Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Cognitive Clusters Load & Active EKOs */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Carga e Volume de EKOs por Cluster Cognitivo (Kubernetes Workers)
              </h3>
              <p className="text-xs text-slate-400">
                Distribuição ontológica do conhecimento e acurácia por domínio
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-1 rounded">
              Debian 12 K8s
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={clusterLoadData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="load" name="Carga do Cluster (%)" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="accuracy" name="Acurácia Decisória (%)" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Decision Outcomes by Domain */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">
                Volume de Decisões e Intercepções MVED por Domínio
              </h3>
              <p className="text-xs text-slate-400">
                Decisões aprovadas diretamente vs ajustadas pelo controlador PASQUARED
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-1 rounded">
              MVED v1.0
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={decisionsByDomainData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis dataKey="domain" stroke="#94a3b8" fontSize={10} interval={0} angle={-15} textAnchor="end" height={45} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="aprovadas" name="Aprovadas Diretas" fill="#3b82f6" stackId="a" radius={[0, 0, 0, 0]} />
                <Bar dataKey="ajustadasMVED" name="Ajustadas MVED" fill="#f59e0b" stackId="a" />
                <Bar dataKey="rejeitadas" name="Rejeitadas por Risco" fill="#ef4444" stackId="a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Quick SAC Interactive Tester */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white">
              Simulador Rápido de Abstração Cognitiva (SAC 8 Níveis)
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Observador Ativo: {observer.name} [P:{observer.P} K:{observer.K}]
          </span>
        </div>

        <p className="text-xs text-slate-300 mb-4">
          Insira qualquer cenário de negócio, solicitação de crédito, prescrição médica ou caso jurídico. 
          O PASQUARED extrairá as UCIs, construirá o grafo cognitivo, gerará hipóteses e eliminará as inconsistentes via MVED.
        </p>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={quickInput}
            onChange={(e) => setQuickInput(e.target.value)}
            placeholder="Digite o cenário a ser submetido ao PASQUARED Controller..."
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500 transition"
          />
          <button
            onClick={handleRunQuickTest}
            disabled={isProcessing || !quickInput.trim()}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs px-6 py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition shrink-0"
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                Executando SAC...
              </span>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Processar Decisão PASQUARED</span>
              </>
            )}
          </button>
        </div>

        {/* Live Result Accordion */}
        {lastResult && (
          <div className="mt-6 bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 animate-fadeIn">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Decisão Consolidada pelo Kernel
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="text-cyan-400">IGA: {lastResult.decision.iga.toFixed(3)}</span>
                <span className="text-indigo-400">ICI: {lastResult.decision.ici.toFixed(3)}</span>
                <span className="text-emerald-400">Status: {lastResult.decision.policyStatus}</span>
              </div>
            </div>

            <div className="bg-slate-900/90 rounded-lg p-4 border border-slate-800">
              <p className="text-sm font-medium text-white leading-relaxed">
                "{lastResult.decision.selectedMeaning}"
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-400 block mb-1 font-semibold">Identificador UCL (CID):</span>
                <span className="text-indigo-300 font-mono text-[11px] break-all">
                  {lastResult.ucl.objectID}
                </span>
              </div>

              <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-400 block mb-1 font-semibold">Clusters Ativados:</span>
                <div className="flex flex-wrap gap-1">
                  {lastResult.decision.activeClusters.map((c: string, idx: number) => (
                    <span key={idx} className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px]">
                      {c}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-400 block mb-1 font-semibold">Hipóteses Inconsistentes Podadas:</span>
                <span className="text-rose-400 font-semibold">
                  {lastResult.decision.rejectedHypotheses.length} hipóteses eliminadas via MVED
                </span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleNavigateKernel}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium transition"
              >
                <span>Inspecionar Grafo Cognitivo e Matriz Completa no Kernel</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
