import React, { useState } from 'react';
import {
  X,
  Building2,
  Lock,
  Shield,
  ArrowRight,
  UserCheck,
  CheckCircle2,
  Layers,
  Key,
  Globe,
  Briefcase,
  Phone,
  Mail,
  FileCheck,
  Cpu,
  Server,
  Zap,
  Sparkles
} from 'lucide-react';
import { Tenant, User, CompanyRegistrationForm } from '../types/pasquared';
import { PasquaredLogo } from './PasquaredLogo';

interface CompanyPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (tenant: Tenant, user: User, isNewRegistration: boolean) => void;
}

export const CompanyPortalModal: React.FC<CompanyPortalModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [loginIdentifier, setLoginIdentifier] = useState('admin.ti@novacorp.com.br');
  const [loginPassword, setLoginPassword] = useState('••••••••••••');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Enterprise Registration Comprehensive Form State
  const [formData, setFormData] = useState<CompanyRegistrationForm>({
    razaoSocial: 'NovaCorp Sistemas & Inteligência Quântica S.A.',
    nomeFantasia: 'NovaCorp Enterprise AI',
    cnpjTaxId: '12.345.678/0001-99',
    inscricaoEstadual: '123.456.789.110',
    setorAtuacao: 'Fintech & Bancário',
    porteEmpresa: 'Enterprise Global',
    numColaboradores: '500 - 2.500',
    pais: 'Brasil',
    estadoUf: 'SP',
    cidade: 'São Paulo',
    endereco: 'Av. Paulista, 1800, Torre Alpha, 22º Andar',
    
    adminNomeCompleto: 'Carlos Eduardo Mendes',
    adminCargo: 'Head de TI',
    adminEmailCorporativo: 'carlos.mendes@novacorp.com.br',
    adminTelefoneWhatsapp: '+55 (11) 98765-4321',
    
    usuarioLogin: 'carlos.novacorp',
    senha: 'NovaCorp@Pasquared2026!',
    confirmacaoSenha: 'NovaCorp@Pasquared2026!',
    mfaHabilitado: true,
    
    iaPrimariaDesejada: 'Google (Gemini 2.5 Flash/Pro)',
    nivelRigorSalvaguarda: 'Strict EU AI Act (High Risk)',
    aceiteTermosGovernanca: true,
    aceiteSLA: true
  });

  const handleInputChange = (field: keyof CompanyRegistrationForm, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCompanyLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg(null);

    setTimeout(() => {
      setIsSubmitting(false);
      const authenticatedTenant: Tenant = {
        id: 'tenant-novacorp-ent',
        name: 'NovaCorp Enterprise AI',
        slug: 'novacorp',
        domain: 'novacorp.com.br',
        tier: 'Enterprise',
        createdAt: new Date().toISOString(),
        status: 'active',
        quotas: {
          maxUsers: 150,
          usedUsers: 12,
          monthlyTokens: 25000000,
          usedTokens: 1420000,
          maxAgents: 40,
          usedAgents: 8,
          maxStorageGB: 1000,
          usedStorageGB: 140
        },
        clusterAllocations: ['cluster-gcp-sa-east', 'cluster-azure-br']
      };

      const authenticatedUser: User = {
        id: `usr-ti-${Date.now().toString(36)}`,
        tenantId: authenticatedTenant.id,
        name: loginIdentifier.split('@')[0] || 'Administrador TI',
        email: loginIdentifier,
        role: 'TenantAdmin',
        department: 'Diretoria de Tecnologia & Infraestrutura',
        mfaEnabled: true,
        status: 'active'
      };

      onSuccess(authenticatedTenant, authenticatedUser, false);
      onClose();
    }, 600);
  };

  const handleCompanyRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.razaoSocial || !formData.cnpjTaxId || !formData.adminEmailCorporativo || !formData.senha) {
      setErrorMsg('Por favor preencha todos os campos obrigatórios da empresa e do Admin de TI.');
      return;
    }

    if (formData.senha !== formData.confirmacaoSenha) {
      setErrorMsg('A senha e a confirmação de senha não coincidem.');
      return;
    }

    if (!formData.aceiteTermosGovernanca) {
      setErrorMsg('É necessário aceitar os Termos de Governança de Dados do PASQUARED-OS.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    setTimeout(() => {
      setIsSubmitting(false);
      const newTenantId = `tenant-${formData.nomeFantasia.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now().toString(36)}`;
      
      const newTenant: Tenant = {
        id: newTenantId,
        name: formData.nomeFantasia || formData.razaoSocial,
        slug: formData.nomeFantasia.toLowerCase().replace(/[^a-z0-9]/g, ''),
        domain: formData.adminEmailCorporativo.split('@')[1] || 'empresa.com.br',
        tier: 'Enterprise',
        createdAt: new Date().toISOString(),
        status: 'active',
        quotas: {
          maxUsers: 100,
          usedUsers: 1,
          monthlyTokens: 20000000,
          usedTokens: 0,
          maxAgents: 30,
          usedAgents: 1,
          maxStorageGB: 500,
          usedStorageGB: 0
        },
        clusterAllocations: ['cluster-gcp-sa-east', 'cluster-local-k8s']
      };

      const newAdminUser: User = {
        id: `usr-admin-${Date.now().toString(36)}`,
        tenantId: newTenantId,
        name: `${formData.adminNomeCompleto} (${formData.adminCargo})`,
        email: formData.adminEmailCorporativo,
        role: 'TenantAdmin',
        department: 'Tecnologia & Governança de IA',
        mfaEnabled: formData.mfaHabilitado,
        status: 'active'
      };

      // Redirect directly to enterprise resource manager
      onSuccess(newTenant, newAdminUser, true);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in overflow-y-auto custom-scrollbar">
      <div className="bg-slate-900 border border-cyan-500/30 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-[0_0_50px_rgba(0,240,255,0.18)] overflow-hidden my-auto">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#031124] via-[#041d38] to-[#012d2b]">
          <div className="flex items-center gap-3">
            <PasquaredLogo size="md" showText={false} />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  Portal de Empresas & Onboarding Corporativo
                </h3>
                <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full">
                  Enterprise Gateway
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Cadastro de Empresas & Conexão de Recursos de TI para Alimentação do PASQUARED-OS
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs (Login vs Cadastro de Empresas) */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 p-2 gap-2">
          <button
            onClick={() => setMode('register')}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition ${
              mode === 'register'
                ? 'bg-gradient-to-r from-cyan-600 to-emerald-600 text-white shadow-lg shadow-cyan-500/25 border border-cyan-400/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Cadastro Completo de Empresa (Novo Tenant)</span>
          </button>
          <button
            onClick={() => setMode('login')}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition ${
              mode === 'login'
                ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>Login de Empresa Cadastrada</span>
          </button>
        </div>

        {/* Error Feedback */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl text-xs text-rose-300 font-mono flex items-center gap-2">
            <X className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form Body */}
        <div className="p-5 sm:p-6 overflow-y-auto custom-scrollbar flex-1">
          {mode === 'login' ? (
            /* Login Form */
            <form onSubmit={handleCompanyLogin} className="space-y-4 max-w-md mx-auto py-6">
              <div className="text-center space-y-1 mb-6">
                <h4 className="text-sm font-bold text-white">Acesso do Administrador de TI</h4>
                <p className="text-xs text-slate-400">
                  Gerencie os recursos, webhooks e fontes de dados da sua empresa no Kernel PASQUARED
                </p>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                  E-mail Corporativo ou CNPJ:
                </label>
                <input
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-cyan-200 focus:outline-none focus:border-cyan-500"
                  placeholder="admin.ti@suaempresa.com.br"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                  Senha de Acesso:
                </label>
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-cyan-200 focus:outline-none focus:border-cyan-500"
                  placeholder="••••••••••••"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/30 transition mt-4"
              >
                <span>{isSubmitting ? 'Autenticando...' : 'Acessar Gestor de Recursos TI'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            /* Complete Enterprise Registration Form */
            <form onSubmit={handleCompanyRegister} className="space-y-6">
              {/* Section 1: Dados da Empresa */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-1 border-b border-cyan-500/20 text-xs font-bold text-cyan-300 uppercase tracking-wider">
                  <Building2 className="w-4 h-4 text-cyan-400" />
                  <span>1. Dados Cadastrais da Empresa</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Razão Social *</label>
                    <input
                      type="text"
                      value={formData.razaoSocial}
                      onChange={(e) => handleInputChange('razaoSocial', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                      placeholder="Empresa S.A."
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Nome Fantasia *</label>
                    <input
                      type="text"
                      value={formData.nomeFantasia}
                      onChange={(e) => handleInputChange('nomeFantasia', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                      placeholder="Nome Comercial"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">CNPJ / Tax ID *</label>
                    <input
                      type="text"
                      value={formData.cnpjTaxId}
                      onChange={(e) => handleInputChange('cnpjTaxId', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
                      placeholder="00.000.000/0001-00"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Setor de Atuação *</label>
                    <select
                      value={formData.setorAtuacao}
                      onChange={(e) => handleInputChange('setorAtuacao', e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Fintech & Bancário">Fintech & Bancário</option>
                      <option value="Saúde & Hospitalar">Saúde & Hospitalar</option>
                      <option value="Energia & Utilities">Energia & Utilities</option>
                      <option value="Indústria 4.0">Indústria 4.0</option>
                      <option value="Varejo & E-commerce">Varejo & E-commerce</option>
                      <option value="Logística">Logística & Supply Chain</option>
                      <option value="Setor Público">Setor Público & Governo</option>
                      <option value="Jurídico & Compliance">Jurídico & Compliance</option>
                      <option value="Telecomunicações">Telecomunicações</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Porte da Empresa</label>
                    <select
                      value={formData.porteEmpresa}
                      onChange={(e) => handleInputChange('porteEmpresa', e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Startup">Startup (até 50 colab.)</option>
                      <option value="PME">PME (50 a 200 colab.)</option>
                      <option value="Middle Market">Middle Market (200 a 1.000)</option>
                      <option value="Enterprise Global">Enterprise Global (+1.000)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Cidade / UF / País</label>
                    <input
                      type="text"
                      value={`${formData.cidade} - ${formData.estadoUf}, ${formData.pais}`}
                      onChange={(e) => {
                        const parts = e.target.value.split('-');
                        handleInputChange('cidade', parts[0] || '');
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Administrador de TI & Segurança */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-1 border-b border-emerald-500/20 text-xs font-bold text-emerald-300 uppercase tracking-wider">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                  <span>2. Administrador de TI & Responsável Técnico</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Nome Completo do Admin TI *</label>
                    <input
                      type="text"
                      value={formData.adminNomeCompleto}
                      onChange={(e) => handleInputChange('adminNomeCompleto', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Cargo Corporativo *</label>
                    <select
                      value={formData.adminCargo}
                      onChange={(e) => handleInputChange('adminCargo', e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                    >
                      <option value="CTO">CTO (Chief Technology Officer)</option>
                      <option value="VP of Engineering">VP of Engineering</option>
                      <option value="Head de TI">Head / Diretor de TI</option>
                      <option value="Arquiteto de IA">Arquiteto de IA & Soluções</option>
                      <option value="CISO / Segurança">CISO / Diretor de Segurança</option>
                      <option value="DPO / Encarregado LGPD">DPO / Encarregado LGPD</option>
                      <option value="Gerente de Infraestrutura">Gerente de Infraestrutura & Cloud</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">E-mail Corporativo do Admin *</label>
                    <input
                      type="email"
                      value={formData.adminEmailCorporativo}
                      onChange={(e) => handleInputChange('adminEmailCorporativo', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-emerald-300 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Telefone / WhatsApp TI *</label>
                    <input
                      type="text"
                      value={formData.adminTelefoneWhatsapp}
                      onChange={(e) => handleInputChange('adminTelefoneWhatsapp', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Credenciais de Autenticação */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-1 border-b border-indigo-500/20 text-xs font-bold text-indigo-300 uppercase tracking-wider">
                  <Key className="w-4 h-4 text-indigo-400" />
                  <span>3. Credenciais de Acesso & Segurança</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Usuário / Login *</label>
                    <input
                      type="text"
                      value={formData.usuarioLogin}
                      onChange={(e) => handleInputChange('usuarioLogin', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Senha Master *</label>
                    <input
                      type="password"
                      value={formData.senha}
                      onChange={(e) => handleInputChange('senha', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Confirmar Senha *</label>
                    <input
                      type="password"
                      value={formData.confirmacaoSenha}
                      onChange={(e) => handleInputChange('confirmacaoSenha', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Section 4: Parametrização Inicial PASQUARED */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-1 border-b border-cyan-500/20 text-xs font-bold text-cyan-300 uppercase tracking-wider">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <span>4. Alocação Inicial do Kernel PASQUARED-OS</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Família de IA Primária</label>
                    <select
                      value={formData.iaPrimariaDesejada}
                      onChange={(e) => handleInputChange('iaPrimariaDesejada', e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Google (Gemini 2.5 Flash/Pro)">Google (Gemini 2.5 Flash / Pro)</option>
                      <option value="Microsoft (Azure OpenAI GPT-4o)">Microsoft (Azure OpenAI GPT-4o)</option>
                      <option value="IBM (Watsonx Granite 3.0)">IBM (Watsonx Granite 3.0 Enterprise)</option>
                      <option value="Cluster Local On-Premise K8s">Cluster Local On-Premise K8s (Llama-3 / Mistral)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Nível de Rigor de Salvaguardas</label>
                    <select
                      value={formData.nivelRigorSalvaguarda}
                      onChange={(e) => handleInputChange('nivelRigorSalvaguarda', e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Strict EU AI Act (High Risk)">Strict EU AI Act (High Risk & PII Block)</option>
                      <option value="High-Assurance Defesa/Financeiro">High-Assurance (Financeiro / Saúde / MVED 95%)</option>
                      <option value="Standard">Standard Enterprise Governance</option>
                    </select>
                  </div>
                </div>

                {/* Terms and Redirection Notice */}
                <div className="space-y-2 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                    <input
                      type="checkbox"
                      checked={formData.aceiteTermosGovernanca}
                      onChange={(e) => handleInputChange('aceiteTermosGovernanca', e.target.checked)}
                      className="rounded bg-slate-950 border-slate-700 text-cyan-500 focus:ring-0"
                    />
                    <span>
                      Declaro conformidade com as Políticas de Governança Epistêmica e Trilha PRE Imutável.
                    </span>
                  </label>

                  <div className="p-3 bg-cyan-950/40 border border-cyan-500/30 rounded-xl flex items-center gap-2 text-xs text-cyan-200">
                    <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span>
                      Após o cadastro, você será <strong>redirecionado automaticamente para a Área de Gerenciamento dos Recursos</strong> para parametrizar seus conectores e alimentar o sistema PASQUARED.
                    </span>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-cyan-600 via-emerald-600 to-blue-600 hover:opacity-95 text-white font-bold text-xs py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/30 transition"
              >
                <span>
                  {isSubmitting ? 'Provisionando Tenant & Redirecionando...' : 'Cadastrar Empresa & Parametrizar Recursos'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
