import React, { useState } from 'react';
import {
  Terminal,
  Play,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  BookOpen,
  HelpCircle,
  Cpu
} from 'lucide-react';
import { ObserverProfile } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';

interface PQLConsoleProps {
  observer: ObserverProfile;
}

export const PQLConsole: React.FC<PQLConsoleProps> = ({ observer }) => {
  const sampleScripts: Record<string, string> = {
    credit: `# PQL: Análise de Risco de Crédito Empresarial
OBSERVE Solicitacao_Emprestimo_100k
OBSERVE Balanco_Patrimonial_Auditoria
ASSOCIATE Solicitacao_Emprestimo_100k Balanco_Patrimonial_Auditoria
CONTEXT Analise_Solvencia_Bancaria
GENERATE Hipoteses_Concessao
VALIDATE Criterios_Resolucao_BACEN
LEARN Registro_Decisao_EKO_Credito`,

    medical: `# PQL: Avaliação Clínica e Bioética de Prescrição
OBSERVE Paciente_Idoso_Polimedicado
OBSERVE Interacao_Anticoagulante_Antiinflamatorio
ASSOCIATE Paciente_Idoso_Polimedicado Interacao_Anticoagulante_Antiinflamatorio
CONTEXT Protocolo_Seguranca_Paciente
GENERATE Hipoteses_Dosagem_Segura
VALIDATE Ensaios_Clinicos_Randomizados
LEARN Protocolo_Ajustado_SMEE`,

    governance: `# PQL: Auditoria e Salvaguardas EU AI Act
OBSERVE Pipeline_IA_Recrutamento_RH
OBSERVE Metricas_Disparidade_Demografica
ASSOCIATE Pipeline_IA_Recrutamento_RH Metricas_Disparidade_Demografica
CONTEXT Conformidade_EU_AI_Act_Art14
GENERATE Hipoteses_Mitigacao_Vies
VALIDATE Testes_Estatisticos_Equidade
LEARN Certificacao_Conformidade_PRE`
  };

  const [pqlCode, setPqlCode] = useState(sampleScripts.credit);
  const [outputConsole, setOutputConsole] = useState<string>('');
  const [metrics, setMetrics] = useState<{ iga: number; ici: number; uciCount: number } | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleRunPQL = () => {
    setIsRunning(true);
    setTimeout(() => {
      const result = globalPasquaredEngine.executePQL(pqlCode, observer);
      setOutputConsole(result.output);
      setMetrics(result.metrics);
      setIsRunning(false);
    }, 300);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(pqlCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              PQL TERMINAL v1.0
            </span>
            <span className="text-xs text-slate-400 font-mono">
              PASQUARED Query Language
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Console de Linguagem Epistemológica PQL
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl mt-1">
            Execute consultas e operações cognitivas diretas no Kernel através de operadores formais: 
            <span className="font-mono text-indigo-300"> OBSERVE, ASSOCIATE, CONTEXT, GENERATE, VALIDATE, LEARN</span>.
          </p>
        </div>

        {/* Template Selectors */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-semibold mr-1">Templates:</span>
          <button
            onClick={() => setPqlCode(sampleScripts.credit)}
            className="bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            Crédito Bancário
          </button>
          <button
            onClick={() => setPqlCode(sampleScripts.medical)}
            className="bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            Clínico & Bioética
          </button>
          <button
            onClick={() => setPqlCode(sampleScripts.governance)}
            className="bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            EU AI Act
          </button>
        </div>
      </div>

      {/* Editor & Output Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* PQL Editor */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-semibold text-white">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <span>Editor PQL</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="text-xs text-slate-400 hover:text-white p-1.5 rounded hover:bg-slate-800 transition"
                title="Copiar Script"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              <button
                onClick={() => setPqlCode('')}
                className="text-xs text-slate-400 hover:text-white p-1.5 rounded hover:bg-slate-800 transition"
                title="Limpar"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          <textarea
            value={pqlCode}
            onChange={(e) => setPqlCode(e.target.value)}
            rows={14}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs font-mono text-indigo-200 focus:outline-none focus:border-indigo-500 transition leading-relaxed"
            placeholder="Digite os comandos PQL aqui..."
          />

          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] text-slate-400 font-mono">
              Linhas: {pqlCode.split('\n').length} | Caracteres: {pqlCode.length}
            </span>

            <button
              onClick={handleRunPQL}
              disabled={isRunning || !pqlCode.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs px-6 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isRunning ? 'Interpretando PQL...' : 'Executar no Kernel'}</span>
            </button>
          </div>
        </div>

        {/* Execution Output & Metrics */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-semibold text-white">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Saída Epistemológica do Kernel</span>
            </div>
            {metrics && (
              <div className="flex items-center gap-2 text-[11px] font-mono">
                <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded">
                  IGA: {metrics.iga}
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded">
                  ICI: {metrics.ici}
                </span>
              </div>
            )}
          </div>

          <div className="w-full h-full bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 overflow-y-auto custom-scrollbar min-h-[300px] whitespace-pre-wrap leading-relaxed">
            {outputConsole ? (
              outputConsole
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 py-12 space-y-2">
                <Terminal className="w-8 h-8 opacity-40" />
                <span>Pressione "Executar no Kernel" para processar o script PQL.</span>
              </div>
            )}
          </div>

          {/* PQL Syntax Reference Card */}
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <span className="text-slate-300 font-semibold block">Gramática PQL:</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono text-[10px]">
              <div><strong className="text-indigo-400">OBSERVE &lt;U&gt;</strong>: Cria UCI</div>
              <div><strong className="text-indigo-400">ASSOCIATE &lt;U1&gt; &lt;U2&gt;</strong>: Cria aresta</div>
              <div><strong className="text-cyan-400">CONTEXT &lt;C&gt;</strong>: Modula contexto</div>
              <div><strong className="text-amber-400">GENERATE &lt;H&gt;</strong>: Gera hipóteses</div>
              <div><strong className="text-emerald-400">VALIDATE &lt;E&gt;</strong>: Executa MVED</div>
              <div><strong className="text-purple-400">LEARN &lt;M&gt;</strong>: Persiste EKO</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
