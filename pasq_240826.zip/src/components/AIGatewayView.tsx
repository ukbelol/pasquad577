import React, { useState } from 'react';
import {
  AIGatewayModel,
  ObserverProfile,
  AIAgent,
  KnowledgeBaseSource
} from '../types/pasquared';
import {
  Boxes,
  Zap,
  Play,
  CheckCircle2,
  Lock,
  Server,
  Activity,
  Plus,
  Edit,
  Trash2,
  Bot,
  Database,
  Globe,
  RefreshCw,
  Sliders,
  ShieldCheck,
  Link,
  Unlink,
  BookOpen,
  Sparkles,
  Search,
  Filter,
  Check
} from 'lucide-react';
import { initialKnowledgeBases, initialAgents } from '../data/mockDatabase';

interface AIGatewayViewProps {
  models: AIGatewayModel[];
  agents?: AIAgent[];
  knowledgeBases?: KnowledgeBaseSource[];
  observer: ObserverProfile;
  onExecuteGatewayCall?: (modelId: string, prompt: string) => Promise<any>;
}

export const AIGatewayView: React.FC<AIGatewayViewProps> = ({
  models: initialModelsList,
  agents: initialAgentsList = initialAgents,
  knowledgeBases: initialKbsList = initialKnowledgeBases,
  observer,
  onExecuteGatewayCall
}) => {
  // Navigation sub-tab
  const [activeSubTab, setActiveSubTab] = useState<
    'gateways_models' | 'ai_agents' | 'knowledge_bases' | 'playground'
  >('knowledge_bases');

  // Models State
  const [modelsList, setModelsList] = useState<AIGatewayModel[]>(initialModelsList);
  const [selectedModelId, setSelectedModelId] = useState(initialModelsList[0]?.id || '');
  const [editingModel, setEditingModel] = useState<AIGatewayModel | null>(null);
  const [showAddModelModal, setShowAddModelModal] = useState(false);

  // New Model Form State
  const [newModelName, setNewModelName] = useState('');
  const [newModelProvider, setNewModelProvider] = useState<'Google' | 'Microsoft' | 'IBM' | 'OpenAI' | 'Local-Cluster'>('Google');
  const [newModelFamily, setNewModelFamily] = useState('Gemini 2.5 Flash');
  const [newModelEndpoint, setNewModelEndpoint] = useState('https://generativelanguage.googleapis.com/v1beta/models');
  const [newModelContextWindow, setNewModelContextWindow] = useState(1048576);
  const [newModelLatency, setNewModelLatency] = useState(240);
  const [newModelCost, setNewModelCost] = useState(0.00015);

  // Agents State
  const [agentsList, setAgentsList] = useState<AIAgent[]>(initialAgentsList);
  const [editingAgent, setEditingAgent] = useState<AIAgent | null>(null);
  const [showAddAgentModal, setShowAddAgentModal] = useState(false);

  // New Agent Form State
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentRole, setNewAgentRole] = useState('');
  const [newAgentDescription, setNewAgentDescription] = useState('');
  const [newAgentModelId, setNewAgentModelId] = useState(initialModelsList[0]?.id || '');
  const [newAgentSystemPrompt, setNewAgentSystemPrompt] = useState('');

  // Knowledge Bases State
  const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBaseSource[]>(initialKbsList);
  const [kbAreaFilter, setKbAreaFilter] = useState<string>('all');
  const [kbScopeFilter, setKbScopeFilter] = useState<'all' | 'public' | 'private'>('all');
  const [kbSearchTerm, setKbSearchTerm] = useState('');
  const [syncingKbId, setSyncingKbId] = useState<string | null>(null);
  const [editingKb, setEditingKb] = useState<KnowledgeBaseSource | null>(null);
  const [showAddKbModal, setShowAddKbModal] = useState(false);

  // New Knowledge Base Form State
  const [newKbName, setNewKbName] = useState('');
  const [newKbArea, setNewKbArea] = useState<KnowledgeBaseSource['area']>('Jurídico & Regulatório');
  const [newKbScope, setNewKbScope] = useState<'public' | 'private'>('public');
  const [newKbUrl, setNewKbUrl] = useState('');
  const [newKbAuth, setNewKbAuth] = useState<KnowledgeBaseSource['authMethod']>('public_no_auth');
  const [newKbDesc, setNewKbDesc] = useState('');
  const [newKbDimension, setNewKbDimension] = useState<KnowledgeBaseSource['mappedDimension']>('Evidência (α)');
  const [newKbFormat, setNewKbFormat] = useState<KnowledgeBaseSource['format']>('PDF/Docs');

  // Playground state
  const [promptText, setPromptText] = useState(
    'Analise a viabilidade de crédito corporativo para uma empresa do setor fabril com faturamento anual de R$ 40 milhões, solicitando R$ 5 milhões de capital de giro.'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [responseOutput, setResponseOutput] = useState<any>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const selectedModel = modelsList.find((m) => m.id === selectedModelId) || modelsList[0];

  // ----------------------------------------------------
  // Model Handlers
  // ----------------------------------------------------
  const handleAddModel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newModelName.trim()) return;

    const newM: AIGatewayModel = {
      id: `model-${Date.now().toString(36)}`,
      name: newModelName,
      provider: newModelProvider,
      modelFamily: newModelFamily,
      endpoint: newModelEndpoint,
      contextWindow: newModelContextWindow,
      latencyMs: newModelLatency,
      costPer1kTokens: newModelCost,
      status: 'available',
      isPasquaredProtected: true,
      pasquaredInterceptionRules: [
        'Intercepção Epistêmica Prévia MVED',
        'Cálculo de Consistência IGA >= 0.70',
        'Gravação de Audit Trail PRE'
      ]
    };

    setModelsList([newM, ...modelsList]);
    setShowAddModelModal(false);
    setNewModelName('');
    showToast(`Modelo/Gateway "${newM.name}" cadastrado com sucesso!`);
  };

  const handleSaveEditedModel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingModel) return;

    setModelsList(modelsList.map(m => (m.id === editingModel.id ? editingModel : m)));
    setEditingModel(null);
    showToast(`Modelo "${editingModel.name}" atualizado!`);
  };

  const handleDeleteModel = (id: string) => {
    setModelsList(modelsList.filter(m => m.id !== id));
    showToast(`Modelo/Gateway removido.`);
  };

  // ----------------------------------------------------
  // Agent Handlers
  // ----------------------------------------------------
  const handleAddAgent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAgentName.trim()) return;

    const newA: AIAgent = {
      id: `agent-${Date.now().toString(36)}`,
      tenantId: 'tenant-global',
      name: newAgentName,
      role: newAgentRole || 'Especialista em Análise',
      description: newAgentDescription || 'Agente orquestrado com salvaguarda PASQUARED',
      modelId: newAgentModelId,
      clusterTarget: 'clus-gov',
      systemPrompt: newAgentSystemPrompt || 'Você é um agente investigativo responsável por coletar fatos.',
      status: 'active',
      governanceLimits: {
        maxTokensPerCall: 4096,
        allowHighRiskActions: false,
        requireHumanApprovalThreshold: 0.75
      },
      totalCalls: 0,
      avgConfidence: 0.95
    };

    setAgentsList([newA, ...agentsList]);
    setShowAddAgentModal(false);
    setNewAgentName('');
    setNewAgentRole('');
    setNewAgentDescription('');
    showToast(`Agente de IA "${newA.name}" criado com sucesso!`);
  };

  const handleSaveEditedAgent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAgent) return;

    setAgentsList(agentsList.map(a => (a.id === editingAgent.id ? editingAgent : a)));
    setEditingAgent(null);
    showToast(`Agente "${editingAgent.name}" salvo com sucesso!`);
  };

  const handleDeleteAgent = (id: string) => {
    setAgentsList(agentsList.filter(a => a.id !== id));
    showToast(`Agente de IA excluído.`);
  };

  // ----------------------------------------------------
  // Knowledge Base Handlers (Conectar, Desconectar, Sync, CRUD)
  // ----------------------------------------------------
  const handleToggleKbConnection = (id: string) => {
    const updated = knowledgeBases.map(kb => {
      if (kb.id === id) {
        const nextStatus = (kb.status === 'connected' ? 'disconnected' : 'connected') as 'connected' | 'disconnected';
        return {
          ...kb,
          status: nextStatus
        };
      }
      return kb;
    });
    setKnowledgeBases(updated);
    const target = knowledgeBases.find(k => k.id === id);
    showToast(`Base "${target?.name}" ${target?.status === 'connected' ? 'desconectada' : 'conectada ao Kernel'}.`);
  };

  const handleSyncKb = (id: string) => {
    setSyncingKbId(id);
    setTimeout(() => {
      setSyncingKbId(null);
      const updated = knowledgeBases.map(kb => {
        if (kb.id === id) {
          return {
            ...kb,
            status: 'connected' as const,
            recordsCount: kb.recordsCount + Math.floor(Math.random() * 80) + 12,
            lastSyncedAt: new Date().toISOString()
          };
        }
        return kb;
      });
      setKnowledgeBases(updated);
      showToast(`Base de conhecimento sincronizada com sucesso! Vetores ontológicos atualizados.`);
    }, 1200);
  };

  const handleAddKnowledgeBase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKbName.trim()) return;

    const newKb: KnowledgeBaseSource = {
      id: `kb-${Date.now().toString(36)}`,
      name: newKbName,
      area: newKbArea,
      scope: newKbScope,
      sourceUrlOrHost: newKbUrl || 'https://api.base-conhecimento.org/feed',
      authMethod: newKbAuth,
      recordsCount: 1540,
      lastSyncedAt: new Date().toISOString(),
      status: 'connected',
      description: newKbDesc || 'Base de conhecimento integrada ao Kernel Epistemológico PASQUARED.',
      mappedDimension: newKbDimension,
      autoSync: true,
      format: newKbFormat
    };

    setKnowledgeBases([newKb, ...knowledgeBases]);
    setShowAddKbModal(false);
    setNewKbName('');
    setNewKbUrl('');
    setNewKbDesc('');
    showToast(`Base "${newKb.name}" cadastrada e conectada com sucesso!`);
  };

  const handleSaveEditedKb = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingKb) return;

    setKnowledgeBases(knowledgeBases.map(k => (k.id === editingKb.id ? editingKb : k)));
    setEditingKb(null);
    showToast(`Base "${editingKb.name}" atualizada com sucesso!`);
  };

  const handleDeleteKb = (id: string) => {
    setKnowledgeBases(knowledgeBases.filter(k => k.id !== id));
    showToast(`Base de conhecimento removida do catálogo.`);
  };

  // Filtered Knowledge Bases
  const filteredKnowledgeBases = knowledgeBases.filter(kb => {
    const matchesArea = kbAreaFilter === 'all' || kb.area === kbAreaFilter;
    const matchesScope = kbScopeFilter === 'all' || kb.scope === kbScopeFilter;
    const matchesSearch =
      kbSearchTerm === '' ||
      kb.name.toLowerCase().includes(kbSearchTerm.toLowerCase()) ||
      kb.description.toLowerCase().includes(kbSearchTerm.toLowerCase()) ||
      kb.area.toLowerCase().includes(kbSearchTerm.toLowerCase());
    return matchesArea && matchesScope && matchesSearch;
  });

  // ----------------------------------------------------
  // Playground Execution Handler
  // ----------------------------------------------------
  const handleTestGateway = async () => {
    if (!promptText.trim()) return;
    setIsGenerating(true);
    setResponseOutput(null);

    try {
      if (onExecuteGatewayCall) {
        const res = await onExecuteGatewayCall(selectedModel.id, promptText);
        setResponseOutput(res);
      } else {
        setTimeout(() => {
          setResponseOutput({
            text: `[PASQUARED Interception Engine v2.5]\nValidação MVED concluída com sucesso (ICI: 0.94, IGA: 0.92).\n\nResposta do modelo [${selectedModel.name} (${selectedModel.provider})]:\n"Com base na análise das evidências de crédito e nos parâmetros de LTV (Garantia) e DTI (Comprometimento de Renda), a solicitação de R$ 5.000.000,00 para a indústria com receita anual de R$ 40 milhões é VIÁVEL, desde que vinculada a garantia real com LTV ≤ 55% e carência de até 6 meses. O risco de insolvência é mitigado pelos clusters financeiros."\n\n✓ Assinatura TEE gravada no Ledger PRE.\n✓ Nenhum desvio ontológico detectado.`,
            latencyMs: selectedModel.latencyMs || 220,
            cost: (selectedModel.costPer1kTokens * 0.45).toFixed(5),
            provider: selectedModel.provider
          });
          setIsGenerating(false);
        }, 1100);
      }
    } catch (e) {
      console.error(e);
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-8 space-y-6 max-w-7xl mx-auto font-sans text-slate-100 animate-in fade-in">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-indigo-950/95 border border-indigo-500 text-indigo-200 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-5 h-5 text-indigo-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="quantum-card-glow rounded-3xl p-6 sm:p-8 relative overflow-hidden border-indigo-500/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[radial-gradient(circle_at_100%_0%,rgba(99,102,241,0.15),transparent_70%)] pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center shrink-0 shadow-[0_0_25px_rgba(99,102,241,0.3)]">
              <Boxes className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  Universal AI Gateway, Agentes & Bases de Conhecimento
                </h1>
                <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
                  PASQUARED PROTECTED
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
                Cadastre e orquestre modelos de IA (Google Gemini, Azure, IBM, OpenAI), gerencie Agentes com salvaguarda epistêmica e conecte bases de conhecimento públicas e privadas de todas as áreas.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => setShowAddKbModal(true)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-1.5 transition"
            >
              <Database className="w-4 h-4" />
              <span>Conectar Nova Base</span>
            </button>

            <button
              onClick={() => setShowAddModelModal(true)}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Cadastrar Gateway / Modelo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveSubTab('knowledge_bases')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeSubTab === 'knowledge_bases'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Database className="w-4 h-4 text-emerald-400" />
          <span>Bases de Conhecimento ({knowledgeBases.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('gateways_models')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeSubTab === 'gateways_models'
              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-[0_0_15px_rgba(99,102,241,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Boxes className="w-4 h-4 text-indigo-400" />
          <span>Roteador & Modelos Gateway ({modelsList.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('ai_agents')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeSubTab === 'ai_agents'
              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-[0_0_15px_rgba(99,102,241,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Bot className="w-4 h-4 text-cyan-400" />
          <span>Agentes de IA Orquestrados ({agentsList.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('playground')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeSubTab === 'playground'
              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-[0_0_15px_rgba(99,102,241,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Zap className="w-4 h-4 text-amber-400" />
          <span>Playground com Intercepção</span>
        </button>
      </div>

      {/* ==================================================== */}
      {/* SUB-TAB 1: BASES DE CONHECIMENTO (PÚBLICAS & PRIVADAS) */}
      {/* ==================================================== */}
      {activeSubTab === 'knowledge_bases' && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="quantum-card-glow rounded-2xl p-4 space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-1">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={kbSearchTerm}
                  onChange={(e) => setKbSearchTerm(e.target.value)}
                  placeholder="Buscar base de conhecimento por nome, tema ou área..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Scope Filter */}
                <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                  <button
                    onClick={() => setKbScopeFilter('all')}
                    className={`px-2.5 py-1 rounded-lg transition ${kbScopeFilter === 'all' ? 'bg-emerald-500/20 text-emerald-300 font-bold' : 'text-slate-400'}`}
                  >
                    Todas
                  </button>
                  <button
                    onClick={() => setKbScopeFilter('public')}
                    className={`px-2.5 py-1 rounded-lg transition ${kbScopeFilter === 'public' ? 'bg-emerald-500/20 text-emerald-300 font-bold' : 'text-slate-400'}`}
                  >
                    Públicas
                  </button>
                  <button
                    onClick={() => setKbScopeFilter('private')}
                    className={`px-2.5 py-1 rounded-lg transition ${kbScopeFilter === 'private' ? 'bg-indigo-500/20 text-indigo-300 font-bold' : 'text-slate-400'}`}
                  >
                    Privadas
                  </button>
                </div>

                {/* Area Dropdown */}
                <select
                  value={kbAreaFilter}
                  onChange={(e) => setKbAreaFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded-xl px-3 py-2 font-mono focus:border-emerald-500"
                >
                  <option value="all">Todas as Áreas</option>
                  <option value="Jurídico & Regulatório">Jurídico & Regulatório</option>
                  <option value="Financeiro & Bancário">Financeiro & Bancário</option>
                  <option value="Saúde & Medicina">Saúde & Medicina</option>
                  <option value="Tecnologia & Cibersegurança">Tecnologia & Cibersegurança</option>
                  <option value="Indústria & Engenharia">Indústria & Engenharia</option>
                  <option value="Governança & Risco">Governança & Risco</option>
                </select>
              </div>
            </div>
          </div>

          {/* Knowledge Bases Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredKnowledgeBases.map((kb) => {
              const isSyncing = syncingKbId === kb.id;
              return (
                <div
                  key={kb.id}
                  className={`quantum-card-glow rounded-2xl p-5 space-y-4 border transition-all ${
                    kb.status === 'connected'
                      ? 'border-emerald-500/30 bg-slate-900/90'
                      : 'border-slate-800 bg-slate-950/80 opacity-75'
                  }`}
                >
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${
                            kb.scope === 'public'
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                              : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                          }`}
                        >
                          {kb.scope === 'public' ? 'Pública' : 'Privada / Confidencial'}
                        </span>
                        <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                          {kb.area}
                        </span>
                      </div>
                      <h4 className="text-base font-bold text-white tracking-tight">{kb.name}</h4>
                    </div>

                    {/* Status Badge */}
                    <span
                      className={`text-[11px] font-mono font-bold px-2.5 py-1 rounded-full border flex items-center gap-1.5 ${
                        kb.status === 'connected'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${kb.status === 'connected' ? 'bg-emerald-400' : 'bg-slate-500'}`}></span>
                      <span>{kb.status === 'connected' ? 'CONECTADA' : 'DESCONECTADA'}</span>
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{kb.description}</p>

                  {/* Metadata Row */}
                  <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono text-slate-400">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Registros / Vetores:</span>
                      <strong className="text-cyan-300">{kb.recordsCount.toLocaleString()} nós</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Dimensão POKO:</span>
                      <strong className="text-amber-300">{kb.mappedDimension}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Formato / Feed:</span>
                      <strong className="text-slate-200">{kb.format}</strong>
                    </div>
                  </div>

                  {/* URL / Source endpoint */}
                  <div className="text-[11px] font-mono text-slate-400 bg-slate-950/60 p-2 rounded-lg border border-slate-800/80 truncate">
                    <span className="text-slate-500">Fonte:</span> {kb.sourceUrlOrHost}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleKbConnection(kb.id)}
                        className={`text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition ${
                          kb.status === 'connected'
                            ? 'bg-rose-950/60 text-rose-300 border-rose-500/30 hover:bg-rose-900/60'
                            : 'bg-emerald-950/60 text-emerald-300 border-emerald-500/30 hover:bg-emerald-900/60'
                        }`}
                      >
                        {kb.status === 'connected' ? (
                          <>
                            <Unlink className="w-3.5 h-3.5 text-rose-400" />
                            <span>Desconectar</span>
                          </>
                        ) : (
                          <>
                            <Link className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Conectar</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => handleSyncKb(kb.id)}
                        disabled={isSyncing || kb.status !== 'connected'}
                        className="text-xs font-bold px-3 py-1.5 rounded-lg border border-cyan-500/30 bg-cyan-950/60 text-cyan-300 hover:bg-cyan-900/60 flex items-center gap-1.5 transition disabled:opacity-50"
                        title="Sincronizar dados ontológicos agora"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isSyncing ? 'animate-spin' : ''}`} />
                        <span>{isSyncing ? 'Sincronizando...' : 'Sincronizar'}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditingKb(kb)}
                        className="text-xs text-amber-300 hover:text-amber-200 bg-amber-950/60 p-1.5 rounded-lg border border-amber-500/30 transition"
                        title="Editar Base de Conhecimento"
                      >
                        <Edit className="w-3.5 h-3.5 text-amber-400" />
                      </button>

                      <button
                        onClick={() => handleDeleteKb(kb.id)}
                        className="text-xs text-rose-300 hover:text-rose-200 bg-rose-950/60 p-1.5 rounded-lg border border-rose-500/30 transition"
                        title="Excluir Base do Catálogo"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 2: ROTEADOR & MODELOS GATEWAY */}
      {/* ==================================================== */}
      {activeSubTab === 'gateways_models' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Catálogo de Provedores & Modelos Conectados</h3>
              <p className="text-xs text-slate-400">
                Rotas de API com governança contínua e salvaguardas de alucinação ativas.
              </p>
            </div>

            <button
              onClick={() => setShowAddModelModal(true)}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Modelo / Gateway</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {modelsList.map((m) => {
              const isSelected = m.id === selectedModelId;
              return (
                <div
                  key={m.id}
                  className={`quantum-card-glow rounded-2xl p-5 space-y-4 border transition-all ${
                    isSelected
                      ? 'border-indigo-500 ring-2 ring-indigo-500/30 bg-indigo-950/30'
                      : 'border-slate-800 bg-slate-900/90'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center">
                        <Boxes className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{m.name}</h4>
                        <span className="text-[11px] text-indigo-300 font-mono uppercase">{m.provider}</span>
                      </div>
                    </div>

                    <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono px-2 py-0.5 rounded-full">
                      {m.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono text-slate-300">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Latência Média:</span>
                      <strong className="text-cyan-300">{m.latencyMs}ms</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Custo / 1k Tokens:</span>
                      <strong className="text-emerald-300">${m.costPer1kTokens}</strong>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[10px] text-slate-500 block uppercase">Context Window:</span>
                      <strong className="text-amber-300">{(m.contextWindow / 1000).toFixed(0)}k tokens</strong>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                    <button
                      onClick={() => {
                        setSelectedModelId(m.id);
                        setActiveSubTab('playground');
                      }}
                      className="text-xs text-indigo-300 hover:text-indigo-200 bg-indigo-950/60 px-3 py-1.5 rounded-lg border border-indigo-500/30 flex items-center gap-1.5 transition font-semibold"
                    >
                      <Play className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Testar no Playground</span>
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditingModel(m)}
                        className="text-xs text-amber-300 hover:text-amber-200 bg-amber-950/60 p-1.5 rounded-lg border border-amber-500/30 transition"
                      >
                        <Edit className="w-3.5 h-3.5 text-amber-400" />
                      </button>

                      <button
                        onClick={() => handleDeleteModel(m.id)}
                        className="text-xs text-rose-300 hover:text-rose-200 bg-rose-950/60 p-1.5 rounded-lg border border-rose-500/30 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 3: AGENTES DE IA ORQUESTRADOS */}
      {/* ==================================================== */}
      {activeSubTab === 'ai_agents' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Agentes Especializados com Salvaguardas</h3>
              <p className="text-xs text-slate-400">
                Agentes autônomos que formulam perguntas contextuais enquanto o PASQUARED delibera o parecer.
              </p>
            </div>

            <button
              onClick={() => setShowAddAgentModal(true)}
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Agente de IA</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {agentsList.map((agent) => (
              <div key={agent.id} className="quantum-card-glow rounded-2xl p-5 space-y-4 border border-cyan-500/30 bg-slate-900/90">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
                      <Bot className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{agent.name}</h4>
                      <span className="text-[11px] text-cyan-300 font-mono">{agent.role}</span>
                    </div>
                  </div>
                  <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-mono px-2 py-0.5 rounded-full border border-emerald-500/30">
                    {agent.status.toUpperCase()}
                  </span>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2">{agent.description}</p>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs font-mono text-slate-400">
                  <div className="flex justify-between">
                    <span>Aprovação Humana Se IGA &lt;:</span>
                    <strong className="text-amber-300">{agent.governanceLimits.requireHumanApprovalThreshold}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Ações de Alto Risco:</span>
                    <strong className={agent.governanceLimits.allowHighRiskActions ? 'text-rose-400' : 'text-emerald-400'}>
                      {agent.governanceLimits.allowHighRiskActions ? 'Permitido' : 'Bloqueado'}
                    </strong>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-800">
                  <button
                    onClick={() => setEditingAgent(agent)}
                    className="text-xs text-amber-300 bg-amber-950/60 p-1.5 rounded-lg border border-amber-500/30 transition"
                  >
                    <Edit className="w-3.5 h-3.5 text-amber-400" />
                  </button>

                  <button
                    onClick={() => handleDeleteAgent(agent.id)}
                    className="text-xs text-rose-300 bg-rose-950/60 p-1.5 rounded-lg border border-rose-500/30 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 4: PLAYGROUND COM INTERCEPÇÃO */}
      {/* ==================================================== */}
      {activeSubTab === 'playground' && (
        <div className="quantum-card-glow rounded-2xl p-6 border border-slate-800 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              <h3 className="text-base font-bold text-white">Playground Interativo com Intercepção PASQUARED</h3>
            </div>
            <div className="text-xs font-mono text-slate-300 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              Modelo Ativo: <strong className="text-indigo-400">{selectedModel.name}</strong> ({selectedModel.provider})
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                Solicitação / Prompt para o AI Gateway:
              </label>
              <textarea
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                rows={8}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs font-mono text-slate-100 focus:outline-none focus:border-indigo-500 transition resize-none"
                placeholder="Digite a instrução para passar pelo AI Gateway protegido..."
              />
              <button
                onClick={handleTestGateway}
                disabled={isGenerating || !promptText.trim()}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs px-6 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition"
              >
                {isGenerating ? (
                  <span className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    Validando via POKO & Executando...
                  </span>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Enviar via AI Gateway Protegido</span>
                  </>
                )}
              </button>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                Retorno com Trilha de Auditoria & MVED:
              </label>
              <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 min-h-[220px] text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed overflow-y-auto">
                {responseOutput ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-[11px]">
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Intercepção PASQUARED Validada
                      </span>
                      <span className="text-slate-400">Latência: {responseOutput.latencyMs}ms</span>
                    </div>
                    <p className="text-slate-100 font-sans text-xs">{responseOutput.text}</p>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-500 py-12 space-y-2">
                    <Boxes className="w-8 h-8 opacity-40" />
                    <span>Envie uma instrução para validar a intercepção de governança em tempo real.</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL: CONECTAR NOVA BASE DE CONHECIMENTO */}
      {/* ==================================================== */}
      {showAddKbModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#030d1a] border border-emerald-500/40 rounded-3xl p-6 sm:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                <span>Conectar Nova Base de Conhecimento (Pública / Privada)</span>
              </h3>
              <button onClick={() => setShowAddKbModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddKnowledgeBase} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300">Nome da Base de Conhecimento:</label>
                  <input
                    type="text"
                    value={newKbName}
                    onChange={(e) => setNewKbName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    placeholder="Ex: Normas Regulatórias ANVISA 2026"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Área de Conhecimento:</label>
                  <select
                    value={newKbArea}
                    onChange={(e) => setNewKbArea(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Jurídico & Regulatório">Jurídico & Regulatório</option>
                    <option value="Financeiro & Bancário">Financeiro & Bancário</option>
                    <option value="Saúde & Medicina">Saúde & Medicina</option>
                    <option value="Tecnologia & Cibersegurança">Tecnologia & Cibersegurança</option>
                    <option value="Indústria & Engenharia">Indústria & Engenharia</option>
                    <option value="Governança & Risco">Governança & Risco</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Escopo da Base:</label>
                  <select
                    value={newKbScope}
                    onChange={(e) => setNewKbScope(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="public">Pública (Regulatórios, Leis, Artigos Científicos)</option>
                    <option value="private">Privada / Confidencial (Data Lake Interno, S3, SQL)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Dimensão Ontológica POKO:</label>
                  <select
                    value={newKbDimension}
                    onChange={(e) => setNewKbDimension(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Evidência (α)">Evidência (α) - Fatos e Dados Concretos</option>
                    <option value="Contexto Local (β)">Contexto Local (β) - Políticas e Procedimentos</option>
                    <option value="Memória Histórica (γ)">Memória Histórica (γ) - Decisões Anteriores</option>
                    <option value="Salvaguarda & Risco (δ)">Salvaguarda & Risco (δ) - Restrições e Leis</option>
                  </select>
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="text-slate-300">URL / Host / Endpoint do Repositório:</label>
                  <input
                    type="text"
                    value={newKbUrl}
                    onChange={(e) => setNewKbUrl(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-cyan-300 font-mono"
                    placeholder="https://api.empresa.com/lake ou s3://meu-bucket/documentos"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Método de Autenticação:</label>
                  <select
                    value={newKbAuth}
                    onChange={(e) => setNewKbAuth(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="public_no_auth">Pública (Sem autenticação necessária)</option>
                    <option value="bearer_token">Bearer Token / JWT</option>
                    <option value="api_key">API Key no Header</option>
                    <option value="mtls">mTLS / Certificado de Cliente X.509</option>
                    <option value="oauth2">OAuth 2.0 Client Credentials</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Formato dos Dados:</label>
                  <select
                    value={newKbFormat}
                    onChange={(e) => setNewKbFormat(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="PDF/Docs">PDF / Documentos Corporativos</option>
                    <option value="SQL Data Lake">SQL Data Lake / PostgreSQL</option>
                    <option value="REST Feed">REST Feed / JSON Realtime</option>
                    <option value="Vector Embedding">Vector Embeddings (Pinecone/Milvus)</option>
                    <option value="Ontological Graph">Grafo Ontológico RDF/OWL</option>
                  </select>
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="text-slate-300">Descrição e Finalidade:</label>
                  <textarea
                    value={newKbDesc}
                    onChange={(e) => setNewKbDesc(e.target.value)}
                    rows={3}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white resize-none"
                    placeholder="Explique o propósito desta base no processo de deliberação..."
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddKbModal(false)}
                  className="px-4 py-2 bg-slate-900 text-xs rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/30"
                >
                  Conectar Base de Conhecimento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL: CADASTRAR NOVO MODELO / GATEWAY */}
      {/* ==================================================== */}
      {showAddModelModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#030d1a] border border-indigo-500/40 rounded-3xl p-6 sm:p-8 max-w-xl w-full space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-400" />
                <span>Cadastrar Novo Modelo no AI Gateway</span>
              </h3>
              <button onClick={() => setShowAddModelModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddModel} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300">Nome do Modelo:</label>
                <input
                  type="text"
                  value={newModelName}
                  onChange={(e) => setNewModelName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  placeholder="Ex: Gemini 2.5 Pro Sovereign"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300">Provedor:</label>
                  <select
                    value={newModelProvider}
                    onChange={(e) => setNewModelProvider(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Google">Google (Gemini)</option>
                    <option value="Microsoft">Microsoft Azure (OpenAI / Phi)</option>
                    <option value="IBM">IBM Watsonx (Granite)</option>
                    <option value="OpenAI">OpenAI Direct</option>
                    <option value="Local-Cluster">Local-Cluster (Soberano On-Prem)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Família / Engine:</label>
                  <input
                    type="text"
                    value={newModelFamily}
                    onChange={(e) => setNewModelFamily(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Endpoint URL da API:</label>
                <input
                  type="text"
                  value={newModelEndpoint}
                  onChange={(e) => setNewModelEndpoint(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-cyan-300 font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300">Latência Média Estimada (ms):</label>
                  <input
                    type="number"
                    value={newModelLatency}
                    onChange={(e) => setNewModelLatency(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Custo / 1k Tokens ($):</label>
                  <input
                    type="number"
                    step="0.00001"
                    value={newModelCost}
                    onChange={(e) => setNewModelCost(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModelModal(false)}
                  className="px-4 py-2 bg-slate-900 text-xs rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl"
                >
                  Salvar Modelo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL: CADASTRAR NOVO AGENTE */}
      {/* ==================================================== */}
      {showAddAgentModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#030d1a] border border-cyan-500/40 rounded-3xl p-6 sm:p-8 max-w-xl w-full space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Bot className="w-4 h-4 text-cyan-400" />
                <span>Criar Agente de IA Orquestrado</span>
              </h3>
              <button onClick={() => setShowAddAgentModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddAgent} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300">Nome do Agente:</label>
                <input
                  type="text"
                  value={newAgentName}
                  onChange={(e) => setNewAgentName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  placeholder="Ex: Agente Investigativo de Crédito PJ"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300">Função / Especialidade:</label>
                  <input
                    type="text"
                    value={newAgentRole}
                    onChange={(e) => setNewAgentRole(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    placeholder="Ex: Auditoria Contábil"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Modelo Vinculado:</label>
                  <select
                    value={newAgentModelId}
                    onChange={(e) => setNewAgentModelId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    {modelsList.map(m => (
                      <option key={m.id} value={m.id}>{m.name} ({m.provider})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">System Prompt / Diretriz Epistêmica:</label>
                <textarea
                  value={newAgentSystemPrompt}
                  onChange={(e) => setNewAgentSystemPrompt(e.target.value)}
                  rows={4}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white resize-none font-mono text-[11px]"
                  placeholder="Defina o comportamento do agente para formulação de perguntas e coleta fática..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddAgentModal(false)}
                  className="px-4 py-2 bg-slate-900 text-xs rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-xl"
                >
                  Criar Agente
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
