import React, { useState } from 'react';
import { Key, Webhook, CheckCircle2, Copy, Plus, RefreshCw, Lock, Globe } from 'lucide-react';

export const IntegrationsView: React.FC = () => {
  const [apiKeys, setApiKeys] = useState([
    {
      id: 'key-prod-01',
      name: 'Produção AI Gateway Interceptor',
      key: 'psq_live_9f823a8c41d94be09f2134a',
      created: '2026-08-10',
      lastUsed: 'Hoje, 14:32',
      status: 'active'
    },
    {
      id: 'key-stg-01',
      name: 'Staging & Pipeline CI/CD',
      key: 'psq_test_1289cf004b2a99182390abc',
      created: '2026-08-15',
      lastUsed: 'Ontem, 19:10',
      status: 'active'
    }
  ]);

  const [webhooks, setWebhooks] = useState([
    {
      id: 'wh-01',
      url: 'https://api.nexus-global.com/governance/pasquared-events',
      events: ['policy.violation', 'pre.recorded', 'human_approval.required'],
      status: 'active',
      deliveries: 1420
    }
  ]);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              DEVELOPER INTEGRATIONS
            </span>
            <span className="text-xs text-slate-400 font-mono">
              API Keys & Webhooks de Governança
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Chaves de API, Webhooks & Integrações Externas
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Conecte seus microsserviços, pipelines de MLOps e plataformas corporativas (SIEM, Datadog, Slack, Teams) ao PASQUARED-OS.
          </p>
        </div>
      </div>

      {/* API Keys */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Key className="w-4 h-4 text-indigo-400" />
            Chaves de Autenticação de API (Bearer Tokens)
          </h3>
          <button
            onClick={() => alert('Nova chave de API gerada com escopo restrito.')}
            className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Criar Nova Chave</span>
          </button>
        </div>

        <div className="space-y-3">
          {apiKeys.map((k) => (
            <div key={k.id} className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 font-mono text-xs">
              <div>
                <div className="font-sans font-bold text-white mb-1">{k.name}</div>
                <div className="text-slate-400 text-[11px]">{k.key}</div>
              </div>
              <div className="flex items-center gap-4 text-slate-400 text-[11px]">
                <span>Criada: {k.created}</span>
                <span>Último Uso: {k.lastUsed}</span>
                <span className="text-emerald-400 font-bold uppercase">{k.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Webhooks */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Webhook className="w-4 h-4 text-cyan-400" />
          Webhooks de Eventos em Tempo Real
        </h3>
        <div className="space-y-3">
          {webhooks.map((w) => (
            <div key={w.id} className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 font-mono text-xs">
              <div>
                <div className="font-sans font-bold text-white mb-1">{w.url}</div>
                <div className="text-slate-400 text-[11px]">{w.events.join(' • ')}</div>
              </div>
              <div className="flex items-center gap-4 text-slate-400 text-[11px]">
                <span>Entregas: {w.deliveries}</span>
                <span className="text-emerald-400 font-bold uppercase">{w.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
