import React, { useState } from 'react';
import {
  BrainCircuit,
  Sliders,
  CheckCircle2,
  XCircle,
  HelpCircle,
  TrendingUp,
  Cpu,
  RefreshCw,
  GitCompare,
  ArrowRight,
  FileCheck
} from 'lucide-react';
import { ObserverProfile, CognitiveVector } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';

interface DecisionIntelligenceViewProps {
  observer: ObserverProfile;
}

export const DecisionIntelligenceView: React.FC<DecisionIntelligenceViewProps> = ({ observer }) => {
  const [scenarioPrompt, setScenarioPrompt] = useState(
    'Empresa de telecomunicações deseja implementar cancelamento automático de contratos inadimplentes por mais de 90 dias com negativação em birôs de crédito.'
  );

  // Counterfactual sliders for Cognitive Vector h=(p,c,m,e,l)
  const [vector, setVector] = useState<CognitiveVector>({
    p: 0.92,
    c: 0.85,
    m: 0.80,
    e: 0.35,
    l: 0.95
  });

  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationResult, setSimulationResult] = useState<any>(null);

  const handleSimulate = async () => {
    setIsSimulating(true);
    try {
      const result = await globalPasquaredEngine.executeSAC(scenarioPrompt, observer);
      setSimulationResult(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSimulating(false);
    }
  };

  const calculatedIGA = globalPasquaredEngine.calculateIGA(vector);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              DECISION INTELLIGENCE
            </span>
            <span className="text-xs text-slate-400 font-mono">
              MPAC Bayesiano & Análise Contrafactual
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Simulador de Inteligência Decisória & Racionalização
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Modele e teste cenários complexos com variação contrafactual do vetor cognitivo <span className="font-mono text-cyan-300">h = (p, c, m, e, l)</span> e 
            eliminação automática de alternativas inviáveis pelo operador MVED.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <BrainCircuit className="w-4 h-4" />
            IGA Calculado: {calculatedIGA.toFixed(3)}
          </span>
        </div>
      </div>

      {/* Grid: Scenario + Vector Sliders vs Results */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Input & Vector Sliders (6 cols) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-5">
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Cenário Decisório Organizacional:
            </label>
            <textarea
              value={scenarioPrompt}
              onChange={(e) => setScenarioPrompt(e.target.value)}
              rows={3}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono resize-none leading-relaxed"
              placeholder="Descreva o dilema ou cenário decisório..."
            />
          </div>

          {/* Cognitive Vector Sliders */}
          <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sliders className="w-4 h-4" />
                Vetor Cognitivo Contrafactual h=(p,c,m,e,l)
              </span>
              <span className="text-[11px] font-mono text-cyan-300">
                IGA: {calculatedIGA.toFixed(3)}
              </span>
            </div>

            {/* Percepção */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Percepção dos Fatos (p):</span>
                <span className="font-mono text-indigo-400">{vector.p.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={vector.p}
                onChange={(e) => setVector({ ...vector, p: parseFloat(e.target.value) })}
                className="w-full accent-indigo-500"
              />
            </div>

            {/* Contexto */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Adequação Contextual (c):</span>
                <span className="font-mono text-indigo-400">{vector.c.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={vector.c}
                onChange={(e) => setVector({ ...vector, c: parseFloat(e.target.value) })}
                className="w-full accent-indigo-500"
              />
            </div>

            {/* Memória */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Reforço de Memória SMEE (m):</span>
                <span className="font-mono text-indigo-400">{vector.m.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={vector.m}
                onChange={(e) => setVector({ ...vector, m: parseFloat(e.target.value) })}
                className="w-full accent-indigo-500"
              />
            </div>

            {/* Emoção */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Intensidade Emocional / Ruído (e):</span>
                <span className="font-mono text-amber-400">{vector.e.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={vector.e}
                onChange={(e) => setVector({ ...vector, e: parseFloat(e.target.value) })}
                className="w-full accent-amber-500"
              />
            </div>

            {/* Coerência Lógica */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Coerência Lógica & Provas (l):</span>
                <span className="font-mono text-emerald-400">{vector.l.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={vector.l}
                onChange={(e) => setVector({ ...vector, l: parseFloat(e.target.value) })}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          <button
            onClick={handleSimulate}
            disabled={isSimulating || !scenarioPrompt.trim()}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition"
          >
            {isSimulating ? (
              <span className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Simulando no Kernel PASQUARED...</span>
              </span>
            ) : (
              <>
                <BrainCircuit className="w-4 h-4" />
                <span>Processar Simulação de Decisão</span>
              </>
            )}
          </button>
        </div>

        {/* Right: Simulation Output & Competing Hypotheses (6 cols) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Deliberação do Algoritmo PASQUARED
              </span>
              {simulationResult && (
                <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                  Status: {simulationResult.decision.policyStatus}
                </span>
              )}
            </div>

            {simulationResult ? (
              <div className="mt-4 space-y-4">
                {/* Winning Decision */}
                <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/60 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    <CheckCircle2 className="w-4 h-4" />
                    Decisão Otimizada Escolhida (Maior IGA & MPAC)
                  </div>
                  <p className="text-sm text-white font-medium leading-relaxed">
                    "{simulationResult.decision.selectedMeaning}"
                  </p>
                  <div className="flex justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800">
                    <span>IGA: <strong className="text-cyan-400">{simulationResult.decision.iga.toFixed(3)}</strong></span>
                    <span>Consistência ICI: <strong className="text-indigo-400">{simulationResult.decision.ici.toFixed(3)}</strong></span>
                  </div>
                </div>

                {/* Rejected Alternatives */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                    Hipóteses Alternativas Rejeitadas (Poda MVED):
                  </span>
                  {simulationResult.decision.rejectedHypotheses.map((rej: any, idx: number) => (
                    <div key={idx} className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-rose-400 font-semibold flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" />
                          Rejeitada
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">Score: {rej.score.toFixed(2)}</span>
                      </div>
                      <p className="text-slate-200">{rej.statement}</p>
                      <p className="text-[11px] text-slate-400 font-mono">Motivo: {rej.reason}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="py-24 text-center text-xs text-slate-500 space-y-2">
                <BrainCircuit className="w-8 h-8 mx-auto opacity-40" />
                <p>Clique em "Processar Simulação de Decisão" para gerar a análise comparativa de hipóteses.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
