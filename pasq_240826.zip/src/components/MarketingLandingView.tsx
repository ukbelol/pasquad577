import React, { useState, useEffect } from 'react';
import {
  Shield,
  Zap,
  Cpu,
  BrainCircuit,
  Database,
  Lock,
  Boxes,
  Activity,
  CheckCircle2,
  ArrowRight,
  ArrowDown,
  ChevronRight,
  ChevronLeft,
  Building2,
  Key,
  Globe,
  Sliders,
  Scale,
  Sparkles,
  Server,
  FileCheck,
  Check,
  Star,
  Play,
  Pause,
  Layers,
  Terminal,
  BarChart3,
  Users,
  Compass,
  FileSpreadsheet,
  Network,
  Eye,
  CheckCircle
} from 'lucide-react';
import { PasquaredLogo, PasquaredImage } from './PasquaredLogo';
import { User } from '../types/pasquared';

interface MarketingLandingViewProps {
  onOpenClientLogin: () => void;
  onOpenClientRegister: (planTier?: string) => void;
  onOpenSuperAdminLogin: () => void;
  onExploreKernelDemo: () => void;
  currentUser: User | null;
  onGoToDashboard: () => void;
}

export const MarketingLandingView: React.FC<MarketingLandingViewProps> = ({
  onOpenClientLogin,
  onOpenClientRegister,
  onOpenSuperAdminLogin,
  onExploreKernelDemo,
  currentUser,
  onGoToDashboard
}) => {
  // Frosted Blur Slide Deck State
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [progressPercent, setProgressPercent] = useState(0);
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annual'>('annual');

  const slides = [
    {
      id: 'mved',
      number: '01',
      icon: BrainCircuit,
      shortTitle: 'Poda MVED',
      badge: 'NÚCLEO EPISTÊMICO INQUEBRÁVEL',
      title: 'Poda MVED: Eliminação Matemática de Alucinações de IA',
      subtitle: 'Multi-Vector Epistemic Disambiguation',
      description:
        'Submeta cada token gerado por LLMs à validação quântica vetorial. O PASQUARED analisa a ontologia POKO em tempo real e descarta desvios factuais antes de atingirem seus sistemas críticos.',
      benefits: [
        'Zero Alucinações em relatórios jurídicos, financeiros e diagnósticos',
        'Cálculo de acurácia epistêmica instantâneo em cada deliberação',
        'Economia de até 78% em retrabalho e auditoria manual'
      ],
      tag: 'Precisão de 99.98%',
      accentGlow: 'rgba(0, 240, 255, 0.35)',
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40',
      activeBorder: 'border-cyan-400',
      imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
      metric: '99.98%',
      metricLabel: 'Acurácia Epistêmica Comprovada'
    },
    {
      id: 'pre',
      number: '02',
      icon: Shield,
      shortTitle: 'Pre-Ledger PRE',
      badge: 'IMUTABILIDADE CRIPTOGRÁFICA',
      title: 'Pre-Ledger PRE: Auditoria e Rastreabilidade Indeléveis',
      subtitle: 'Provable Reality Enclave & Merkle Proofs',
      description:
        'Grave cada decisão da IA com hash SHA-256 e assinatura de chave assimétrica em um ledger distribuído à prova de adulteração. Perfeito para auditorias do BACEN, SEC, LGPD e ISO 42001.',
      benefits: [
        'Provas matemáticas de não-repúdio aceitas em tribunais e auditorias',
        'Reconstituição passo a passo do raciocínio da IA em microssegundos',
        'Blindagem jurídica contra ações de responsabilidade civil algorítmica'
      ],
      tag: 'Conformidade Forense',
      accentGlow: 'rgba(16, 185, 129, 0.35)',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40',
      activeBorder: 'border-emerald-400',
      imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1200&q=80',
      metric: '100%',
      metricLabel: 'Rastreabilidade Criptográfica'
    },
    {
      id: 'gateway',
      number: '03',
      icon: Cpu,
      shortTitle: 'AI Gateway Híbrido',
      badge: 'ORQUESTRAÇÃO MULTI-MODELO',
      title: 'AI Gateway Híbrido: Gemini, Claude, GPT & Watsonx',
      subtitle: 'Roteamento Inteligente por Custo, Latência e Especialidade',
      description:
        'Unifique seus provedores de inteligência artificial em um único pipeline corporativo de alta resiliência com fallback automático, cache semântico de embeddings e balanceamento quântico.',
      benefits: [
        'Redução média de 42% no custo de tokens com roteamento inteligente',
        'Disponibilidade 99.999% com failover automático instantâneo',
        'Políticas unificadas de DLP (Prevenção de Perda de Dados) em todos os modelos'
      ],
      tag: 'Alta Performance',
      accentGlow: 'rgba(99, 102, 241, 0.35)',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
      activeBorder: 'border-indigo-400',
      imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1200&q=80',
      metric: '42%',
      metricLabel: 'Redução Direta de Custos de API'
    },
    {
      id: 'connectors',
      number: '04',
      icon: Database,
      shortTitle: 'Conectores Universais',
      badge: 'ALIMENTAÇÃO & INGESTÃO CORPORATIVA',
      title: 'Conectores Universais: ERP, SQL, Data Lakes & IoT',
      subtitle: 'Alimente o Kernel com seus Dados Reais sem Complexidade',
      description:
        'Conecte com facilidade SAP, Salesforce, PostgreSQL, bancos legados, webhooks e APIs REST para que o motor decisório tome deliberações com base no contexto específico da sua empresa.',
      benefits: [
        'Integração rápida em poucos cliques via interface visual ou PQL',
        'Parametrização dinâmica de pesos de decisão por departamento',
        'Isolamento multi-tenant com criptografia ponta a ponta'
      ],
      tag: 'Plug & Play Corporativo',
      accentGlow: 'rgba(245, 158, 11, 0.35)',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
      activeBorder: 'border-amber-400',
      imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=80',
      metric: '50+',
      metricLabel: 'Conectores Nativos Prontos'
    },
    {
      id: 'compliance',
      number: '05',
      icon: Scale,
      shortTitle: 'Conformidade Global',
      badge: 'BLINDAGEM REGULATÓRIA GLOBAL',
      title: 'EU AI Act, ISO/IEC 42001 & Governança IGA',
      subtitle: 'Matriz de Risco 5x5 com Mitigação em Tempo Real',
      description:
        'Controles de risco automatizados para IA de Alto Risco. Avaliação contínua de viés algorítmico, equidade, transparência e aprovações humanas obrigatórias conforme a legislação global.',
      benefits: [
        'Adesão automática às exigências do Regulamento Europeu de IA',
        'Relatórios executivos prontos para auditorias externas em 1 clique',
        'Detecção proativa de anomalias e bloqueio de violações de conformidade'
      ],
      tag: 'Certificação Instantânea',
      accentGlow: 'rgba(6, 182, 212, 0.35)',
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40',
      activeBorder: 'border-cyan-400',
      imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80',
      metric: '100%',
      metricLabel: 'Conformidade Regulatória Total'
    }
  ];

  // Auto slide loop with animated progress bar (11 seconds per slide)
  useEffect(() => {
    if (!isAutoPlaying) return;
    const duration = 11000; // 11 segundos de transição entre cada slide
    const intervalTime = 50;
    let elapsed = 0;

    const timer = setInterval(() => {
      elapsed += intervalTime;
      setProgressPercent(Math.min(100, (elapsed / duration) * 100));

      if (elapsed >= duration) {
        elapsed = 0;
        setCurrentSlideIndex(prev => (prev + 1) % slides.length);
        setProgressPercent(0);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isAutoPlaying, currentSlideIndex, slides.length]);

  const handleSelectSlide = (idx: number) => {
    setCurrentSlideIndex(idx);
    setProgressPercent(0);
  };

  const handleNextSlide = () => {
    setCurrentSlideIndex(prev => (prev + 1) % slides.length);
    setProgressPercent(0);
  };

  const handlePrevSlide = () => {
    setCurrentSlideIndex(prev => (prev - 1 + slides.length) % slides.length);
    setProgressPercent(0);
  };

  const currentSlide = slides[currentSlideIndex];

  // Acquisition Plans
  const plans = [
    {
      id: 'starter',
      tier: 'STARTER SCALE',
      badge: 'Ideal para Startups & Médias',
      priceMonthly: 'R$ 2.490',
      priceAnnual: 'R$ 1.990',
      period: '/mês',
      description: 'Estruture a governança dos seus primeiros agentes com segurança criptográfica e conformidade.',
      features: [
        'Até 5 Agentes de IA Concorrentes',
        'Poda MVED Básica (Taxa de acurácia 98.5%)',
        'Pre-Ledger PRE com retenção de 90 dias',
        'AI Gateway com Gemini 2.5 Flash & GPT-4o Mini',
        'Até 5 Usuários e Administradores',
        '10 Conectores de Dados (REST / SQL)',
        'Suporte em Horário Comercial'
      ],
      highlight: false,
      buttonText: 'Contratar Starter',
      buttonClass: 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
    },
    {
      id: 'enterprise',
      tier: 'COGNITIVE ENTERPRISE',
      badge: 'Mais Escolhido por Grandes Empresas',
      priceMonthly: 'R$ 6.890',
      priceAnnual: 'R$ 5.490',
      period: '/mês',
      description: 'Poder total do Kernel PASQUARED-OS com parametrização irrestrita e auditoria em tempo real.',
      features: [
        'Agentes de IA Ilimitados',
        'Poda MVED Avançada com Ontologia POKO Total (99.98%)',
        'Pre-Ledger PRE Imutável com Retenção Vitalícia',
        'AI Gateway Completo (Gemini Pro, Claude 3.5 Sonnet, GPT-4o, Watsonx)',
        'Usuários e Departamentos Ilimitados com RBAC',
        'Conectores Universais Ilimitados (SAP, Salesforce, Postgres, Kafka)',
        'Matriz de Riscos 5x5 & Relatórios EU AI Act / ISO 42001',
        'Parametrizador Decisório de TI com Simulações em Tempo Real',
        'SLA 99.99% com Suporte 24/7 Dedicado'
      ],
      highlight: true,
      buttonText: 'Contratar Enterprise Pro',
      buttonClass: 'bg-gradient-to-r from-cyan-500 via-blue-600 to-emerald-500 hover:opacity-95 text-white shadow-[0_0_25px_rgba(0,240,255,0.4)]'
    },
    {
      id: 'quantum_sovereign',
      tier: 'QUANTUM SOVEREIGN',
      badge: 'Governo & Defesa / On-Premise',
      priceMonthly: 'R$ 14.500',
      priceAnnual: 'R$ 11.900',
      period: '/mês',
      description: 'Implementação isolada em ambiente soberano com certificados dedicados e nós K8s próprios.',
      features: [
        'Deploy Soberano On-Premise, Air-Gapped ou Nuvem Privada',
        'Certbot SSL Let\'s Encrypt com Domínio Próprio e Gestor Apache',
        'Calibração Quântica de Pesos Direto no Kernel Root',
        'Acesso Completo ao Console PQL (PASQUARED Query Language)',
        'Cluster Dedicado Kubernetes com Nós de Inferência Exclusivos',
        'Customização de Modelos Locais (Llama 3, DeepSeek R1, Mistral)',
        'Engenheiro de Solução & Arquiteto de IA Dedicado'
      ],
      highlight: false,
      buttonText: 'Solicitar Acesso Soberano',
      buttonClass: 'bg-gradient-to-r from-amber-600 to-orange-600 hover:opacity-95 text-white border border-amber-500/40 shadow-lg shadow-amber-600/30'
    }
  ];

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-black overflow-x-hidden font-sans">
      {/* Top Navbar */}
      <header className="sticky top-0 z-50 bg-[#030d1a]/90 backdrop-blur-xl border-b border-cyan-500/20 px-3 sm:px-6 py-2.5 flex items-center justify-between shadow-[0_4px_30px_rgba(0,0,0,0.8)]">
        <div className="flex items-center gap-3">
          {/* Módulo de Acoplamento de Imagem (Image Coupling Module) */}
          <div className="relative w-10 h-10 rounded-xl flex items-center justify-center shrink-0 overflow-hidden border border-cyan-400/50 bg-[#020b18] shadow-[0_0_15px_rgba(0,240,255,0.3)]">
            <PasquaredImage
              alt="PASQUARED-OS Logotipo"
              className="w-full h-full object-contain p-1 relative z-10 filter drop-shadow-[0_0_8px_rgba(0,245,160,0.6)]"
            />
          </div>
          {/* Nome do Sistema em Primeiro Plano */}
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-black tracking-tight text-base sm:text-lg bg-gradient-to-r from-cyan-300 via-blue-300 to-emerald-300 bg-clip-text text-transparent">
                PASQUARED-OS
              </span>
              <span className="bg-gradient-to-r from-cyan-500/20 to-emerald-500/20 text-cyan-300 border border-cyan-400/30 text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full tracking-widest shadow-[0_0_10px_rgba(0,240,255,0.2)]">
                v2.5
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-300 font-mono tracking-tight">
              Enterprise Cognitive Governance & Quantum Engine
            </p>
          </div>
        </div>

        {/* Quick Anchor Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs font-semibold text-slate-300">
          <button
            onClick={() => scrollToSection('apresentacao-blur')}
            className="px-3 py-1.5 rounded-lg hover:text-cyan-300 hover:bg-slate-900/80 transition flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Apresentação</span>
          </button>
          <button
            onClick={() => scrollToSection('planos')}
            className="px-3 py-1.5 rounded-lg hover:text-emerald-300 hover:bg-slate-900/80 transition flex items-center gap-1"
          >
            <Star className="w-3.5 h-3.5 text-emerald-400" />
            <span>Planos & Preços</span>
          </button>
          <button
            onClick={() => scrollToSection('funcionalidades')}
            className="px-3 py-1.5 rounded-lg hover:text-blue-300 hover:bg-slate-900/80 transition flex items-center gap-1"
          >
            <Cpu className="w-3.5 h-3.5 text-blue-400" />
            <span>Módulos</span>
          </button>
          <button
            onClick={() => scrollToSection('conectores')}
            className="px-3 py-1.5 rounded-lg hover:text-amber-300 hover:bg-slate-900/80 transition flex items-center gap-1"
          >
            <Database className="w-3.5 h-3.5 text-amber-400" />
            <span>Conectores TI</span>
          </button>
          <button
            onClick={() => scrollToSection('seguranca')}
            className="px-3 py-1.5 rounded-lg hover:text-purple-300 hover:bg-slate-900/80 transition flex items-center gap-1"
          >
            <Shield className="w-3.5 h-3.5 text-purple-400" />
            <span>Segurança</span>
          </button>
        </nav>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => scrollToSection('planos')}
            className="hidden sm:flex items-center gap-1.5 text-xs text-cyan-300 hover:text-white font-semibold px-3 py-1.5 rounded-xl border border-cyan-500/30 hover:bg-cyan-950/60 backdrop-blur-md transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Ver Planos</span>
          </button>

          {currentUser ? (
            <button
              onClick={onGoToDashboard}
              className="bg-gradient-to-r from-cyan-600 to-emerald-600 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl shadow-lg shadow-cyan-500/30 flex items-center gap-1.5 hover:opacity-95 transition"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Meu Dashboard</span>
            </button>
          ) : (
            <>
              <button
                onClick={onOpenClientLogin}
                className="text-xs text-slate-300 hover:text-white font-semibold px-3 py-1.5 rounded-xl hover:bg-slate-900/80 transition border border-slate-800"
              >
                Entrar
              </button>

              <button
                onClick={() => onOpenClientRegister()}
                className="bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl shadow-md shadow-cyan-600/30 border border-cyan-400/40 flex items-center gap-1.5 transition"
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Cadastrar</span>
              </button>
            </>
          )}

          {/* Super Admin Restricted Gate */}
          <button
            onClick={onOpenSuperAdminLogin}
            className="flex items-center gap-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-2.5 py-1.5 rounded-xl transition backdrop-blur-md"
            title="Área Restrita Root para Super Administrador"
          >
            <Lock className="w-3 h-3 text-amber-400" />
            <span className="hidden sm:inline">Super Admin</span>
          </button>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* PRIMEIRA TELA COMPLETA SEM ROLAGEM: HERO COMPACTO + TODOS OS SLIDES BLUR */}
      {/* ========================================================================= */}
      <section
        id="apresentacao-blur"
        className="relative min-h-[calc(100vh-60px)] flex flex-col justify-between px-3 sm:px-6 lg:px-8 py-3 max-w-7xl mx-auto w-full"
      >
        {/* Glow ambient background lights */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[380px] bg-[radial-gradient(circle,rgba(0,240,255,0.15)_0%,rgba(0,102,255,0.08)_40%,transparent_70%)] pointer-events-none blur-3xl -z-10" />

        {/* Compact Hero Header (Clean & Direct) */}
        <div className="text-center space-y-1.5 pt-1">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-emerald-500/10 border border-cyan-500/30 px-3 py-1 rounded-full backdrop-blur-md shadow-[0_0_15px_rgba(0,240,255,0.15)]">
            <PasquaredImage className="w-4 h-4 object-contain animate-pulse" alt="logo" />
            <span className="text-[11px] font-mono font-bold text-cyan-300 tracking-wider uppercase">
              Governança Cognitiva & Decisão Autônoma • PASQUARED-OS
            </span>
            <span className="bg-cyan-400/20 text-cyan-200 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
              99.98% Acurácia
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white leading-tight max-w-4xl mx-auto">
            Controle Absoluto e Imutável da IA Corporativa
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl mx-auto line-clamp-2 sm:line-clamp-none">
            Elimine alucinações matemáticas com a <strong>Poda MVED</strong>, garanta rastreabilidade no <strong>Pre-Ledger PRE</strong> e orquestre múltiplos modelos em um enclave blindado.
          </p>
        </div>

        {/* ========================================================== */}
        {/* FROSTED BLUR SLIDE SHOWCASE (TODOS OS SLIDES EM ESTILO BLUR) */}
        {/* ========================================================== */}
        <div className="my-2 space-y-2.5">
          {/* Frosted Glass Tab Selector: TODOS OS 5 SLIDES VISÍVEIS DIRETAMENTE */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 sm:gap-2">
            {slides.map((slide, idx) => {
              const IconComp = slide.icon;
              const isActive = currentSlideIndex === idx;

              return (
                <button
                  key={slide.id}
                  onClick={() => handleSelectSlide(idx)}
                  className={`relative p-2 sm:p-2.5 rounded-2xl text-left transition-all duration-300 backdrop-blur-xl flex flex-col justify-between overflow-hidden ${
                    isActive
                      ? 'bg-slate-900/80 border border-cyan-400 shadow-[0_0_20px_rgba(0,240,255,0.3)] ring-1 ring-cyan-400/50'
                      : 'bg-slate-950/50 hover:bg-slate-900/60 border border-slate-800/80 hover:border-cyan-500/30 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {/* Subtle active glow indicator */}
                  {isActive && (
                    <div
                      className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 pointer-events-none"
                      style={{ boxShadow: `inset 0 0 15px ${slide.accentGlow}` }}
                    />
                  )}

                  <div className="flex items-center justify-between w-full relative z-10">
                    <span className="text-[10px] font-mono font-bold text-slate-400">
                      {slide.number}
                    </span>
                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center ${
                        isActive
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50'
                          : 'bg-slate-900 text-slate-400'
                      }`}
                    >
                      <IconComp className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <div className="relative z-10 mt-1">
                    <div
                      className={`text-xs font-bold truncate ${
                        isActive ? 'text-white' : 'text-slate-300'
                      }`}
                    >
                      {slide.shortTitle}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono truncate hidden sm:block">
                      {slide.metric} • {slide.tag}
                    </div>
                  </div>

                  {/* Active Progress Bar inside tab */}
                  {isActive && isAutoPlaying && (
                    <div className="w-full bg-slate-800 h-1 rounded-full mt-1.5 overflow-hidden">
                      <div
                        className="bg-cyan-400 h-full transition-all duration-75 ease-linear shadow-[0_0_8px_rgba(0,240,255,0.8)]"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* MAIN FROSTED BLUR ACTIVE SLIDE CONTAINER */}
          <div className="relative rounded-3xl backdrop-blur-2xl bg-[#040f21]/75 border border-cyan-500/30 p-4 sm:p-6 shadow-[0_15px_40px_rgba(0,0,0,0.8)] overflow-hidden">
            {/* Top Glassmorphism Ambient Glow */}
            <div
              className="absolute top-0 right-0 w-96 h-96 rounded-full pointer-events-none blur-3xl opacity-30 -z-10"
              style={{ background: currentSlide.accentGlow }}
            />

            {/* Slide Header & Controls */}
            <div className="flex items-center justify-between border-b border-cyan-500/15 pb-2.5 mb-3">
              <div className="flex items-center gap-2">
                <span
                  className={`text-[10px] sm:text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider border backdrop-blur-md ${currentSlide.badgeColor}`}
                >
                  {currentSlide.badge}
                </span>
                <span className="text-[11px] font-mono text-cyan-400/80 hidden sm:inline">
                  Slide {currentSlideIndex + 1} de {slides.length}
                </span>
              </div>

              {/* Player Navigation Buttons */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsAutoPlaying(!isAutoPlaying)}
                  className="p-1.5 rounded-lg bg-slate-900/90 border border-slate-700 text-slate-300 hover:text-white transition"
                  title={isAutoPlaying ? 'Pausar Rotação' : 'Iniciar Rotação'}
                >
                  {isAutoPlaying ? (
                    <Pause className="w-3.5 h-3.5 text-cyan-400" />
                  ) : (
                    <Play className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </button>
                <button
                  onClick={handlePrevSlide}
                  className="p-1.5 rounded-lg bg-slate-900/90 border border-cyan-500/30 text-cyan-300 hover:text-white hover:bg-cyan-950 transition"
                  title="Slide Anterior"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextSlide}
                  className="p-1.5 rounded-lg bg-slate-900/90 border border-cyan-500/30 text-cyan-300 hover:text-white hover:bg-cyan-950 transition"
                  title="Próximo Slide"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Slide Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-6 items-center">
              {/* Left Column: Descriptive text and key benefits */}
              <div className="lg:col-span-7 space-y-3 text-left">
                <div>
                  <h3 className="text-lg sm:text-2xl font-black text-white tracking-tight leading-snug">
                    {currentSlide.title}
                  </h3>
                  <div className="text-xs font-semibold text-cyan-300 font-mono mt-0.5">
                    {currentSlide.subtitle}
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-3 sm:line-clamp-none">
                  {currentSlide.description}
                </p>

                {/* Benefits Bullet Points */}
                <div className="space-y-1.5 pt-1">
                  {currentSlide.benefits.map((benefit, bIdx) => (
                    <div
                      key={bIdx}
                      className="flex items-start gap-2 text-xs sm:text-xs text-slate-200"
                    >
                      <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-2.5 h-2.5" />
                      </div>
                      <span>{benefit}</span>
                    </div>
                  ))}
                </div>

                {/* Direct Action Buttons */}
                <div className="flex flex-wrap items-center gap-2.5 pt-2">
                  <button
                    onClick={() => onOpenClientRegister('enterprise')}
                    className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-md shadow-cyan-500/25 flex items-center gap-1.5 transition"
                  >
                    <span>Contratar este Módulo</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => scrollToSection('funcionalidades')}
                    className="bg-slate-950/80 hover:bg-slate-900 text-cyan-300 text-xs font-semibold px-3.5 py-2 rounded-xl border border-slate-800 transition backdrop-blur-md"
                  >
                    Detalhes do Módulo
                  </button>
                </div>
              </div>

              {/* Right Column: High-Res Thematic Visual with Frosted Blur Badges */}
              <div className="lg:col-span-5 relative">
                <div className="relative rounded-2xl overflow-hidden border border-cyan-500/30 shadow-[0_0_25px_rgba(0,240,255,0.2)] group">
                  <img
                    src={currentSlide.imageUrl}
                    alt={currentSlide.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-44 sm:h-56 lg:h-64 object-cover object-center transform group-hover:scale-105 transition-transform duration-700"
                  />

                  {/* Dark Vignette Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent pointer-events-none" />

                  {/* Top Floating Frosted Tag */}
                  <div className="absolute top-2.5 right-2.5 bg-slate-950/80 border border-cyan-400/50 rounded-lg px-2.5 py-1 text-[10px] font-mono text-cyan-300 shadow-lg backdrop-blur-md">
                    {currentSlide.tag}
                  </div>

                  {/* Bottom Metric Frosted Bar */}
                  <div className="absolute bottom-2.5 left-2.5 right-2.5 bg-slate-950/85 border border-cyan-500/30 rounded-xl p-2.5 backdrop-blur-md shadow-lg flex items-center justify-between">
                    <div>
                      <div className="text-xl font-black text-white font-mono leading-tight">
                        {currentSlide.metric}
                      </div>
                      <div className="text-[10px] text-cyan-300">
                        {currentSlide.metricLabel}
                      </div>
                    </div>
                    <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center">
                      <Zap className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Seamless Navigation to Other Sections Below */}
        <div className="pt-2 pb-1 text-center">
          <button
            onClick={() => scrollToSection('planos')}
            className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 bg-slate-950/80 hover:bg-slate-900 border border-cyan-500/30 px-4 py-2 rounded-full backdrop-blur-md shadow-md transition animate-bounce"
          >
            <span>Ver Planos & Todas as Funcionalidades Abaixo</span>
            <ArrowDown className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SEÇÃO 2: PLANOS DE AQUISIÇÃO DO SISTEMA */}
      {/* ========================================================================= */}
      <section
        id="planos"
        className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-10 border-t border-cyan-500/20"
      >
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full">
            <Star className="w-3.5 h-3.5" />
            <span>Transparência & Escalabilidade</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white">
            Planos de Aquisição do PASQUARED Enterprise
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Escolha o nível de governança ideal para sua operação. Todos os planos incluem segurança avançada e isolamento criptográfico.
          </p>

          {/* Monthly / Annual Toggle */}
          <div className="flex items-center justify-center gap-3 pt-3">
            <span
              className={`text-xs font-semibold ${
                billingPeriod === 'monthly' ? 'text-white' : 'text-slate-400'
              }`}
            >
              Cobrança Mensal
            </span>
            <button
              onClick={() =>
                setBillingPeriod(billingPeriod === 'monthly' ? 'annual' : 'monthly')
              }
              className="w-14 h-7 bg-slate-900 border border-cyan-500/40 rounded-full p-1 flex items-center transition"
            >
              <div
                className={`w-5 h-5 bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-full shadow-md transform transition ${
                  billingPeriod === 'annual' ? 'translate-x-7' : 'translate-x-0'
                }`}
              />
            </button>
            <span
              className={`text-xs font-semibold flex items-center gap-1.5 ${
                billingPeriod === 'annual' ? 'text-cyan-300' : 'text-slate-400'
              }`}
            >
              <span>Cobrança Anual</span>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
                Economize 20%
              </span>
            </span>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {plans.map(plan => (
            <div
              key={plan.id}
              className={`rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 relative backdrop-blur-xl ${
                plan.highlight
                  ? 'glass-blur-active border-cyan-400/80 shadow-[0_0_40px_rgba(0,240,255,0.25)] scale-100 lg:-translate-y-2'
                  : 'glass-blur-panel hover:border-cyan-500/40'
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 text-[11px] font-black uppercase px-4 py-1 rounded-full shadow-lg font-mono">
                  ★ Mais Recomendado
                </div>
              )}

              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {/* Módulo de Acoplamento de Imagem (Plano) */}
                      <div className="relative w-8 h-8 rounded-lg flex items-center justify-center shrink-0 overflow-hidden border border-cyan-400/50 bg-[#020b18] shadow-[0_0_10px_rgba(0,240,255,0.25)]">
                        <PasquaredImage
                          alt="PASQUARED-OS Logotipo Plano"
                          className="w-full h-full object-contain p-1 relative z-10"
                        />
                      </div>
                      <h3 className="text-lg font-black text-white tracking-wide">
                        {plan.tier}
                      </h3>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/70 border border-cyan-500/30 px-2 py-0.5 rounded-md">
                      {plan.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed min-h-[36px]">
                    {plan.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl sm:text-4xl font-black text-white font-mono">
                      {billingPeriod === 'annual' ? plan.priceAnnual : plan.priceMonthly}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {plan.period}
                    </span>
                  </div>
                  {billingPeriod === 'annual' && (
                    <div className="text-[11px] text-emerald-400 font-mono mt-1">
                      Faturado anualmente com desconto garantido
                    </div>
                  )}
                </div>

                {/* Features Checklist */}
                <div className="space-y-2.5 pt-2">
                  <div className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                    Funcionalidades Inclusas:
                  </div>
                  {plan.features.map((feat, fIdx) => (
                    <div
                      key={fIdx}
                      className="flex items-start gap-2.5 text-xs text-slate-200"
                    >
                      <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-8">
                <button
                  onClick={() => onOpenClientRegister(plan.id)}
                  className={`w-full font-bold text-xs sm:text-sm py-3.5 rounded-xl transition flex items-center justify-center gap-2 ${plan.buttonClass}`}
                >
                  <span>{plan.buttonText}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SEÇÃO 3: MÓDULOS & FUNCIONALIDADES COMPLETAS DO SISTEMA */}
      {/* ========================================================================= */}
      <section
        id="funcionalidades"
        className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-10 border-t border-cyan-500/20"
      >
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest bg-cyan-500/10 border border-cyan-500/30 px-3 py-1 rounded-full">
            <Cpu className="w-3.5 h-3.5" />
            <span>Arquitetura Completa da Plataforma</span>
          </div>
          <h2 className="text-3xl font-black text-white">
            Tudo o que sua Organização Precisa em um Único Ecossistema
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Descubra como cada módulo do PASQUARED-OS trabalha de maneira orquestrada para garantir agilidade e conformidade.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="glass-blur-panel rounded-2xl p-6 space-y-3 hover:border-cyan-400/60 transition">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Kernel PASQUARED-OS & POKO</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Estrutura ontológica quântica (EKO, UCL e Raciocínio Baseado em Evidências) que transforma dados brutos em decisões confiáveis com controle milimétrico.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-6 space-y-3 hover:border-emerald-400/60 transition">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Governança & Políticas IGA</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Definição de regras de conformidade corporativa com aprovação humana obrigatória (Human-in-the-loop) para ações críticas de negócio.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-6 space-y-3 hover:border-indigo-400/60 transition">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Agentes Inteligentes Orquestrados</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Implante equipes de agentes com papéis bem definidos (Diagnóstico, Análise de Contratos, Detecção de Fraude) guiados pelo Kernel.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-6 space-y-3 hover:border-amber-400/60 transition">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
              <BarChart3 className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Matriz de Risco 5x5 Proativa</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Monitore ameaças de segurança, vazamento de dados e viés algorítmico com plano de mitigação instantâneo e pontuação em tempo real.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-6 space-y-3 hover:border-purple-400/60 transition">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center">
              <Terminal className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Console PQL de Consulta</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Linguagem de consulta direta PASQUARED Query Language para consultar ontologias, rastrear deliberações e auditar grafos de conhecimento.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-6 space-y-3 hover:border-rose-400/60 transition">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center">
              <FileCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Relatórios de Auditoria Forense</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Exporte relatórios oficiais com assinaturas criptográficas, hashes de validação e métricas de conformidade para conselhos e órgãos reguladores.
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SEÇÃO 4: CONECTORES TI & ALIMENTAÇÃO CORPORATIVA */}
      {/* ========================================================================= */}
      <section
        id="conectores"
        className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-10 border-t border-cyan-500/20"
      >
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full">
            <Database className="w-3.5 h-3.5" />
            <span>Alimentação em Tempo Real</span>
          </div>
          <h2 className="text-3xl font-black text-white">
            Conectores Universais Plug & Play
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Alimente o Kernel PASQUARED com as fontes de dados reais da sua organização através de conectores seguros e criptografados.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="glass-blur-panel rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                <Database className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full">
                Ativo
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">Bancos SQL / Postgres</h4>
            <p className="text-[11px] text-slate-300">
              Sincronização em tempo real de tabelas relacionais com filtragem de dados sensíveis.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <Server className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full">
                Nativo
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">ERP SAP & Oracle</h4>
            <p className="text-[11px] text-slate-300">
              Extração segura de dados contábeis, faturamento e logística para enriquecimento do Kernel.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Network className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full">
                REST / GraphQL
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">APIs & Webhooks</h4>
            <p className="text-[11px] text-slate-300">
              Endpoints customizados para acionamento de agentes e deliberação epistêmica por eventos.
            </p>
          </div>

          <div className="glass-blur-panel rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full">
                ETL Automático
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">Data Lakes & Arquivos</h4>
            <p className="text-[11px] text-slate-300">
              Ingestão de contratos PDF, relatórios CSV e planilhas com vetorização semântica imediata.
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SEÇÃO 5: SEGURANÇA, ISOLAMENTO & AUDITORIA */}
      {/* ========================================================================= */}
      <section
        id="seguranca"
        className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-10 border-t border-cyan-500/20"
      >
        <div className="glass-blur-active rounded-3xl p-8 sm:p-12 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-300 uppercase tracking-wider bg-cyan-500/20 border border-cyan-500/40 px-3 py-1 rounded-full">
                <Shield className="w-3.5 h-3.5" />
                <span>Blindagem Criptográfica</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                Isolamento Multi-Tenant com Chaves Criptográficas Exclusivas
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Cada empresa cadastrada possui um tenant logicamente e criptograficamente isolado. Seus dados nunca são compartilhados ou utilizados para treino de modelos externos.
              </p>
              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="flex items-center gap-2 text-xs text-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Criptografia AES-256 em Repouso</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>TLS 1.3 em Trânsito</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Assinatura Digital SHA-256</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Conformidade LGPD & GDPR</span>
                </div>
              </div>
            </div>

            <div className="space-y-4 text-center lg:text-right">
              <div className="p-6 rounded-2xl bg-slate-950/80 border border-cyan-500/30 text-left backdrop-blur-md">
                <div className="text-xs font-mono text-cyan-400 mb-1">Status de Criptografia do Kernel</div>
                <div className="text-lg font-bold text-white flex items-center justify-between">
                  <span>Enclave Pre-Ledger</span>
                  <span className="text-xs text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full font-mono">
                    100% OPERACIONAL
                  </span>
                </div>
                <div className="mt-3 text-xs text-slate-400 font-mono">
                  Hash Root: 0x9f83a...e4d1 (Merkle Block #1,498,202)
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center lg:justify-end gap-3 pt-2">
                <button
                  onClick={() => onOpenClientRegister('enterprise')}
                  className="bg-gradient-to-r from-cyan-600 to-emerald-600 hover:opacity-95 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-lg transition"
                >
                  Cadastrar Minha Empresa
                </button>
                <button
                  onClick={onOpenClientLogin}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm px-5 py-3 rounded-xl border border-slate-700 transition"
                >
                  Fazer Login
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* FOOTER NAVEGÁVEL COM ACESSO DIRETO */}
      {/* ========================================================================= */}
      <footer className="mt-auto border-t border-cyan-500/20 bg-[#020813] py-8 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <PasquaredLogo size="sm" />
            <div className="text-xs text-slate-400">
              © 2026 PASQUARED Enterprise AI Governance. Todos os direitos reservados.
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 font-mono">
            <button
              onClick={() => scrollToSection('apresentacao-blur')}
              className="hover:text-cyan-300 transition"
            >
              Apresentação
            </button>
            <span>•</span>
            <button
              onClick={() => scrollToSection('planos')}
              className="hover:text-cyan-300 transition"
            >
              Planos
            </button>
            <span>•</span>
            <button
              onClick={() => scrollToSection('funcionalidades')}
              className="hover:text-cyan-300 transition"
            >
              Funcionalidades
            </button>
            <span>•</span>
            <button
              onClick={() => scrollToSection('conectores')}
              className="hover:text-cyan-300 transition"
            >
              Conectores
            </button>
            <span>•</span>
            <button onClick={onOpenClientLogin} className="hover:text-cyan-300 transition">
              Entrar
            </button>
            <span>•</span>
            <button onClick={() => onOpenClientRegister()} className="hover:text-cyan-300 transition">
              Cadastrar
            </button>
            <span>•</span>
            <button
              onClick={onOpenSuperAdminLogin}
              className="hover:text-amber-400 transition flex items-center gap-1"
            >
              <Lock className="w-3 h-3 text-amber-400" />
              <span>Super Admin</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
