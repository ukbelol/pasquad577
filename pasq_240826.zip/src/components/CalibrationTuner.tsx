import React, { useState } from 'react';
import { X, Sliders, CheckCircle2, RefreshCw } from 'lucide-react';
import { CalibrationParams } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';

interface CalibrationTunerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CalibrationTuner: React.FC<CalibrationTunerProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [calibration, setCalibration] = useState<CalibrationParams>(globalPasquaredEngine.getCalibration());
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    globalPasquaredEngine.updateCalibration(calibration);
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 shadow-2xl space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Ajuste Rápido de Calibração</h3>
              <p className="text-xs text-slate-400">Pesos e limiares do algoritmo PASQUARED</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Peso Base α:</span>
              <span className="font-mono text-indigo-400">{(calibration.alpha * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.10"
              max="0.60"
              step="0.05"
              value={calibration.alpha}
              onChange={(e) => setCalibration({ ...calibration, alpha: parseFloat(e.target.value) })}
              className="w-full accent-indigo-500"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Intensidade Contextual β:</span>
              <span className="font-mono text-indigo-400">{(calibration.beta * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.10"
              max="0.50"
              step="0.05"
              value={calibration.beta}
              onChange={(e) => setCalibration({ ...calibration, beta: parseFloat(e.target.value) })}
              className="w-full accent-indigo-500"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Limiar de Convergência ε:</span>
              <span className="font-mono text-amber-400">{calibration.epsilon}</span>
            </div>
            <input
              type="range"
              min="0.005"
              max="0.05"
              step="0.005"
              value={calibration.epsilon}
              onChange={(e) => setCalibration({ ...calibration, epsilon: parseFloat(e.target.value) })}
              className="w-full accent-amber-500"
            />
          </div>
        </div>

        <button
          onClick={handleSave}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition"
        >
          {saved ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Sliders className="w-4 h-4" />}
          <span>{saved ? 'Calibração Aplicada!' : 'Salvar Calibração'}</span>
        </button>
      </div>
    </div>
  );
};
