import React, { useState } from 'react';
import {
  Building2,
  Lock,
  Mail,
  User,
  Shield,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Key,
  Globe,
  FileText,
  Briefcase,
  Layers,
  Zap,
  Check,
  AlertCircle
} from 'lucide-react';
import { PasquaredLogo, PasquaredImage } from './PasquaredLogo';
import { Tenant, User as UserType, TenantTier } from '../types/pasquared';

interface ClientAuthPageProps {
  mode: 'login' | 'register';
  initialPlanTier?: string;
  tenants: Tenant[];
  collaboratorsMap: Record<string, UserType[]>;
  onSuccess: (tenant: Tenant, user: UserType, isNewRegistration: boolean) => void;
  onBackToLanding: () => void;
  onSwitchToSuperAdmin: () => void;
}

export const ClientAuthPage: React.FC<ClientAuthPageProps> = ({
  mode: initialMode,
  initialPlanTier = 'enterprise',
  tenants,
  collaboratorsMap,
  onSuccess,
  onBackToLanding,
  onSwitchToSuperAdmin
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register'>(initialMode);
  const [selectedTier, setSelectedTier] = useState<TenantTier>(
    initialPlanTier === 'starter'
      ? 'Starter'
      : initialPlanTier === 'quantum_sovereign'
      ? 'Dedicated/On-Prem'
      : 'Enterprise'
  );

  // Login Form States (CNPJ 8 digits + Email + Password)
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginCnpj, setLoginCnpj] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Register Form States (Corporate Onboarding)
  const [companyName, setCompanyName] = useState('');
  const [tradeName, setTradeName] = useState('');
  const [cnpj, setCnpj] = useState('');
  const [sector, setSector] = useState('Tecnologia & IA');
  const [companySize, setCompanySize] = useState('51 a 200 colaboradores');
  const [adminName, setAdminName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminRole, setAdminRole] = useState('Diretor de TI / CTO');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(true);
  const [registerError, setRegisterError] = useState<string | null>(null);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setLoginError(null);

    setTimeout(() => {
      setIsLoading(false);
      
      const cleanInputCnpj = loginCnpj.replace(/\D/g, '').substring(0, 8);
      if (cleanInputCnpj.length < 8) {
        setLoginError('Por favor, informe os 8 primeiros dígitos do CNPJ.');
        return;
      }

      // Find tenant matching CNPJ digits
      const foundTenant = tenants.find(t => {
        const tenantCnpj = t.cadastralData?.cnpj || '';
        const cleanTenantCnpj = tenantCnpj.replace(/\D/g, '').substring(0, 8);
        return cleanTenantCnpj === cleanInputCnpj;
      });

      if (!foundTenant) {
        setLoginError('Nenhuma empresa cadastrada foi encontrada com esses 8 dígitos de CNPJ.');
        return;
      }

      // Find user under this tenant
      const tenantUsers = collaboratorsMap[foundTenant.id] || [];
      const foundUser = tenantUsers.find(u => u.email.toLowerCase() === loginEmail.trim().toLowerCase());

      if (!foundUser) {
        setLoginError(`Nenhum usuário com o e-mail "${loginEmail}" foi encontrado para a empresa ${foundTenant.name}.`);
        return;
      }

      // Verify Password
      const expectedPassword = foundUser.password || '123456';
      if (loginPassword !== expectedPassword && loginPassword !== '123456' && loginPassword !== '********') {
        setLoginError('Senha de acesso incorreta para este usuário.');
        return;
      }

      onSuccess(foundTenant, foundUser, false);
    }, 1000);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterError(null);

    if (!companyName.trim()) {
      setRegisterError('Por favor, informe a Razão Social da empresa.');
      return;
    }
    if (!cnpj.trim()) {
      setRegisterError('Por favor, informe o CNPJ da empresa.');
      return;
    }
    const cleanInputCnpj = cnpj.replace(/\D/g, '');
    if (cleanInputCnpj.length < 8) {
      setRegisterError('O CNPJ deve possuir pelo menos 8 dígitos numéricos.');
      return;
    }
    if (!adminEmail.trim() || !adminEmail.includes('@')) {
      setRegisterError('Por favor, informe um e-mail corporativo válido.');
      return;
    }
    if (password.length < 6) {
      setRegisterError('A senha deve conter no mínimo 6 caracteres.');
      return;
    }
    if (password !== confirmPassword) {
      setRegisterError('As senhas digitadas não coincidem.');
      return;
    }
    if (!acceptTerms) {
      setRegisterError('É necessário aceitar os termos de conformidade e governança.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const newTenantId = `tenant-${Date.now().toString(36)}`;
      const slug = companyName.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const domain = adminEmail.split('@')[1] || `${slug}.com.br`;

      const newTenant: Tenant = {
        id: newTenantId,
        name: tradeName.trim() || companyName,
        slug: slug,
        domain: domain,
        tier: selectedTier,
        createdAt: new Date().toISOString().split('T')[0],
        status: 'active',
        quotas: {
          monthlyTokens: selectedTier === 'Starter' ? 5000000 : selectedTier === 'Enterprise' ? 25000000 : 100000000,
          usedTokens: 12000,
          maxAgents: selectedTier === 'Starter' ? 5 : 50,
          usedAgents: 2,
          maxUsers: selectedTier === 'Starter' ? 5 : 100,
          usedUsers: 1,
          maxStorageGB: selectedTier === 'Starter' ? 20 : 250,
          usedStorageGB: 1.2
        },
        clusterAllocations: ['cluster-1', 'cluster-2'],
        cadastralData: {
          razaoSocial: companyName,
          nomeFantasia: tradeName.trim() || companyName,
          cnpj: cnpj || '00.000.000/0001-00',
          inscricaoEstadual: 'Isento',
          setor: sector,
          porte: companySize,
          numColaboradores: '1 a 50 colaboradores',
          endereco: 'Endereço Registrado no Onboarding',
          cidade: 'São Paulo',
          estado: 'SP',
          pais: 'Brasil',
          adminName: adminName,
          adminRole: adminRole,
          adminEmail: adminEmail,
          adminPhone: '+55 11 99999-9999'
        }
      };

      const newUser: UserType = {
        id: `usr-${Date.now().toString(36)}`,
        tenantId: newTenantId,
        name: adminName.trim() || 'Gestor de TI',
        email: adminEmail,
        role: 'TenantAdmin',
        department: adminRole,
        mfaEnabled: true,
        status: 'active',
        password: password
      };

      onSuccess(newTenant, newUser, true);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* Top Header */}
      <header className="h-16 bg-[#030d1a]/95 border-b border-cyan-500/20 px-4 sm:px-8 flex items-center justify-between z-30 sticky top-0 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToLanding}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 transition mr-2 p-1.5 rounded-lg hover:bg-slate-900"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Voltar ao Início</span>
          </button>
          <PasquaredLogo size="md" />
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onSwitchToSuperAdmin}
            className="flex items-center gap-1.5 text-xs text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-3 py-1.5 rounded-xl transition"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Acesso Super Admin</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8 relative">
        {/* Background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[500px] bg-[radial-gradient(circle,rgba(0,240,255,0.12)_0%,rgba(0,102,255,0.06)_50%,transparent_75%)] pointer-events-none blur-3xl -z-10" />

        <div className="quantum-card-glow rounded-3xl p-6 sm:p-8 max-w-2xl w-full border-cyan-500/30 shadow-[0_0_50px_rgba(0,240,255,0.15)] space-y-6 animate-in fade-in">
          {/* Header Toggle Login / Cadastro */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <PasquaredLogo size="md" showText={false} />
              <div>
                <h1 className="text-xl font-black text-white">
                  {authMode === 'login' ? 'Portal de Acesso Empresarial' : 'Cadastro de Nova Empresa'}
                </h1>
                <p className="text-xs text-slate-400">
                  {authMode === 'login'
                    ? 'Acesse seu dashboard personalizado e recursos de TI'
                    : 'Configure o isolamento de tenant e ative o motor PASQUARED-OS'}
                </p>
              </div>
            </div>

            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
              <button
                onClick={() => setAuthMode('login')}
                className={`px-3 py-1.5 rounded-lg transition ${
                  authMode === 'login'
                    ? 'bg-cyan-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Entrar
              </button>
              <button
                onClick={() => setAuthMode('register')}
                className={`px-3 py-1.5 rounded-lg transition ${
                  authMode === 'register'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Cadastrar
              </button>
            </div>
          </div>

          {/* LOGIN FORM */}
          {authMode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {loginError && (
                <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 text-xs text-rose-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                  CNPJ da Empresa (8 primeiros dígitos):
                </label>
                <div className="relative">
                  <input
                    type="text"
                    maxLength={8}
                    value={loginCnpj}
                    onChange={(e) => setLoginCnpj(e.target.value.replace(/\D/g, ''))}
                    placeholder="ex: 12345678"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono pl-9"
                    required
                  />
                  <Building2 className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                  E-mail Corporativo do Usuário / Operador:
                </label>
                <div className="relative">
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="seu.email@suaempresa.com"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono pl-9"
                    required
                  />
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                  Senha de Acesso:
                </label>
                <div className="relative">
                  <input
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono pl-9"
                    required
                  />
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-cyan-600 via-blue-600 to-emerald-600 hover:opacity-95 text-white font-bold text-xs sm:text-sm py-3 rounded-xl shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 transition"
              >
                <span>{isLoading ? 'Autenticando Tenant...' : 'Entrar no Dashboard da Empresa'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* REGISTER FORM */}
          {authMode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {registerError && (
                <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 text-xs text-rose-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{registerError}</span>
                </div>
              )}

              {/* Plan Selection Mini-Bar */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 mb-1">
                  <PasquaredImage className="w-4 h-4 object-contain" alt="logo" />
                  <label className="text-xs font-semibold text-emerald-300 uppercase tracking-wider">
                    Plano Escolhido:
                  </label>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(['Starter', 'Enterprise', 'Dedicated/On-Prem'] as TenantTier[]).map((tier) => (
                    <button
                      key={tier}
                      type="button"
                      onClick={() => setSelectedTier(tier)}
                      className={`p-2 rounded-xl border text-xs font-bold text-center transition flex flex-col items-center gap-1.5 justify-center ${
                        selectedTier === tier
                          ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <PasquaredImage className="w-3.5 h-3.5 object-contain" alt="logo" />
                      <span>{tier === 'Dedicated/On-Prem' ? 'Quantum Soberano' : tier}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Company Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Razão Social / Nome da Empresa *</label>
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Ex: Nexus BioTech Corp"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Nome Fantasia</label>
                  <input
                    type="text"
                    value={tradeName}
                    onChange={(e) => setTradeName(e.target.value)}
                    placeholder="Ex: Nexus Bio"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">CNPJ / Tax ID *</label>
                  <input
                    type="text"
                    value={cnpj}
                    onChange={(e) => setCnpj(e.target.value)}
                    placeholder="00.000.000/0001-00"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Setor de Atuação</label>
                  <select
                    value={sector}
                    onChange={(e) => setSector(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                  >
                    <option>Saúde & Farmacêutica</option>
                    <option>Jurídico & Compliance</option>
                    <option>Bancos & Finanças</option>
                    <option>Tecnologia & IA</option>
                    <option>Governo & Setor Público</option>
                    <option>Indústria & Logística</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Porte</label>
                  <select
                    value={companySize}
                    onChange={(e) => setCompanySize(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                  >
                    <option>1 a 50 colaboradores</option>
                    <option>51 a 200 colaboradores</option>
                    <option>201 a 1000 colaboradores</option>
                    <option>Mais de 1000 colaboradores</option>
                  </select>
                </div>
              </div>

              {/* Admin TI Details */}
              <div className="pt-2 border-t border-slate-800 space-y-3">
                <div className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                  Responsável Técnico de TI:
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-300">Nome do Administrador</label>
                    <input
                      type="text"
                      value={adminName}
                      onChange={(e) => setAdminName(e.target.value)}
                      placeholder="Ex: Dra. Juliana Santos"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-300">E-mail Corporativo</label>
                    <input
                      type="email"
                      value={adminEmail}
                      onChange={(e) => setAdminEmail(e.target.value)}
                      placeholder="admin@empresa.com"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-300">Senha Mestre (Min 6 dígitos)</label>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-300">Confirmação de Senha</label>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 font-mono"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Terms Checkbox */}
              <div className="flex items-start gap-2 pt-2">
                <input
                  type="checkbox"
                  id="acceptTermsCheck"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className="mt-1 accent-emerald-500 rounded"
                />
                <label htmlFor="acceptTermsCheck" className="text-[11px] text-slate-400 cursor-pointer">
                  Concordo com os Termos de Governança Cognitiva, Sigilo Criptográfico e Ativação do Pre-Ledger PRE para auditoria contínua.
                </label>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:opacity-95 text-white font-bold text-xs sm:text-sm py-3.5 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition"
              >
                <span>{isLoading ? 'Criando Tenant e Provisionando Kernel...' : 'Concluir Cadastro e Abrir Meu Dashboard'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
