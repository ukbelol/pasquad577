import React, { useState } from 'react';
import {
  Building2,
  Database,
  Sliders,
  Play,
  Zap,
  CheckCircle2,
  AlertCircle,
  Plus,
  RefreshCw,
  Server,
  ArrowRight,
  Shield,
  Activity,
  Layers,
  Key,
  Globe,
  Radio,
  Cpu,
  Download,
  Share2,
  Terminal,
  FileCode,
  SlidersHorizontal,
  Check
} from 'lucide-react';
import {
  Tenant,
  User,
  EnterpriseDataConnector,
  DecisionParameterizationConfig,
  DecisionRecord,
  ObserverProfile
} from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';
import { PasquaredLogo } from './PasquaredLogo';

interface EnterpriseResourceManagementViewProps {
  tenant: Tenant;
  currentUser: User | null;
  observer: ObserverProfile;
  onNavigateToKernel?: () => void;
  onNavigateToAudit?: () => void;
}

export const EnterpriseResourceManagementView: React.FC<EnterpriseResourceManagementViewProps> = ({
  tenant,
  currentUser,
  observer,
  onNavigateToKernel,
  onNavigateToAudit
}) => {
  const [activeTab, setActiveTab] = useState<'connectors' | 'parameters' | 'simulator' | 'api_keys'>('connectors');

  // Initial Enterprise Connectors State
  const [connectors, setConnectors] = useState<EnterpriseDataConnector[]>([
    {
      id: 'conn-hubspot-crm',
      tenantId: tenant.id,
      name: 'HubSpot CRM Database - Leads & Contatos',
      sourceType: 'hubspot_crm',
      endpointUrlOrHost: 'https://api.hubapi.com/crm/v3/objects/contacts',
      authMethod: 'oauth2',
      frequency: 'every_5_min',
      status: 'active',
      recordsIngested: 219500,
      lastSyncAt: new Date().toISOString(),
      mappedCognitiveDimension: 'Contexto Local (β)',
      targetClusterDomain: 'Marketing, Clientes & Vendas',
      samplePayloadFormat: '{\n  "id": "hub-cont-3312",\n  "properties": {\n    "firstname": "Felipe",\n    "lastname": "Andrade",\n    "email": "felipe@hubspot-leads.com",\n    "hs_lead_status": "IN_PROGRESS",\n    "lifecyclestage": "lead",\n    "associated_deal_value": 75000\n  }\n}',
      confidenceWeight: 0.94
    },
    {
      id: 'conn-rest-core-banking',
      tenantId: tenant.id,
      name: 'API Core Bancário & Transações PIX (REST)',
      sourceType: 'rest_api',
      endpointUrlOrHost: 'https://api.novacorp.internal/v2/transactions/stream',
      authMethod: 'bearer_token',
      frequency: 'real_time_stream',
      status: 'active',
      recordsIngested: 842910,
      lastSyncAt: new Date().toISOString(),
      mappedCognitiveDimension: 'Evidência (α)',
      targetClusterDomain: 'Financeiro & Risco de Crédito',
      samplePayloadFormat: '{"tx_id": "9921", "amount": 45000, "score_serasa": 780, "kyc_status": "APPROVED"}',
      confidenceWeight: 0.95
    },
    {
      id: 'conn-sql-datalake',
      tenantId: tenant.id,
      name: 'Data Lake Corporativo (Snowflake / PostgreSQL)',
      sourceType: 'database_sql',
      endpointUrlOrHost: 'postgresql://db-lake.novacorp.internal:5432/epistemic_lake',
      authMethod: 'mtls',
      frequency: 'every_1_min',
      status: 'active',
      recordsIngested: 3120400,
      lastSyncAt: new Date().toISOString(),
      mappedCognitiveDimension: 'Memória Histórica (γ)',
      targetClusterDomain: 'Governança & Risco Corporativo',
      samplePayloadFormat: '{"client_id": "C-1092", "historical_default_rate": 0.012, "contracts_active": 4}',
      confidenceWeight: 0.90
    },
    {
      id: 'conn-erp-sap',
      tenantId: tenant.id,
      name: 'ERP SAP S/4HANA (Faturamento & Compliance)',
      sourceType: 'erp_crm',
      endpointUrlOrHost: 'https://sap-gateway.novacorp.internal/odata/v4/GovernanceService',
      authMethod: 'oauth2',
      frequency: 'every_5_min',
      status: 'active',
      recordsIngested: 145000,
      lastSyncAt: new Date().toISOString(),
      mappedCognitiveDimension: 'Contexto Local (β)',
      targetClusterDomain: 'Jurídico & Auditoria',
      samplePayloadFormat: '{"invoice_id": "INV-8891", "approver": "Finance_Director", "risk_level": "LOW"}',
      confidenceWeight: 0.88
    },
    {
      id: 'conn-webhook-crm',
      tenantId: tenant.id,
      name: 'Webhook de Atendimento & Ouvidoria (Salesforce)',
      sourceType: 'webhook',
      endpointUrlOrHost: 'https://app.pasquared.space/api/v1/feed/webhook/crm-8819',
      authMethod: 'api_key',
      frequency: 'real_time_stream',
      status: 'active',
      recordsIngested: 62400,
      lastSyncAt: new Date().toISOString(),
      mappedCognitiveDimension: 'Salvaguarda & Risco (δ)',
      targetClusterDomain: 'Ética & Segurança de IA',
      samplePayloadFormat: '{"ticket_id": "T-404", "sentiment": "CRITICAL", "pii_detected": false}',
      confidenceWeight: 0.92
    }
  ]);

  // HubSpot Integration States
  const [hubspotIntegrationMethod, setHubspotIntegrationMethod] = useState<'private_app' | 'oauth2' | 'webhook'>('private_app');
  const [hubspotPrivateToken, setHubspotPrivateToken] = useState('');
  const [hubspotClientId, setHubspotClientId] = useState('');
  const [hubspotClientSecret, setHubspotClientSecret] = useState('');
  const [hubspotEntity, setHubspotEntity] = useState<'contacts' | 'companies' | 'deals' | 'tickets'>('contacts');
  const [hubspotWebhookTrigger, setHubspotWebhookTrigger] = useState('contact.creation');
  const [oauthStatus, setOauthStatus] = useState<'idle' | 'authorizing' | 'authorized'>('idle');

  // Decision Parameterization Config
  const [paramsConfig, setParamsConfig] = useState<DecisionParameterizationConfig>({
    tenantId: tenant.id,
    decisionDomain: 'Decisão Epistêmica de Crédito & Compliance em Tempo Real',
    alphaEvidenceWeight: 0.40,
    betaContextWeight: 0.25,
    gammaMemoryWeight: 0.20,
    deltaSafeguardWeight: 0.15,
    mvedThreshold: 0.65,
    igaMinimumForAutoApproval: 0.80,
    humanInTheLoopThreshold: 0.60,
    observationTimeWindowMinutes: 30,
    autoPruneInvalidHypotheses: true,
    quarantineHighRiskOutputs: true,
    activeDataFeedIds: connectors.map(c => c.id)
  });

  const [isSavedParams, setIsSavedParams] = useState(false);

  // Live Feeder Simulator State
  const [simInput, setSimInput] = useState(`{
  "transacao_id": "TX-PASQ-882190",
  "valor_solicitado": 350000.00,
  "score_credito": 820,
  "faturamento_mensal": 1200000.00,
  "tempo_relacionamento_meses": 48,
  "indice_inadimplencia_setorial": 0.024,
  "politica_esg_aderente": true,
  "alerta_lavagem_dinheiro_coaf": false
}`);
  const [isProcessingSim, setIsProcessingSim] = useState(false);
  const [simDecisionRecord, setSimDecisionRecord] = useState<DecisionRecord | null>(null);

  // New Connector Modal state
  const [isAddingConnector, setIsAddingConnector] = useState(false);
  const [newConnName, setNewConnName] = useState('');
  const [newConnType, setNewConnType] = useState<any>('rest_api');
  const [newConnEndpoint, setNewConnEndpoint] = useState('');
  const [newConnDimension, setNewConnDimension] = useState<any>('Evidência (α)');

  const handleSaveParameters = () => {
    setIsSavedParams(true);
    setTimeout(() => setIsSavedParams(false), 3000);
  };

  const handleAddConnector = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newConnName || !newConnEndpoint) return;

    let authMethod: any = 'bearer_token';
    let samplePayload = '{"status": "NEW_DATA_FEED"}';
    let targetDomain = 'Operações Corporativas';

    if (newConnType === 'hubspot_crm') {
      targetDomain = 'Marketing, Clientes & Vendas';
      if (hubspotIntegrationMethod === 'oauth2') {
        authMethod = 'oauth2';
      } else if (hubspotIntegrationMethod === 'private_app') {
        authMethod = 'bearer_token';
      } else {
        authMethod = 'api_key';
      }

      // Custom payload format depending on entity type
      if (hubspotEntity === 'contacts') {
        samplePayload = '{\n  "id": "hub-cont-new",\n  "properties": {\n    "firstname": "Felipe",\n    "lastname": "Andrade",\n    "email": "felipe@hubspot-leads.com",\n    "hs_lead_status": "IN_PROGRESS",\n    "lifecyclestage": "lead"\n  }\n}';
      } else if (hubspotEntity === 'companies') {
        samplePayload = '{\n  "id": "hub-comp-new",\n  "properties": {\n    "name": "Nova Tech Solutions",\n    "domain": "novatech.com",\n    "industry": "Software & Serviços",\n    "annualrevenue": "15000000.00"\n  }\n}';
      } else if (hubspotEntity === 'deals') {
        samplePayload = '{\n  "id": "hub-deal-new",\n  "properties": {\n    "dealname": "Aquisição PASQ-OS Enterprise",\n    "amount": "250000.00",\n    "dealstage": "contractsent",\n    "pipeline": "default"\n  }\n}';
      } else {
        samplePayload = '{\n  "id": "hub-tick-new",\n  "properties": {\n    "subject": "Inconsistência de Sincronização ERP SAP",\n    "content": "Fluxo de faturamento apresentou latência de 2min no Ledger",\n    "hs_ticket_priority": "HIGH",\n    "hs_pipeline_stage": "1"\n  }\n}';
      }
    }

    const created: EnterpriseDataConnector = {
      id: `conn-${Date.now().toString(36)}`,
      tenantId: tenant.id,
      name: newConnName,
      sourceType: newConnType,
      endpointUrlOrHost: newConnEndpoint,
      authMethod: authMethod,
      frequency: hubspotIntegrationMethod === 'webhook' ? 'real_time_stream' : 'every_5_min',
      status: 'active',
      recordsIngested: 0,
      lastSyncAt: new Date().toISOString(),
      mappedCognitiveDimension: newConnDimension,
      targetClusterDomain: targetDomain,
      samplePayloadFormat: samplePayload,
      confidenceWeight: 0.92
    };

    setConnectors(prev => [created, ...prev]);
    setIsAddingConnector(false);
    setNewConnName('');
    setNewConnEndpoint('');
    // Reset temporary HubSpot states
    setHubspotPrivateToken('');
    setHubspotClientId('');
    setHubspotClientSecret('');
    setOauthStatus('idle');
  };

  const handleExecuteSim = async () => {
    setIsProcessingSim(true);
    try {
      // Execute PASQUARED engine logic with tenant weights
      const result = await globalPasquaredEngine.executeSAC(simInput, observer);
      setSimDecisionRecord(result.decision);
    } catch (err) {
      console.error('Error simulating decision in PASQUARED kernel:', err);
    } finally {
      setIsProcessingSim(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-8 space-y-6 max-w-7xl mx-auto animate-in fade-in text-slate-100">
      {/* Enterprise Top Banner */}
      <div className="quantum-card-glow rounded-3xl p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[radial-gradient(circle_at_100%_0%,rgba(0,240,255,0.15),transparent_70%)] pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start gap-4">
            <PasquaredLogo size="lg" showText={false} />
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  {tenant.name}
                </h1>
                <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full shadow-[0_0_12px_rgba(0,240,255,0.3)]">
                  {tenant.tier} Enterprise
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  Conexão PASQUARED Online
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
                Hub do Administrador de TI: configure os conectores de dados, estabeleça as matrizes de ponderação cognitiva e alimente o sistema PASQUARED para deliberações de decisão automatizadas.
              </p>
              <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-slate-400 font-mono">
                <span>Admin TI: <strong className="text-cyan-300">{currentUser?.name || 'Administrador TI'}</strong></span>
                <span>•</span>
                <span>Tokens Alocados: <strong className="text-emerald-300">{tenant.quotas.monthlyTokens.toLocaleString()} / mês</strong></span>
                <span>•</span>
                <span>Dominio FQDN: <strong className="text-indigo-300">app.pasquared.space</strong></span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => setActiveTab('simulator')}
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-cyan-600/30 flex items-center gap-2 transition"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Simular Ingestão & Decisão</span>
            </button>
            {onNavigateToKernel && (
              <button
                onClick={onNavigateToKernel}
                className="bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 font-semibold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transition"
              >
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>Inspecionar Kernel</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('connectors')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'connectors'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Database className="w-4 h-4 text-cyan-400" />
          <span>1. Conectores & Fontes de Dados ({connectors.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('parameters')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'parameters'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Sliders className="w-4 h-4 text-emerald-400" />
          <span>2. Parametrização Decisória PASQUARED</span>
        </button>

        <button
          onClick={() => setActiveTab('simulator')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'simulator'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Zap className="w-4 h-4 text-amber-400" />
          <span>3. Simulador de Ingestão & Decisão Ao Vivo</span>
        </button>

        <button
          onClick={() => setActiveTab('api_keys')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'api_keys'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Key className="w-4 h-4 text-indigo-400" />
          <span>4. Chaves de API & Webhooks de Alimentação</span>
        </button>
      </div>

      {/* TAB 1: Conectores & Fontes de Dados */}
      {activeTab === 'connectors' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white">Fontes de Alimentação de Dados da Empresa</h3>
              <p className="text-xs text-slate-400">
                Conecte suas APIs, bancos de dados, ERPs e sensores IoT para converter dados brutos em UCL (Universal Cognitive Language).
              </p>
            </div>
            <button
              onClick={() => setIsAddingConnector(true)}
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-cyan-600/30 transition self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Conector de Dados</span>
            </button>
          </div>

          {/* Add Connector Modal / Drawer */}
          {isAddingConnector && (
            <div className="bg-slate-900 border border-cyan-500/40 rounded-2xl p-5 space-y-4 shadow-xl animate-in fade-in">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-cyan-400" />
                  <span>Cadastrar Nova Fonte de Dados para o PASQUARED</span>
                </h4>
                <button
                  onClick={() => setIsAddingConnector(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <AlertCircle className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleAddConnector} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Nome do Conector:</label>
                  <input
                    type="text"
                    value={newConnName}
                    onChange={(e) => setNewConnName(e.target.value)}
                    placeholder="Ex: API Transações Financeiras"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Tipo de Conector:</label>
                  <select
                    value={newConnType}
                    onChange={(e) => {
                      const val = e.target.value;
                      setNewConnType(val);
                      if (val === 'hubspot_crm') {
                        setNewConnName('HubSpot CRM - Leads & Clientes');
                        setNewConnEndpoint('https://api.hubapi.com/crm/v3/objects/contacts');
                        setNewConnDimension('Contexto Local (β)');
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="rest_api">REST API (JSON/HTTP)</option>
                    <option value="webhook">Webhook Receptor</option>
                    <option value="database_sql">Banco SQL / PostgreSQL / Oracle</option>
                    <option value="data_lake">Data Lake (Snowflake / BigQuery)</option>
                    <option value="erp_crm">ERP SAP / Salesforce CRM</option>
                    <option value="hubspot_crm">HubSpot CRM Database & Webhooks</option>
                    <option value="iot_telemetry">Sensores IoT / MQTT Telemetry</option>
                    <option value="document_ucl">Documentos & Normas (PDF/UCL)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Dimensão Cognitiva Alimentada:</label>
                  <select
                    value={newConnDimension}
                    onChange={(e) => setNewConnDimension(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Evidência (α)">Evidência Direta (α - Peso de Fato)</option>
                    <option value="Contexto Local (β)">Contexto Local (β - Circunstância)</option>
                    <option value="Memória Histórica (γ)">Memória Histórica (γ - Série Temporal)</option>
                    <option value="Salvaguarda & Risco (δ)">Salvaguarda & Risco (δ - Compliance)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Endpoint / URI de Conexão:</label>
                  <input
                    type="text"
                    value={newConnEndpoint}
                    onChange={(e) => setNewConnEndpoint(e.target.value)}
                    placeholder="https://api.empresa.com/v1/feed"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>

                {newConnType === 'hubspot_crm' && (
                  <div className="sm:col-span-2 lg:col-span-4 bg-slate-950/80 border border-amber-500/30 rounded-2xl p-4 mt-2 space-y-4 animate-in slide-in-from-top duration-300">
                    <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-[#ff7a59] animate-pulse" />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">Parâmetros de Integração de API HubSpot</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {/* 1. Entity type selection */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-slate-300">Entidade Alvo (Database Object):</label>
                        <select
                          value={hubspotEntity}
                          onChange={(e) => {
                            const ent = e.target.value as any;
                            setHubspotEntity(ent);
                            // Dynamic endpoint adjustment based on entity
                            let endpoint = 'https://api.hubapi.com/crm/v3/objects/contacts';
                            if (ent === 'companies') endpoint = 'https://api.hubapi.com/crm/v3/objects/companies';
                            if (ent === 'deals') endpoint = 'https://api.hubapi.com/crm/v3/objects/deals';
                            if (ent === 'tickets') endpoint = 'https://api.hubapi.com/crm/v3/objects/tickets';
                            setNewConnEndpoint(endpoint);
                          }}
                          className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                        >
                          <option value="contacts">Contacts (Contatos & Leads)</option>
                          <option value="companies">Companies (Empresas Corporativas)</option>
                          <option value="deals">Deals (Oportunidades Comerciais)</option>
                          <option value="tickets">Tickets (Suporte & Atendimento)</option>
                        </select>
                      </div>

                      {/* 2. Integration Method selection */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-slate-300">Método de Integração HubSpot:</label>
                        <select
                          value={hubspotIntegrationMethod}
                          onChange={(e) => setHubspotIntegrationMethod(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                        >
                          <option value="private_app">Token de App Privado (Recomendado)</option>
                          <option value="oauth2">OAuth 2.0 Auth Flow (Segurança Delegada)</option>
                          <option value="webhook">Subscrição em Webhooks (Tempo Real)</option>
                        </select>
                      </div>

                      {/* 3. Helper status / triggers */}
                      <div className="space-y-1">
                        {hubspotIntegrationMethod === 'webhook' ? (
                          <>
                            <label className="text-[11px] font-semibold text-slate-300">Gatilho do Webhook (HubSpot Developer Portal):</label>
                            <select
                              value={hubspotWebhookTrigger}
                              onChange={(e) => setHubspotWebhookTrigger(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                            >
                              <option value="contact.creation">Ao criar Contato (contact.creation)</option>
                              <option value="contact.deletion">Ao deletar Contato (contact.deletion)</option>
                              <option value="deal.creation">Ao criar Oportunidade (deal.creation)</option>
                              <option value="company.creation">Ao criar Empresa (company.creation)</option>
                            </select>
                          </>
                        ) : (
                          <>
                            <label className="text-[11px] font-semibold text-slate-300">Frequência de Ingestão (Polling):</label>
                            <div className="text-xs text-cyan-300 bg-cyan-950/20 border border-cyan-800/40 rounded-xl px-3 py-2 font-mono">
                              Sincronização a cada 5 min
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Conditionally render credentials inputs based on the selected method */}
                    {hubspotIntegrationMethod === 'private_app' && (
                      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl space-y-2 animate-in fade-in duration-200">
                        <div className="flex items-center justify-between">
                          <label className="text-[11px] font-bold text-slate-300">Token de Acesso do App Privado (Private App Access Token):</label>
                          <span className="text-[10px] text-[#ff7a59] font-mono">Começa com pat-na1-... ou pat-eu1-...</span>
                        </div>
                        <input
                          type="password"
                          value={hubspotPrivateToken}
                          onChange={(e) => setHubspotPrivateToken(e.target.value)}
                          placeholder="pat-na1-xxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff7a59]"
                        />
                        <p className="text-[10px] text-slate-400 font-sans">
                          Como obter: No seu portal HubSpot, vá em <strong>Configurações &gt; Integrações &gt; Apps Privados &gt; Criar app privado</strong>. Conceda escopos de leitura para a entidade selecionada (ex: <code>crm.objects.contacts.read</code>) e cole o token acima.
                        </p>
                      </div>
                    )}

                    {hubspotIntegrationMethod === 'oauth2' && (
                      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl space-y-3 animate-in fade-in duration-200">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-slate-300">Client ID do App Developer:</label>
                            <input
                              type="text"
                              value={hubspotClientId}
                              onChange={(e) => setHubspotClientId(e.target.value)}
                              placeholder="Ex: d189c4a2-xxxx-xxxx"
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff7a59]"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-slate-300">Client Secret do App Developer:</label>
                            <input
                              type="password"
                              value={hubspotClientSecret}
                              onChange={(e) => setHubspotClientSecret(e.target.value)}
                              placeholder="••••••••••••••••••••"
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff7a59]"
                            />
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-800">
                          <div className="text-[10px] text-slate-400">
                            Redirect URI configurada no HubSpot Portal: <code className="text-cyan-300 bg-slate-950 px-1.5 py-0.5 rounded">https://app.pasquared.space/api/v1/hubspot/oauth/callback</code>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              if (!hubspotClientId || !hubspotClientSecret) {
                                alert('Por favor, digite o Client ID e Client Secret antes de autenticar.');
                                return;
                              }
                              setOauthStatus('authorizing');
                              setTimeout(() => {
                                setOauthStatus('authorized');
                              }, 1800);
                            }}
                            className={`px-4 py-2 font-bold text-xs rounded-xl flex items-center gap-2 transition shrink-0 ${
                              oauthStatus === 'authorized'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : oauthStatus === 'authorizing'
                                ? 'bg-slate-800 text-slate-300 cursor-not-allowed border border-slate-700'
                                : 'bg-[#ff7a59] hover:bg-[#ff8f73] text-white shadow-lg shadow-[#ff7a59]/20'
                            }`}
                            disabled={oauthStatus === 'authorizing' || oauthStatus === 'authorized'}
                          >
                            {oauthStatus === 'authorizing' ? (
                              <>
                                <RefreshCw className="w-4 h-4 animate-spin text-slate-400" />
                                <span>Conectando Enclave HubSpot...</span>
                              </>
                            ) : oauthStatus === 'authorized' ? (
                              <>
                                <Check className="w-4 h-4 text-emerald-400" />
                                <span>OAuth Autorizado com Sucesso!</span>
                              </>
                            ) : (
                              <>
                                <Globe className="w-4 h-4" />
                                <span>Vincular Conta HubSpot (OAuth 2.0)</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}

                    {hubspotIntegrationMethod === 'webhook' && (
                      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl space-y-3 animate-in fade-in duration-200">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1 flex-1">
                            <span className="text-[11px] font-bold text-slate-300 block">URL de Destino do Webhook (Target Ingestion URL):</span>
                            <div className="p-2.5 bg-slate-950 rounded-xl font-mono text-xs text-amber-300 border border-slate-800 truncate select-all">
                              https://app.pasquared.space/api/v1/tenants/{tenant.id}/hubspot/webhook
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(`https://app.pasquared.space/api/v1/tenants/${tenant.id}/hubspot/webhook`);
                            }}
                            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-xs rounded-xl transition shrink-0 self-end sm:self-auto"
                          >
                            Copiar URL
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-normal">
                          Para ativar o sincronismo em tempo real (Push), crie um aplicativo no <strong>Developer HubSpot</strong>, vá em <strong>Webhooks &gt; Configurar URL de webhook</strong>, insira a URL acima e ative a inscrição de gatilho selecionada (ex: <code>{hubspotWebhookTrigger}</code>). O PASQUARED-OS processará e sanitizará cada push imediatamente.
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <div className="sm:col-span-2 lg:col-span-4 flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingConnector(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-cyan-600/30"
                  >
                    Salvar e Ativar Conector
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Connectors Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {connectors.map((conn) => (
              <div
                key={conn.id}
                className={`quantum-card-glow rounded-2xl p-5 space-y-4 transition ${
                  conn.sourceType === 'hubspot_crm'
                    ? 'hover:border-[#ff7a59]/50 border-amber-500/20'
                    : 'hover:border-cyan-400/50'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                      conn.sourceType === 'hubspot_crm'
                        ? 'bg-[#ff7a59]/15 text-[#ff7a59] border-[#ff7a59]/30'
                        : 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30'
                    }`}>
                      {conn.sourceType === 'hubspot_crm' ? <Radio className="w-5 h-5 animate-pulse" /> : <Database className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5 flex-wrap">
                        {conn.name}
                        {conn.sourceType === 'hubspot_crm' && (
                          <span className="text-[9px] bg-[#ff7a59]/15 text-[#ff7a59] border border-[#ff7a59]/30 px-1.5 py-0.2 rounded font-sans uppercase font-bold tracking-wider">
                            HubSpot Native
                          </span>
                        )}
                      </h4>
                      <span className="text-[11px] text-cyan-300 font-mono">
                        Tipo: {conn.sourceType === 'hubspot_crm' ? 'HUBSPOT_CRM' : conn.sourceType.toUpperCase()} • Autenticação: {conn.authMethod === 'bearer_token' ? 'Token (Bearer)' : conn.authMethod === 'oauth2' ? 'OAuth 2.0' : conn.authMethod.toUpperCase()}
                      </span>
                    </div>
                  </div>

                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    ATIVO
                  </span>
                </div>

                <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-800 space-y-1.5 text-xs font-mono">
                  <div className="text-slate-400 truncate">
                    Endpoint: <span className="text-slate-200">{conn.endpointUrlOrHost}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Dimensão Cognitiva: <strong className="text-emerald-300">{conn.mappedCognitiveDimension}</strong></span>
                    <span>Peso de Confiança: <strong className="text-cyan-300">{conn.confidenceWeight * 100}%</strong></span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Registros Ingeridos: <strong className="text-white">{conn.recordsIngested.toLocaleString()}</strong></span>
                    <span className="text-[11px] text-slate-500">Último sync: {new Date(conn.lastSyncAt).toLocaleTimeString()}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-xs">
                  <span className="text-slate-400">Domínio Alvo: <strong>{conn.targetClusterDomain}</strong></span>
                  <button
                    onClick={() => {
                      setSimInput(conn.samplePayloadFormat);
                      setActiveTab('simulator');
                    }}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 transition"
                  >
                    <span>Carregar Payload no Simulador</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: Parametrização Decisória PASQUARED */}
      {activeTab === 'parameters' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Parametrização dos Pesos Cognitivos & Limiares MVED</h3>
              <p className="text-xs text-slate-400">
                Ajuste como o Modelo Probabilístico de Ativação Cognitiva (MPAC) e a Poda MVED calcularão decisões para o seu Tenant.
              </p>
            </div>

            <button
              onClick={handleSaveParameters}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition"
            >
              {isSavedParams ? <Check className="w-4 h-4" /> : <Sliders className="w-4 h-4" />}
              <span>{isSavedParams ? 'Parâmetros Salvos no Kernel!' : 'Salvar Calibração'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Cognitive Weights MPAC */}
            <div className="quantum-card-glow rounded-2xl p-5 space-y-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>Pesos das 4 Dimensões Cognitivas: P(u) = α·w + β·ct + γ·mi + δ·ei</span>
              </h4>

              {/* Slider Alpha */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">α - Evidência Objetiva (Dados Fatuais de API/SQL):</span>
                  <span className="font-mono text-cyan-300 font-bold">{(paramsConfig.alphaEvidenceWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="0.8"
                  step="0.05"
                  value={paramsConfig.alphaEvidenceWeight}
                  onChange={(e) => setParamsConfig({ ...paramsConfig, alphaEvidenceWeight: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* Slider Beta */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">β - Contexto Local & Setorial da Empresa:</span>
                  <span className="font-mono text-indigo-300 font-bold">{(paramsConfig.betaContextWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="0.6"
                  step="0.05"
                  value={paramsConfig.betaContextWeight}
                  onChange={(e) => setParamsConfig({ ...paramsConfig, betaContextWeight: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-400"
                />
              </div>

              {/* Slider Gamma */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">γ - Memória Histórica & Casos Anteriores:</span>
                  <span className="font-mono text-emerald-300 font-bold">{(paramsConfig.gammaMemoryWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.5"
                  step="0.05"
                  value={paramsConfig.gammaMemoryWeight}
                  onChange={(e) => setParamsConfig({ ...paramsConfig, gammaMemoryWeight: parseFloat(e.target.value) })}
                  className="w-full accent-emerald-400"
                />
              </div>

              {/* Slider Delta */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">δ - Salvaguarda Ética, Risco & PII:</span>
                  <span className="font-mono text-amber-300 font-bold">{(paramsConfig.deltaSafeguardWeight * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.5"
                  step="0.05"
                  value={paramsConfig.deltaSafeguardWeight}
                  onChange={(e) => setParamsConfig({ ...paramsConfig, deltaSafeguardWeight: parseFloat(e.target.value) })}
                  className="w-full accent-amber-400"
                />
              </div>
            </div>

            {/* Thresholds and Triggers */}
            <div className="quantum-card-glow rounded-2xl p-5 space-y-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>Limiares de Poda MVED & Supervisão Humana (HITL)</span>
              </h4>

              {/* MVED Threshold */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">Limiar de Poda MVED (Eliminação de Hipóteses Fracas):</span>
                  <span className="font-mono text-rose-300 font-bold">{(paramsConfig.mvedThreshold * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.40"
                  max="0.95"
                  step="0.05"
                  value={paramsConfig.mvedThreshold}
                  onChange={(e) => setParamsConfig({ ...paramsConfig, mvedThreshold: parseFloat(e.target.value) })}
                  className="w-full accent-rose-400"
                />
                <span className="text-[10px] text-slate-400">Hipóteses com score abaixo de {(paramsConfig.mvedThreshold * 100).toFixed(0)}% são descartadas.</span>
              </div>

              {/* IGA Auto Approval */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">Índice Global de Abstração (IGA) Mínimo para Aprovação Direta:</span>
                  <span className="font-mono text-cyan-300 font-bold">{(paramsConfig.igaMinimumForAutoApproval * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.65"
                  max="0.99"
                  step="0.01"
                  value={paramsConfig.igaMinimumForAutoApproval}
                  onChange={(e) => setParamsConfig({ ...paramsConfig, igaMinimumForAutoApproval: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* HITL Checkboxes */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={paramsConfig.autoPruneInvalidHypotheses}
                    onChange={(e) => setParamsConfig({ ...paramsConfig, autoPruneInvalidHypotheses: e.target.checked })}
                    className="rounded bg-slate-950 border-slate-700 text-cyan-500"
                  />
                  <span>Descarte automático de alucinações via MVED (Grafo Epistêmico)</span>
                </label>
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={paramsConfig.quarantineHighRiskOutputs}
                    onChange={(e) => setParamsConfig({ ...paramsConfig, quarantineHighRiskOutputs: e.target.checked })}
                    className="rounded bg-slate-950 border-slate-700 text-emerald-500"
                  />
                  <span>Reter saídas com score de risco acima de 70% para aprovação de comitê</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Simulador de Ingestão & Decisão Ao Vivo */}
      {activeTab === 'simulator' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Simulador de Ingestão & Deliberação Epistêmica</h3>
              <p className="text-xs text-slate-400">
                Envie dados corporativos estruturados e veja a deliberação em tempo real calculada pelo Kernel PASQUARED.
              </p>
            </div>
            <button
              onClick={handleExecuteSim}
              disabled={isProcessingSim}
              className="bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-cyan-600/30 flex items-center gap-2 transition"
            >
              <Zap className={`w-4 h-4 ${isProcessingSim ? 'animate-spin' : 'fill-current'}`} />
              <span>{isProcessingSim ? 'Processando no Kernel...' : 'Executar Deliberação PASQUARED'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Input Payload */}
            <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 flex flex-col space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-cyan-300">
                <span className="flex items-center gap-1.5">
                  <FileCode className="w-4 h-4 text-cyan-400" />
                  Payload de Dados Ingeridos (JSON / UCL)
                </span>
                <span className="text-[11px] font-mono text-slate-400">Entrada Empresarial</span>
              </div>
              <textarea
                value={simInput}
                onChange={(e) => setSimInput(e.target.value)}
                rows={12}
                className="w-full flex-1 bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-cyan-200 focus:outline-none focus:border-cyan-500 resize-none shadow-inner"
              />
            </div>

            {/* Output Deliberation */}
            <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-4 flex flex-col space-y-3">
              <div className="flex items-center justify-between text-xs font-semibold text-emerald-300">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Resultado da Deliberação do Kernel PASQUARED
                </span>
                {simDecisionRecord && (
                  <span className="text-[11px] font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 px-2 py-0.5 rounded">
                    CID: {simDecisionRecord.hashCID.slice(0, 16)}...
                  </span>
                )}
              </div>

              {simDecisionRecord ? (
                <div className="space-y-3 overflow-y-auto max-h-80 custom-scrollbar pr-1">
                  {/* Selected Meaning */}
                  <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl space-y-1">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">
                      Decisão Epistêmica Selecionada:
                    </span>
                    <p className="text-xs text-white font-medium">
                      {simDecisionRecord.selectedMeaning}
                    </p>
                  </div>

                  {/* Metrics Bar */}
                  <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center">
                      <span className="text-[10px] text-slate-400 block">IGA (Abstração)</span>
                      <strong className="text-cyan-300 text-sm">{(simDecisionRecord.iga * 100).toFixed(1)}%</strong>
                    </div>
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center">
                      <span className="text-[10px] text-slate-400 block">ICI (Consistência)</span>
                      <strong className="text-indigo-300 text-sm">{(simDecisionRecord.ici * 100).toFixed(1)}%</strong>
                    </div>
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-center">
                      <span className="text-[10px] text-slate-400 block">Status Política</span>
                      <strong className="text-emerald-300 text-xs">{simDecisionRecord.policyStatus}</strong>
                    </div>
                  </div>

                  {/* Rejected Hypotheses (MVED) */}
                  <div className="space-y-1 text-xs">
                    <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
                      <Shield className="w-3.5 h-3.5 text-rose-400" />
                      Hipóteses Eliminadas pela Poda MVED:
                    </span>
                    <div className="space-y-1.5">
                      {simDecisionRecord.rejectedHypotheses.map((h, i) => (
                        <div key={i} className="bg-slate-950/70 border border-rose-500/20 p-2 rounded-lg text-[11px]">
                          <div className="text-rose-300 font-semibold">{h.statement}</div>
                          <div className="text-slate-400 text-[10px]">Motivo: {h.reason} (Score: {(h.score * 100).toFixed(0)}%)</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-slate-500 space-y-2">
                  <Cpu className="w-10 h-10 text-slate-700 animate-pulse" />
                  <p className="text-xs">
                    Clique em "Executar Deliberação PASQUARED" para submeter o payload corporativo ao Kernel.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Chaves de API & Webhooks */}
      {activeTab === 'api_keys' && (
        <div className="quantum-card-glow rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-base font-bold text-white">Chaves de Ingestão de Dados & Webhooks Corporativos</h3>
            <p className="text-xs text-slate-400">
              Use estes endpoints para enviar fluxos contínuos de telemetria diretamente do seu ERP, banco de dados ou pipelines CI/CD.
            </p>
          </div>

          <div className="space-y-4">
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-cyan-300">Endpoint Webhook Ingestion REST:</span>
                <span className="text-emerald-400 font-mono text-[11px]">HTTPS POST (TLS 1.3)</span>
              </div>
              <div className="p-2.5 bg-slate-900 rounded-lg font-mono text-xs text-slate-200 overflow-x-auto">
                https://app.pasquared.space/api/v1/tenants/{tenant.id}/feed/ingest
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-cyan-300">Chave de API do Tenant (Bearer Secret):</span>
                <span className="text-amber-400 font-mono text-[11px]">Grau Enterprise</span>
              </div>
              <div className="p-2.5 bg-slate-900 rounded-lg font-mono text-xs text-amber-200 overflow-x-auto">
                psq_live_ent_{tenant.id.replace(/[^a-z0-9]/g, '')}_88921a4f00bc8921
              </div>
            </div>

            <div className="p-4 bg-cyan-950/30 border border-cyan-500/20 rounded-xl text-xs text-cyan-200 space-y-1">
              <div className="font-bold text-cyan-300">Instruções para o Administrador de TI:</div>
              <p>
                Configure suas rotinas no cron, Apache NiFi, Airflow ou triggers de banco de dados para realizar requisições POST com cabeçalho <code>Authorization: Bearer psq_live_...</code>. Todos os registros serão convertidos automaticamente em UCL e armazenados com carimbo temporal no Ledger PRE.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
