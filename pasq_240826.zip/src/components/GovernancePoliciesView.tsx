import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Lock,
  Eye,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Plus,
  Filter,
  UserCheck
} from 'lucide-react';
import { GovernancePolicy } from '../types/pasquared';

interface GovernancePoliciesViewProps {
  policies: GovernancePolicy[];
}

export const GovernancePoliciesView: React.FC<GovernancePoliciesViewProps> = ({ policies: initialPolicies }) => {
  const [policies, setPolicies] = useState<GovernancePolicy[]>(initialPolicies);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [approvalsQueue, setApprovalsQueue] = useState([
    {
      id: 'appr-01',
      title: 'Concessão de Financiamento Empresarial Excepcional',
      requester: 'Agente de Risco de Crédito',
      riskScore: 4.2,
      igaScore: 0.78,
      reason: 'Valor de R$ 5M excede limite automático e exige aprovação de Compliance Officer (EU AI Act Art. 14)',
      status: 'pending',
      timestamp: 'Hoje, 14:22'
    },
    {
      id: 'appr-02',
      title: 'Acesso a Dados Clínicos Anonimizados para Pesquisa de Oncologia',
      requester: 'Assistente Clínico & Bioética',
      riskScore: 3.8,
      igaScore: 0.82,
      reason: 'Requer chancela do comitê de ética em conformidade com LGPD e Termo de Consentimento',
      status: 'pending',
      timestamp: 'Hoje, 11:05'
    }
  ]);

  const filteredPolicies = selectedCategory === 'all'
    ? policies
    : policies.filter(p => p.category === selectedCategory);

  const handleApprove = (id: string) => {
    setApprovalsQueue(prev => prev.filter(a => a.id !== id));
  };

  const handleReject = (id: string) => {
    setApprovalsQueue(prev => prev.filter(a => a.id !== id));
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              GOVERNANCE & POLICIES
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Intercepção Regulatória em Tempo Real
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Políticas de Governança, Salvaguardas & Human-in-the-Loop
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Defina regras automáticas de intercepção, anonimização de PII, limites de alucinação e fila de aprovação humana para ações de alto impacto.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <UserCheck className="w-4 h-4" />
            {approvalsQueue.length} Aprovações Pendentes
          </span>
        </div>
      </div>

      {/* Human in the Loop Approval Queue */}
      {approvalsQueue.length > 0 && (
        <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              <h3 className="text-base font-bold text-white">
                Fila de Supervisão Humana Obrigatória (Human-in-the-Loop)
              </h3>
            </div>
            <span className="text-xs font-mono text-amber-400">
              EU AI Act Art. 14 • Decisões de Alto Risco
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {approvalsQueue.map((item) => (
              <div key={item.id} className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{item.title}</span>
                  <span className="text-[10px] font-mono text-slate-400">{item.timestamp}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{item.reason}</p>
                <div className="flex justify-between text-[11px] font-mono text-slate-400 bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <span>Solicitante: <strong className="text-slate-200">{item.requester}</strong></span>
                  <span>IGA Score: <strong className="text-cyan-400">{item.igaScore}</strong></span>
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => handleApprove(item.id)}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold py-2 rounded-lg flex items-center justify-center gap-1.5 transition"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Aprovar Decisão</span>
                  </button>
                  <button
                    onClick={() => handleReject(item.id)}
                    className="flex-1 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-600/40 text-xs font-semibold py-2 rounded-lg flex items-center justify-center gap-1.5 transition"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Rejeitar</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Policies List & Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white">Políticas Ativas do Sistema</h3>
            <p className="text-xs text-slate-400">Regras de negócio e salvaguardas verificadas a cada ciclo do PASQUARED Controller.</p>
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none"
            >
              <option value="all">Todas as Categorias</option>
              <option value="Privacy & PII">Privacidade & PII</option>
              <option value="Regulatory">Regulatório & EU AI Act</option>
              <option value="Hallucination & Grounding">Alucinação & MVED</option>
              <option value="Bias & Fairness">Viés & Equidade</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredPolicies.map((policy) => (
            <div key={policy.id} className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-bold">
                  {policy.category}
                </span>
                <span className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded">
                  {policy.violationsCount} violações interceptadas
                </span>
              </div>
              <h4 className="text-sm font-bold text-white">{policy.name}</h4>
              <p className="text-xs text-slate-300">{policy.description}</p>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 font-mono text-[11px] text-indigo-300">
                Regra: {policy.ruleDefinition}
              </div>
              <div className="flex justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
                <span>Ação: <strong className="text-amber-400 uppercase">{policy.actionOnViolation}</strong></span>
                <span>Severidade: <strong className="text-rose-400 uppercase">{policy.severity}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
