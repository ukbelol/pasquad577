import React, { useState } from 'react';
import {
  Cpu,
  Layers,
  Network,
  Grid,
  CheckCircle2,
  XCircle,
  Sparkles,
  ArrowRight,
  RefreshCw,
  GitBranch,
  FileText,
  Activity,
  Zap,
  Info
} from 'lucide-react';
import { ObserverProfile, UCI, CognitiveGraph, Hypothesis, EKO, EpistemicTraceRecord } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';
import { PasquaredLogo } from './PasquaredLogo';

interface PasquaredKernelViewProps {
  currentObserver: ObserverProfile;
}

export const PasquaredKernelView: React.FC<PasquaredKernelViewProps> = ({ currentObserver }) => {
  const [inputText, setInputText] = useState(
    'Empresa de tecnologia submete solicitação de acesso a base de dados clínicos e genômicos para treino de modelo preditivo de IA sob auditoria LGPD e EU AI Act.'
  );
  const [activeTab, setActiveTab] = useState<'sac' | 'graph' | 'matrix' | 'hypotheses' | 'insights' | 'trace'>('sac');
  const [isRunning, setIsRunning] = useState(false);
  const [currentStage, setCurrentStage] = useState<number>(0);
  const [executionResult, setExecutionResult] = useState<any>(null);

  const handleRunFullCycle = async () => {
    setIsRunning(true);
    setCurrentStage(1);

    try {
      // Simulate sequential SAC stages for visual feedback
      const result = await globalPasquaredEngine.executeSAC(
        inputText,
        currentObserver,
        (stageNum) => {
          setCurrentStage(stageNum);
        }
      );

      setExecutionResult(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsRunning(false);
    }
  };

  const sacStages = [
    { level: 1, name: 'Percepção', desc: 'Recepção de estímulos, estruturação de UCIs e cálculo PAC' },
    { level: 2, name: 'Reconhecimento', desc: 'Classificação ontológica POKO e descoberta de clusters' },
    { level: 3, name: 'Associação', desc: 'Construção do Grafo Cognitivo G=(U,R,W) e Matriz A=[aij]' },
    { level: 4, name: 'Contextualização', desc: 'Modulação contextual C e memória acumulada SMEE' },
    { level: 5, name: 'Inferência', desc: 'Geração de hipóteses e cálculo MPAC Bayesiano' },
    { level: 6, name: 'Validação', desc: 'MVED: Eliminação de hipóteses inconsistentes e cálculo ICI' },
    { level: 7, name: 'Abstração', desc: 'Convergência interpretativa ΔI < ε e cálculo IGA final' },
    { level: 8, name: 'Significado', desc: 'Geração do EKO, registro de novo Insight e gravação no PRE' },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Top Formal Ontology Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <PasquaredLogo size="md" showText={false} />
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
                  PASQUARED-OS KERNEL (PCK)
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  Ontologia Formal: Ω = (O, U, R, C, M, H, S)
                </span>
              </div>
              <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
                Núcleo Cognitivo Operacional & Sequência de Abstração (SAC)
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRunFullCycle}
              disabled={isRunning || !inputText.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Executando Nível {currentStage}/8...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-current" />
                  <span>Executar Ciclo Completo SAC</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Input Prompt Box */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
            Entrada Cognitiva de Informação (UCL Input):
          </label>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={2}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 transition resize-none font-mono"
            placeholder="Insira dados brutos ou prompt para processamento pelo Kernel..."
          />
        </div>

        {/* Mathematical Formulas Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 text-slate-300">
          <div>
            <span className="text-indigo-400 font-bold block">PAC(ui):</span>
            α·wi + β·ci + γ·mi + δ·ei
          </div>
          <div>
            <span className="text-cyan-400 font-bold block">IGA (Abstração):</span>
            λ₁p + λ₂c + λ₃m + λ₄e + λ₅l
          </div>
          <div>
            <span className="text-emerald-400 font-bold block">MPAC (Bayesiano):</span>
            P(Hi | U, C, M)
          </div>
          <div>
            <span className="text-amber-400 font-bold block">Convergência:</span>
            ΔI = |IGAt - IGAt-1| &lt; ε
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-800 gap-2 overflow-x-auto custom-scrollbar pb-1">
        <button
          onClick={() => setActiveTab('sac')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition ${
            activeTab === 'sac'
              ? 'bg-slate-900 text-indigo-400 border-t-2 border-indigo-500 border-x border-slate-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Sequência SAC (8 Níveis)</span>
        </button>

        <button
          onClick={() => setActiveTab('graph')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition ${
            activeTab === 'graph'
              ? 'bg-slate-900 text-indigo-400 border-t-2 border-indigo-500 border-x border-slate-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <Network className="w-4 h-4" />
          <span>Grafo Cognitivo Ponderado G=(U,R,W)</span>
        </button>

        <button
          onClick={() => setActiveTab('matrix')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition ${
            activeTab === 'matrix'
              ? 'bg-slate-900 text-indigo-400 border-t-2 border-indigo-500 border-x border-slate-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <Grid className="w-4 h-4" />
          <span>Matriz de Associação A=[aij]</span>
        </button>

        <button
          onClick={() => setActiveTab('hypotheses')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition ${
            activeTab === 'hypotheses'
              ? 'bg-slate-900 text-indigo-400 border-t-2 border-indigo-500 border-x border-slate-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <GitBranch className="w-4 h-4" />
          <span>Eliminação de Hipóteses (MVED)</span>
        </button>

        <button
          onClick={() => setActiveTab('insights')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition ${
            activeTab === 'insights'
              ? 'bg-slate-900 text-indigo-400 border-t-2 border-indigo-500 border-x border-slate-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Memória Dinâmica de Insights</span>
        </button>

        <button
          onClick={() => setActiveTab('trace')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition ${
            activeTab === 'trace'
              ? 'bg-slate-900 text-indigo-400 border-t-2 border-indigo-500 border-x border-slate-800'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Rastreabilidade PRE (Audit Trail)</span>
        </button>
      </div>

      {/* Tab 1: SAC Stepper */}
      {activeTab === 'sac' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">
                Fluxo Sequencial de Abstração Cognitiva (SAC)
              </h3>
              <p className="text-xs text-slate-400">
                Transformação sistemática de dados heterogêneos em significado consolidado via 8 níveis formais.
              </p>
            </div>
            {executionResult && (
              <span className="text-xs font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Ciclo Concluído (IGA: {executionResult.decision.iga.toFixed(3)})
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {sacStages.map((stage) => {
              const isCurrent = currentStage === stage.level;
              const isPast = executionResult || currentStage > stage.level;

              return (
                <div
                  key={stage.level}
                  className={`p-4 rounded-xl border transition-all ${
                    isCurrent
                      ? 'bg-indigo-950/60 border-indigo-500 ring-2 ring-indigo-500/30 shadow-lg'
                      : isPast
                      ? 'bg-slate-950 border-slate-800 text-slate-200'
                      : 'bg-slate-950/40 border-slate-800/50 text-slate-400 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-bold font-mono flex items-center justify-center">
                      {stage.level}
                    </span>
                    <span className="text-[10px] font-mono uppercase text-slate-400">
                      {isPast ? 'COMPLETO' : isCurrent ? 'PROCESSANDO' : 'AGUARDANDO'}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white mb-1">{stage.name}</h4>
                  <p className="text-xs text-slate-300 leading-snug">{stage.desc}</p>
                </div>
              );
            })}
          </div>

          {executionResult && (
            <div className="mt-6 bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Resultado do Nível 8 (Significado Consolidado no EKO):
              </h4>
              <p className="text-sm text-white font-medium bg-slate-900 p-4 rounded-lg border border-slate-800 leading-relaxed">
                "{executionResult.decision.selectedMeaning}"
              </p>
              <div className="flex flex-wrap gap-4 text-xs font-mono text-slate-300 pt-2 border-t border-slate-800">
                <span>EKO ID: <strong className="text-indigo-400">{executionResult.eko.id}</strong></span>
                <span>IGA Final: <strong className="text-cyan-400">{executionResult.decision.iga.toFixed(3)}</strong></span>
                <span>ICI (Consistência): <strong className="text-emerald-400">{executionResult.decision.ici.toFixed(3)}</strong></span>
                <span>CID: <strong className="text-slate-400">{executionResult.ucl.objectID}</strong></span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Cognitive Graph G=(U,R,W) */}
      {activeTab === 'graph' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">
                Grafo Cognitivo Ponderado: G = (U, R, W)
              </h3>
              <p className="text-xs text-slate-400">
                Vértices representam Unidades Cognitivas de Informação (UCIs) e arestas representam relações ponderadas.
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-3 py-1 rounded">
              Complexidade: O(n²)
            </span>
          </div>

          {/* Interactive Graph Node Display */}
          <div className="bg-slate-950 rounded-xl p-6 border border-slate-800 min-h-[360px] flex flex-col justify-between">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {(executionResult?.eko.graph.nodes || [
                { uid: 'u1', content: 'Auditoria LGPD & EU AI Act', category: 'Direito', w: 0.95, pac: 0.92 },
                { uid: 'u2', content: 'Base de Dados Clínicos & Genômicos', category: 'Medicina', w: 0.98, pac: 0.95 },
                { uid: 'u3', content: 'Treino de Modelo Preditivo IA', category: 'Tecnologia', w: 0.85, pac: 0.88 },
                { uid: 'u4', content: 'Consentimento de Pacientes', category: 'Bioética', w: 0.92, pac: 0.90 },
              ]).map((node: any, idx: number) => (
                <div key={idx} className="bg-slate-900 border border-indigo-900/50 p-4 rounded-xl shadow-md hover:border-indigo-500 transition">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold">
                      UCI: {node.uid}
                    </span>
                    <span className="text-xs text-slate-400">{node.category}</span>
                  </div>
                  <p className="text-xs font-medium text-white line-clamp-2">{node.content}</p>
                  <div className="mt-3 flex items-center justify-between text-[10px] font-mono text-slate-400 border-t border-slate-800 pt-2">
                    <span>Peso (w): <strong className="text-white">{node.w}</strong></span>
                    <span>PAC: <strong className="text-cyan-400">{node.pac || 0.85}</strong></span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-slate-900/80 rounded-xl border border-slate-800">
              <h5 className="text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                Arestas e Conexões Ponderadas (Rij = (Ui, Uj, w)):
              </h5>
              <div className="flex flex-wrap gap-2 text-xs">
                {(executionResult?.eko.graph.edges || [
                  { fromUid: 'u2 (Dados Clínicos)', toUid: 'u4 (Consentimento)', type: 'causal', w: 0.94 },
                  { fromUid: 'u1 (EU AI Act)', toUid: 'u3 (Modelo IA)', type: 'logical', w: 0.91 },
                  { fromUid: 'u2 (Dados Clínicos)', toUid: 'u1 (LGPD)', type: 'semantic', w: 0.88 }
                ]).map((edge: any, idx: number) => (
                  <span key={idx} className="bg-slate-800 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 font-mono text-[11px] flex items-center gap-1.5">
                    <span className="text-indigo-400 font-bold">{edge.fromUid}</span>
                    <ArrowRight className="w-3 h-3 text-slate-400" />
                    <span className="text-cyan-400 font-bold">{edge.toUid}</span>
                    <span className="text-emerald-400 font-semibold">[{edge.type} • w={edge.w}]</span>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Association Matrix A=[aij] */}
      {activeTab === 'matrix' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">
                Matriz de Associação Cognitiva Ativa: A = [aᵢⱼ]
              </h3>
              <p className="text-xs text-slate-400">
                Representação matricial da intensidade das relações entre todas as UCIs ativas.
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-3 py-1 rounded">
              aᵢⱼ = R(Uᵢ, Uⱼ)
            </span>
          </div>

          <div className="bg-slate-950 rounded-xl p-6 border border-slate-800 overflow-x-auto">
            {(() => {
              const matrix = executionResult?.eko.graph.associationMatrix || [
                [0, 0.92, 0.85, 0.40],
                [0.92, 0, 0.88, 0.50],
                [0.85, 0.88, 0, 0.72],
                [0.40, 0.50, 0.72, 0]
              ];
              const labels = executionResult?.eko.graph.matrixLabels || ['U1: Dados Clínicos', 'U2: LGPD / EU Act', 'U3: Modelo IA', 'U4: Consentimento'];

              return (
                <table className="w-full text-xs font-mono border-collapse">
                  <thead>
                    <tr>
                      <th className="p-3 text-left text-slate-400 border border-slate-800">UCI</th>
                      {labels.map((lbl: string, idx: number) => (
                        <th key={idx} className="p-3 text-center text-indigo-400 border border-slate-800 bg-slate-900/50">
                          {lbl.substring(0, 16)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {matrix.map((row: number[], rIdx: number) => (
                      <tr key={rIdx}>
                        <td className="p-3 text-slate-300 font-semibold border border-slate-800 bg-slate-900/50">
                          {labels[rIdx]?.substring(0, 16) || `U${rIdx + 1}`}
                        </td>
                        {row.map((val: number, cIdx: number) => {
                          const intensity = val > 0.8 ? 'bg-indigo-600/60 text-white font-bold' : val > 0.5 ? 'bg-indigo-900/40 text-indigo-200' : val > 0 ? 'bg-slate-800/40 text-slate-400' : 'text-slate-600';
                          return (
                            <td key={cIdx} className={`p-3 text-center border border-slate-800 ${intensity}`}>
                              {val.toFixed(2)}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              );
            })()}
          </div>
        </div>
      )}

      {/* Tab 4: Hypotheses Elimination Arena */}
      {activeTab === 'hypotheses' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">
                Arena de Eliminação de Hipóteses (Operador MVED)
              </h3>
              <p className="text-xs text-slate-400">
                Plausibilidade Bayesiana MPAC e eliminação rigorosa de proposições inconsistentes ou de alto risco.
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-3 py-1 rounded">
              V(H) Validador Epistêmico
            </span>
          </div>

          <div className="space-y-4">
            {(executionResult?.eko.hypotheses || [
              {
                id: 'hyp-1',
                statement: 'Aprovar acesso aos dados mediante anonimização diferencial, encriptação homomórfica e auditoria periódica.',
                domain: 'Governança & Medicina',
                vector: { p: 0.94, c: 0.90, m: 0.88, e: 0.25, l: 0.98 },
                posteriorP: 0.88,
                igaScore: 0.892,
                status: 'selected',
                evidences: ['Alinhamento ao Art. 10 do EU AI Act', 'Salvaguarda de anonimização médica validada']
              },
              {
                id: 'hyp-2',
                statement: 'Conceder acesso direto com termo simples de responsabilidade sem criptografia homomórfica.',
                domain: 'Governança',
                vector: { p: 0.60, c: 0.50, m: 0.45, e: 0.70, l: 0.40 },
                posteriorP: 0.35,
                igaScore: 0.485,
                status: 'eliminated',
                eliminationReason: 'Inconsistência lógica severa e violação de requisitos de proteção de dados sensíveis'
              }
            ]).map((hyp: any, idx: number) => {
              const isSelected = hyp.status === 'selected';
              const isEliminated = hyp.status === 'eliminated';

              return (
                <div
                  key={idx}
                  className={`p-5 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-slate-950 border-emerald-500/80 ring-1 ring-emerald-500/30'
                      : isEliminated
                      ? 'bg-slate-950/60 border-rose-900/60 opacity-80'
                      : 'bg-slate-950 border-slate-800'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      {isSelected ? (
                        <span className="flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold px-2.5 py-0.5 rounded-full">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          HIPÓTESE VENCEDORA SELECIONADA
                        </span>
                      ) : (
                        <span className="flex items-center gap-1.5 bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold px-2.5 py-0.5 rounded-full">
                          <XCircle className="w-3.5 h-3.5" />
                          ELIMINADA VIA MVED
                        </span>
                      )}
                      <span className="text-xs text-slate-400 font-mono">ID: {hyp.id}</span>
                    </div>

                    <div className="flex items-center gap-3 text-xs font-mono">
                      <span>P(H|U,C,M): <strong className={isSelected ? 'text-emerald-400' : 'text-slate-400'}>{(hyp.posteriorP || 0.85).toFixed(2)}</strong></span>
                      <span>IGA: <strong className={isSelected ? 'text-cyan-400' : 'text-slate-400'}>{(hyp.igaScore || 0.88).toFixed(3)}</strong></span>
                    </div>
                  </div>

                  <p className="text-sm font-medium text-white mb-3">"{hyp.statement}"</p>

                  {/* Cognitive Vector h=(p,c,m,e,l) */}
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-wrap items-center gap-4 text-xs font-mono text-slate-300">
                    <span className="text-indigo-400 font-bold">Vetor Cognitivo h=(p,c,m,e,l):</span>
                    <span>p: <strong className="text-white">{hyp.vector?.p || 0.9}</strong></span>
                    <span>c: <strong className="text-white">{hyp.vector?.c || 0.85}</strong></span>
                    <span>m: <strong className="text-white">{hyp.vector?.m || 0.8}</strong></span>
                    <span>e: <strong className="text-white">{hyp.vector?.e || 0.3}</strong></span>
                    <span>l: <strong className="text-white">{hyp.vector?.l || 0.95}</strong></span>
                  </div>

                  {hyp.eliminationReason && (
                    <p className="mt-2 text-xs text-rose-400 font-medium">
                      Motivo da Eliminação: {hyp.eliminationReason}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 5: Dynamic Insights Memory */}
      {activeTab === 'insights' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">
                Memória Dinâmica de Insights (SMEE)
              </h3>
              <p className="text-xs text-slate-400">
                Geração automática de novos insights a cada ciclo interpretativo, armazenados hierarquicamente na memória evolutiva.
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-3 py-1 rounded">
              L(M) Operador de Aprendizagem
            </span>
          </div>

          <div className="space-y-3">
            {[
              {
                id: 'ins-01',
                statement: 'A conjunção de anonimização diferencial com encriptação homomórfica reduz em 98.4% o risco residual de vazamento de dados genômicos.',
                category: 'Medicina & Governança',
                novelty: 0.92,
                impact: 'Transformacional',
                date: 'Agora'
              },
              {
                id: 'ins-02',
                statement: 'Modelos supervisionados com operadores MVED apresentam taxa zero de alucinação de artigos jurídicos falsos.',
                category: 'Direito & IA',
                novelty: 0.85,
                impact: 'Alto',
                date: 'Hoje, 14:10'
              },
              {
                id: 'ins-03',
                statement: 'Ajuste de LTV com DTI ponderado pelo histórico de transações reduz a inadimplência sem diminuir concessões legítimas.',
                category: 'Finanças',
                novelty: 0.79,
                impact: 'Alto',
                date: 'Ontem'
              }
            ].map((ins, idx) => (
              <div key={idx} className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="bg-indigo-500/20 text-indigo-300 text-[10px] font-mono px-2 py-0.5 rounded font-bold">
                      {ins.category}
                    </span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-semibold">
                      Impacto: {ins.impact}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-white">{ins.statement}</p>
                </div>
                <div className="text-right text-xs font-mono text-slate-400 shrink-0">
                  <span>Novidade: {(ins.novelty * 100).toFixed(0)}%</span>
                  <div className="text-[10px] text-slate-400">{ins.date}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: Protocol of Epistemological Traceability (PRE) */}
      {activeTab === 'trace' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">
                Protocolo de Rastreabilidade Epistemológica (PRE)
              </h3>
              <p className="text-xs text-slate-400">
                Encadeamento criptográfico imutável (hash chain) de cada decisão tomada pelo Kernel.
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-3 py-1 rounded">
              Assinatura TEE Criptografada
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {(globalPasquaredEngine.getTraceRecords().length > 0
              ? globalPasquaredEngine.getTraceRecords()
              : [
                  {
                    id: 'pre-01',
                    actionTaken: 'Decisão aprovada com salvaguardas MVED ativas',
                    currentIGA: 0.892,
                    currentICI: 0.940,
                    signatureHash: 'cid-p2-sign-83fa9b12-l9f3',
                    timestamp: new Date().toISOString()
                  }
                ]
            ).map((rec: any, idx: number) => (
              <div key={idx} className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-slate-400 text-[11px]">
                  <span>ID: <strong className="text-indigo-400">{rec.id}</strong></span>
                  <span>{rec.timestamp}</span>
                </div>
                <p className="text-sm font-sans font-medium text-white">{rec.actionTaken}</p>
                <div className="flex flex-wrap gap-4 text-[11px] text-slate-400 pt-2 border-t border-slate-800/60">
                  <span>IGA: <strong className="text-cyan-400">{rec.currentIGA?.toFixed(3) || '0.890'}</strong></span>
                  <span>ICI: <strong className="text-emerald-400">{rec.currentICI?.toFixed(3) || '0.920'}</strong></span>
                  <span>Hash Assinatura: <strong className="text-indigo-300">{rec.signatureHash}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
