import React, { useState } from 'react';
import {
  FileCheck,
  CheckCircle2,
  Shield,
  Clock,
  Download,
  Filter,
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { ComplianceControl } from '../types/pasquared';

interface ComplianceViewProps {
  controls: ComplianceControl[];
}

export const ComplianceView: React.FC<ComplianceViewProps> = ({ controls: initialControls }) => {
  const [controls, setControls] = useState<ComplianceControl[]>(initialControls);
  const [selectedFramework, setSelectedFramework] = useState<string>('all');

  const frameworks = ['EU AI Act', 'ISO/IEC 42001', 'NIST AI RMF', 'LGPD/GDPR', 'SOC2 Type II'];

  const filtered = selectedFramework === 'all'
    ? controls
    : controls.filter(c => c.framework === selectedFramework);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              REGULATORY COMPLIANCE
            </span>
            <span className="text-xs text-slate-400 font-mono">
              EU AI Act • ISO 42001 • NIST RMF • LGPD
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Conformidade Regulatória & Auditoria de IA
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Mapeamento exaustivo de controles de conformidade com coleta automatizada de evidências, 
            trilha de rastreabilidade epistêmica (PRE) e exportação de relatórios para órgãos reguladores.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => alert('Relatório de Conformidade Auditável gerado com sucesso.')}
            className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition"
          >
            <Download className="w-4 h-4" />
            <span>Exportar Dossiê Técnico</span>
          </button>
        </div>
      </div>

      {/* Frameworks Filter Bar */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setSelectedFramework('all')}
          className={`text-xs font-semibold px-4 py-2 rounded-xl border transition ${
            selectedFramework === 'all'
              ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/20'
              : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
          }`}
        >
          Todos os Frameworks ({controls.length})
        </button>
        {frameworks.map((fw) => (
          <button
            key={fw}
            onClick={() => setSelectedFramework(fw)}
            className={`text-xs font-semibold px-4 py-2 rounded-xl border transition ${
              selectedFramework === fw
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/20'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            {fw}
          </button>
        ))}
      </div>

      {/* Controls List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((control) => (
          <div key={control.id} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3 shadow-sm hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-bold">
                {control.framework}
              </span>
              <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                <CheckCircle2 className="w-3 h-3" />
                CONFORME
              </span>
            </div>

            <div>
              <span className="text-xs font-mono text-cyan-400 font-bold block">{control.controlCode}</span>
              <h4 className="text-sm font-bold text-white mt-0.5">{control.title}</h4>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{control.description}</p>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800">
              <span>Evidências no PRE: <strong className="text-indigo-400">{control.evidenceCount}</strong></span>
              <span>Auditado: <strong className="text-slate-200">{control.lastAuditDate}</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
