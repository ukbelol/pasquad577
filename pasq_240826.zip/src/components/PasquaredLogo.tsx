import React from 'react';

interface PasquaredLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  showText?: boolean;
  subtitle?: string;
  glow?: boolean;
  className?: string;
}

export const PasquaredSvgLogo: React.FC<{ className?: string }> = ({ className = 'w-full h-full' }) => {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 512 512" 
      className={className}
    >
      <defs>
        <radialGradient id="quantumGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#00f0ff" stopOpacity={0.9}/>
          <stop offset="35%" stopColor="#0066ff" stopOpacity={0.6}/>
          <stop offset="70%" stopColor="#00f5a0" stopOpacity={0.3}/>
          <stop offset="100%" stopColor="#030712" stopOpacity={0}/>
        </radialGradient>
        <linearGradient id="neonCyanBlue" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#00f0ff"/>
          <stop offset="50%" stopColor="#0077ff"/>
          <stop offset="100%" stopColor="#00f5a0"/>
        </linearGradient>
        <filter id="neonBloom" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="8" result="blur"/>
          <feMerge>
            <feMergeNode in="blur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>

      <circle cx="256" cy="256" r="230" fill="#040d1a" stroke="#00f0ff" strokeWidth={2} strokeOpacity={0.3}/>
      <circle cx="256" cy="256" r="210" fill="url(#quantumGlow)"/>

      <g stroke="url(#neonCyanBlue)" strokeWidth={3} fill="none" opacity={0.8} filter="url(#neonBloom)">
        <ellipse cx="256" cy="256" rx="200" ry="70" transform="rotate(-30 256 256)"/>
        <ellipse cx="256" cy="256" rx="200" ry="70" transform="rotate(30 256 256)"/>
        <ellipse cx="256" cy="256" rx="200" ry="70" transform="rotate(90 256 256)"/>
      </g>

      <circle cx="95" cy="165" r="7" fill="#00f0ff" filter="url(#neonBloom)"/>
      <circle cx="417" cy="347" r="7" fill="#00f5a0" filter="url(#neonBloom)"/>
      <circle cx="95" cy="347" r="7" fill="#00f5a0" filter="url(#neonBloom)"/>
      <circle cx="417" cy="165" r="7" fill="#00f0ff" filter="url(#neonBloom)"/>
      <circle cx="256" cy="56" r="8" fill="#00ffff" filter="url(#neonBloom)"/>
      <circle cx="256" cy="456" r="8" fill="#00f5a0" filter="url(#neonBloom)"/>

      <g filter="url(#neonBloom)">
        <path d="M 256 90 L 390 190 L 390 330 L 256 420 L 122 330 L 122 190 Z" 
              fill="#031124" fillOpacity={0.8} 
              stroke="url(#neonCyanBlue)" strokeWidth={6} strokeLinejoin="round"/>
        
        <path d="M 200 160 L 200 350 M 200 160 L 270 160 C 310 160 310 240 270 240 L 200 240" 
              stroke="#ffffff" strokeWidth={22} strokeLinecap="round" strokeLinejoin="round" fill="none"/>
        <path d="M 200 160 L 200 350 M 200 160 L 270 160 C 310 160 310 240 270 240 L 200 240" 
              stroke="url(#neonCyanBlue)" strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" fill="none"/>

        <path d="M 315 175 C 315 160 345 160 345 175 C 345 195 315 205 315 215 L 348 215" 
              stroke="#00f5a0" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      </g>

      <circle cx="256" cy="256" r="14" fill="#ffffff" filter="url(#neonBloom)"/>
    </svg>
  );
};

export const PasquaredImage: React.FC<{
  className?: string;
  alt?: string;
}> = ({ className = '', alt = 'PASQUARED-OS Logotipo' }) => {
  return <PasquaredSvgLogo className={className} />;
};

export const PasquaredLogo: React.FC<PasquaredLogoProps> = ({
  size = 'md',
  showText = true,
  subtitle,
  glow = true,
  className = ''
}) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
    '2xl': 'w-28 h-28'
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-xl',
    xl: 'text-2xl',
    '2xl': 'text-4xl'
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Quantum Logo Container with vector SVG */}
      <div
        className={`relative ${sizeClasses[size]} rounded-2xl flex items-center justify-center shrink-0 overflow-hidden ${
          glow
            ? 'shadow-[0_0_25px_rgba(0,240,255,0.45)] border border-cyan-400/60 ring-1 ring-cyan-400/30'
            : 'border border-slate-800'
        } bg-gradient-to-br from-[#020b18] via-[#041d38] to-[#012d2b] transition-all duration-300 group`}
      >
        {/* Animated Quantum Ray Background */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,240,255,0.3),transparent_70%)] animate-pulse pointer-events-none" />

        <PasquaredSvgLogo className="w-full h-full object-contain p-1 relative z-10 filter drop-shadow-[0_0_10px_rgba(0,245,160,0.7)] transition-transform duration-300 group-hover:scale-105" />
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span
              className={`font-black tracking-tight ${textSizes[size]} bg-gradient-to-r from-cyan-300 via-blue-300 to-emerald-300 bg-clip-text text-transparent`}
            >
              PASQUARED-OS
            </span>
            <span className="bg-gradient-to-r from-cyan-500/20 to-emerald-500/20 text-cyan-300 border border-cyan-400/30 text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full tracking-widest shadow-[0_0_10px_rgba(0,240,255,0.2)]">
              v2.5
            </span>
          </div>
          <p className="text-[11px] text-slate-300 font-mono tracking-tight">
            {subtitle || 'Enterprise Cognitive Governance & Quantum Engine'}
          </p>
        </div>
      )}
    </div>
  );
};
