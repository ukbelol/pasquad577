import React, { useState } from 'react';
import {
  BookOpen,
  Sliders,
  Database,
  ShieldCheck,
  Bot,
  Boxes,
  Activity,
  Key,
  Terminal,
  HelpCircle,
  FileCheck,
  Layers,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Code2,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Zap,
  Building2,
  Workflow,
  ShieldAlert,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { PasquaredLogo } from './PasquaredLogo';

interface OperationsManualModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialModule?: string;
}

export const OperationsManualModal: React.FC<OperationsManualModalProps> = ({
  isOpen,
  onClose,
  initialModule = 'overview'
}) => {
  const [selectedTopic, setSelectedTopic] = useState<string>(initialModule);
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  const manualSections = [
    {
      id: 'overview',
      title: '1. Visão Geral & Arquitetura de Parametrização',
      icon: BookOpen,
      category: 'Fundamentos',
      summary: 'Como o PASQUARED-OS funciona, os 4 pilares ontológicos POKO e o fluxo de dados.',
      content: {
        intro:
          'O PASQUARED-OS é um Sistema Operacional Cognitivo e Enclave de Governança de IA. Todo cliente tem controle granular de como o sistema deve deliberar, quais modelos de IA usar, quais dados ingerir e quais regras de conformidade aplicar.',
        whereToFind: 'Disponível em: Menu Lateral > Gestão de Recursos & Dados TI / Calibração & Parâmetros / AI Gateway.',
        parameters: [
          {
            name: 'Tenant ID & Slug',
            where: 'Painel do Cliente > Perfil da Empresa ou Menu Tenants',
            meaning: 'Identificador criptográfico único que isola as matrizes de memória e logs de auditoria do cliente.',
            howToSet: 'Gerado automaticamente no cadastro da empresa ou editável pelo Administrador da Empresa.'
          },
          {
            name: 'Observador O(P, E, K, B)',
            where: 'Cabeçalho Superior > Seletor de Observador ou Módulo Decision Intelligence',
            meaning: 'Vetor de calibração ontológica: P (Perspectiva), E (Evidência), K (Conhecimento a Priori), B (Viés de Decisão).',
            howToSet: 'Selecione perfis pré-definidos (Ex: Risco de Crédito, Auditoria Jurídica, Ética Clínica) ou crie novos vetores customizados.'
          }
        ],
        stepByStep: [
          'Cadastre sua empresa no Portal de Empresas ou faça login com suas credenciais.',
          'Acesse "Gestão de Recursos & Dados TI" para conectar as fontes de dados da sua empresa (SAP, Postgres, REST APIs).',
          'Configure as políticas de governança na aba "Governança & Políticas" definindo limites de alucinação e aprovações humanas obrigatórias.',
          'Escolha quais modelos de IA ativar no "AI Gateway" e defina os pesos de acurácia epistêmica desejados.'
        ]
      }
    },
    {
      id: 'connectors',
      title: '2. Módulo de Conectores & Recursos de TI',
      icon: Database,
      category: 'Dados & Integrações',
      summary: 'Parametrização de ERP SAP, Bancos SQL/Data Lake, APIs REST e Webhooks.',
      content: {
        intro:
          'O Módulo de Conectores permite que o PASQUARED ingira dados corporativos em tempo real para ancorar as deliberações de IA em fatos concretos e eliminar alucinações (Grounding Epistêmico).',
        whereToFind: 'Menu Lateral > "Gestão de Recursos & Dados TI" > Aba "Conectores de Dados Corporativos".',
        parameters: [
          {
            name: 'Endpoint URL / Host Connection String',
            where: 'Modal "Cadastrar Novo Conector" > Campo "Endpoint URL / Host"',
            meaning: 'Endereço de rede seguro (HTTPS / WSS / JDBC) onde residem os dados da empresa.',
            howToSet: 'Ex: "https://api.empresa.com.br/v1/transacoes" ou "postgresql://db.empresa.internal:5432/datalake".'
          },
          {
            name: 'Método de Autenticação (Auth Method)',
            where: 'Modal "Cadastrar Novo Conector" > Campo "Método de Autenticação"',
            meaning: 'Protocolo de credenciais para acesso: Bearer Token, API Key, OAuth2 ou mTLS.',
            howToSet: 'Selecione o protocolo correspondente e insira o segredo no cofre isolado de chaves (Vault).'
          },
          {
            name: 'Dimensão Cognitiva Mapeada',
            where: 'Configuração do Conector > Seletor "Dimensão Ontológica"',
            meaning: 'Define qual vetor do Kernel o conector alimenta: Evidência (α), Contexto Local (β), Memória Histórica (γ) ou Salvaguarda (δ).',
            howToSet: 'Selecione "Evidência (α)" para transações e dados factuais; "Memória Histórica (γ)" para bases de clientes e histórico; "Salvaguarda (δ)" para regras jurídicas e compliance.'
          },
          {
            name: 'Peso de Confiabilidade (0.0 a 1.0)',
            where: 'Configuração do Conector > Slider "Peso de Confiabilidade"',
            meaning: 'Grau de certeza atribuído aos dados deste conector no cálculo da Poda MVED.',
            howToSet: 'Configure 0.95 - 1.0 para bancos de dados internos auditados; 0.70 - 0.85 para APIs de terceiros ou feeds públicos.'
          }
        ],
        stepByStep: [
          'Clique no botão "+ Novo Conector Corporativo" no topo da página de Recursos TI.',
          'Preencha o Nome Amigável do Conector (ex: "ERP SAP Faturamento").',
          'Escolha o Tipo de Fonte: REST API, Banco de Dados SQL, ERP/CRM ou Webhook.',
          'Insira a URL de conexão e o Token / API Key de autenticação.',
          'Escolha a Frequência de Sincronização (Tempo Real, 1 min, 5 min, etc.).',
          'Defina a Dimensão Cognitiva e o Peso de Confiabilidade.',
          'Clique em "Salvar e Ativar Conector". O sistema iniciará a ingestão segura com criptografia TLS 1.3.'
        ]
      }
    },
    {
      id: 'gateway',
      title: '3. Módulo AI Gateway (Multi-Model Routing)',
      icon: Boxes,
      category: 'Modelos de IA',
      summary: 'Como parametrizar rotas de LLM (Gemini, GPT-4o, Claude, Watsonx, Modelos Locais).',
      content: {
        intro:
          'O AI Gateway atua como proxy inteligente e enclave de segurança, inspecionando prompts e respostas antes de chegarem aos usuários ou sistemas.',
        whereToFind: 'Menu Lateral > "AI Gateway (Multi-Model)".',
        parameters: [
          {
            name: 'Modelo de IA Ativo',
            where: 'Tela AI Gateway > Seletor de Modelo de IA',
            meaning: 'LLM ou modelo de inferência utilizado para processar a requisição.',
            howToSet: 'Escolha entre Google Gemini Pro, Microsoft Azure OpenAI GPT-4o, Anthropic Claude 3.5 Sonnet, IBM Watsonx ou Cluster Local (Llama 3 / DeepSeek).'
          },
          {
            name: 'Sanitização de PII (Anonimização LGPD/GDPR)',
            where: 'AI Gateway > Configuração de Rota > Checkbox "Sanitização de PII"',
            meaning: 'Mascara automaticamente CPFs, cartões de crédito, e-mails e dados de saúde antes de enviar à nuvem.',
            howToSet: 'Mantenha "Ativado" para conformidade com a LGPD/GDPR.'
          },
          {
            name: 'Intercepção PASQUARED & Validação MVED',
            where: 'AI Gateway > Checkbox "Intercepção PASQUARED"',
            meaning: 'Submete a resposta gerada pela LLM à validação vetorial da ontologia POKO antes de retornar.',
            howToSet: 'Recomendado sempre manter ATIVADO para bloquear alucinações matemáticas.'
          }
        ],
        stepByStep: [
          'Selecione o modelo de IA que melhor atende à sua demanda de custo vs. raciocínio.',
          'Insira o Prompt de Negócio na caixa de texto do simulador ou use o endpoint `/api/gateway/generate`.',
          'Ative a flag `pasquaredValidation: true` para aplicar o filtro de veracidade epistêmica.',
          'Execute a requisição e analise o scorecard de acurácia, latência e hash gravado no Pre-Ledger.'
        ]
      }
    },
    {
      id: 'agents',
      title: '4. Módulo de Agentes de IA Orquestrados',
      icon: Bot,
      category: 'Automação Inteligente',
      summary: 'Configuração de agentes especialistas com fluxo de perguntas investigativas e decisão.',
      content: {
        intro:
          'Os Agentes de IA executam fluxos de raciocínio investigativo estruturado, fazendo perguntas de contexto para o usuário ou buscando dados em conectores para tomar decisões seguras.',
        whereToFind: 'Menu Lateral > "AI Agents Orquestrados".',
        parameters: [
          {
            name: 'Papel do Agente (Agent Role & Specialty)',
            where: 'Tela de Agentes > Seletor de Agente',
            meaning: 'Especialidade cognitiva: Risco de Crédito Bancário, Auditoria de Conformidade EU AI Act ou Assistente Clínico.',
            howToSet: 'Selecione o agente adequado para o caso de uso.'
          },
          {
            name: 'Objetivo de Negócio (Goal Prompt)',
            where: 'Campo de texto "Objetivo do Agente"',
            meaning: 'Instrução clara do que o agente deve deliberar ou aprovar.',
            howToSet: 'Ex: "Avaliar liberação de crédito de R$ 500.000 para capital de giro com garantia em duplicatas".'
          },
          {
            name: 'Respostas de Contexto Investigativo',
            where: 'Fase 2 do Agente: Formulário de Perguntas Contextuais',
            meaning: 'Dados essenciais solicitados pelo agente para embasamento formal.',
            howToSet: 'Preencha os valores solicitados (ex: faturamento mensal, histórico de compliance, índices de risco).'
          }
        ],
        stepByStep: [
          'Escolha o agente especialista desejado no seletor.',
          'Defina o objetivo de negócio e clique em "Iniciar Deliberação com Agente".',
          'Responda às perguntas investigativas geradas pelo agente.',
          'Clique em "Executar Deliberação PASQUARED-OS". O motor validará a ontologia e gerará o parecer final fundamentado com hash SHA-256.'
        ]
      }
    },
    {
      id: 'governance_risk',
      title: '5. Módulo de Governança, Riscos 5x5 e Políticas',
      icon: ShieldCheck,
      category: 'Governança & Risco',
      summary: 'Parametrização de políticas de salvaguarda, aprovação humana (Human-in-the-Loop) e matriz de riscos.',
      content: {
        intro:
          'Permite que a equipe de compliance e segurança configure limites de risco e regras de intercepção obrigatória.',
        whereToFind: 'Menu Lateral > "Governança & Políticas" e "Risk Management 5x5".',
        parameters: [
          {
            name: 'Limiar de Aprovação Humana (Human-in-the-Loop / IGA Score)',
            where: 'Governança & Políticas > Configuração de Políticas',
            meaning: 'Nota de risco acima da qual a IA é PROIBIDA de agir sozinha e precisa de chancela humana.',
            howToSet: 'Valores típicos: 0.75 a 0.85. Se a deliberação superar este score, ela vai para a Fila de Aprovações Pendentes.'
          },
          {
            name: 'Matriz 5x5: Probabilidade (1 a 5) × Impacto (1 a 5)',
            where: 'Risk Management 5x5 > Matriz de Calor Interativa',
            meaning: 'Classificação de riscos da IA (alucinação, viés, vazamento de PII, indisponibilidade).',
            howToSet: 'Clique nas células da matriz para visualizar riscos associados ou clique em "+ Novo Risco" para cadastrar novas salvaguardas.'
          },
          {
            name: 'Ações de Mitigação Obrigatórias',
            where: 'Detalhes do Risco > Campo "Plano de Mitigação"',
            meaning: 'Procedimentos automáticos que o sistema deve acionar caso o risco se manifeste.',
            howToSet: 'Ex: "Ativar Poda MVED estrita e encaminhar para o Comitê de Risco".'
          }
        ],
        stepByStep: [
          'Monitore a aba "Fila de Aprovações IGA" para autorizar ou rejeitar decisões de alto impacto.',
          'Acesse a Matriz 5x5 para mapear vulnerabilidades dos seus modelos.',
          'Revise os controles de conformidade para auditorias ISO 42001 e EU AI Act na aba de Compliance.'
        ]
      }
    },
    {
      id: 'calibration',
      title: '6. Calibração & Parâmetros Algorítmicos (α, β, ε)',
      icon: SlidersHorizontal,
      category: 'Parâmetros Avançados',
      summary: 'Onde encontrar e como ajustar os pesos matemáticos do Kernel PASQUARED.',
      content: {
        intro:
          'Os parâmetros matemáticos controlam a rigidez do algoritmo contra incertezas e alucinações.',
        whereToFind: 'Menu Lateral > "Calibração & Parâmetros" ou Botão "Calibrador" no topo.',
        parameters: [
          {
            name: 'Peso Base α (Alpha - Rigidez de Evidência)',
            where: 'Calibrador de Parâmetros > Slider "Peso Base α"',
            meaning: 'Proporção de peso atribuída estritamente às evidências factuais comprovadas.',
            howToSet: 'Padrão: 0.35 (35%). Empresas financeiras ou de saúde podem elevar para 0.45 - 0.55 para máxima exigência de provas.'
          },
          {
            name: 'Intensidade Contextual β (Beta)',
            where: 'Calibrador de Parâmetros > Slider "Intensidade Contextual β"',
            meaning: 'Sensibilidade do algoritmo a nuances do contexto específico do cliente.',
            howToSet: 'Padrão: 0.25 (25%). Ajuste entre 0.15 e 0.35 dependendo do dinamismo do setor.'
          },
          {
            name: 'Limiar de Convergência ε (Epsilon)',
            where: 'Calibrador de Parâmetros > Slider "Limiar de Convergência ε"',
            meaning: 'Tolerância a desvios matemáticos antes de declarar uma alucinação de IA.',
            howToSet: 'Padrão: 0.01 (1%). Valores menores que 0.01 tornam a poda extremamente rigorosa.'
          }
        ],
        stepByStep: [
          'Abra o painel "Calibrador" no menu.',
          'Ajuste os sliders conforme as diretrizes de governança da sua empresa.',
          'Clique em "Salvar Calibração". As novas constantes serão propagadas instantaneamente para todas as deliberações.'
        ]
      }
    },
    {
      id: 'audit',
      title: '7. Pre-Ledger PRE: Auditoria Forense & Merkle Proofs',
      icon: FileCheck,
      category: 'Auditoria & Imutabilidade',
      summary: 'Como exportar logs forenses, verificar hashes SHA-256 e comprovar conformidade.',
      content: {
        intro:
          'O Pre-Ledger PRE registra todas as decisões de forma indelével com assinatura criptográfica assimétrica.',
        whereToFind: 'Menu Lateral > "Audit Trail Imutável (PRE)".',
        parameters: [
          {
            name: 'Hash SHA-256 do Registro',
            where: 'Tabela de Auditoria > Coluna "Hash do Enclave"',
            meaning: 'Resumo criptográfico da decisão, incluindo prompt, contexto, regras aplicadas e parecer.',
            howToSet: 'Gerado automaticamente em tempo de execução pela função criptográfica do Pre-Ledger.'
          },
          {
            name: 'Exportação de Relatório Forense',
            where: 'Audit Trail > Botão "Exportar Relatório PDF/JSON"',
            meaning: 'Dossiê estruturado para apresentação a órgãos reguladores (BACEN, CVM, ANPD, SEC).',
            howToSet: 'Clique no botão de exportação e selecione o período desejado.'
          }
        ],
        stepByStep: [
          'Acesse o módulo de Auditoria PRE.',
          'Filtre as decisões por período, agente ou nível de risco.',
          'Clique em qualquer linha para expandir a reconstituição epistêmica passo a passo.',
          'Clique em "Exportar Prova Criptográfica" para obter o arquivo assinado digitalmente.'
        ]
      }
    },
    {
      id: 'hubspot',
      title: '8. Relatórios de CRM: Integração com HubSpot API & Prompts',
      icon: Workflow,
      category: 'Dados & Integrações',
      summary: 'Como extrair dados de Contatos, Empresas e Negócios (Deals) e estruturar perguntas cognitivas.',
      content: {
        intro:
          'O PASQUARED-OS permite conectar dados estruturados de CRM via HubSpot API (utilizando tokens de acesso privado) para gerar relatórios automatizados, forecasting comercial e auditoria de funil usando Inteligência Artificial.',
        whereToFind: 'Menu Lateral > "Gestão de Recursos & Dados TI" > Novo Conector REST API (Endpoint: api.hubapi.com).',
        parameters: [
          {
            name: 'HubSpot Private App Access Token (pat-na1-...)',
            where: 'HubSpot > Configurações > Integrações > Aplicativos Privados (Private Apps)',
            meaning: 'Token de segurança OAuth que fornece permissões granulares de leitura para o PASQUARED-OS.',
            howToSet: 'Crie um aplicativo privado com os escopos crm.objects.contacts.read, crm.objects.deals.read e crm.objects.companies.read.'
          },
          {
            name: 'Mapeamento de Propriedades de Objeto (Query Properties)',
            where: 'Configuração do Endpoint do Conector',
            meaning: 'Campos específicos do HubSpot a serem extraídos da API (ex: dealname, amount, dealstage, closedate).',
            howToSet: 'Anexe o parâmetro ?properties=dealname,amount,dealstage,closedate,pipeline na URL do conector para extração de negócios.'
          },
          {
            name: 'Engenharia de Prompt para Relatórios (Fórmula Cognitiva)',
            where: 'AI Agents Orquestrados / Chat de Inteligência de Decisão',
            meaning: 'Estruturação da pergunta usando Persona + Contexto de Conector + Tarefa Analítica + Formato de Saída.',
            howToSet: 'Ex: "Aja como Diretor de RevOps. Usando os dados extraídos do conector HubSpot, elabore um relatório de funil com faturamento em tabela Markdown."'
          }
        ],
        stepByStep: [
          'Obtenha o seu Token de Acesso Privado no HubSpot e configure um novo conector com URL "https://api.hubapi.com/crm/v3/objects/".',
          'Utilize os AI Agents ou o módulo "Decision Intelligence" para ler do conector de dados corporativos.',
          'Formule perguntas específicas delimitando as propriedades que deseja analisar (ex: quantidade de deals, ticket médio, deals estagnados).',
          'Peça explicitamente relatórios estruturados (ex: tabelas, bullet points com recomendações de ação baseadas em riscos) para melhor visualização.'
        ]
      }
    },
    {
      id: 'ai-prompting',
      title: '9. Operando a IA: Guia de Prompts, Comandos & Relatórios',
      icon: Bot,
      category: 'Operação da IA',
      summary: 'Manual passo a passo de como e onde acessar o prompt da IA, formular perguntas, obter respostas e gerar relatórios executivos no PASQUARED-OS.',
      content: {
        intro:
          'O PASQUARED-OS disponibiliza múltiplos módulos conversacionais e cognitivos para interagir com IA. Você pode fazer perguntas complexas, enviar instruções estruturadas de governança e solicitar a consolidação de dados corporativos (como dados de CRM do HubSpot ou ERP SAP) em relatórios executivos altamente profissionais.',
        whereToFind: 'Menu Lateral > Seções: "Decision Intelligence", "AI Gateway (Multi-Model)" e "AI Agents Orquestrados".',
        parameters: [
          {
            name: 'Módulo: Decision Intelligence (Inteligência de Decisão)',
            where: 'Menu Lateral > "Decision Intelligence"',
            meaning: 'Ambiente de modelagem de cenários estratégicos integrando o Vetor Cognitivo h=(p,c,m,e,l) (Político, Cultural, Mítico, Econômico, Legal).',
            howToSet: 'Escreva a descrição do seu cenário, ajuste os sliders de conformidade para calibrar o viés regulatório/ético e clique em "Iniciar Análise Cognitiva" para gerar uma árvore de decisão ponderada.'
          },
          {
            name: 'Módulo: AI Gateway (Multi-Model Hub)',
            where: 'Menu Lateral > "AI Gateway (Multi-Model)"',
            meaning: 'Central de prompts direta e ágil conectada aos principais LLMs (Gemini, Claude, GPT, Mistral, Llama).',
            howToSet: 'Selecione o provedor e modelo de IA no cabeçalho do módulo, cole seu prompt estruturado no campo de texto e clique em "Enviar Prompt" para extração e testes imediatos.'
          },
          {
            name: 'Módulo: AI Agents Orquestrados',
            where: 'Menu Lateral > "AI Agents Orquestrados"',
            meaning: 'Painel conversacional com Agentes Especialistas treinados em tarefas de conformidade comercial, risco de crédito ou LGPD.',
            howToSet: 'Selecione o agente nichado de sua preferência, forneça a meta ou problema estratégico e envie comandos diretos para receber análises prontas e formulários preenchidos.'
          }
        ],
        stepByStep: [
          'Passo 1: Navegue até o módulo "AI Gateway (Multi-Model)" para consultas gerais de dados e respostas imediatas em tempo de execução.',
          'Passo 2: Defina uma Persona no início do seu prompt para calibrar as respostas da IA (Ex: "Aja como Diretor de RevOps" ou "Aja como Auditor Jurídico").',
          'Passo 3: Mapeie o Contexto referenciando os conectores integrados (Ex: "Usando os dados analíticos do conector HubSpot...").',
          'Passo 4: Utilize Comandos de Formato para ditar a estética do relatório final (Ex: "Apresente os resultados em uma tabela Markdown e uma lista numerada de planos de mitigação de riscos comerciais").',
          'Passo 5: Para análises de conformidade profunda e impacto regulatório, acesse "Decision Intelligence" para ver a aderência legal e social da sua proposta.'
        ]
      }
    }
  ];

  const filteredSections = manualSections.filter(
    s =>
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.content.intro.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeSection = manualSections.find(s => s.id === selectedTopic) || manualSections[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in text-slate-100 font-sans">
      <div className="bg-[#030c1b] border border-cyan-500/30 rounded-3xl w-full max-w-6xl h-[90vh] flex flex-col shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-hidden">
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-cyan-500/20 bg-slate-950/90 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <PasquaredLogo size="md" showText={false} />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                  Manual de Operação & Guia de Parametrização do Sistema
                </h2>
                <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full">
                  PASQUARED-OS v2.4
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Instruções passo a passo de como parametrizar cada módulo, onde encontrar as configurações e como operá-los.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 border border-slate-800 transition"
            title="Fechar Manual"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-slate-800/80 bg-[#040e1e] flex items-center justify-between gap-4 shrink-0">
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              placeholder="Buscar por módulo, parâmetro (ex: SAP, Token, α, PII)..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950/90 border border-cyan-500/30 rounded-xl px-3.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
            />
          </div>
          <div className="text-xs font-mono text-cyan-400/80 hidden sm:block">
            {manualSections.length} Módulos Documentados
          </div>
        </div>

        {/* Content Body: Left Index + Right Detailed Guide */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          {/* Left Navigation Menu */}
          <div className="md:col-span-4 border-r border-slate-800/80 overflow-y-auto p-3 space-y-1.5 bg-slate-950/40 custom-scrollbar">
            <div className="text-[10px] font-mono uppercase text-slate-400 font-bold px-2 py-1">
              Índice dos Módulos & Parâmetros
            </div>
            {filteredSections.map(sec => {
              const IconComp = sec.icon;
              const isSelected = selectedTopic === sec.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => setSelectedTopic(sec.id)}
                  className={`w-full text-left p-3 rounded-2xl transition flex items-start gap-3 ${
                    isSelected
                      ? 'bg-cyan-950/60 border border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                      : 'hover:bg-slate-900/80 text-slate-300 border border-transparent'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                      isSelected
                        ? 'bg-cyan-500/30 text-cyan-300 border border-cyan-400/50'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    <IconComp className="w-4 h-4" />
                  </div>
                  <div className="space-y-0.5 flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-cyan-400">{sec.category}</span>
                    </div>
                    <div className="text-xs font-bold truncate">{sec.title}</div>
                    <p className="text-[11px] text-slate-400 line-clamp-2">{sec.summary}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Topic Details View */}
          <div className="md:col-span-8 overflow-y-auto p-5 sm:p-8 space-y-6 custom-scrollbar bg-slate-950/20">
            <div className="space-y-2 border-b border-cyan-500/20 pb-4">
              <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/30 px-3 py-1 rounded-full text-xs font-mono text-cyan-300 font-bold">
                {activeSection.category}
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {activeSection.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {activeSection.content.intro}
              </p>
            </div>

            {/* Onde Encontrar */}
            <div className="p-4 bg-slate-950 border border-cyan-500/30 rounded-2xl space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-300 uppercase tracking-wider font-mono">
                <Compass className="w-4 h-4 text-cyan-400" />
                <span>Onde Encontrar este Módulo no Sistema</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 font-mono bg-slate-900/90 p-3 rounded-xl border border-slate-800">
                {activeSection.content.whereToFind}
              </p>
            </div>

            {/* Tabela de Parâmetros Detalhados */}
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-400" />
                <span>Parâmetros Configuráveis & Onde Inserir</span>
              </h4>

              <div className="space-y-3">
                {activeSection.content.parameters.map((param, pIdx) => (
                  <div
                    key={pIdx}
                    className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2 hover:border-cyan-500/40 transition"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                      <span className="text-xs sm:text-sm font-bold text-cyan-300 font-mono">
                        {param.name}
                      </span>
                      <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                        Localização: {param.where}
                      </span>
                    </div>

                    <div className="text-xs text-slate-300 space-y-1">
                      <div>
                        <strong className="text-slate-400">O que significa: </strong>
                        {param.meaning}
                      </div>
                      <div>
                        <strong className="text-emerald-300">Como parametrizar: </strong>
                        <span className="text-slate-200">{param.howToSet}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Passo a Passo de Operação */}
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>Passo a Passo de Operação & Configuração</span>
              </h4>

              <div className="space-y-2">
                {activeSection.content.stepByStep.map((step, sIdx) => (
                  <div
                    key={sIdx}
                    className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-200"
                  >
                    <div className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 flex items-center justify-center shrink-0 font-mono font-bold text-xs mt-0.5">
                      {sIdx + 1}
                    </div>
                    <span className="leading-relaxed pt-0.5">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/90 flex flex-wrap items-center justify-between gap-4 shrink-0">
          <div className="text-xs text-slate-400 font-mono">
            Documentação Técnica do Kernel PASQUARED-OS • ISO 42001 & EU AI Act Ready
          </div>
          <button
            onClick={onClose}
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-5 py-2 rounded-xl shadow-lg shadow-cyan-600/30 transition"
          >
            Entendido & Fechar Manual
          </button>
        </div>
      </div>
    </div>
  );
};

function Compass(props: any) {
  return <Navigation {...props} />;
}

import { Navigation } from 'lucide-react';
