import React from 'react';
import { CreditCard, CheckCircle2, Zap, Server, Shield, Sparkles } from 'lucide-react';
import { Tenant } from '../types/pasquared';
import { PasquaredImage } from './PasquaredLogo';

interface BillingViewProps {
  tenant: Tenant;
}

export const BillingView: React.FC<BillingViewProps> = ({ tenant }) => {
  const plans = [
    {
      name: 'Starter',
      price: '$499 / mês',
      description: 'Para times iniciando governança e compliance de IA.',
      features: ['Até 5 Usuários', 'Até 5 Agentes de IA', '10.000 Inferências PASQUARED/mês', 'Trilha de Auditoria PRE 30 dias']
    },
    {
      name: 'Business',
      price: '$1.499 / mês',
      description: 'Para empresas médias com múltiplos modelos e agentes em produção.',
      features: ['Até 25 Usuários', 'Até 20 Agentes de IA', '100.000 Inferências PASQUARED/mês', 'Trilha PRE 1 ano', 'Suporte SLA 4h']
    },
    {
      name: 'Enterprise',
      price: '$4.999 / mês',
      description: 'Governança global e auditoria contínua para corporações.',
      isCurrent: true,
      features: ['Usuários Ilimitados', 'Agentes Ilimitados', '1M+ Inferências PASQUARED/mês', 'Trilha PRE Imutável Perpétua', 'SLA 99.99%', 'SSO / SAML / OIDC']
    },
    {
      name: 'Dedicated / On-Premise',
      price: 'Customizado',
      description: 'Instalação completa em infraestrutura privada (Debian 12 / Kubernetes).',
      features: ['Air-gapped / Sem saída externa', 'Código Kernel On-Prem', 'Clusters Dedicados', 'Customização de POKO & PQL']
    }
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              BILLING & QUOTAS
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Plano Atual: {tenant.tier.toUpperCase()}
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Planos de Assinatura, Cotas & Faturamento
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Monitore o consumo de tokens, limites de agentes e capacidade de auditoria PRE da sua organização.
          </p>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((p, idx) => (
          <div
            key={idx}
            className={`p-6 rounded-2xl border flex flex-col justify-between space-y-4 ${
              p.isCurrent
                ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30 shadow-xl'
                : 'bg-slate-900 border-slate-800'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  {/* Módulo de Acoplamento de Imagem (Plano) */}
                  <div className="relative w-8 h-8 rounded-lg flex items-center justify-center shrink-0 overflow-hidden border border-cyan-400/50 bg-[#020b18] shadow-[0_0_10px_rgba(0,240,255,0.25)]">
                    <PasquaredImage
                      alt="PASQUARED-OS Logotipo Plano"
                      className="w-full h-full object-contain p-1 relative z-10"
                    />
                  </div>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">{p.name}</span>
                </div>
                {p.isCurrent && (
                  <span className="text-[10px] font-mono bg-indigo-500 text-white px-2 py-0.5 rounded-full font-bold">
                    PLANO ATUAL
                  </span>
                )}
              </div>
              <div className="text-2xl font-bold text-white mb-2">{p.price}</div>
              <p className="text-xs text-slate-400 mb-4">{p.description}</p>

              <div className="space-y-2 pt-2 border-t border-slate-800 text-xs text-slate-300">
                {p.features.map((f, fIdx) => (
                  <div key={fIdx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{f}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              className={`w-full py-2.5 rounded-xl text-xs font-semibold transition ${
                p.isCurrent
                  ? 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              {p.isCurrent ? 'Gerenciar Plano' : 'Fazer Upgrade'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
