import React, { useState } from 'react';
import {
  Users,
  Building2,
  Shield,
  Key,
  CheckCircle2,
  Lock,
  Plus,
  Server,
  UserCheck
} from 'lucide-react';
import { Tenant, User } from '../types/pasquared';

interface TenantsRbacViewProps {
  tenants: Tenant[];
  currentTenant: Tenant;
  onSelectTenant: (tenant: Tenant) => void;
}

export const TenantsRbacView: React.FC<TenantsRbacViewProps> = ({
  tenants,
  currentTenant,
  onSelectTenant
}) => {
  const [users, setUsers] = useState<User[]>([
    {
      id: 'usr-1',
      tenantId: currentTenant.id,
      name: 'Roger S.',
      email: 'roger577@pasquared.space',
      role: 'SuperAdmin',
      department: 'Arquitetura & Governança de IA',
      mfaEnabled: true,
      status: 'active'
    },
    {
      id: 'usr-2',
      tenantId: currentTenant.id,
      name: 'Dra. Helena Martins',
      email: 'helena.martins@nexus-global.com',
      role: 'ComplianceOfficer',
      department: 'Jurídico & Compliance',
      mfaEnabled: true,
      status: 'active'
    },
    {
      id: 'usr-3',
      tenantId: currentTenant.id,
      name: 'Carlos Mendez',
      email: 'carlos.mendez@nexus-global.com',
      role: 'RiskManager',
      department: 'Gestão de Risco Operacional',
      mfaEnabled: true,
      status: 'active'
    },
    {
      id: 'usr-4',
      tenantId: currentTenant.id,
      name: 'Lucas Tanaka',
      email: 'lucas.tanaka@nexus-global.com',
      role: 'AIEngineer',
      department: 'Engenharia de MLOps',
      mfaEnabled: true,
      status: 'active'
    }
  ]);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              MULTI-TENANCY & RBAC
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Isolamento Criptográfico de Tenants & SSO
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Gestão de Organizações, Usuários & Permissões (RBAC)
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Controle de acesso baseado em funções (RBAC), autenticação MFA/OIDC, isolamento estrito de dados e alocação de cotas por tenant.
          </p>
        </div>
      </div>

      {/* Tenants Cards */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-white">Organizações / Tenants Cadastrados</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {tenants.map((t) => {
            const isSelected = t.id === currentTenant.id;
            return (
              <div
                key={t.id}
                onClick={() => onSelectTenant(t)}
                className={`p-5 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold">
                    {t.tier}
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono">Ativo</span>
                </div>
                <h4 className="text-sm font-bold text-white mb-1">{t.name}</h4>
                <div className="space-y-1 text-[11px] font-mono text-slate-400 mt-3 pt-2 border-t border-slate-800">
                  <div>Usuários: <strong className="text-white">{t.quotas.usedUsers}/{t.quotas.maxUsers}</strong></div>
                  <div>Agentes: <strong className="text-white">{t.quotas.usedAgents}/{t.quotas.maxAgents}</strong></div>
                  <div>Armazenamento: <strong className="text-white">{t.quotas.usedStorageGB} GB</strong></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Users & Roles List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-white">Usuários & Papeis RBAC do Tenant Atual</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="text-slate-400 uppercase bg-slate-950 border-b border-slate-800 font-mono text-[11px]">
              <tr>
                <th className="p-3">Nome / Usuário</th>
                <th className="p-3">E-mail</th>
                <th className="p-3">Função RBAC</th>
                <th className="p-3">Departamento</th>
                <th className="p-3">MFA</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-950/60 transition">
                  <td className="p-3 font-sans font-semibold text-white">{u.name}</td>
                  <td className="p-3 text-slate-300">{u.email}</td>
                  <td className="p-3">
                    <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded text-[10px] font-bold">
                      {u.role}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400 font-sans">{u.department}</td>
                  <td className="p-3 text-emerald-400">ATIVO</td>
                  <td className="p-3 text-emerald-400 font-bold">ONLINE</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
