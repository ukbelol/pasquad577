import React, { useState } from 'react';
import { X, Lock, Shield, ArrowRight, UserCheck, Key } from 'lucide-react';
import { User } from '../types/pasquared';
import { PasquaredLogo } from './PasquaredLogo';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin }) => {
  if (!isOpen) return null;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (email === 'roger577@pasquared.space' && password === '21121201@Roger') {
      const superAdminUser: User = {
        id: 'usr-superadmin',
        tenantId: 'tenant-enterprise-01',
        name: 'Roger S. (Super Admin)',
        email: 'roger577@pasquared.space',
        role: 'SuperAdmin',
        department: 'Arquitetura & Governança Global',
        mfaEnabled: true,
        status: 'active'
      };
      onLogin(superAdminUser);
      onClose();
    } else if (email && password) {
      const normalUser: User = {
        id: `usr-${Date.now().toString(36)}`,
        tenantId: 'tenant-enterprise-01',
        name: email.split('@')[0],
        email: email,
        role: 'ComplianceOfficer',
        department: 'Governança & Risco',
        mfaEnabled: true,
        status: 'active'
      };
      onLogin(normalUser);
      onClose();
    } else {
      setError('Por favor preencha todos os campos.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <PasquaredLogo size="md" showText={false} />
            <div>
              <h3 className="text-base font-bold text-white">Autenticação PASQUARED-OS</h3>
              <p className="text-xs text-slate-400">Acesso seguro ao Kernel de Governança</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">E-mail Corporativo:</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
              placeholder="seu.email@empresa.com"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Senha de Acesso:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
              placeholder="••••••••••••"
            />
          </div>

          {error && <div className="text-xs text-rose-400 font-mono">{error}</div>}

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition"
          >
            <span>Autenticar & Entrar</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
