import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Filter,
  Plus,
  ArrowRight,
  TrendingDown,
  Info
} from 'lucide-react';
import { RiskItem } from '../types/pasquared';

interface RiskManagementViewProps {
  risks: RiskItem[];
}

export const RiskManagementView: React.FC<RiskManagementViewProps> = ({ risks: initialRisks }) => {
  const [risks, setRisks] = useState<RiskItem[]>(initialRisks);
  const [selectedRisk, setSelectedRisk] = useState<RiskItem | null>(initialRisks[0] || null);

  // 5x5 Matrix coordinates: Probability (1-5) x Impact (1-5)
  const getRiskScoreColor = (prob: number, imp: number) => {
    const score = prob * imp;
    if (score >= 15) return 'bg-rose-600/80 text-white font-bold border-rose-500';
    if (score >= 8) return 'bg-amber-600/80 text-white font-bold border-amber-500';
    return 'bg-emerald-600/60 text-white font-bold border-emerald-500';
  };

  const getRisksInCell = (prob: number, imp: number) => {
    return risks.filter(r => r.probability === prob && r.impact === imp);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              ENTERPRISE RISK MANAGEMENT
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Matriz 5x5 • Probabilidade × Impacto
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Matriz de Riscos de Inteligência Artificial
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Mapeamento contínuo de riscos operacionais, regulatórios e de modelo (alucinações, vazamento de PII, viés demográfico) com planos de mitigação PASQUARED.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono bg-rose-500/20 text-rose-300 border border-rose-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <ShieldAlert className="w-4 h-4" />
            {risks.length} Riscos Mapeados
          </span>
        </div>
      </div>

      {/* Grid: 5x5 Interactive Matrix & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 5x5 Matrix (8 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Matriz de Probabilidade vs Impacto</h3>
            <span className="text-xs text-slate-400 font-mono">Escala 1 (Mínimo) a 5 (Crítico)</span>
          </div>

          <div className="overflow-x-auto">
            <div className="min-w-[480px]">
              {/* Y Axis Label: Probabilidade */}
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider text-center mb-2">
                ▲ Probabilidade de Ocorrência (1 a 5)
              </div>

              <div className="grid grid-rows-5 gap-2">
                {[5, 4, 3, 2, 1].map((prob) => (
                  <div key={prob} className="grid grid-cols-6 gap-2 items-center">
                    {/* Prob Label */}
                    <div className="text-xs font-mono text-slate-400 font-bold text-right pr-2">
                      P{prob}
                    </div>

                    {/* Impact Columns 1 to 5 */}
                    {[1, 2, 3, 4, 5].map((imp) => {
                      const cellRisks = getRisksInCell(prob, imp);
                      const isSelected = selectedRisk && selectedRisk.probability === prob && selectedRisk.impact === imp;

                      return (
                        <div
                          key={imp}
                          onClick={() => cellRisks.length > 0 && setSelectedRisk(cellRisks[0])}
                          className={`h-16 rounded-xl border p-1.5 flex flex-col justify-between transition cursor-pointer ${getRiskScoreColor(prob, imp)} ${
                            isSelected ? 'ring-2 ring-white scale-105 shadow-lg' : 'hover:opacity-90'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[10px]">
                            <span>{prob * imp}</span>
                            {cellRisks.length > 0 && (
                              <span className="bg-slate-900/80 px-1.5 py-0.2 rounded-full font-mono text-white text-[9px]">
                                {cellRisks.length} risco(s)
                              </span>
                            )}
                          </div>
                          <div className="text-[9px] font-sans truncate text-white/90">
                            {cellRisks[0]?.title || ''}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>

              {/* X Axis Label: Impacto */}
              <div className="grid grid-cols-6 gap-2 mt-2">
                <div></div>
                {[1, 2, 3, 4, 5].map((imp) => (
                  <div key={imp} className="text-xs font-mono text-slate-400 font-bold text-center">
                    Impacto {imp}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Selected Risk Details (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                Detalhes do Risco & Plano de Mitigação
              </span>
              {selectedRisk && (
                <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                  Score: {selectedRisk.score}/25
                </span>
              )}
            </div>

            {selectedRisk ? (
              <div className="mt-4 space-y-4">
                <div>
                  <span className="text-[10px] font-mono uppercase text-indigo-300 bg-indigo-500/20 px-2 py-0.5 rounded font-bold">
                    {selectedRisk.category}
                  </span>
                  <h4 className="text-base font-bold text-white mt-1.5">{selectedRisk.title}</h4>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div>Probabilidade: <strong className="text-amber-400">{selectedRisk.probability}/5</strong></div>
                  <div>Impacto: <strong className="text-rose-400">{selectedRisk.impact}/5</strong></div>
                  <div>Status: <strong className="text-emerald-400 uppercase">{selectedRisk.status}</strong></div>
                  <div>Última Avaliação: <strong className="text-slate-300">{selectedRisk.lastAssessed}</strong></div>
                </div>

                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                    Plano de Mitigação PASQUARED:
                  </span>
                  <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-xs text-slate-200 leading-relaxed font-mono">
                    {selectedRisk.mitigationPlan}
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-16 text-center text-xs text-slate-500">
                Selecione uma célula na matriz para inspecionar os riscos e salvaguardas.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
