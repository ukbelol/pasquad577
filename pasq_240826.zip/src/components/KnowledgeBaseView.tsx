import React, { useState } from 'react';
import {
  Database,
  FileText,
  Upload,
  Search,
  Sparkles,
  CheckCircle2,
  Layers,
  Network,
  Cpu,
  RefreshCw,
  FolderOpen
} from 'lucide-react';
import { EKO, ObserverProfile, UCIType } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';

interface KnowledgeBaseViewProps {
  ekos: EKO[];
  observer: ObserverProfile;
}

export const KnowledgeBaseView: React.FC<KnowledgeBaseViewProps> = ({ ekos: initialEkos, observer }) => {
  const [ekos, setEkos] = useState<EKO[]>(initialEkos);
  const [ingestInput, setIngestInput] = useState('');
  const [inputType, setInputType] = useState<UCIType>('text');
  const [isIngesting, setIsIngesting] = useState(false);
  const [lastUCL, setLastUCL] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleIngest = () => {
    if (!ingestInput.trim()) return;
    setIsIngesting(true);

    setTimeout(() => {
      const ucl = globalPasquaredEngine.parseToUCL(ingestInput, 'Base de Conhecimento Empresarial', observer);
      setLastUCL(ucl);

      const newEKO: EKO = {
        id: `eko-ingest-${Date.now().toString(36)}`,
        version: '1.0.0',
        title: `Ingestão UCL: ${ingestInput.substring(0, 45)}...`,
        domain: ucl.cdna.primaryDomain,
        ucis: ['uci-ingest-01', 'uci-ingest-02'],
        hypotheses: [],
        evidences: ['Documento Ingerido via UCL Universal Parser'],
        graph: { nodes: [], edges: [] },
        confidence: 0.94,
        maturity: 'consolidated',
        insights: [],
        selectedMeaning: ingestInput,
        iga: 0.88,
        ici: 0.91,
        timestamp: new Date().toISOString()
      };

      setEkos([newEKO, ...ekos]);
      setIsIngesting(false);
      setIngestInput('');
    }, 400);
  };

  const filteredEkos = ekos.filter(e => 
    e.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    e.domain.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              POKO ONTOLOGY & UCL PARSER
            </span>
            <span className="text-xs text-slate-400 font-mono">
              EKO Library & DNA Cognitivo (CDNA)
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Base de Conhecimento Epistemológica & Ingestão UCL
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Converta documentos heterogêneos (PDF, TXT, DB, JSON, Áudio, Visão) na Linguagem Universal Cognitiva (UCL) com 
            identificador CID e extração de DNA Cognitivo (CDNA).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <Database className="w-4 h-4" />
            {ekos.length} EKOs Consolidados
          </span>
        </div>
      </div>

      {/* UCL Ingestor Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Upload className="w-4 h-4 text-indigo-400" />
            Ingestor Universal UCL (PDF / TXT / Banco de Dados / Visão)
          </h3>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Modalidade:</span>
            <select
              value={inputType}
              onChange={(e) => setInputType(e.target.value as UCIType)}
              className="bg-slate-800 border border-slate-700 text-white text-xs rounded-lg px-2.5 py-1 focus:outline-none"
            >
              <option value="text">Texto / Documento (TXT/PDF)</option>
              <option value="database">Banco de Dados Relacional</option>
              <option value="concept">Conceito / Política</option>
              <option value="image">Visão Computacional (Imagem)</option>
              <option value="audio">Áudio / Transcrição</option>
            </select>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={ingestInput}
            onChange={(e) => setIngestInput(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
            placeholder="Insira o texto normativo, regulamento, diretriz ou documento para normalizar em UCL..."
          />
          <button
            onClick={handleIngest}
            disabled={isIngesting || !ingestInput.trim()}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold px-6 py-3 rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition shrink-0"
          >
            {isIngesting ? (
              <span className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Normalizando UCL...</span>
              </span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Ingerir & Gerar CDNA</span>
              </>
            )}
          </button>
        </div>

        {/* Last Ingested UCL Object Preview */}
        {lastUCL && (
          <div className="bg-slate-950 rounded-xl p-4 border border-indigo-900/60 space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between text-indigo-400 pb-1 border-b border-slate-800">
              <span className="font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Objeto UCL Gerado com Sucesso
              </span>
              <span className="text-[10px] text-slate-400">CID: {lastUCL.objectID}</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-slate-300">
              <div>Domínio Primário: <strong className="text-white">{lastUCL.cdna.primaryDomain}</strong></div>
              <div>Confiabilidade: <strong className="text-emerald-400">{(lastUCL.cdna.initialReliability * 100).toFixed(0)}%</strong></div>
              <div>Granularidade: <strong className="text-cyan-400">{lastUCL.cdna.granularity}</strong></div>
              <div>Sensibilidade: <strong className="text-amber-400">{lastUCL.cdna.sensitivity}</strong></div>
            </div>
          </div>
        )}
      </div>

      {/* EKOs Library */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white">Catálogo Global de EKOs (Epistemic Knowledge Objects)</h3>
            <p className="text-xs text-slate-400">Conhecimento estruturado, versionado e persistido na memória SMEE.</p>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por título ou domínio..."
                className="bg-slate-800 border border-slate-700 text-xs text-white pl-9 pr-4 py-2 rounded-xl focus:outline-none focus:border-indigo-500 w-64"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredEkos.map((eko) => (
            <div key={eko.id} className="bg-slate-950 border border-slate-800 p-5 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-bold">
                  {eko.domain}
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                  {eko.maturity} • v{eko.version}
                </span>
              </div>
              <h4 className="text-sm font-bold text-white">{eko.title}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{eko.selectedMeaning}</p>
              <div className="flex justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800">
                <span>IGA: <strong className="text-cyan-400">{eko.iga}</strong></span>
                <span>ICI: <strong className="text-emerald-400">{eko.ici}</strong></span>
                <span>ID: <strong className="text-slate-400">{eko.id}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
