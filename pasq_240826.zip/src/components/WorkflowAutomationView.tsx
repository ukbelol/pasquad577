import React, { useState } from 'react';
import {
  Workflow,
  Play,
  CheckCircle2,
  Clock,
  ArrowRight,
  Plus,
  AlertTriangle,
  Zap,
  Activity
} from 'lucide-react';
import { AutomationWorkflow } from '../types/pasquared';

interface WorkflowAutomationViewProps {
  workflows: AutomationWorkflow[];
}

export const WorkflowAutomationView: React.FC<WorkflowAutomationViewProps> = ({ workflows: initialWorkflows }) => {
  const [workflows, setWorkflows] = useState<AutomationWorkflow[]>(initialWorkflows);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              WORKFLOW AUTOMATION
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Pipelines Cognitivos Orientados a Eventos
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Automação de Fluxos & Interceptores de Decisão
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Crie pipelines automatizados disparados por eventos (Violação de Política, Excesso de Risco, Ingestão de Dados) com 
            execução de SAC e ações de mitigação orquestradas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <Zap className="w-4 h-4" />
            {workflows.length} Workflows Ativos
          </span>
        </div>
      </div>

      {/* Workflows List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {workflows.map((wf) => (
          <div key={wf.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-0.5 rounded font-bold">
                Trigger: {wf.triggerEvent}
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-bold">
                {wf.status.toUpperCase()}
              </span>
            </div>

            <h4 className="text-base font-bold text-white">{wf.name}</h4>

            {/* Steps Timeline */}
            <div className="space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs">
              <span className="text-slate-400 font-bold block mb-2">Etapas do Pipeline:</span>
              {wf.steps.map((step, sIdx) => (
                <div key={sIdx} className="flex items-center gap-2 text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                  <span>{step}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800 font-mono">
              <span>Execuções: <strong className="text-white">{wf.executionsCount}</strong></span>
              <span>Última Execução: <strong className="text-slate-300">{wf.lastRun}</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
