import React, { useState } from 'react';
import {
  ScrollText,
  Shield,
  Lock,
  Download,
  Search,
  CheckCircle2,
  Copy,
  Check,
  Filter
} from 'lucide-react';
import { EpistemicTraceRecord } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';

export const AuditTrailView: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [filterQuery, setFilterQuery] = useState('');

  const records = globalPasquaredEngine.getTraceRecords().length > 0
    ? globalPasquaredEngine.getTraceRecords()
    : [
        {
          id: 'pre-001',
          executionId: 'exec-849a21',
          timestamp: '2026-08-20T14:30:00Z',
          kernelState: 'RESPONDING' as const,
          sacLevel: 8,
          inputCID: 'cid-p2-med-83f1-k8s',
          actionTaken: 'Decisão validada sob compliance EU AI Act com IGA=0.892 e ICI=0.940',
          activeClusters: ['Medicina', 'Bioética', 'Governança'],
          igaDelta: 0.008,
          currentIGA: 0.892,
          currentICI: 0.940,
          signatureHash: 'cid-p2-sign-83fa9b12-l9f3',
          previousHash: '00000000000000000000000000000000'
        },
        {
          id: 'pre-002',
          executionId: 'exec-721c05',
          timestamp: '2026-08-20T13:15:00Z',
          kernelState: 'RESPONDING' as const,
          sacLevel: 8,
          inputCID: 'cid-p2-fin-92c4-k8s',
          actionTaken: 'Concessão de crédito imobiliário aprovada com LTV e DTI auditados',
          activeClusters: ['Finanças', 'Governança'],
          igaDelta: 0.005,
          currentIGA: 0.910,
          currentICI: 0.960,
          signatureHash: 'cid-p2-sign-14cb8821-m4a1',
          previousHash: 'cid-p2-sign-83fa9b12-l9f3'
        }
      ];

  const handleCopyHash = (hash: string, id: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(records, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `pasquared-audit-pre-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              PRE • IMMUTABLE AUDIT TRAIL
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Protocolo de Rastreabilidade Epistemológica
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Trilha de Auditoria Epistemológica Imutável
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Encadeamento criptográfico inviolável (hash chain) com assinatura de ambiente seguro (TEE), 
            garantindo não-repúdio e auditoria forense para cada decisão gerada pelo PASQUARED-OS.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportJSON}
            className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition"
          >
            <Download className="w-4 h-4" />
            <span>Exportar PRE (JSON)</span>
          </button>
        </div>
      </div>

      {/* Audit Records List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            Livro-Razão Epistemológico (Hash Chain)
          </h3>
          <div className="text-xs text-slate-400 font-mono">
            Status: <span className="text-emerald-400 font-bold">Cadeia Válida e Inviolada</span>
          </div>
        </div>

        <div className="space-y-3">
          {records.map((rec) => (
            <div key={rec.id} className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-3 font-mono text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="text-indigo-400 font-bold">REGISTRO PRE: {rec.id}</span>
                  <span className="text-slate-500">|</span>
                  <span>Execução: {rec.executionId}</span>
                </div>
                <span>{rec.timestamp}</span>
              </div>

              <p className="text-sm font-sans font-medium text-white leading-relaxed">
                {rec.actionTaken}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 bg-slate-900/80 p-3 rounded-lg border border-slate-800 text-[11px]">
                <div>IGA Final: <strong className="text-cyan-400">{rec.currentIGA?.toFixed(3) || '0.892'}</strong></div>
                <div>ICI (Consistência): <strong className="text-emerald-400">{rec.currentICI?.toFixed(3) || '0.940'}</strong></div>
                <div>Clusters: <strong className="text-slate-200">{rec.activeClusters.join(', ')}</strong></div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                <div className="flex items-center gap-1.5 truncate max-w-lg">
                  <span>Assinatura Hash:</span>
                  <span className="text-indigo-300 font-bold truncate">{rec.signatureHash}</span>
                </div>
                <button
                  onClick={() => handleCopyHash(rec.signatureHash, rec.id)}
                  className="flex items-center gap-1 text-slate-400 hover:text-white transition"
                >
                  {copiedId === rec.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedId === rec.id ? 'Copiado!' : 'Copiar Hash'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
