import React, { useState } from 'react';
import {
  Bot,
  Brain,
  HelpCircle,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Shield,
  Sliders,
  Send,
  RefreshCw,
  Cpu
} from 'lucide-react';
import { AIAgent, ObserverProfile } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';

interface AIAgentsViewProps {
  agents: AIAgent[];
  observer: ObserverProfile;
}

export const AIAgentsView: React.FC<AIAgentsViewProps> = ({ agents, observer }) => {
  const [selectedAgentId, setSelectedAgentId] = useState(agents[0]?.id || '');
  const [agentGoal, setAgentGoal] = useState('Análise de Risco de Crédito para expansão de fábrica industrial.');
  
  // Agent Workflow Steps
  const [workflowStage, setWorkflowStage] = useState<'idle' | 'asking_questions' | 'pasquared_deciding' | 'synthesizing_results'>('idle');
  const [generatedQuestions, setGeneratedQuestions] = useState<string[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [pasquaredDecision, setPasquaredDecision] = useState<any>(null);
  const [finalSynthesizedResult, setFinalSynthesizedResult] = useState<string>('');

  const activeAgent = agents.find(a => a.id === selectedAgentId) || agents[0];

  // 1. Agent Generates Contextual Questions
  const handleStartAgentFlow = () => {
    setWorkflowStage('asking_questions');
    setPasquaredDecision(null);
    setFinalSynthesizedResult('');

    if (activeAgent.id.includes('credit')) {
      const q = [
        'Qual o valor solicitado e qual o prazo pretendido de amortização?',
        'Quais são os índices atuais de LTV (Garantia) e DTI (Comprometimento de Renda)?',
        'Existem apontamentos cadastrais nos órgãos de proteção ao crédito nos últimos 24 meses?'
      ];
      setGeneratedQuestions(q);
      setUserAnswers({
        0: 'R$ 2.500.000 em 60 meses',
        1: 'LTV estimado em 48% com imóvel fabril; DTI em 22% da receita operacional líquida',
        2: 'Zero apontamentos cadastrais; certidões negativas fiscais e trabalhistas 100% válidas'
      });
    } else if (activeAgent.id.includes('clinical')) {
      const q = [
        'Qual o diagnóstico primário e idade do paciente?',
        'Há histórico de alergias medicamentosas ou insuficiência renal/hepática?',
        'Quais medicamentos de uso contínuo estão em administração concomitante?'
      ];
      setGeneratedQuestions(q);
      setUserAnswers({
        0: 'Paciente de 68 anos com insuficiência cardíaca classe III',
        1: 'Sem alergias conhecidas; clearance de creatinina estável em 65 mL/min',
        2: 'Varfarina 5mg/dia e Enalapril 10mg/dia'
      });
    } else {
      const q = [
        'Qual a finalidade do sistema de IA e quem são os usuários afetados?',
        'Os dados de treino contêm categorias sensíveis ou protegidas por lei?',
        'Existe salvaguarda de intervenção humana (Human-in-the-Loop) implementada?'
      ];
      setGeneratedQuestions(q);
      setUserAnswers({
        0: 'Triagem automatizada de currículos para cargos de engenharia',
        1: 'Todos os atributos de gênero, etnia e idade são anonimizados antes do modelo',
        2: 'Sim, a decisão de descarte exige confirmação por recrutador sênior'
      });
    }
  };

  // 2. Submit to PASQUARED Controller & Synthesize Outcome
  const handleSendToPasquared = async () => {
    setWorkflowStage('pasquared_deciding');

    const aggregatedPayload = `Objetivo do Agente: ${agentGoal}\n\nRespostas Coletadas:\n${generatedQuestions.map((q, i) => `P: ${q}\nR: ${userAnswers[i] || 'Não informada'}`).join('\n')}`;

    try {
      const result = await globalPasquaredEngine.executeSAC(aggregatedPayload, observer);
      setPasquaredDecision(result);

      setWorkflowStage('synthesizing_results');
      setTimeout(() => {
        setFinalSynthesizedResult(
          `[Síntese do Agente ${activeAgent.name}]: Com base na decisão deliberada pelo PASQUARED Controller (IGA: ${result.decision.iga.toFixed(3)}, ICI: ${result.decision.ici.toFixed(3)}), a operação está autorizada sob os seguintes parâmetros:\n\n1. Parecer Fático: ${result.decision.selectedMeaning}\n2. Salvaguardas Ativas: Monitoramento contínuo via cluster [${result.decision.activeClusters.join(', ')}]\n3. Registro Epistemológico: EKO ${result.eko.id} gravado no PRE imutável.`
        );
      }, 500);
    } catch (e) {
      console.error(e);
      setWorkflowStage('idle');
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-mono font-bold px-2 py-0.5 rounded">
              AI AGENTS ORCHESTRATION
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Agente formula perguntas ➔ PASQUARED decide ➔ Agente sintetiza
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Agentes de IA Orquestrados pelo PASQUARED Controller
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl mt-1">
            Arquitetura em que o agente de IA é responsável por interagir, coletar evidências e gerar perguntas contextuais, 
            enquanto o algoritmo PASQUARED atua como controlador central e árbitro epistêmico da decisão.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <Cpu className="w-4 h-4" />
            PASQUARED Controller no Comando
          </span>
        </div>
      </div>

      {/* Agents Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {agents.map((agent) => {
          const isSelected = agent.id === selectedAgentId;
          return (
            <div
              key={agent.id}
              onClick={() => {
                setSelectedAgentId(agent.id);
                setWorkflowStage('idle');
                setPasquaredDecision(null);
                setFinalSynthesizedResult('');
              }}
              className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30 shadow-lg'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                  {agent.status}
                </span>
              </div>
              <h4 className="text-sm font-bold text-white mb-1">{agent.name}</h4>
              <p className="text-xs text-slate-400 mb-3">{agent.role}</p>
              <p className="text-xs text-slate-300 line-clamp-2 mb-3">{agent.description}</p>
              <div className="flex justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800">
                <span>Chamadas: <strong className="text-white">{agent.totalCalls}</strong></span>
                <span>Confiança: <strong className="text-emerald-400">{(agent.avgConfidence * 100).toFixed(0)}%</strong></span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Agent & PASQUARED Decision Loop */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white">
              Ciclo Interativo: Agente ➔ PASQUARED ➔ Resultado
            </h3>
          </div>
          <span className="text-xs font-mono text-indigo-400 bg-slate-800 px-3 py-1 rounded">
            Agente Ativo: {activeAgent.name}
          </span>
        </div>

        {/* Step 1: User sets initial goal */}
        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
            1. Defina o Objetivo ou Caso para o Agente:
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={agentGoal}
              onChange={(e) => setAgentGoal(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 transition"
              placeholder="Descreva o caso a ser analisado..."
            />
            <button
              onClick={handleStartAgentFlow}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition shrink-0"
            >
              <Bot className="w-4 h-4" />
              <span>Gerar Perguntas Contextuais</span>
            </button>
          </div>
        </div>

        {/* Step 2: Agent's Formulated Questions & Answers */}
        {workflowStage !== 'idle' && (
          <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-2">
                <HelpCircle className="w-4 h-4" />
                2. Perguntas Contextuais Formuladas pelo Agente:
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                Evidências para o PASQUARED Controller
              </span>
            </div>

            <div className="space-y-3">
              {generatedQuestions.map((question, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="text-xs text-slate-300 font-medium flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-800 text-indigo-400 text-[10px] font-bold flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <span>{question}</span>
                  </div>
                  <input
                    type="text"
                    value={userAnswers[idx] || ''}
                    onChange={(e) => setUserAnswers({ ...userAnswers, [idx]: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                    placeholder="Resposta / Evidência..."
                  />
                </div>
              ))}
            </div>

            <div className="pt-3 flex justify-end">
              <button
                onClick={handleSendToPasquared}
                disabled={workflowStage === 'pasquared_deciding'}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold px-6 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition"
              >
                {workflowStage === 'pasquared_deciding' ? (
                  <span className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>PASQUARED Processando Decisão...</span>
                  </span>
                ) : (
                  <>
                    <Brain className="w-4 h-4" />
                    <span>Submeter ao PASQUARED Controller</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Step 3: PASQUARED Deliberation & Agent's Final Synthesis */}
        {pasquaredDecision && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* PASQUARED Decision Deliberation */}
            <div className="bg-slate-950 rounded-xl p-5 border border-indigo-900/60 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Brain className="w-4 h-4" />
                  Decisão do PASQUARED Controller
                </span>
                <span className="text-xs font-mono text-cyan-400">
                  IGA: {pasquaredDecision.decision.iga.toFixed(3)}
                </span>
              </div>
              <p className="text-xs text-white font-medium bg-slate-900 p-3 rounded-lg border border-slate-800">
                "{pasquaredDecision.decision.selectedMeaning}"
              </p>
              <div className="text-[11px] font-mono text-slate-400 space-y-1">
                <div>Clusters: <strong className="text-slate-200">{pasquaredDecision.decision.activeClusters.join(', ')}</strong></div>
                <div>Hipóteses Rejeitadas: <strong className="text-rose-400">{pasquaredDecision.decision.rejectedHypotheses.length} eliminadas</strong></div>
                <div>Status da Política: <strong className="text-emerald-400">{pasquaredDecision.decision.policyStatus}</strong></div>
              </div>
            </div>

            {/* Agent's Final Synthesized Result */}
            <div className="bg-slate-950 rounded-xl p-5 border border-emerald-900/60 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Bot className="w-4 h-4" />
                  Resultado Sintetizado pelo Agente
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded">
                  Auditável PRE
                </span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed">
                {finalSynthesizedResult || 'Sintetizando ações a partir da decisão deliberada...'}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
