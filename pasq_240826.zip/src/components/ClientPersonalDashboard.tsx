import React, { useState } from 'react';
import {
  Building2,
  Shield,
  Activity,
  Zap,
  Boxes,
  Database,
  Cpu,
  Lock,
  Globe,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Download,
  Terminal,
  ArrowRight,
  TrendingUp,
  CreditCard,
  UserCheck,
  RefreshCw,
  Plus,
  Play,
  Key,
  SlidersHorizontal,
  BookOpen,
  Check
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import { Tenant, User, ObserverProfile, DecisionRecord } from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';
import { PasquaredLogo } from './PasquaredLogo';
import { OperationsManualModal } from './OperationsManualModal';

interface ClientPersonalDashboardProps {
  tenant: Tenant;
  currentUser: User | null;
  observer: ObserverProfile;
  teamMembers: User[];
  onAddTeamMember: (member: User) => void;
  onUpdateTeamMember: (member: User) => void;
  onUpgradePlan: (newPlanTier: string) => void;
  onUpdateTenant?: (tenant: Tenant) => void;
  onNavigateToKernel: () => void;
  onNavigateToEnterpriseFeeder: () => void;
  onNavigateToPQL: () => void;
  onNavigateToAudit: () => void;
  onOpenUpgradeModal: () => void;
  onOpenManual?: () => void;
}

interface UpgradeWallProps {
  requiredPlan: 'Professional' | 'Enterprise';
  featureName: string;
  onUpgrade: () => void;
}

const UpgradeWall: React.FC<UpgradeWallProps> = ({ requiredPlan, featureName, onUpgrade }) => {
  return (
    <div className="quantum-card-glow rounded-2xl p-8 text-center space-y-6 max-w-2xl mx-auto my-12 border border-rose-500/30 bg-slate-950/80 animate-in fade-in zoom-in-95">
      <div className="w-16 h-16 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30 flex items-center justify-center mx-auto shadow-[0_0_15px_rgba(239,68,68,0.2)]">
        <Lock className="w-8 h-8" />
      </div>
      
      <div className="space-y-2">
        <h3 className="text-lg font-black text-white">Recurso Premium Restrito</h3>
        <p className="text-xs text-slate-300 max-w-md mx-auto">
          O módulo <strong className="text-cyan-300">"{featureName}"</strong> não está incluso no plano contratado da sua empresa.
        </p>
        <div className="text-xs font-semibold text-rose-300 font-mono py-1.5 px-4 bg-rose-500/10 border border-rose-500/20 rounded-full inline-block mt-2">
          Faça upgrade para o plano "{requiredPlan}" para acessar esta funcionalidade
        </div>
      </div>

      <div className="border-t border-slate-900 pt-6 space-y-3">
        <button
          onClick={onUpgrade}
          className="bg-gradient-to-r from-cyan-500 via-blue-600 to-emerald-500 hover:opacity-95 text-white font-bold text-xs px-6 py-3.5 rounded-xl shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-2 transition mx-auto w-full max-w-sm"
        >
          <Zap className="w-4 h-4 animate-pulse" />
          <span>Fazer Upgrade para o Plano {requiredPlan} Agora</span>
        </button>
        <p className="text-[10px] text-slate-500">
          * A alteração do plano é processada instantaneamente e as cotas de dados serão liberadas em tempo real.
        </p>
      </div>
    </div>
  );
};

interface SpecialtyAIAgent {
  id: string;
  name: string;
  provider: string;
  accuracy: string;
  focus: string;
  description: string;
}

interface SpecialtyArea {
  id: string;
  name: string;
  description: string;
  functions: {
    id: string;
    name: string;
    description: string;
    defaultAgentId: string;
    agents: SpecialtyAIAgent[];
  }[];
}

const SPECIALTY_AREAS: SpecialtyArea[] = [
  {
    id: 'logistica',
    name: 'Logística & Cadeia de Suprimentos',
    description: 'Gestão de frotas, otimização de rotas inteligentes e previsões de estoque físico.',
    functions: [
      {
        id: 'func-log-route',
        name: 'Otimização de Rotas de Distribuição',
        description: 'Planejamento dinâmico de frotas e traçado de rotas com janelas horárias complexas.',
        defaultAgentId: 'agent-log-route-1',
        agents: [
          {
            id: 'agent-log-route-1',
            name: 'PASQUARED RouteMaster Agent v3',
            provider: 'Kernel POKO Local',
            accuracy: '99.4%',
            focus: 'Algoritmo de Colônia de Formigas & Grafos',
            description: 'Especialista em trânsito urbano e otimização geométrica de pontos de entrega.'
          },
          {
            id: 'agent-log-route-2',
            name: 'DeepRoute Llama-3 Specialized',
            provider: 'Meta Llama-3 (AI Gateway)',
            accuracy: '98.1%',
            focus: 'Otimização Heurística de Redes',
            description: 'Equilibrado para despachos estaduais e transporte de carga pesada.'
          }
        ]
      },
      {
        id: 'func-log-stock',
        name: 'Previsão de Demanda & Estoque',
        description: 'Cálculo inteligente de ponto de pedido, estoque de segurança e sazonalidade de suprimentos.',
        defaultAgentId: 'agent-log-stock-1',
        agents: [
          {
            id: 'agent-log-stock-1',
            name: 'Cognitive StockForecaster v2',
            provider: 'Kernel POKO Local',
            accuracy: '99.1%',
            focus: 'Modelagem Bayesiana de Séries Temporais',
            description: 'Previsão preditiva para múltiplos centros de distribuição.'
          },
          {
            id: 'agent-log-stock-2',
            name: 'PASQUARED SupplyChain Predictor',
            provider: 'Gemini 2.5 Flash',
            accuracy: '99.7%',
            focus: 'Visão Unificada de Grafos EKO',
            description: 'Cruza notícias do mercado e clima para prever faltas críticas de insumos.'
          }
        ]
      },
      {
        id: 'func-log-fleet',
        name: 'Gestão e Despacho de Frotas',
        description: 'Alocação automatizada de motoristas e acompanhamento em tempo real.',
        defaultAgentId: 'agent-log-fleet-1',
        agents: [
          {
            id: 'agent-log-fleet-1',
            name: 'FleetDispatch Automaton',
            provider: 'Kernel POKO Local',
            accuracy: '98.9%',
            focus: 'Despacho Event-Driven em Tempo Real',
            description: 'Garante o menor tempo ocioso dos motoristas e agendamentos instantâneos.'
          }
        ]
      }
    ]
  },
  {
    id: 'rh',
    name: 'Recursos Humanos (RH) & DHO',
    description: 'Triagem de candidatos, avaliações estruturadas de competências e assistentes de onboarding.',
    functions: [
      {
        id: 'func-rh-screening',
        name: 'Triagem Ontológica de Currículos',
        description: 'Varredura e classificação semântica de currículos com base em matrizes de habilidades.',
        defaultAgentId: 'agent-rh-screening-1',
        agents: [
          {
            id: 'agent-rh-screening-1',
            name: 'SMEE Profile Matcher Pro',
            provider: 'Kernel POKO Local',
            accuracy: '99.2%',
            focus: 'Mapeamento de Habilidades POKO',
            description: 'Identifica a aderência real do candidato à cultura e ao perfil técnico da empresa.'
          },
          {
            id: 'agent-rh-screening-2',
            name: 'PASQUARED CV Parser & Ranker',
            provider: 'Gemini 2.5 Flash',
            accuracy: '98.7%',
            focus: 'Processamento de Linguagem Natural (NLP)',
            description: 'Parser veloz para grandes volumes de candidaturas em formatos diversos.'
          }
        ]
      },
      {
        id: 'func-rh-perf',
        name: 'Avaliação Contínua de Desempenho',
        description: 'Consolidação de avaliações 360º, feedbacks não estruturados e metas corporativas.',
        defaultAgentId: 'agent-rh-perf-1',
        agents: [
          {
            id: 'agent-rh-perf-1',
            name: 'Cognitive Feedback Synthesizer',
            provider: 'Kernel POKO Local',
            accuracy: '99.0%',
            focus: 'Análise de Sentimento & Métricas Objetivas',
            description: 'Sintetiza dezenas de feedbacks em planos de desenvolvimento individual (PDI) acionáveis.'
          }
        ]
      },
      {
        id: 'func-rh-onboard',
        name: 'Assistente de Onboarding Corporativo',
        description: 'Guia interativo para recém-admitidos sobre normas de governança, cultura e ferramentas.',
        defaultAgentId: 'agent-rh-onboard-1',
        agents: [
          {
            id: 'agent-rh-onboard-1',
            name: 'OnboardBuddy AI Assistant',
            provider: 'Llama-3 (AI Gateway)',
            accuracy: '98.5%',
            focus: 'Conversação Contextual de Políticas',
            description: 'Reduz o tempo de adaptação de novos colaboradores esclarecendo dúvidas de processos internos.'
          }
        ]
      }
    ]
  },
  {
    id: 'financas',
    name: 'Finanças, Crédito & Riscos',
    description: 'Análise de solvência, auditoria de transações financeiras e controle de risco de liquidez.',
    functions: [
      {
        id: 'func-fin-risk',
        name: 'Análise de Risco de Crédito',
        description: 'Pareceres automáticos baseados em balanços patrimoniais, faturamento e dados de birôs.',
        defaultAgentId: 'agent-fin-risk-1',
        agents: [
          {
            id: 'agent-fin-risk-1',
            name: 'CreditRisk Analyst Pro',
            provider: 'Kernel POKO Local',
            accuracy: '99.8%',
            focus: 'Lógica Financeira Profunda & Solvência',
            description: 'Analisa faturas, demonstrações contábeis e calcula o score de crédito corporativo.'
          },
          {
            id: 'agent-fin-risk-2',
            name: 'PASQUARED RiskMatrix Oracle',
            provider: 'Gemini 2.5 Flash',
            accuracy: '99.9%',
            focus: 'Avaliação de Risco Cognitivo Multivariado',
            description: 'Cruza volatilidades do mercado financeiro externo com balanços internos do tenant.'
          }
        ]
      },
      {
        id: 'func-fin-fraud',
        name: 'Auditoria e Prevenção de Fraudes',
        description: 'Monitoramento contínuo de lançamentos em contas e faturas buscando desvios e anomalias.',
        defaultAgentId: 'agent-fin-fraud-1',
        agents: [
          {
            id: 'agent-fin-fraud-1',
            name: 'FraudSentry AI Guard',
            provider: 'Kernel POKO Local',
            accuracy: '99.95%',
            focus: 'Diferenciação de Padrões e Auditoria PRE',
            description: 'Dispara alertas instantâneos de conformidade antes da gravação de transações suspeitas no livro de pré-auditoria.'
          }
        ]
      }
    ]
  },
  {
    id: 'juridico',
    name: 'Jurídico, Compliance & Regulatório',
    description: 'Análise de minutas contratuais, conformidade com a LGPD e mapeamento de riscos regulatórios.',
    functions: [
      {
        id: 'func-law-contract',
        name: 'Análise Contratual & Cláusulas',
        description: 'Identificação de cláusulas abusivas, riscos de responsabilidade e vigência.',
        defaultAgentId: 'agent-law-contract-1',
        agents: [
          {
            id: 'agent-law-contract-1',
            name: 'LexSentry Contract Auditor',
            provider: 'Kernel POKO Local',
            accuracy: '99.6%',
            focus: 'Auditoria Semântico-Legal Avançada',
            description: 'Verifica se o contrato atende aos requisitos internos de governança e SLAs cadastrados.'
          }
        ]
      },
      {
        id: 'func-law-lgpd',
        name: 'Auditoria de LGPD & Proteção de PII',
        description: 'Rastreia e bloqueia o fluxo de dados pessoais de clientes nas interações e logs de sistema.',
        defaultAgentId: 'agent-law-lgpd-1',
        agents: [
          {
            id: 'agent-law-lgpd-1',
            name: 'PII Guard & ANPD Compliance Agent',
            provider: 'Kernel POKO Local',
            accuracy: '99.98%',
            focus: 'Detecção de Dados Pessoais Identificáveis (PII)',
            description: 'Ofusca dados confidenciais e valida se as interações de IA atendem à legislação de privacidade.'
          }
        ]
      }
    ]
  }
];

export const ClientPersonalDashboard: React.FC<ClientPersonalDashboardProps> = ({
  tenant,
  currentUser,
  observer,
  teamMembers,
  onAddTeamMember,
  onUpdateTeamMember,
  onUpgradePlan,
  onUpdateTenant,
  onNavigateToKernel,
  onNavigateToEnterpriseFeeder,
  onNavigateToPQL,
  onNavigateToAudit,
  onOpenUpgradeModal,
  onOpenManual
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'connectors' | 'deliberation' | 'team' | 'ai_specialists'>('overview');

  const [selectedSpecialtyAreaId, setSelectedSpecialtyAreaId] = useState<string>('logistica');
  const [activeAIs, setActiveAIs] = useState<Record<string, string>>(() => {
    return (tenant as any).activeAIsByArea || {
      'func-log-route': 'agent-log-route-1',
      'func-log-stock': 'agent-log-stock-1',
      'func-log-fleet': 'agent-log-fleet-1',
      'func-rh-screening': 'agent-rh-screening-1',
      'func-rh-perf': 'agent-rh-perf-1',
      'func-rh-onboard': 'agent-rh-onboard-1',
      'func-fin-risk': 'agent-fin-risk-1',
      'func-fin-fraud': 'agent-fin-fraud-1',
      'func-law-contract': 'agent-law-contract-1',
      'func-law-lgpd': 'agent-law-lgpd-1',
    };
  });

  const handleSelectAgentForFunction = (functionId: string, agentId: string) => {
    const updated = {
      ...activeAIs,
      [functionId]: agentId
    };
    setActiveAIs(updated);
    if (onUpdateTenant) {
      onUpdateTenant({
        ...tenant,
        activeAIsByArea: updated
      } as any);
    }
    setSuccessMessage(`IA Especialista configurada com sucesso para a respectiva função organizacional.`);
  };

  // Sub-aba do menu administrativo
  const [adminSubTab, setAdminSubTab] = useState<'employees' | 'plan_tier'>('employees');

  // Controle de edicao de colaboradores
  const [editingEmployeeId, setEditingEmployeeId] = useState<string | null>(null);

  // Prompt para upgrade de plano
  const [planUpgradePrompt, setPlanUpgradePrompt] = useState<{
    isOpen: boolean;
    requiredPlan: 'Professional' | 'Enterprise';
    featureName: string;
  }>({
    isOpen: false,
    requiredPlan: 'Professional',
    featureName: ''
  });

  // Local Manual Modal State
  const [isLocalManualOpen, setIsLocalManualOpen] = useState(false);

  // Simulated User / Active Employee ID for testing RBAC permissions
  const [simulatedUserId, setSimulatedUserId] = useState<string>(currentUser?.id || 'admin');

  // Connectors interactive CRUD form states
  const [isCreatingConnector, setIsCreatingConnector] = useState(false);
  const [editingConnectorId, setEditingConnectorId] = useState<string | null>(null);
  const [connName, setConnName] = useState('');
  const [connType, setConnType] = useState('REST');
  const [connUrl, setConnUrl] = useState('');
  const [connAuth, setConnAuth] = useState('Bearer Token');
  const [connSync, setConnSync] = useState('Tempo Real');
  const [connLatency, setConnLatency] = useState('20ms');

  // Quick Simulation state for client's custom data
  const [testInput, setTestInput] = useState(
    'Aprovar liberação de crédito/investimento de R$ 450.000 para expansão hospitalar baseada no score de solvência de 92 e conformidade LGPD.'
  );
  const [isSimulating, setIsSimulating] = useState(false);
  const [lastDecision, setLastDecision] = useState<DecisionRecord | null>(null);

  // Password generation rule:
  // - First 3 letters of company name (Trading name) in UPPERCASE
  // - "@"
  // - First 3 letters of employee name in lowercase
  // - DOB in format MM/DD/AA (MM/DD/YY)
  const generateInitialPassword = (companyName: string, employeeName: string, dobString: string) => {
    const cleanCompany = companyName.replace(/[^a-zA-Z0-9]/g, '');
    const compPrefix = cleanCompany.substring(0, 3).toUpperCase().padEnd(3, 'P');
    const cleanEmployee = employeeName.replace(/[^a-zA-Z0-9]/g, '');
    const empPrefix = cleanEmployee.substring(0, 3).toLowerCase().padEnd(3, 'x');
    
    let dobFormatted = '01/01/00';
    if (dobString) {
      const parts = dobString.split('-');
      if (parts.length === 3) {
        const year = parts[0].substring(2); // last 2 digits (YY)
        const month = parts[1];             // month (MM)
        const day = parts[2];               // day (DD)
        dobFormatted = `${month}/${day}/${year}`;
      }
    }
    return `${compPrefix}@${empPrefix}${dobFormatted}`;
  };

  const companyResources = [
    { id: 'res-fin-fc', name: 'Financeiro: Fluxo de Caixa', area: 'Financeiro', description: 'Visualização de saldos de contas e projeções de faturamento.' },
    { id: 'res-fin-cp', name: 'Financeiro: Contas a Pagar/Receber', area: 'Financeiro', description: 'Aprovação de faturas e monitoramento de recebíveis.' },
    { id: 'res-fin-dre', name: 'Financeiro: DRE Analítica', area: 'Financeiro', description: 'Geração do Demonstrativo de Resultados do Exercício.' },
    { id: 'res-rh-fp', name: 'Recursos Humanos: Folha de Pagamento', area: 'Recursos Humanos', description: 'Cálculo de vencimentos, impostos e benefícios corporativos.' },
    { id: 'res-rh-gp', name: 'Recursos Humanos: Gestão de Pessoas', area: 'Recursos Humanos', description: 'Avaliações de desempenho, plano de cargos e salários.' },
    { id: 'res-rh-ad', name: 'Recursos Humanos: Admissão/Demissão', area: 'Recursos Humanos', description: 'Processamento de contratos e homologações trabalhistas.' },
    { id: 'res-log-es', name: 'Logística: Estoque Físico & Inventário', area: 'Logística', description: 'Balanço de materiais, entradas e saídas de produtos.' },
    { id: 'res-log-rf', name: 'Logística: Rastreamento de Frotas', area: 'Logística', description: 'Monitoramento geolocalizado de despacho e entregas.' },
    { id: 'res-ai-gate', name: 'Inteligência Artificial: AI Gateway', area: 'Inteligência Artificial', description: 'Acesso direto aos modelos de linguagem (Gemini, Azure GPT, Watson).' },
    { id: 'res-ai-agent', name: 'Inteligência Artificial: AI Agents', area: 'Inteligência Artificial', description: 'Orquestração e parametrização de agentes inteligentes autónomos.' },
    { id: 'res-ti-conn', name: 'TI e Infraestrutura: Conectores de Dados', area: 'TI e Infraestrutura', description: 'Mapeamento de endpoints de API (REST, HubSpot, SAP S/4HANA).' },
    { id: 'res-gov-iga', name: 'Governança & Risco: Políticas de Governança', area: 'Governança & Risco', description: 'Configuração e auditoria de regras de mitigação de alucinação.' }
  ];

  // Form States for Employee creation
  const [employeeName, setEmployeeName] = useState('');
  const [employeeEmail, setEmployeeEmail] = useState('');
  const [employeeDept, setEmployeeDept] = useState('');
  const [employeePhone, setEmployeePhone] = useState('');
  const [employeeDob, setEmployeeDob] = useState('');
  const [employeeRole, setEmployeeRole] = useState<string>('Viewer');
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const activeUser = simulatedUserId === 'admin'
    ? {
        id: 'admin',
        name: currentUser?.name || 'Administrador TI',
        email: currentUser?.email || 'admin@empresa.com.br',
        role: 'TenantAdmin',
        department: 'TI & Governança',
        permissions: companyResources.map(r => r.id)
      }
    : (() => {
        const member = teamMembers.find(m => m.id === simulatedUserId);
        return member ? {
          id: member.id,
          name: member.name,
          email: member.email,
          role: member.role,
          department: member.department,
          permissions: member.permissions || []
        } : {
          id: 'admin',
          name: currentUser?.name || 'Administrador TI',
          email: currentUser?.email || 'admin@empresa.com.br',
          role: 'TenantAdmin',
          department: 'TI & Governança',
          permissions: companyResources.map(r => r.id)
        };
      })();

  const handleTogglePermission = (id: string) => {
    setSelectedPermissions(prev =>
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    );
  };

  const isResourceUnlocked = (resourceId: string, planTier: string) => {
    const tier = (planTier || '').toLowerCase();
    if (tier === 'enterprise') return true;
    
    if (tier === 'professional') {
      return resourceId !== 'res-ti-conn' && resourceId !== 'res-gov-iga';
    }
    
    if (tier === 'starter') {
      return resourceId === 'res-fin-fc' || resourceId === 'res-fin-cp' || resourceId === 'res-fin-dre' ||
             resourceId === 'res-rh-fp' || resourceId === 'res-rh-gp' || resourceId === 'res-rh-ad';
    }
    
    return false;
  };

  const handleToggleEmployeeStatus = (member: User) => {
    const updatedEmp: User = {
      ...member,
      status: member.status === 'active' ? 'inactive' : 'active'
    };
    onUpdateTeamMember(updatedEmp);
    setSuccessMessage(`O status de "${member.name}" foi alterado para ${updatedEmp.status === 'active' ? 'Ativo' : 'Desativado'}.`);
  };

  const handleSubmitEmployeeForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!employeeName.trim() || !employeeEmail.trim() || !employeeDob) return;

    if (editingEmployeeId) {
      const existing = teamMembers.find(m => m.id === editingEmployeeId);
      const updatedEmp: User = {
        id: editingEmployeeId,
        tenantId: tenant.id,
        name: employeeName.trim(),
        email: employeeEmail.trim(),
        department: employeeDept.trim() || 'Operações',
        phone: employeePhone.trim() || '+55 (11) 99999-9999',
        dob: employeeDob,
        role: employeeRole,
        mfaEnabled: existing?.mfaEnabled || false,
        status: existing?.status || 'active',
        password: existing?.password || generateInitialPassword(tenant.name, employeeName, employeeDob),
        generatedPassword: existing?.generatedPassword || generateInitialPassword(tenant.name, employeeName, employeeDob),
        permissions: [...selectedPermissions]
      };

      onUpdateTeamMember(updatedEmp);
      setSuccessMessage(`Dados do colaborador "${employeeName}" salvos com sucesso!`);
      setEditingEmployeeId(null);
    } else {
      const currentCount = teamMembers.length + 1; // +1 pro Admin
      const maxUsers = tenant.quotas.maxUsers || 5;
      if (currentCount >= maxUsers) {
        setPlanUpgradePrompt({
          isOpen: true,
          requiredPlan: tenant.planTier.toLowerCase() === 'starter' ? 'Professional' : 'Enterprise',
          featureName: `Adicionar colaboradores excedentes (Limite do plano atual: ${maxUsers} usuários)`
        });
        return;
      }

      const generatedPassword = generateInitialPassword(tenant.name, employeeName, employeeDob);

      const newEmp: User = {
        id: `usr-${Date.now().toString(36)}`,
        tenantId: tenant.id,
        name: employeeName.trim(),
        email: employeeEmail.trim(),
        department: employeeDept.trim() || 'Operações',
        phone: employeePhone.trim() || '+55 (11) 99999-9999',
        dob: employeeDob,
        role: employeeRole,
        mfaEnabled: false,
        status: 'active',
        password: generatedPassword,
        generatedPassword: generatedPassword,
        permissions: [...selectedPermissions]
      };

      onAddTeamMember(newEmp);
      setSuccessMessage(`Colaborador(a) "${employeeName}" cadastrado(a)! Senha Inicial Gerada: ${generatedPassword}`);
    }

    // Reset Form
    setEmployeeName('');
    setEmployeeEmail('');
    setEmployeeDept('');
    setEmployeePhone('');
    setEmployeeDob('');
    setEmployeeRole('Viewer');
    setSelectedPermissions([]);
  };

  // Client Data Connectors state
  const [connectorsList, setConnectorsList] = useState([
    { id: 'conn-1', name: 'ERP SAP S/4HANA (Financeiro & Suprimentos)', type: 'ERP', status: 'online', latency: '42ms', syncRate: 'A cada 5 min' },
    { id: 'conn-2', name: 'PostgreSQL Prod Data Lake', type: 'SQL', status: 'online', latency: '18ms', syncRate: 'Tempo Real' },
    { id: 'conn-3', name: 'CRM Salesforce / HubSpot (Contratos & Clientes)', type: 'CRM', status: 'online', latency: '65ms', syncRate: 'Webhooks' },
    { id: 'conn-4', name: 'REST API Legada de Diagnósticos / Operações', type: 'REST', status: 'online', latency: '95ms', syncRate: 'Polling 15 min' }
  ]);

  // Client Usage Data for Recharts
  const tokenUsageData = [
    { day: 'Seg', tokens: 140000, decisions: 320, accuracy: 99.8 },
    { day: 'Ter', tokens: 210000, decisions: 480, accuracy: 99.9 },
    { day: 'Qua', tokens: 190000, decisions: 410, accuracy: 99.7 },
    { day: 'Qui', tokens: 280000, decisions: 620, accuracy: 99.9 },
    { day: 'Sex', tokens: 320000, decisions: 710, accuracy: 100 },
    { day: 'Sáb', tokens: 90000, decisions: 180, accuracy: 99.8 },
    { day: 'Dom', tokens: 60000, decisions: 120, accuracy: 99.9 }
  ];

  const handleSimulateDecision = async () => {
    setIsSimulating(true);
    try {
      const result = await globalPasquaredEngine.executeSAC(testInput, observer);
      setLastDecision(result.decision);
    } catch (err) {
      console.error('Error simulating decision in client dashboard:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  const usedTokenPercent = Math.min(
    100,
    Math.round(((tenant.quotas.usedTokens || 120000) / tenant.quotas.monthlyTokens) * 100)
  );

  return (
    <div className="p-4 sm:p-6 md:p-8 space-y-6 max-w-7xl mx-auto animate-in fade-in text-slate-100 font-sans">
      {/* Personalized Top Welcome Banner */}
      <div className="quantum-card-glow rounded-3xl p-6 sm:p-8 relative overflow-hidden border-cyan-500/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[radial-gradient(circle_at_100%_0%,rgba(0,240,255,0.15),transparent_70%)] pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start gap-4 flex-1">
            <PasquaredLogo size="lg" showText={false} />

            <div className="space-y-1 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {tenant.name}
                </h1>
                <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 text-xs font-mono font-bold px-3 py-0.5 rounded-full shadow-[0_0_12px_rgba(0,240,255,0.3)]">
                  PLANO {tenant.tier.toUpperCase()}
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
                  Status: Ativo & Seguro
                </span>
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
                  Perfil Ativo: {activeUser.role}
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
                Dashboard Exclusivo de Governança Cognitiva & Gestão de Recursos de IA. Bem-vindo(a),{' '}
                <strong className="text-cyan-300">{activeUser.name}</strong> ({activeUser.email}).
              </p>

              <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-2">
                <span>Domínio: <strong className="text-cyan-300">{tenant.domain || `${tenant.slug}.com.br`}</strong></span>
                <span>•</span>
                <span>Pre-Ledger: <strong className="text-emerald-300">Imutável Sincronizado</strong></span>
                <span>•</span>
                <span>Observador O(P,E,K,B): <strong className="text-indigo-300">{observer.name}</strong></span>
              </div>

              {/* ACTIVE USER SIMULATOR / RBAC CONTROLLER */}
              <div className="pt-3 max-w-md">
                <label className="block text-[10px] font-mono font-bold text-amber-400 mb-1 flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                  SIMULADOR DE USUÁRIO / COLABORADOR DA EMPRESA:
                </label>
                <select
                  value={simulatedUserId}
                  onChange={(e) => {
                    setSimulatedUserId(e.target.value);
                    // Reset connector creation state when switching profiles for security
                    setIsCreatingConnector(false);
                    setEditingConnectorId(null);
                  }}
                  className="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-semibold"
                >
                  <option value="admin">🏢 Administrador Principal (Acesso Total)</option>
                  {teamMembers.map(member => (
                    <option key={member.id} value={member.id}>
                      👤 {member.name} ({member.role} - {member.department})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">
                  Altere o perfil ativo para visualizar a página inicial exatamente como o novo funcionário vê, com base nos recursos concedidos.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Hub Buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => setIsLocalManualOpen(true)}
              className="bg-slate-900/90 hover:bg-cyan-950 text-cyan-300 font-bold text-xs px-4 py-2.5 rounded-xl border border-cyan-500/40 flex items-center gap-2 transition shadow-sm"
            >
              <BookOpen className="w-4 h-4 text-cyan-400" />
              <span>Manual de Operações</span>
            </button>

            <button
              onClick={() => setActiveTab('connectors')}
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-cyan-600/30 flex items-center gap-2 transition"
            >
              <Database className="w-4 h-4 text-white" />
              <span>Gerenciar Conectores</span>
            </button>

            <button
              onClick={onNavigateToKernel}
              className="bg-slate-900 hover:bg-slate-800 text-cyan-300 font-bold text-xs px-4 py-2.5 rounded-xl border border-cyan-500/30 flex items-center gap-2 transition"
            >
              <Cpu className="w-4 h-4" />
              <span>Kernel PASQUARED-OS</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Token Quota */}
        <div className="quantum-card-glow rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300">Cota Mensal de Tokens</span>
            <Boxes className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">
            {tenant.quotas.monthlyTokens.toLocaleString()}
          </div>
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
            <div
              className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full transition-all duration-500 shadow-[0_0_8px_rgba(0,240,255,0.6)]"
              style={{ width: `${Math.max(5, usedTokenPercent)}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-slate-400 font-mono">
            <span>{usedTokenPercent}% Consumido</span>
            <span className="text-cyan-300">{(tenant.quotas.monthlyTokens - (tenant.quotas.usedTokens || 120000)).toLocaleString()} Livres</span>
          </div>
        </div>

        {/* Epistemic Accuracy */}
        <div className="quantum-card-glow rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300">Acurácia Poda MVED</span>
            <Shield className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-300 font-mono">
            99.98%
          </div>
          <p className="text-[11px] text-slate-400">
            Zero alucinações críticas nos últimos 2.840 disparos.
          </p>
        </div>

        {/* Active Conectors */}
        <div className="quantum-card-glow rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300">Conectores Ativos</span>
            <Database className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-black text-indigo-300 font-mono">
            {connectorsList.length} / 50
          </div>
          <p className="text-[11px] text-slate-400">
            SAP, Postgres, Salesforce e REST sincronizados.
          </p>
        </div>

        {/* Pre-Ledger PRE Hashes */}
        <div className="quantum-card-glow rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300">Auditoria Forense (PRE)</span>
            <FileCheck className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-300 font-mono">
            100%
          </div>
          <p className="text-[11px] text-slate-400">
            Assinaturas SHA-256 e Merkle Proofs imutáveis.
          </p>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'overview'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Activity className="w-4 h-4 text-cyan-400" />
          <span>Visão Geral & Telemetria</span>
        </button>

        <button
          onClick={() => setActiveTab('connectors')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'connectors'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Database className="w-4 h-4 text-emerald-400" />
          <span>Conectores de Dados ({connectorsList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('deliberation')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'deliberation'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Play className="w-4 h-4 text-indigo-400" />
          <span>Simulador Decisório em Tempo Real</span>
        </button>

        {activeUser.role === 'TenantAdmin' && (
          <>
            <button
              onClick={() => setActiveTab('team')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                activeTab === 'team'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <UserCheck className="w-4 h-4 text-amber-400" />
              <span>Equipe & Permissões RBAC</span>
            </button>

            <button
              onClick={() => setActiveTab('ai_specialists')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                activeTab === 'ai_specialists'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span>IAs Especialistas por Área</span>
            </button>
          </>
        )}
      </div>

      {/* TAB 1: Overview & Consumption Telemetry */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 quantum-card-glow rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Consumo de Tokens & Deliberações Semanais</h3>
                <p className="text-xs text-slate-400">
                  Histórico de volume de requisições e taxa de conformidade epistêmica.
                </p>
              </div>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-lg">
                Taxa de Sucesso: 99.9%
              </span>
            </div>

            <div className="h-72 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={tokenUsageData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="tokenColor" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00f0ff" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#00f0ff" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="day" stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <YAxis stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#040d1a', borderColor: '#00f0ff', borderRadius: '12px', fontSize: '11px', color: '#fff' }}
                  />
                  <Area type="monotone" dataKey="tokens" stroke="#00f0ff" fillOpacity={1} fill="url(#tokenColor)" name="Tokens Consumidos" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-4">
            {/* Quick Actions Card */}
            <div className="quantum-card-glow rounded-2xl p-6 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-400" />
                <span>Ações Rápidas do Tenant</span>
              </h3>

              <div className="space-y-2">
                <button
                  onClick={onNavigateToEnterpriseFeeder}
                  className="w-full bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 text-xs font-semibold p-3 rounded-xl flex items-center justify-between transition"
                >
                  <span>Parametrizar Conectores e Pesos</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onNavigateToPQL}
                  className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs font-semibold p-3 rounded-xl flex items-center justify-between transition"
                >
                  <span>Executar Consultas PQL</span>
                  <Terminal className="w-4 h-4 text-indigo-400" />
                </button>

                <button
                  onClick={onNavigateToAudit}
                  className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs font-semibold p-3 rounded-xl flex items-center justify-between transition"
                >
                  <span>Ver Trilha de Auditoria Forense</span>
                  <FileCheck className="w-4 h-4 text-emerald-400" />
                </button>

                <button
                  onClick={onOpenUpgradeModal}
                  className="w-full bg-gradient-to-r from-cyan-600 to-emerald-600 hover:opacity-95 text-white text-xs font-bold p-3 rounded-xl flex items-center justify-between shadow-lg shadow-cyan-600/20 transition"
                >
                  <span>Alterar Plano / Adicionar Tokens</span>
                  <CreditCard className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* RBAC Resources Card */}
            <div className="quantum-card-glow rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-400" />
                  <span>Recursos Cedidos (RBAC)</span>
                </h3>
                <span className="text-[10px] font-mono bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2 py-0.5 rounded-md">
                  {activeUser.id === 'admin' ? 'Acesso Total' : 'Acesso Restrito'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Abaixo estão os módulos e dados autorizados para <strong className="text-cyan-300">{activeUser.name}</strong> pelo Administrador Principal:
              </p>

              <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                {companyResources.map((res) => {
                  const isAssigned = activeUser.permissions.includes(res.id);
                  return (
                    <div 
                      key={res.id} 
                      className={`p-2.5 rounded-xl border transition flex items-center justify-between gap-3 ${
                        isAssigned 
                          ? 'bg-slate-900/60 border-emerald-500/30 text-slate-200' 
                          : 'bg-slate-950/40 border-slate-900 text-slate-500 opacity-60'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className={`w-1.5 h-1.5 rounded-full ${isAssigned ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                          <span className="text-xs font-bold truncate block">{res.name}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 block truncate">{res.description}</span>
                      </div>
                      <div className="shrink-0 font-mono text-[10px] font-bold">
                        {isAssigned ? (
                          <span className="text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-500/20">
                            CEDIDO
                          </span>
                        ) : (
                          <span className="text-slate-500 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                            BLOQUEADO
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Connectors List */}
      {activeTab === 'connectors' && (
        tenant.planTier.toLowerCase() !== 'enterprise' ? (
          <UpgradeWall
            requiredPlan="Enterprise"
            featureName="TI & Conectores de Dados (SAP, Salesforce, HubSpot)"
            onUpgrade={() => {
              onUpgradePlan('Enterprise');
              setSuccessMessage("Upgrade realizado com sucesso! Sua empresa agora conta com o plano Enterprise e o módulo de Conectores está desbloqueado.");
            }}
          />
        ) : (
          <div className="space-y-4">
          {!activeUser.permissions.includes('res-ti-conn') ? (
            <div className="quantum-card-glow rounded-2xl p-8 text-center space-y-4 border border-red-500/20 bg-slate-950/60 max-w-xl mx-auto">
              <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mx-auto">
                <Lock className="w-8 h-8 text-red-400" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-black text-white">Acesso Restrito ao Conector de TI</h3>
                <p className="text-xs text-slate-300">
                  O colaborador <strong className="text-amber-300">{activeUser.name}</strong> não possui a permissão <strong className="text-cyan-300">TI e Infraestrutura: Conectores de Dados</strong> concedida pelo administrador.
                </p>
                <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 text-[11px] text-slate-400 max-w-md mx-auto">
                  Apenas usuários com o recurso <strong className="text-emerald-400">"Conectores de Dados"</strong> ativado em sua credencial podem visualizar, criar ou modificar conexões de API.
                </div>
              </div>
              <div className="pt-2 flex flex-col sm:flex-row justify-center gap-2">
                <button
                  onClick={() => setSimulatedUserId('admin')}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition"
                >
                  Alternar para Administrador (Acesso Total)
                </button>
                <button
                  onClick={() => setActiveTab('team')}
                  className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs px-4 py-2 rounded-xl transition"
                >
                  Ir para Equipe & Permissões
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Database className="w-5 h-5 text-cyan-400" />
                    <span>Conectores de Recursos de TI Registrados</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Fontes de dados corporativas parametrizadas que alimentam a ontologia POKO da {tenant.name} e são acessadas por {activeUser.name}.
                  </p>
                </div>
                {!isCreatingConnector && (
                  <button
                    onClick={() => {
                      setEditingConnectorId(null);
                      setConnName('');
                      setConnType('REST');
                      setConnUrl('https://api.hubspot.com/v1');
                      setConnAuth('Bearer Token');
                      setConnSync('Tempo Real');
                      setConnLatency('15ms');
                      setIsCreatingConnector(true);
                    }}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md shadow-cyan-600/30 flex items-center gap-2 self-start sm:self-auto transition"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Criar Novo Conector</span>
                  </button>
                )}
              </div>

              {/* Form Container (Create or Edit) */}
              {isCreatingConnector && (
                <div className="quantum-card-glow rounded-2xl p-6 border border-cyan-500/30 bg-slate-900/60 space-y-4 max-w-2xl mx-auto">
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <Database className="w-4 h-4 text-cyan-400" />
                    <span>{editingConnectorId ? '✏️ Editar Conector Existente' : '🔌 Cadastrar Novo Conector de Dados'}</span>
                  </h4>
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (!connName.trim()) return;

                    if (editingConnectorId) {
                      setConnectorsList(prev => prev.map(c => {
                        if (c.id === editingConnectorId) {
                          return {
                            ...c,
                            name: connName.trim(),
                            type: connType,
                            latency: connLatency,
                            syncRate: connSync
                          };
                        }
                        return c;
                      }));
                      setEditingConnectorId(null);
                    } else {
                      const newConn = {
                        id: `conn-${Date.now().toString(36)}`,
                        name: connName.trim(),
                        type: connType,
                        status: 'online',
                        latency: connLatency,
                        syncRate: connSync
                      };
                      setConnectorsList(prev => [...prev, newConn]);
                    }

                    // Reset
                    setConnName('');
                    setIsCreatingConnector(false);
                  }} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-300">Nome do Conector:</label>
                        <input
                          type="text"
                          required
                          value={connName}
                          onChange={(e) => setConnName(e.target.value)}
                          placeholder="Ex: HubSpot CRM API, Oracle DB Cloud"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-300">Tipo de Integração:</label>
                        <select
                          value={connType}
                          onChange={(e) => setConnType(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                        >
                          <option value="REST">REST API (Webhooks / Polling)</option>
                          <option value="CRM">CRM (HubSpot, Salesforce, Pipedrive)</option>
                          <option value="SQL">Relational SQL Database (PostgreSQL, MySQL)</option>
                          <option value="ERP">Enterprise Resource (SAP S/4HANA, TOTVS)</option>
                          <option value="GraphQL">GraphQL Endpoint</option>
                        </select>
                      </div>

                      <div className="space-y-1 sm:col-span-2">
                        <label className="text-xs font-semibold text-slate-300">URL do Endpoint de Integração:</label>
                        <input
                          type="url"
                          required
                          value={connUrl}
                          onChange={(e) => setConnUrl(e.target.value)}
                          placeholder="https://api.empresa.com/v1"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-300">Método de Autenticação:</label>
                        <select
                          value={connAuth}
                          onChange={(e) => setConnAuth(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                        >
                          <option value="Bearer Token">OAuth Bearer Token</option>
                          <option value="API Key">API Secret Key (Header)</option>
                          <option value="Basic Auth">Basic Username & Password</option>
                          <option value="No Auth">Sem Autenticação</option>
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">Frequência:</label>
                          <select
                            value={connSync}
                            onChange={(e) => setConnSync(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                          >
                            <option value="Tempo Real">Tempo Real</option>
                            <option value="A cada 5 min">A cada 5 min</option>
                            <option value="A cada 15 min">A cada 15 min</option>
                            <option value="Diário">Diário</option>
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">Latência Alvo:</label>
                          <input
                            type="text"
                            required
                            value={connLatency}
                            onChange={(e) => setConnLatency(e.target.value)}
                            placeholder="Ex: 15ms"
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsCreatingConnector(false);
                          setEditingConnectorId(null);
                        }}
                        className="bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-300 font-bold text-xs px-4 py-2 rounded-xl transition"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-md shadow-cyan-600/30 transition"
                      >
                        {editingConnectorId ? 'Salvar Alterações' : 'Salvar Novo Conector'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Connectors List Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {connectorsList.map((conn) => {
                  const isOnline = conn.status === 'online';
                  return (
                    <div 
                      key={conn.id} 
                      className={`quantum-card-glow rounded-2xl p-5 space-y-3 border transition-colors ${
                        isOnline ? 'border-slate-800 bg-slate-900/40' : 'border-red-950/40 bg-red-950/5'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                            isOnline 
                              ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30' 
                              : 'bg-slate-950 text-slate-500 border-slate-800'
                          }`}>
                            <Database className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-white leading-tight">{conn.name}</h4>
                            <span className="text-[11px] text-cyan-300 font-mono">Tipo: {conn.type}</span>
                          </div>
                        </div>
                        <span className={`border text-[10px] font-mono px-2 py-0.5 rounded-full flex items-center gap-1.5 shrink-0 ${
                          isOnline 
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
                            : 'bg-slate-900 text-slate-400 border-slate-800'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`}></span>
                          <span>{isOnline ? 'ATIVO' : 'DESATIVADO'}</span>
                        </span>
                      </div>

                      <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono text-slate-400">
                        <div>Latência: <strong className="text-cyan-300">{conn.latency}</strong></div>
                        <div>Sincronização: <strong className="text-white">{conn.syncRate}</strong></div>
                      </div>

                      {/* Controls Row */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                        <button
                          onClick={() => {
                            // Toggle status
                            setConnectorsList(prev => prev.map(c => {
                              if (c.id === conn.id) {
                                return { ...c, status: c.status === 'online' ? 'offline' : 'online' };
                              }
                              return c;
                            }));
                          }}
                          className={`font-semibold px-2.5 py-1 rounded-lg border transition ${
                            isOnline
                              ? 'bg-slate-950 hover:bg-amber-950/20 border-amber-500/20 text-amber-300'
                              : 'bg-emerald-600 hover:bg-emerald-500 text-white border-transparent'
                          }`}
                        >
                          {isOnline ? '⏸️ Desativar' : '▶️ Ativar'}
                        </button>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setEditingConnectorId(conn.id);
                              setConnName(conn.name);
                              setConnType(conn.type);
                              setConnUrl('https://api.empresa.com/v1');
                              setConnAuth('Bearer Token');
                              setConnSync(conn.syncRate);
                              setConnLatency(conn.latency);
                              setIsCreatingConnector(true);
                              window.scrollTo({ top: 300, behavior: 'smooth' });
                            }}
                            className="bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-300 px-3 py-1 rounded-lg font-medium transition"
                          >
                            ✏️ Editar
                          </button>

                          <button
                            onClick={() => {
                              if (confirm(`Deseja realmente excluir o conector "${conn.name}"?`)) {
                                setConnectorsList(prev => prev.filter(c => c.id !== conn.id));
                              }
                            }}
                            className="bg-red-950/60 hover:bg-red-900/80 border border-red-500/30 text-red-300 px-3 py-1 rounded-lg font-medium transition"
                          >
                            🗑️ Excluir
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
        )
      )}

      {/* TAB 3: Real-Time Decision Simulator */}
      {activeTab === 'deliberation' && (
        tenant.planTier.toLowerCase() === 'starter' ? (
          <UpgradeWall
            requiredPlan="Professional"
            featureName="Simulador Decisório em Tempo Real com Poda MVED"
            onUpgrade={() => {
              onUpgradePlan('Professional');
              setSuccessMessage("Upgrade realizado com sucesso! Sua empresa agora conta com o plano Professional e o Simulador Decisório está desbloqueado.");
            }}
          />
        ) : (
          <div className="space-y-6">
          <div className="quantum-card-glow rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Play className="w-5 h-5 text-cyan-400" />
              <span>Simulador Decisório com Poda MVED do seu Tenant</span>
            </h3>
            <p className="text-xs text-slate-300">
              Digite uma proposição ou requisição corporativa para ver a deliberação do Kernel PASQUARED-OS aplicando a ontologia e políticas de {tenant.name}.
            </p>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-cyan-300">Proposição / Requisição a Submeter:</label>
              <textarea
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                rows={3}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>

            <button
              onClick={handleSimulateDecision}
              disabled={isSimulating}
              className="bg-gradient-to-r from-cyan-500 via-blue-600 to-emerald-500 hover:opacity-95 text-white font-bold text-xs px-6 py-3 rounded-xl shadow-lg shadow-cyan-500/30 flex items-center gap-2 transition"
            >
              <Zap className={`w-4 h-4 ${isSimulating ? 'animate-spin' : ''}`} />
              <span>{isSimulating ? 'Submetendo ao Kernel...' : 'Executar Deliberação Epistêmica'}</span>
            </button>

            {/* Simulated Output Result */}
            {lastDecision && (
              <div className="mt-6 p-5 bg-slate-950 border border-cyan-500/40 rounded-2xl space-y-4 shadow-inner">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm font-bold text-white">
                      Deliberação Aprovada: {lastDecision.outcome}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-cyan-300">
                    ID: {lastDecision.id.substring(0, 16)}...
                  </span>
                </div>

                <p className="text-xs text-slate-200 leading-relaxed font-sans">
                  {lastDecision.explanation}
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Acurácia Epistêmica:</div>
                    <div className="text-cyan-300 font-bold">{(lastDecision.epistemicAccuracy * 100).toFixed(2)}%</div>
                  </div>
                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Poda MVED:</div>
                    <div className="text-emerald-300 font-bold">{lastDecision.mvedPruningApplied ? 'Ativada' : 'Padrão'}</div>
                  </div>
                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Pre-Ledger PRE:</div>
                    <div className="text-indigo-300 font-bold">SHA-256 Gravado</div>
                  </div>
                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Aprovação IGA:</div>
                    <div className="text-amber-300 font-bold">{lastDecision.iga.toFixed(4)}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )
    )}

      {/* TAB 4: General Administrative Menu */}
      {activeTab === 'team' && activeUser.role === 'TenantAdmin' && (
        <div className="space-y-6">
          {/* Sub-tab navigation */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
            <button
              type="button"
              onClick={() => setAdminSubTab('employees')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                adminSubTab === 'employees'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <UserCheck className="w-4 h-4 text-amber-400" />
              <span>Administração de Funcionários (CRUD)</span>
            </button>

            <button
              type="button"
              onClick={() => setAdminSubTab('plan_tier')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                adminSubTab === 'plan_tier'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <CreditCard className="w-4 h-4 text-amber-400" />
              <span>Matriz de Recursos & Upgrade de Planos</span>
            </button>
          </div>

          {/* Success Notification Alert */}
          {successMessage && (
            <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-start justify-between gap-3 animate-in fade-in slide-in-from-top-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block font-mono">Sucesso • Alteração Salva</span>
                <p className="text-xs text-emerald-200 font-medium">
                  {successMessage}
                </p>
                <span className="text-[10px] text-emerald-400 font-mono block">
                  Configurações ativas do tenant atualizadas em tempo real.
                </span>
              </div>
              <button
                onClick={() => setSuccessMessage(null)}
                className="text-emerald-400 hover:text-emerald-300 font-bold text-xs px-2 py-1 rounded"
              >
                ✕ Fechar
              </button>
            </div>
          )}

          {/* SUB-TAB 1: EMPLOYEES CRUD */}
          {adminSubTab === 'employees' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Form Section */}
              <div className="lg:col-span-5 quantum-card-glow rounded-2xl p-6 space-y-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-amber-400" />
                    <span>{editingEmployeeId ? '✏️ Editar Cadastro do Funcionário' : '➕ Cadastrar Novo Funcionário / Operador'}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {editingEmployeeId 
                      ? 'Modifique os dados cadastrais, atribuição e permissões granulares deste colaborador e clique em salvar.'
                      : 'Cadastre uma nova conta corporativa. Uma senha padrão única será gerada e as permissões de acesso aos recursos ativos do seu pacote contratado serão mapeadas.'}
                  </p>
                </div>

                <form onSubmit={handleSubmitEmployeeForm} className="space-y-3 text-xs">
                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">Nome Completo do Funcionário:</label>
                    <input
                      type="text"
                      value={employeeName}
                      onChange={(e) => setEmployeeName(e.target.value)}
                      placeholder="Ex: Carlos Roberto Souza"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-slate-300 font-semibold">E-mail Corporativo:</label>
                      <input
                        type="email"
                        value={employeeEmail}
                        onChange={(e) => setEmployeeEmail(e.target.value)}
                        placeholder="carlos@empresa.com.br"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-300 font-semibold">Telefone / Ramal:</label>
                      <input
                        type="text"
                        value={employeePhone}
                        onChange={(e) => setEmployeePhone(e.target.value)}
                        placeholder="+55 11 99999-0000"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-slate-300 font-semibold">Departamento:</label>
                      <input
                        type="text"
                        value={employeeDept}
                        onChange={(e) => setEmployeeDept(e.target.value)}
                        placeholder="Ex: Recursos Humanos"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-300 font-semibold">Data de Nascimento:</label>
                      <input
                        type="date"
                        value={employeeDob}
                        onChange={(e) => setEmployeeDob(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-white focus:border-amber-500 focus:outline-none font-mono"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">Nível de Função (Perfil):</label>
                    <select
                      value={employeeRole}
                      onChange={(e) => setEmployeeRole(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:border-amber-500 focus:outline-none"
                    >
                      <option value="ComplianceOfficer">ComplianceOfficer (DPO/Risco)</option>
                      <option value="RiskManager">RiskManager (Gestor de Risco)</option>
                      <option value="AIEngineer">AIEngineer (TI / Engenheiro de IA)</option>
                      <option value="Auditor">Auditor (Auditoria Fiscal/Forense)</option>
                      <option value="Viewer">Viewer (Visualizador de Dashboard)</option>
                    </select>
                  </div>

                  {/* Granular Permissions Table */}
                  <div className="space-y-2 pt-2 border-t border-slate-800/80">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block">
                          Recursos Liberados para o Funcionário
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono">
                          Disponibilidade baseada no seu plano atual ({tenant.planTier})
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            const unlockedIds = companyResources
                              .filter(res => isResourceUnlocked(res.id, tenant.planTier))
                              .map(res => res.id);
                            setSelectedPermissions(unlockedIds);
                            setSuccessMessage("Todos os acessos disponíveis no seu plano atual foram selecionados automaticamente.");
                          }}
                          className="text-[10px] bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/35 text-amber-300 font-mono font-bold px-2 py-1 rounded transition flex items-center gap-1 shrink-0"
                        >
                          ⚡ Liberar Todos do Plano
                        </button>
                        <span className="text-[10px] text-slate-400 shrink-0 font-mono">
                          {selectedPermissions.length} Selecionados
                        </span>
                      </div>
                    </div>
                    
                    <div className="border border-slate-800 rounded-xl overflow-hidden max-h-56 overflow-y-auto font-sans">
                      <table className="w-full text-left border-collapse text-[11px]">
                        <thead>
                          <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                            <th className="p-2 text-center w-10">Ativo</th>
                            <th className="p-2">Módulo / Área</th>
                            <th className="p-2">Recurso do SuperAdmin</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-900 bg-slate-950/30">
                          {companyResources.map(res => {
                            const isAvailableInPlan = isResourceUnlocked(res.id, tenant.planTier);
                            return (
                              <tr key={res.id} className={`transition ${isAvailableInPlan ? 'hover:bg-slate-900/60' : 'opacity-40 bg-slate-950/80 cursor-not-allowed'}`}>
                                <td className="p-2 text-center">
                                  <input
                                    type="checkbox"
                                    checked={selectedPermissions.includes(res.id)}
                                    onChange={() => {
                                      if (isAvailableInPlan) {
                                        handleTogglePermission(res.id);
                                      } else {
                                        // Trigger upgrade modal
                                        setPlanUpgradePrompt({
                                          isOpen: true,
                                          requiredPlan: res.id === 'res-ti-conn' || res.id === 'res-gov-iga' ? 'Enterprise' : 'Professional',
                                          featureName: `Liberar o recurso "${res.name}"`
                                        });
                                      }
                                    }}
                                    className="w-4 h-4 rounded border-slate-800 text-amber-500 focus:ring-amber-500 accent-amber-500 cursor-pointer"
                                  />
                                </td>
                                <td className="p-2 font-semibold text-slate-300">
                                  {res.area}
                                  {!isAvailableInPlan && <span className="text-[9px] text-rose-400 font-bold font-mono ml-1 block">🔒 Upgrade</span>}
                                </td>
                                <td className="p-2">
                                  <div className="font-medium text-white">{res.name}</div>
                                  <div className="text-[10px] text-slate-400">{res.description}</div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2 font-sans">
                    {editingEmployeeId && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingEmployeeId(null);
                          setEmployeeName('');
                          setEmployeeEmail('');
                          setEmployeeDept('');
                          setEmployeePhone('');
                          setEmployeeDob('');
                          setEmployeeRole('Viewer');
                          setSelectedPermissions([]);
                        }}
                        className="flex-1 bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold p-3 rounded-xl border border-slate-800 transition"
                      >
                        Cancelar
                      </button>
                    )}
                    <button
                      type="submit"
                      className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold p-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition"
                    >
                      {editingEmployeeId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                      <span>{editingEmployeeId ? 'Salvar Cadastro' : 'Registrar Colaborador'}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* List Section */}
              <div className="lg:col-span-7 space-y-4 font-sans">
                <div className="quantum-card-glow rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="text-sm font-bold text-white font-sans">Equipe Registrada ({teamMembers.length + 1})</h3>
                      <p className="text-[11px] text-slate-400">
                        Lista de funcionários com acesso corporativo ao sistema.
                      </p>
                    </div>
                    <span className="text-xs font-mono text-cyan-300 bg-cyan-500/10 border border-cyan-500/30 px-3 py-1 rounded-full">
                      Cota de Usuários: {teamMembers.length + 1} / {tenant.quotas.maxUsers}
                    </span>
                  </div>

                  <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
                    {/* Current Admin User (Self) */}
                    <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shrink-0">
                          <UserCheck className="w-4 h-4" />
                        </div>
                        <div className="space-y-0.5">
                          <div className="text-xs font-bold text-white flex items-center gap-2">
                            <span>{currentUser?.name || 'Administrador TI'}</span>
                            <span className="bg-amber-500/20 text-amber-300 text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase">
                              Dono Tenant
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">{currentUser?.email}</div>
                          <div className="text-[10px] text-slate-500 font-mono">Depto: TI / Segurança</div>
                        </div>
                      </div>
                      <div className="flex sm:flex-col items-start sm:items-end justify-between shrink-0 gap-1 text-[11px]">
                        <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] font-mono px-2 py-0.5 rounded">
                          {currentUser?.role || 'TenantAdmin'}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-medium">Acesso Total (Master)</span>
                      </div>
                    </div>

                    {/* Registered Operators list */}
                    {teamMembers.length === 0 ? (
                      <div className="p-8 text-center text-slate-500 border border-dashed border-slate-800 rounded-xl text-xs">
                        Nenhum funcionário cadastrado ainda. Use o formulário ao lado para registrar o primeiro operador.
                      </div>
                    ) : (
                      teamMembers.map(member => {
                        const isActive = member.status !== 'inactive';
                        return (
                          <div key={member.id} className={`p-4 border rounded-xl space-y-3 transition ${isActive ? 'bg-[#050b14] border-slate-800' : 'bg-slate-950/40 border-slate-900 opacity-60'}`}>
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-900/60 pb-2.5">
                              <div className="flex items-start gap-3">
                                <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${isActive ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                                  <UserCheck className="w-4 h-4" />
                                </div>
                                <div className="space-y-0.5">
                                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                                    <span>{member.name}</span>
                                    {isActive ? (
                                      <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] px-1.5 py-0.2 rounded font-mono uppercase">
                                        Ativo
                                      </span>
                                    ) : (
                                      <span className="bg-red-500/10 text-red-400 border border-red-500/20 text-[9px] px-1.5 py-0.2 rounded font-mono uppercase">
                                        Inativo
                                      </span>
                                    )}
                                  </h4>
                                  <div className="text-[11px] text-slate-400 font-mono">{member.email}</div>
                                  <div className="text-[10px] text-slate-400">
                                    Depto: <strong className="text-slate-300">{member.department}</strong> • Tel: <strong className="text-slate-300">{member.phone}</strong>
                                  </div>
                                </div>
                              </div>

                              <div className="flex sm:flex-col items-start sm:items-end justify-between shrink-0 gap-1.5">
                                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono px-2 py-0.5 rounded">
                                  {member.role}
                                </span>
                                <span className="text-[10px] text-slate-500 font-mono">Nascimento: {member.dob}</span>
                              </div>
                            </div>

                            {/* Security Detail */}
                            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-900 flex items-center justify-between gap-2 text-[11px] font-mono">
                              <div className="space-y-0.5">
                                <span className="text-[9px] text-slate-400 block uppercase tracking-wider">Senha Provisória:</span>
                                <span className="text-cyan-300 font-bold tracking-wide select-all">{member.generatedPassword}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(member.generatedPassword);
                                  setSuccessMessage(`Senha de ${member.name} copiada para a área de transferência.`);
                                }}
                                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded text-[10px] transition shrink-0"
                              >
                                Copiar
                              </button>
                            </div>

                            {/* Assigned Resources chips */}
                            <div className="space-y-1">
                              <span className="text-[9px] text-slate-400 block uppercase tracking-wider font-mono">Recursos Concedidos:</span>
                              <div className="flex flex-wrap gap-1.5">
                                {(!member.permissions || member.permissions.length === 0) ? (
                                  <span className="text-[10px] text-slate-500 italic font-mono">Nenhum recurso ativo liberado.</span>
                                ) : (
                                  member.permissions.map(permId => {
                                    const resObj = companyResources.find(r => r.id === permId);
                                    return (
                                      <span key={permId} className="bg-slate-900 border border-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded-md font-mono flex items-center gap-1">
                                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                                        <span>{resObj ? resObj.name.split(': ')[1] : permId}</span>
                                      </span>
                                    );
                                  })
                                )}
                              </div>
                            </div>

                            {/* Action Buttons Row */}
                            <div className="flex items-center gap-2 pt-2 border-t border-slate-900/60 justify-end">
                              <button
                                type="button"
                                onClick={() => {
                                  setEmployeeName(member.name);
                                  setEmployeeEmail(member.email);
                                  setEmployeePhone(member.phone || '');
                                  setEmployeeDept(member.department || '');
                                  setEmployeeDob(member.dob || '');
                                  setEmployeeRole(member.role);
                                  setSelectedPermissions(member.permissions || []);
                                  setEditingEmployeeId(member.id);
                                  window.scrollTo({ top: 300, behavior: 'smooth' });
                                }}
                                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-lg text-[11px] font-bold transition flex items-center gap-1"
                              >
                                ✏️ Editar Cadastro
                              </button>
                              
                              <button
                                type="button"
                                onClick={() => handleToggleEmployeeStatus(member)}
                                className={`px-3 py-1.5 rounded-lg border text-[11px] font-bold transition flex items-center gap-1 ${
                                  isActive
                                    ? 'bg-rose-950/40 hover:bg-rose-900/60 border-rose-500/30 text-rose-300'
                                    : 'bg-emerald-950/40 hover:bg-emerald-900/60 border-emerald-500/30 text-emerald-300'
                                }`}
                              >
                                {isActive ? '⏸️ Desativar Conta' : '▶️ Ativar Conta'}
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 2: PLAN MATRIX & UPGRADES */}
          {adminSubTab === 'plan_tier' && (
            <div className="space-y-6">
              {/* Plan Overview Card */}
              <div className="quantum-card-glow rounded-2xl p-6 bg-slate-950/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-500/10 border border-cyan-500/30 px-3 py-1 rounded-full">
                      PLANO ATUAL DO TENANT
                    </span>
                    <h3 className="text-xl font-black text-white uppercase tracking-wide font-sans">
                      {tenant.planTier} Tier
                    </h3>
                  </div>
                  <p className="text-xs text-slate-300 max-w-xl">
                    Sua empresa está operando sob os parâmetros da assinatura corporativa <strong className="text-amber-300 font-semibold">{tenant.planTier}</strong>. 
                    Veja as cotas liberadas, gerencie os recursos ativos e faça upgrade instantâneo para liberar recursos adicionais.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs font-mono shrink-0">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Limite de Usuários:</div>
                    <div className="text-cyan-300 font-bold text-sm">{tenant.quotas.maxUsers} Colaboradores</div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Tokens Mensais:</div>
                    <div className="text-emerald-300 font-bold text-sm">{(tenant.quotas.monthlyTokens).toLocaleString()} PM</div>
                  </div>
                </div>
              </div>

              {/* Company Resource Matrix Grid */}
              <div className="space-y-3 font-sans">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider block font-mono">
                  Matriz Geral de Recursos Corporativos & Compatibilidade de Planos
                </h4>
                <p className="text-xs text-slate-400">
                  Abaixo estão listados todos os módulos de gestão do PASQUARED-OS. Clique em qualquer recurso para avaliar o escopo ou realizar upgrade.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {/* Item 1: Financeiro */}
                  <div className="bg-slate-950 border border-slate-800/80 p-5 rounded-2xl space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex justify-between items-start gap-2">
                        <span className="text-xs font-bold text-white">1. Módulo Financeiro</span>
                        <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                          INCLUSO
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        Controle completo do fluxo de caixa, demonstrativo DRE, contas a pagar, faturamento e contas a receber.
                      </p>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 text-center block">
                      Disponível em: Starter, Professional, Enterprise
                    </span>
                  </div>

                  {/* Item 2: RH */}
                  <div className="bg-slate-950 border border-slate-800/80 p-5 rounded-2xl space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex justify-between items-start gap-2">
                        <span className="text-xs font-bold text-white">2. Recursos Humanos (RBAC)</span>
                        <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                          INCLUSO
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        Cálculo de folha de pagamento, controle de admissões, demissões, férias e gerenciamento rítmico de colaboradores.
                      </p>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 text-center block">
                      Disponível em: Starter, Professional, Enterprise
                    </span>
                  </div>

                  {/* Item 3: Logística */}
                  {(() => {
                    const isUnlocked = isResourceUnlocked('res-log-es', tenant.planTier);
                    return (
                      <div 
                        onClick={() => {
                          if (!isUnlocked) {
                            setPlanUpgradePrompt({
                              isOpen: true,
                              requiredPlan: 'Professional',
                              featureName: 'Logística & Gestão de Estoque Físico/Frota'
                            });
                          }
                        }}
                        className={`border p-5 rounded-2xl space-y-3 flex flex-col justify-between cursor-pointer transition ${
                          isUnlocked 
                            ? 'bg-slate-950 border-slate-800/80' 
                            : 'bg-slate-950/40 border-rose-500/20 hover:border-rose-500/40'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex justify-between items-start gap-2">
                            <span className="text-xs font-bold text-white">3. Logística & Frota</span>
                            {isUnlocked ? (
                              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                                INCLUSO
                              </span>
                            ) : (
                              <span className="bg-rose-500/10 text-rose-400 border border-rose-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono flex items-center gap-1">
                                <Lock className="w-3 h-3" /> BLOQUEADO
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 leading-relaxed">
                            Balanço físico de estoque, inventário integrado e monitoramento geolocalizado de despacho e frota.
                          </p>
                        </div>
                        {isUnlocked ? (
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 text-center block">
                            Disponível em: Professional, Enterprise
                          </span>
                        ) : (
                          <button 
                            type="button"
                            className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2 py-1 rounded border border-rose-500/20 hover:bg-rose-500/20 text-center block w-full transition"
                          >
                            Faça upgrade para o plano "Professional" para acessar
                          </button>
                        )}
                      </div>
                    );
                  })()}

                  {/* Item 4: IA */}
                  {(() => {
                    const isUnlocked = isResourceUnlocked('res-ai-gate', tenant.planTier);
                    return (
                      <div 
                        onClick={() => {
                          if (!isUnlocked) {
                            setPlanUpgradePrompt({
                              isOpen: true,
                              requiredPlan: 'Professional',
                              featureName: 'Inteligência Artificial: AI Gateway & Orquestração de Agentes'
                            });
                          }
                        }}
                        className={`border p-5 rounded-2xl space-y-3 flex flex-col justify-between cursor-pointer transition ${
                          isUnlocked 
                            ? 'bg-slate-950 border-slate-800/80' 
                            : 'bg-slate-950/40 border-rose-500/20 hover:border-rose-500/40'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex justify-between items-start gap-2">
                            <span className="text-xs font-bold text-white">4. Inteligência Artificial Avançada</span>
                            {isUnlocked ? (
                              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                                INCLUSO
                              </span>
                            ) : (
                              <span className="bg-rose-500/10 text-rose-400 border border-rose-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono flex items-center gap-1">
                                <Lock className="w-3 h-3" /> BLOQUEADO
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 leading-relaxed">
                            AI Gateway com múltiplos modelos e parametrização/disparo de agentes autônomos de auditoria cognitiva.
                          </p>
                        </div>
                        {isUnlocked ? (
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 text-center block">
                            Disponível em: Professional, Enterprise
                          </span>
                        ) : (
                          <button 
                            type="button"
                            className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2 py-1 rounded border border-rose-500/20 hover:bg-rose-500/20 text-center block w-full transition"
                          >
                            Faça upgrade para o plano "Professional" para acessar
                          </button>
                        )}
                      </div>
                    );
                  })()}

                  {/* Item 5: TI & Conectores */}
                  {(() => {
                    const isUnlocked = isResourceUnlocked('res-ti-conn', tenant.planTier);
                    return (
                      <div 
                        onClick={() => {
                          if (!isUnlocked) {
                            setPlanUpgradePrompt({
                              isOpen: true,
                              requiredPlan: 'Enterprise',
                              featureName: 'TI e Infraestrutura: Mapeamento de APIs customizadas (SAP S/4HANA, HubSpot)'
                            });
                          }
                        }}
                        className={`border p-5 rounded-2xl space-y-3 flex flex-col justify-between cursor-pointer transition ${
                          isUnlocked 
                            ? 'bg-slate-950 border-slate-800/80' 
                            : 'bg-slate-950/40 border-rose-500/20 hover:border-rose-500/40'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex justify-between items-start gap-2">
                            <span className="text-xs font-bold text-white">5. TI & Conectores de Dados</span>
                            {isUnlocked ? (
                              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                                INCLUSO
                              </span>
                            ) : (
                              <span className="bg-rose-500/10 text-rose-400 border border-rose-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono flex items-center gap-1">
                                <Lock className="w-3 h-3" /> BLOQUEADO
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 leading-relaxed">
                            Mapeamento de endpoints, criação e gerenciamento de conectores customizados de TI, SAP, HubSpot, Salesforce.
                          </p>
                        </div>
                        {isUnlocked ? (
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 text-center block">
                            Disponível em: Enterprise
                          </span>
                        ) : (
                          <button 
                            type="button"
                            className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2 py-1 rounded border border-rose-500/20 hover:bg-rose-500/20 text-center block w-full transition"
                          >
                            Faça upgrade para o plano "Enterprise" para acessar
                          </button>
                        )}
                      </div>
                    );
                  })()}

                  {/* Item 6: Governança */}
                  {(() => {
                    const isUnlocked = isResourceUnlocked('res-gov-iga', tenant.planTier);
                    return (
                      <div 
                        onClick={() => {
                          if (!isUnlocked) {
                            setPlanUpgradePrompt({
                              isOpen: true,
                              requiredPlan: 'Enterprise',
                              featureName: 'Governança & Risco: Políticas de Governança IGA e Pre-Ledger PRE'
                            });
                          }
                        }}
                        className={`border p-5 rounded-2xl space-y-3 flex flex-col justify-between cursor-pointer transition ${
                          isUnlocked 
                            ? 'bg-slate-950 border-slate-800/80' 
                            : 'bg-slate-950/40 border-rose-500/20 hover:border-rose-500/40'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex justify-between items-start gap-2">
                            <span className="text-xs font-bold text-white">6. Governança, Risco & IGA</span>
                            {isUnlocked ? (
                              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                                INCLUSO
                              </span>
                            ) : (
                              <span className="bg-rose-500/10 text-rose-400 border border-rose-500/30 text-[10px] font-bold px-2 py-0.5 rounded font-mono flex items-center gap-1">
                                <Lock className="w-3 h-3" /> BLOQUEADO
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 leading-relaxed">
                            Configuração de mitigação de alucinação, compliance normativo e auditoria criptográfica baseada em hashes Merkle.
                          </p>
                        </div>
                        {isUnlocked ? (
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 text-center block">
                            Disponível em: Enterprise
                          </span>
                        ) : (
                          <button 
                            type="button"
                            className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2 py-1 rounded border border-rose-500/20 hover:bg-rose-500/20 text-center block w-full transition"
                          >
                            Faça upgrade para o plano "Enterprise" para acessar
                          </button>
                        )}
                      </div>
                    );
                  })()}
                </div>
              </div>

              {/* Subscriptions Plan Alters */}
              <div className="quantum-card-glow rounded-2xl p-6 border border-slate-800 space-y-4">
                <div>
                  <h4 className="text-sm font-bold text-white">Gerenciamento e Alteração Dinâmica de Planos</h4>
                  <p className="text-xs text-slate-400">
                    Altere o plano corporativo da empresa do tenant instantaneamente clicando nos botões abaixo para avaliação do fluxo.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Starter Option */}
                  <div className={`p-4 rounded-xl border flex flex-col justify-between space-y-3 transition ${tenant.planTier.toLowerCase() === 'starter' ? 'bg-amber-500/5 border-amber-500/40 shadow-sm' : 'bg-slate-950 border-slate-900'}`}>
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-white">Plano Starter</span>
                        {tenant.planTier.toLowerCase() === 'starter' && <span className="text-[9px] font-bold font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded">Ativo</span>}
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Indicado para pequenas empresas. Cota de 5 usuários e módulos de Financeiro e Recursos Humanos ativados.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={tenant.planTier.toLowerCase() === 'starter'}
                      onClick={() => {
                        onUpgradePlan('Starter');
                        setSuccessMessage("Sua empresa agora opera sob o Plano Starter. Os limites de cotas e acessos foram reajustados para 5 usuários máximos.");
                      }}
                      className={`w-full py-2 rounded-lg text-[11px] font-bold transition text-center ${tenant.planTier.toLowerCase() === 'starter' ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed' : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black'}`}
                    >
                      {tenant.planTier.toLowerCase() === 'starter' ? 'Plano Ativo' : 'Mudar para Plano Starter'}
                    </button>
                  </div>

                  {/* Professional Option */}
                  <div className={`p-4 rounded-xl border flex flex-col justify-between space-y-3 transition ${tenant.planTier.toLowerCase() === 'professional' ? 'bg-amber-500/5 border-amber-500/40 shadow-sm' : 'bg-slate-950 border-slate-900'}`}>
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-white font-sans">Plano Professional</span>
                        {tenant.planTier.toLowerCase() === 'professional' && <span className="text-[9px] font-bold font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-sans">Ativo</span>}
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Para empresas em crescimento. Cota de 25 usuários, inclui Inteligência Artificial, Logística e Simulador Decisório.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={tenant.planTier.toLowerCase() === 'professional'}
                      onClick={() => {
                        onUpgradePlan('Professional');
                        setSuccessMessage("Sua empresa agora opera sob o Plano Professional. Os limites de cotas foram expandidos para 25 usuários máximos.");
                      }}
                      className={`w-full py-2 rounded-lg text-[11px] font-bold transition text-center ${tenant.planTier.toLowerCase() === 'professional' ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed' : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black'}`}
                    >
                      {tenant.planTier.toLowerCase() === 'professional' ? 'Plano Ativo' : 'Mudar para Plano Professional'}
                    </button>
                  </div>

                  {/* Enterprise Option */}
                  <div className={`p-4 rounded-xl border flex flex-col justify-between space-y-3 transition ${tenant.planTier.toLowerCase() === 'enterprise' ? 'bg-amber-500/5 border-amber-500/40 shadow-sm' : 'bg-slate-950 border-slate-900'}`}>
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-white font-sans">Plano Enterprise</span>
                        {tenant.planTier.toLowerCase() === 'enterprise' && <span className="text-[9px] font-bold font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-sans">Ativo</span>}
                      </div>
                      <p className="text-[10px] text-slate-400 font-sans">
                        Controle total corporativo. Cota de 100+ usuários, suporte para customização completa de APIs, Governança e auditoria Merkle.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={tenant.planTier.toLowerCase() === 'enterprise'}
                      onClick={() => {
                        onUpgradePlan('Enterprise');
                        setSuccessMessage("Sua empresa agora opera sob o Plano Enterprise (Acesso Total). Conectores de TI e Governança foram completamente desbloqueados.");
                      }}
                      className={`w-full py-2 rounded-lg text-[11px] font-bold transition text-center ${tenant.planTier.toLowerCase() === 'enterprise' ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed' : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black'}`}
                    >
                      {tenant.planTier.toLowerCase() === 'enterprise' ? 'Plano Ativo' : 'Mudar para Plano Enterprise'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: AI Specialty Selector by Area */}
      {activeTab === 'ai_specialists' && (
        <div className="space-y-6">
          <div className="quantum-card-glow rounded-3xl p-6 bg-slate-950/80 border border-slate-800 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-900">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-lg font-black text-white uppercase tracking-wider font-sans">
                    Configuração de Agentes de IA Especializados por Área
                  </h2>
                </div>
                <p className="text-xs text-slate-300 max-w-3xl">
                  Selecione e distribua as IAs mais qualificadas do PASQUARED-OS para cada departamento e fluxo de negócios específico. 
                  Sua escolha influenciará diretamente a precisão das tomadas de decisão e roteamento automatizado de processos.
                </p>
              </div>

              <div className="bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-xs font-mono font-bold px-3 py-1 rounded-full text-center">
                Ativo: Multi-Model Gateway
              </div>
            </div>

            {/* Department Selection Pills */}
            <div className="flex flex-wrap items-center gap-2">
              {SPECIALTY_AREAS.map(area => {
                const isSelected = selectedSpecialtyAreaId === area.id;
                return (
                  <button
                    key={area.id}
                    type="button"
                    onClick={() => setSelectedSpecialtyAreaId(area.id)}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                      isSelected
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                        : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-900 hover:bg-slate-900'
                    }`}
                  >
                    <span>{area.id === 'logistica' ? '🚚' : area.id === 'rh' ? '👥' : area.id === 'financas' ? '📊' : '⚖️'}</span>
                    <span>{area.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Department Detail & Functions List */}
          {(() => {
            const currentArea = SPECIALTY_AREAS.find(a => a.id === selectedSpecialtyAreaId);
            if (!currentArea) return null;

            return (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Side Info Panel */}
                <div className="lg:col-span-4 quantum-card-glow rounded-3xl p-5 bg-slate-950/80 border border-slate-800 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5 uppercase tracking-wider font-mono">
                    <span>Sobre o Departamento</span>
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {currentArea.description}
                  </p>

                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-2 text-xs text-slate-400">
                    <div className="text-white font-bold font-mono text-[10px] uppercase text-emerald-400 tracking-wider">
                      🎯 Instrução para Roteamento:
                    </div>
                    <p className="leading-relaxed">
                      Todas as consultas operacionais enviadas por colaboradores do departamento <strong className="text-slate-200">"{currentArea.name}"</strong> serão interpretadas de acordo com as diretrizes e pesos da IA especializada escolhida abaixo.
                    </p>
                  </div>

                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-2 text-xs">
                    <span className="text-[10px] text-amber-400 font-bold block uppercase tracking-wider font-mono">Governança Cognitiva:</span>
                    <p className="text-slate-300 text-xs">
                      O Kernel EKO valida as saídas das IAs especialistas aplicando a Poda MVED para mitigar alucinações e auditar com SHA-256 no Pre-Ledger PRE.
                    </p>
                  </div>
                </div>

                {/* Functions Mapping Content */}
                <div className="lg:col-span-8 space-y-4">
                  {currentArea.functions.map(func => {
                    const selectedAgentId = activeAIs[func.id] || func.defaultAgentId;
                    const selectedAgent = func.agents.find(a => a.id === selectedAgentId) || func.agents[0];

                    return (
                      <div key={func.id} className="quantum-card-glow rounded-3xl p-5 sm:p-6 bg-slate-950/80 border border-slate-800 space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                          <div className="space-y-1">
                            <h4 className="text-sm font-bold text-white font-sans">{func.name}</h4>
                            <p className="text-xs text-slate-400 leading-relaxed">{func.description}</p>
                          </div>

                          {/* Agent Dropdown Selector */}
                          <div className="shrink-0 min-w-[220px]">
                            <label className="block text-[10px] font-mono font-bold text-emerald-400 mb-1 uppercase tracking-wider">
                              Escolher Agente de IA:
                            </label>
                            <select
                              value={selectedAgentId}
                              onChange={(e) => handleSelectAgentForFunction(func.id, e.target.value)}
                              className="w-full bg-slate-900 border border-emerald-500/30 rounded-xl px-3 py-2 text-xs text-emerald-300 focus:outline-none focus:border-emerald-400 font-semibold cursor-pointer animate-none"
                            >
                              {func.agents.map(agent => (
                                <option key={agent.id} value={agent.id}>
                                  🤖 {agent.name}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        {/* Active Agent Tech Spec Detail card */}
                        <div className="bg-slate-900/60 rounded-2xl p-4 border border-slate-850 space-y-3 font-sans">
                          <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-900/60">
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                              <span className="text-xs font-black text-white">{selectedAgent.name}</span>
                            </div>
                            <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 px-2 py-0.5 rounded">
                              Provedor: {selectedAgent.provider}
                            </span>
                          </div>

                          <p className="text-xs text-slate-300 leading-relaxed">
                            {selectedAgent.description}
                          </p>

                          <div className="grid grid-cols-2 gap-3 text-xs font-mono pt-1">
                            <div className="bg-slate-950 p-2 rounded-xl border border-slate-900">
                              <span className="text-[9px] text-slate-500 block uppercase tracking-wider">Acurácia Esperada:</span>
                              <strong className="text-emerald-400 font-bold">{selectedAgent.accuracy}</strong>
                            </div>
                            <div className="bg-slate-950 p-2 rounded-xl border border-slate-900">
                              <span className="text-[9px] text-slate-500 block uppercase tracking-wider">Foco Técnico:</span>
                              <strong className="text-cyan-300 font-bold text-[10px] truncate block">{selectedAgent.focus}</strong>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Dynamic Plan Upgrade Prompt Modal */}
      {planUpgradePrompt.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#0b1324] border border-amber-500/30 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-[0_0_40px_rgba(245,158,11,0.15)]">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                  <Lock className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider font-sans">Recurso Bloqueado</h3>
                  <p className="text-[10px] text-slate-400 font-mono">Requer Plano {planUpgradePrompt.requiredPlan}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPlanUpgradePrompt(prev => ({ ...prev, isOpen: false }))}
                className="text-slate-400 hover:text-slate-200 font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <p className="text-xs text-slate-300">
                A funcionalidade <strong className="text-white">"{planUpgradePrompt.featureName}"</strong> não está inclusa no seu plano atual (<strong className="text-amber-400">{tenant.planTier}</strong>).
              </p>
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl space-y-1.5 text-xs">
                <span className="text-[10px] text-amber-300 font-bold block uppercase tracking-wider font-mono">Mensagem do Sistema:</span>
                <p className="text-slate-300 font-medium leading-relaxed">
                  Faça upgrade para o plano "{planUpgradePrompt.requiredPlan}" para acessar esta funcionalidade.
                </p>
              </div>
            </div>

            <div className="flex gap-2 font-sans pt-2">
              <button
                type="button"
                onClick={() => setPlanUpgradePrompt(prev => ({ ...prev, isOpen: false }))}
                className="flex-1 bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold py-2.5 rounded-xl border border-slate-800 text-xs transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onUpgradePlan(planUpgradePrompt.requiredPlan);
                  setPlanUpgradePrompt(prev => ({ ...prev, isOpen: false }));
                  setSuccessMessage(`Upgrade para o plano "${planUpgradePrompt.requiredPlan}" realizado com sucesso! Todos os recursos correspondentes foram liberados para gerenciamento.`);
                }}
                className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/20 transition"
              >
                <Check className="w-4 h-4" />
                <span>Ativar Plano {planUpgradePrompt.requiredPlan}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <OperationsManualModal
        isOpen={isLocalManualOpen}
        onClose={() => setIsLocalManualOpen(false)}
      />
    </div>
  );
};
