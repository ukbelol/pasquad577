import React from 'react';
import {
  LayoutDashboard,
  Cpu,
  Terminal,
  BrainCircuit,
  Bot,
  Database,
  ShieldAlert,
  SlidersHorizontal,
  FileCheck,
  Scale,
  Workflow,
  ScrollText,
  ShieldCheck,
  Users,
  CreditCard,
  Webhook,
  Activity,
  Boxes,
  Zap,
  Building2,
  Lock,
  Radio,
  Sliders,
  BookOpen
} from 'lucide-react';

export type ActiveModule =
  | 'dashboard'
  | 'enterprise_feeder'
  | 'company_portal'
  | 'kernel'
  | 'pql'
  | 'decision'
  | 'gateway'
  | 'agents'
  | 'knowledge'
  | 'policies'
  | 'risk'
  | 'compliance'
  | 'workflows'
  | 'audit'
  | 'superadmin'
  | 'calibration'
  | 'tenants'
  | 'billing'
  | 'integrations';

interface SidebarProps {
  activeModule: ActiveModule;
  onSelectModule: (mod: ActiveModule) => void;
  isSuperAdmin: boolean;
  activeRiskCount: number;
  pendingApprovalsCount: number;
  onOpenCompanyPortal?: () => void;
  onOpenManual?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule,
  onSelectModule,
  isSuperAdmin,
  activeRiskCount,
  pendingApprovalsCount,
  onOpenCompanyPortal,
  onOpenManual
}) => {
  const sections = [
    {
      title: 'EMPRESAS & RECURSOS DE TI',
      items: [
        {
          id: 'enterprise_feeder' as ActiveModule,
          label: 'Gestão de Recursos & Dados TI',
          icon: Zap,
          badge: 'Decisão',
          badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
        },
        {
          id: 'company_portal' as ActiveModule,
          label: 'Portal & Cadastro de Empresas',
          icon: Building2,
          badge: 'Onboarding',
          badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
        },
        { id: 'dashboard' as ActiveModule, label: 'Dashboard Executivo', icon: LayoutDashboard }
      ]
    },
    {
      title: 'CORE & COGNITIVO',
      items: [
        { id: 'kernel' as ActiveModule, label: 'PASQUARED-OS Kernel', icon: Cpu, badge: 'PCK v1' },
        { id: 'pql' as ActiveModule, label: 'PQL Console', icon: Terminal },
        { id: 'decision' as ActiveModule, label: 'Decision Intelligence', icon: BrainCircuit }
      ]
    },
    {
      title: 'IA & AGENTES',
      items: [
        { id: 'gateway' as ActiveModule, label: 'AI Gateway (Multi-Model)', icon: Boxes, badge: '5 Provedores' },
        { id: 'agents' as ActiveModule, label: 'AI Agents Orquestrados', icon: Bot },
        { id: 'knowledge' as ActiveModule, label: 'Knowledge Base & UCL', icon: Database }
      ]
    },
    {
      title: 'GOVERNANÇA & RISCO',
      items: [
        {
          id: 'policies' as ActiveModule,
          label: 'Governança & Políticas',
          icon: ShieldCheck,
          badgeCount: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined,
          badgeColor: 'bg-amber-500'
        },
        {
          id: 'risk' as ActiveModule,
          label: 'Risk Management 5x5',
          icon: ShieldAlert,
          badgeCount: activeRiskCount > 0 ? activeRiskCount : undefined,
          badgeColor: 'bg-rose-500'
        },
        { id: 'compliance' as ActiveModule, label: 'Compliance (EU AI / ISO)', icon: FileCheck },
        { id: 'workflows' as ActiveModule, label: 'Workflow Automation', icon: Workflow },
        { id: 'audit' as ActiveModule, label: 'Audit Trail Imutável (PRE)', icon: ScrollText }
      ]
    },
    {
      title: 'ÁREA RESTRITA & ADMINISTRAÇÃO',
      items: [
        {
          id: 'superadmin' as ActiveModule,
          label: 'Área Super Admin',
          icon: Scale,
          badge: isSuperAdmin ? 'ROOT' : 'Restrita',
          badgeColor: isSuperAdmin
            ? 'bg-amber-500/30 text-amber-300 border-amber-500/40 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
            : 'bg-slate-900 text-slate-400 border-slate-800'
        },
        { id: 'calibration' as ActiveModule, label: 'Calibração & Parâmetros', icon: SlidersHorizontal },
        { id: 'tenants' as ActiveModule, label: 'Tenants & RBAC', icon: Users },
        { id: 'billing' as ActiveModule, label: 'Planos & Quotas', icon: CreditCard },
        { id: 'integrations' as ActiveModule, label: 'Integrações & Webhooks', icon: Webhook }
      ]
    }
  ];

  return (
    <aside className="w-64 bg-[#030d1a]/95 border-r border-cyan-500/20 flex flex-col h-[calc(100vh-4rem)] select-none shrink-0 overflow-y-auto custom-scrollbar backdrop-blur-sm">
      <div className="p-4 space-y-6">
        {sections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-1">
            <h3 className="px-3 text-[10px] font-bold uppercase tracking-wider text-cyan-400/70 font-mono">
              {section.title}
            </h3>
            <div className="space-y-0.5 mt-1.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeModule === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (item.id === 'company_portal' && onOpenCompanyPortal) {
                        onOpenCompanyPortal();
                      } else {
                        onSelectModule(item.id);
                      }
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-500/25 border border-cyan-400/40'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-white' : 'text-cyan-400/70'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded-md border font-mono ${
                          item.badgeColor ||
                          (isActive
                            ? 'bg-cyan-700/50 text-cyan-100 border-cyan-400/50'
                            : 'bg-slate-900 text-slate-400 border-slate-800')
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}

                    {item.badgeCount !== undefined && (
                      <span
                        className={`text-[10px] font-bold text-white px-1.5 py-0.2 rounded-full ${
                          item.badgeColor || 'bg-cyan-500'
                        }`}
                      >
                        {item.badgeCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Manual de Operação Button */}
      {onOpenManual && (
        <div className="px-4 pt-2">
          <button
            onClick={onOpenManual}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,240,255,0.15)] transition"
          >
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-cyan-400" />
              <span>Manual de Operação</span>
            </div>
            <span className="text-[10px] font-mono bg-cyan-500/20 px-1.5 py-0.5 rounded text-cyan-200">
              Guia
            </span>
          </button>
        </div>
      )}

      {/* Cluster telemetry mini card at bottom of sidebar */}
      <div className="mt-auto p-4 border-t border-cyan-500/20 bg-slate-950/60">
        <div className="quantum-card-glow rounded-xl p-3">
          <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
            <span className="flex items-center gap-1.5 font-semibold text-cyan-300">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              Nós Quânticos K8s
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">5/5 Online</span>
          </div>
          <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mb-2 border border-slate-800">
            <div className="bg-gradient-to-r from-cyan-400 via-blue-500 to-emerald-400 h-full w-[92%] shadow-[0_0_8px_rgba(0,240,255,0.6)]"></div>
          </div>
          <p className="text-[10px] text-slate-400 font-mono">
            SSL Certbot • Apache 2 • PostgreSQL • Qdrant • Redis
          </p>
        </div>
      </div>
    </aside>
  );
};
