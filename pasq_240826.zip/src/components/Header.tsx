import React from 'react';
import {
  Shield,
  Activity,
  Layers,
  Terminal,
  Download,
  Sliders,
  LogOut,
  UserCheck,
  Building2,
  CheckCircle2,
  Lock,
  Zap,
  SlidersHorizontal,
  Globe,
  BookOpen
} from 'lucide-react';
import { Tenant, ObserverProfile, User } from '../types/pasquared';
import { PasquaredLogo } from './PasquaredLogo';

interface HeaderProps {
  currentTenant: Tenant;
  tenants: Tenant[];
  onSelectTenant: (tenant: Tenant) => void;
  currentObserver: ObserverProfile;
  observers: ObserverProfile[];
  onSelectObserver: (obs: ObserverProfile) => void;
  currentUser: User | null;
  onOpenAuth: () => void;
  onOpenCompanyPortal: () => void;
  onOpenInstaller: () => void;
  onOpenPQL: () => void;
  onOpenCalibrator: () => void;
  onNavigateToEnterpriseFeeder: () => void;
  onNavigateToSuperAdmin: () => void;
  onOpenManual?: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTenant,
  tenants,
  onSelectTenant,
  currentObserver,
  observers,
  onSelectObserver,
  currentUser,
  onOpenAuth,
  onOpenCompanyPortal,
  onOpenInstaller,
  onOpenPQL,
  onOpenCalibrator,
  onNavigateToEnterpriseFeeder,
  onNavigateToSuperAdmin,
  onOpenManual,
  onLogout
}) => {
  return (
    <header className="h-16 bg-[#030d1a]/95 border-b border-cyan-500/20 px-4 md:px-6 flex items-center justify-between z-30 sticky top-0 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
      {/* Brand & Logo with img/logo-pasq.png */}
      <div className="flex items-center gap-3">
        <PasquaredLogo size="md" />
      </div>

      {/* Center Controls: Tenant & Observer Selector */}
      <div className="hidden lg:flex items-center gap-3">
        {/* Tenant Selector */}
        <div className="flex items-center bg-slate-950/80 border border-cyan-500/30 rounded-xl px-3 py-1.5 text-xs text-slate-200 shadow-inner">
          <Building2 className="w-3.5 h-3.5 text-cyan-400 mr-2" />
          <span className="text-slate-400 mr-1.5">Tenant:</span>
          <select
            value={currentTenant.id}
            onChange={(e) => {
              const found = tenants.find(t => t.id === e.target.value);
              if (found) onSelectTenant(found);
            }}
            className="bg-transparent text-cyan-300 font-medium focus:outline-none cursor-pointer"
          >
            {tenants.map(t => (
              <option key={t.id} value={t.id} className="bg-slate-900 text-white">
                {t.name} ({t.tier})
              </option>
            ))}
          </select>
        </div>

        {/* Observer Profile Selector: O=(P,E,K,B) */}
        <div className="flex items-center bg-slate-950/80 border border-emerald-500/30 rounded-xl px-3 py-1.5 text-xs text-slate-200 shadow-inner" title="Perfil do Observador O=(P,E,K,B)">
          <UserCheck className="w-3.5 h-3.5 text-emerald-400 mr-2" />
          <span className="text-slate-400 mr-1.5">Observador:</span>
          <select
            value={currentObserver.id}
            onChange={(e) => {
              const found = observers.find(o => o.id === e.target.value);
              if (found) onSelectObserver(found);
            }}
            className="bg-transparent text-emerald-300 font-medium focus:outline-none cursor-pointer"
          >
            {observers.map(o => (
              <option key={o.id} value={o.id} className="bg-slate-900 text-white">
                {o.name} [P:{o.P.toFixed(2)} K:{o.K.toFixed(2)}]
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Right Quick Actions */}
      <div className="flex items-center gap-2">
        {/* Manual de Operação & Parametrização */}
        {onOpenManual && (
          <button
            onClick={onOpenManual}
            className="flex items-center gap-1.5 bg-slate-900/90 hover:bg-cyan-950/80 text-cyan-300 hover:text-white text-xs font-semibold px-3 py-2 rounded-xl border border-cyan-500/30 transition shadow-sm"
            title="Abrir Manual de Operação e Guia de Parametrização de Módulos"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Manual de Operação</span>
          </button>
        )}

        {/* Portal de Empresas (Login ou Cadastro) */}
        <button
          onClick={onOpenCompanyPortal}
          className="flex items-center gap-1.5 bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white text-xs font-bold px-3 py-2 rounded-xl shadow-md shadow-cyan-600/25 border border-cyan-400/40 transition"
          title="Login ou Cadastro de Novas Empresas no PASQUARED"
        >
          <Building2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Portal Empresas</span>
        </button>

        {/* Gestor de Recursos TI */}
        <button
          onClick={onNavigateToEnterpriseFeeder}
          className="hidden md:flex items-center gap-1.5 bg-slate-900/90 hover:bg-slate-800 text-cyan-300 hover:text-white text-xs font-medium px-3 py-2 rounded-xl border border-cyan-500/30 transition"
          title="Parametrizar Conectores e Alimentar o PASQUARED com Dados"
        >
          <Zap className="w-3.5 h-3.5 text-cyan-400" />
          <span>Recursos TI</span>
        </button>

        {/* PQL Console Button */}
        <button
          onClick={onOpenPQL}
          className="hidden xl:flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-medium px-3 py-2 rounded-xl border border-slate-800 transition"
          title="Abrir Console PQL (PASQUARED Query Language)"
        >
          <Terminal className="w-3.5 h-3.5 text-indigo-400" />
          <span>PQL</span>
        </button>

        {/* Calibrator */}
        <button
          onClick={onOpenCalibrator}
          className="hidden xl:flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-cyan-300 hover:text-white text-xs font-medium px-3 py-2 rounded-xl border border-slate-800 transition"
          title="Calibração de Parâmetros Decisórios"
        >
          <Sliders className="w-3.5 h-3.5 text-cyan-400" />
          <span>Calibrador</span>
        </button>

        {/* Installer & SSL Certbot */}
        <button
          onClick={onOpenInstaller}
          className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/40 text-xs font-medium px-3 py-2 rounded-xl shadow-sm transition"
          title="Gerar Instalador SSL Certbot para app.pasquared.space"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">SSL & Stack</span>
        </button>

        {/* Super Admin Restricted Zone Button */}
        <button
          onClick={onNavigateToSuperAdmin}
          className={`flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-xl border transition ${
            currentUser?.role === 'SuperAdmin'
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-[0_0_12px_rgba(245,158,11,0.25)]'
              : 'bg-slate-900/80 text-amber-400 border-amber-500/30 hover:bg-slate-800'
          }`}
          title="Área Restrita do Super Admin"
        >
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Super Admin</span>
        </button>

        {/* User Badge / Logout */}
        {currentUser && (
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="text-right hidden lg:block">
              <div className="text-xs font-medium text-white flex items-center gap-1 justify-end">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-cyan-400 font-mono">{currentUser.email}</div>
            </div>
            <button
              onClick={onLogout}
              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-xl transition"
              title="Encerrar Sessão"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
