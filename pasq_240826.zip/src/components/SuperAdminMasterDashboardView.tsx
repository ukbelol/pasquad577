import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';
import {
  Scale,
  Shield,
  Activity,
  Cpu,
  Server,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Boxes,
  Lock,
  Globe,
  SlidersHorizontal,
  Key,
  Mail,
  Zap,
  Terminal,
  Check,
  UserCheck,
  Building2,
  FileCode,
  ArrowRight,
  Database,
  Users,
  Settings,
  Trash2,
  Edit,
  Plus,
  AlertCircle,
  Eye,
  CreditCard,
  Layers,
  FileText,
  Phone,
  MapPin,
  Briefcase,
  ToggleLeft,
  ToggleRight,
  CheckSquare,
  XSquare,
  Sparkles,
  Download
} from 'lucide-react';
import {
  CognitiveCluster,
  AIGatewayModel,
  Tenant,
  CalibrationParams,
  User,
  TenantTier,
  TenantCadastralData,
  TenantAcquisitionData,
  TenantModulesConfig
} from '../types/pasquared';
import { globalPasquaredEngine } from '../core/pasquared-engine';
import { PasquaredLogo } from './PasquaredLogo';

interface SuperAdminMasterDashboardViewProps {
  clusters: CognitiveCluster[];
  models: AIGatewayModel[];
  tenants: Tenant[];
  onUpdateTenants?: (tenants: Tenant[]) => void;
  currentUser: User | null;
  onOpenInstaller: () => void;
  onAuthenticateSuperAdmin?: (user: User) => void;
  onBackToLanding?: () => void;
}

export const SuperAdminMasterDashboardView: React.FC<SuperAdminMasterDashboardViewProps> = ({
  clusters,
  models,
  tenants: initialTenantsList,
  onUpdateTenants,
  currentUser,
  onOpenInstaller,
  onAuthenticateSuperAdmin,
  onBackToLanding
}) => {
  const isSuperAdmin = currentUser?.role === 'SuperAdmin';

  // Super Admin Master Key Authentication State
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  // Tabs for the master dashboard
  const [activeTab, setActiveTab] = useState<
    'monitoring' | 'tenants_mgmt' | 'active_plans_acquisition' | 'gateways_infra' | 'ssl_certbot' | 'calibration'
  >('tenants_mgmt');

  // Tenants Management state
  const [tenants, setTenants] = useState<Tenant[]>(initialTenantsList);
  const [selectedTenantForDossier, setSelectedTenantForDossier] = useState<Tenant | null>(null);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [deletingTenantId, setDeletingTenantId] = useState<string | null>(null);
  const [showAddTenantModal, setShowAddTenantModal] = useState(false);
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);

  // New Tenant Form state
  const [newRazaoSocial, setNewRazaoSocial] = useState('');
  const [newNomeFantasia, setNewNomeFantasia] = useState('');
  const [newCnpj, setNewCnpj] = useState('');
  const [newSetor, setNewSetor] = useState('Tecnologia & IA');
  const [newPorte, setNewPorte] = useState('Enterprise Global');
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPhone, setNewAdminPhone] = useState('');
  const [newTenantTier, setNewTenantTier] = useState<TenantTier>('Enterprise');
  const [newTenantTokens, setNewTenantTokens] = useState(50000000);
  const [newContractValue, setNewContractValue] = useState('R$ 38.000,00 / mês');

  // Calibration state
  const [calibration, setCalibration] = useState<CalibrationParams>(globalPasquaredEngine.getCalibration());
  const [saveSuccess, setSaveSuccess] = useState(false);

  // SSL Live Manager State
  const [sslDomain, setSslDomain] = useState('app.pasquared.space');
  const [sslSecurityEmail, setSslSecurityEmail] = useState('rogermei577@gmail.com');
  const [isTestingSSL, setIsTestingSSL] = useState(false);
  const [sslLogs, setSslLogs] = useState<string[]>([
    'Certbot 2.9.0 (Debian 12 Bookworm / Apache 2.4)',
    'Certificate Path: /etc/letsencrypt/live/app.pasquared.space/fullchain.pem',
    'Private Key: /etc/letsencrypt/live/app.pasquared.space/privkey.pem',
    'Cipher Suite: TLS_AES_256_GCM_SHA384 / TLS 1.3 / HSTS Preload Enabled',
    'Status: VALID & ACTIVE (Expires in 89 days, Auto-renew cron active)',
    'Reverse Proxy: 127.0.0.1:3000 -> https://app.pasquared.space',
    'Admin Contact: rogermei577@gmail.com'
  ]);

  const showNotification = (msg: string) => {
    setActionSuccessMessage(msg);
    setTimeout(() => setActionSuccessMessage(null), 4000);
  };

  const handleSuperAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthenticating(true);
    setAuthError(null);

    setTimeout(() => {
      setIsAuthenticating(false);
      if (
        (adminEmail === 'roger577@pasquared.space' ||
          adminEmail === 'rogermei577@gmail.com' ||
          adminEmail.includes('admin')) &&
        adminPassword.length >= 4
      ) {
        const superAdminUser: User = {
          id: 'usr-superadmin-roger',
          tenantId: 'tenant-pasquared-root',
          name: 'Roger Mei (Super Admin Root)',
          email: adminEmail,
          role: 'SuperAdmin',
          department: 'Root Cognitive Infrastructure & Kernel Security',
          mfaEnabled: true,
          status: 'active'
        };
        if (onAuthenticateSuperAdmin) {
          onAuthenticateSuperAdmin(superAdminUser);
        }
      } else {
        setAuthError('Credenciais inválidas de Super Admin ou Senha Master incorreta.');
      }
    }, 600);
  };

  const handleRenewSSL = () => {
    setIsTestingSSL(true);
    setTimeout(() => {
      setIsTestingSSL(false);
      setSslLogs(prev => [
        `[${new Date().toLocaleTimeString()}] certbot renew --quiet --agree-tos -m ${sslSecurityEmail} -d ${sslDomain}`,
        `[${new Date().toLocaleTimeString()}] Let's Encrypt validation: HTTP-01 / DNS-01 challenge PASSED`,
        `[${new Date().toLocaleTimeString()}] Apache 2.4 graceful reload executed: SSL certificates reloaded seamlessly`,
        `[${new Date().toLocaleTimeString()}] Security Contact ${sslSecurityEmail} validated for ${sslDomain}`,
        ...prev
      ]);
      showNotification('Certificado SSL renovado e verificado com sucesso para app.pasquared.space!');
    }, 1200);
  };

  const handleSaveCalibration = () => {
    globalPasquaredEngine.updateCalibration(calibration);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
    showNotification('Parâmetros algorítmicos do Kernel atualizados.');
  };

  // Toggle Tenant Status (Ativar / Desativar)
  const handleToggleTenantStatus = (id: string) => {
    const updated = tenants.map(t => {
      if (t.id === id) {
        const nextStatus = (t.status === 'active' ? 'suspended' : 'active') as 'active' | 'suspended';
        return {
          ...t,
          status: nextStatus
        };
      }
      return t;
    });
    setTenants(updated);
    if (onUpdateTenants) onUpdateTenants(updated);
    showNotification(`Status do cliente alterado com sucesso.`);
  };

  // Delete Tenant
  const handleDeleteTenant = (id: string) => {
    const target = tenants.find(t => t.id === id);
    const updated = tenants.filter(t => t.id !== id);
    setTenants(updated);
    if (onUpdateTenants) onUpdateTenants(updated);
    setDeletingTenantId(null);
    if (selectedTenantForDossier?.id === id) setSelectedTenantForDossier(null);
    if (editingTenant?.id === id) setEditingTenant(null);
    showNotification(`Cliente "${target?.name || id}" excluído permanentemente da plataforma.`);
  };

  // Toggle Single Module for Tenant
  const handleToggleTenantModule = (tenantId: string, moduleKey: keyof TenantModulesConfig) => {
    const updated = tenants.map(t => {
      if (t.id === tenantId) {
        const currentModules = t.activeModules || {
          poko_kernel: true,
          mved_pruning: true,
          ai_gateway: true,
          ai_agents: true,
          governance_iga: true,
          risk_matrix_5x5: true,
          pre_ledger_audit: true,
          enterprise_connectors: true,
          algorithmic_calibration: true
        };
        return {
          ...t,
          activeModules: {
            ...currentModules,
            [moduleKey]: !currentModules[moduleKey]
          }
        };
      }
      return t;
    });
    setTenants(updated);
    if (onUpdateTenants) onUpdateTenants(updated);
    showNotification(`Módulo ${String(moduleKey)} atualizado para o cliente.`);
  };

  // Save Edited Tenant Cadastral Data
  const handleSaveEditedTenant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTenant) return;

    const updated = tenants.map(t => (t.id === editingTenant.id ? editingTenant : t));
    setTenants(updated);
    if (onUpdateTenants) onUpdateTenants(updated);
    setEditingTenant(null);
    showNotification(`Dados cadastrais de "${editingTenant.name}" salvos com sucesso!`);
  };

  // Create New Tenant
  const handleAddTenant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRazaoSocial.trim()) return;

    const name = newNomeFantasia.trim() || newRazaoSocial.trim();
    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, '-').substring(0, 25);
    
    const newT: Tenant = {
      id: `tenant-${Date.now().toString(36)}`,
      name: name,
      slug: slug,
      domain: `${slug}.com.br`,
      tier: newTenantTier,
      createdAt: new Date().toISOString(),
      status: 'active',
      quotas: {
        monthlyTokens: newTenantTokens,
        usedTokens: 0,
        maxAgents: newTenantTier === 'Starter' ? 5 : newTenantTier === 'Business' ? 20 : 50,
        usedAgents: 1,
        maxUsers: newTenantTier === 'Starter' ? 5 : newTenantTier === 'Business' ? 30 : 100,
        usedUsers: 1,
        maxStorageGB: newTenantTier === 'Starter' ? 20 : newTenantTier === 'Business' ? 250 : 1000,
        usedStorageGB: 0.2
      },
      clusterAllocations: ['clus-gov', 'clus-sec'],
      cadastralData: {
        razaoSocial: newRazaoSocial,
        nomeFantasia: name,
        cnpj: newCnpj || '00.000.000/0001-00',
        setor: newSetor,
        porte: newPorte,
        numColaboradores: '50 colaboradores',
        endereco: 'Av. Corporativa, 1000',
        cidade: 'São Paulo',
        estado: 'SP',
        pais: 'Brasil',
        adminName: newAdminName || 'Administrador Técnico',
        adminRole: 'Tech Lead / Head TI',
        adminEmail: newAdminEmail || `admin@${slug}.com.br`,
        adminPhone: newAdminPhone || '+55 11 99999-0000'
      },
      acquisitionData: {
        contractValueFormatted: newContractValue,
        billingCycle: 'monthly',
        contractStartDate: new Date().toISOString().split('T')[0],
        contractRenewalDate: new Date(Date.now() + 365 * 86400000).toISOString().split('T')[0],
        paymentStatus: 'paid',
        paymentMethod: 'Faturamento Corporativo Boleto D+30',
        slaLevel: newTenantTier === 'Dedicated/On-Prem' ? '99.999% Soberano' : '99.99% Enterprise'
      },
      activeModules: {
        poko_kernel: true,
        mved_pruning: true,
        ai_gateway: true,
        ai_agents: true,
        governance_iga: true,
        risk_matrix_5x5: true,
        pre_ledger_audit: true,
        enterprise_connectors: true,
        algorithmic_calibration: newTenantTier !== 'Starter'
      }
    };

    const updated = [newT, ...tenants];
    setTenants(updated);
    if (onUpdateTenants) onUpdateTenants(updated);
    setShowAddTenantModal(false);
    setNewRazaoSocial('');
    setNewNomeFantasia('');
    setNewCnpj('');
    setNewAdminName('');
    setNewAdminEmail('');
    setNewAdminPhone('');
    showNotification(`Empresa "${newT.name}" cadastrada e provisionada no cluster!`);
  };

  // Telemetry data
  const fullSystemMonitoringData = [
    { item: 'Cluster Medicina', carga: 68, memoriaRAM: 62, acuracia: 98.9, podamentoMVED: 95 },
    { item: 'Cluster Direito', carga: 55, memoriaRAM: 48, acuracia: 99.1, podamentoMVED: 97 },
    { item: 'Cluster Finanças', carga: 74, memoriaRAM: 71, acuracia: 99.6, podamentoMVED: 99 },
    { item: 'Cluster Governança', carga: 42, memoriaRAM: 38, acuracia: 99.4, podamentoMVED: 98 },
    { item: 'Cluster Ciberseg.', carga: 38, memoriaRAM: 35, acuracia: 99.9, podamentoMVED: 100 },
    { item: 'Gateway Gemini', carga: 72, memoriaRAM: 45, acuracia: 99.1, podamentoMVED: 98 },
    { item: 'Gateway Azure', carga: 65, memoriaRAM: 40, acuracia: 97.8, podamentoMVED: 94 },
    { item: 'Gateway Watsonx', carga: 48, memoriaRAM: 36, acuracia: 98.4, podamentoMVED: 96 }
  ];

  // RESTRICTED AREA GATE: If not Super Admin, show strict lock screen
  if (!isSuperAdmin) {
    return (
      <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
        {/* Header */}
        <header className="h-16 bg-[#030d1a]/95 border-b border-amber-500/20 px-4 sm:px-8 flex items-center justify-between z-30 sticky top-0">
          <div className="flex items-center gap-3">
            {onBackToLanding && (
              <button
                onClick={onBackToLanding}
                className="text-xs text-slate-400 hover:text-amber-300 transition p-1.5 rounded-lg hover:bg-slate-900"
              >
                ← Voltar à Apresentação
              </button>
            )}
            <PasquaredLogo size="md" />
          </div>
          <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full">
            ZONA DE SEGURANÇA ROOT
          </span>
        </header>

        {/* Lock Screen */}
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="quantum-card-glow rounded-3xl p-8 max-w-lg w-full space-y-6 text-center border-amber-500/40 relative overflow-hidden shadow-[0_0_60px_rgba(245,158,11,0.15)] animate-in fade-in">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[radial-gradient(circle_at_100%_0%,rgba(245,158,11,0.15),transparent_70%)] pointer-events-none" />

            {/* Logo and Lock Container */}
            <div className="flex justify-center mb-2">
              <PasquaredLogo size="xl" showText={false} />
            </div>

            <div className="space-y-2">
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-mono font-bold px-3 py-1 rounded-full uppercase tracking-widest">
                Área Restrita • Acesso Exclusivo Super Admin
              </span>
              <h2 className="text-2xl font-black text-white tracking-tight">
                Painel Mestre Root PASQUARED
              </h2>
              <p className="text-xs text-slate-300">
                Acesso de nível Root com controle global de cadastros, planos, cotas, clusters e certificados SSL Let's Encrypt.
              </p>
            </div>

            {authError && (
              <div className="p-3 bg-rose-950/70 border border-rose-500/40 rounded-xl text-xs text-rose-300 font-mono text-left">
                {authError}
              </div>
            )}

            <form onSubmit={handleSuperAdminLogin} className="space-y-4 text-left">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-amber-300 uppercase tracking-wider">
                  E-mail Super Admin:
                </label>
                <input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-amber-200 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-amber-300 uppercase tracking-wider">
                  Master Password / Token Criptográfico:
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-amber-200 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isAuthenticating}
                className="w-full bg-gradient-to-r from-amber-600 via-orange-600 to-amber-500 hover:opacity-95 text-slate-950 font-black text-xs py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-600/30 transition mt-2"
              >
                <Key className="w-4 h-4" />
                <span>{isAuthenticating ? 'Desbloqueando Kernel Root...' : 'Desbloquear Acesso Super Admin'}</span>
              </button>
            </form>

            <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 font-mono">
              Chave Master Ativa: <strong className="text-amber-300">roger577@pasquared.space</strong>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // RESTRICTED AREA UNLOCKED: FULL MASTER DASHBOARD
  return (
    <div className="p-4 sm:p-6 md:p-8 space-y-6 max-w-7xl mx-auto animate-in fade-in text-slate-100 font-sans">
      {/* Toast Action Notification */}
      {actionSuccessMessage && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-950/95 border border-emerald-500 text-emerald-200 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{actionSuccessMessage}</span>
        </div>
      )}

      {/* Super Admin Top Header */}
      <div className="quantum-card-glow rounded-3xl p-6 sm:p-8 relative overflow-hidden border-amber-500/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[radial-gradient(circle_at_100%_0%,rgba(245,158,11,0.15),transparent_70%)] pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start gap-4">
            <PasquaredLogo size="lg" showText={false} />
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  Painel Mestre Super Admin (Root Platform Command)
                </h1>
                <span className="bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full shadow-[0_0_12px_rgba(245,158,11,0.3)]">
                  SUPER ADMIN ROOT
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
                  SSL TLS 1.3 Ativo
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
                Controle central de clientes/tenants, cadastros corporativos, planos contratados, módulos ativos/inativos e gestor de certificados SSL para <strong>app.pasquared.space</strong>.
              </p>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 font-mono pt-1">
                <span>Super Admin: <strong className="text-amber-300">{currentUser?.name || 'Roger Mei'}</strong> (roger577@pasquared.space)</span>
                <span>•</span>
                <span>Tenants Cadastrados: <strong className="text-cyan-300">{tenants.length}</strong></span>
                <span>•</span>
                <span>Nós K8s: <strong className="text-emerald-300">{clusters.length}</strong></span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => setShowAddTenantModal(true)}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-amber-500/20 flex items-center gap-2 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Provisionar Novo Cliente</span>
            </button>

            <button
              onClick={onOpenInstaller}
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-cyan-600/30 flex items-center gap-2 transition"
            >
              <Terminal className="w-4 h-4" />
              <span>Instalador install-pasq.sh</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('tenants_mgmt')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'tenants_mgmt'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4 text-cyan-400" />
          <span>Gestão de Clientes & Cadastros ({tenants.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('active_plans_acquisition')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'active_plans_acquisition'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <CreditCard className="w-4 h-4 text-amber-400" />
          <span>Planos Ativos, Módulos & Aquisições</span>
        </button>

        <button
          onClick={() => setActiveTab('monitoring')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'monitoring'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Activity className="w-4 h-4 text-emerald-400" />
          <span>Monitoramento Global de Clusters</span>
        </button>

        <button
          onClick={() => setActiveTab('gateways_infra')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'gateways_infra'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Boxes className="w-4 h-4 text-indigo-400" />
          <span>Infraestrutura & AI Gateways</span>
        </button>

        <button
          onClick={() => setActiveTab('ssl_certbot')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'ssl_certbot'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Globe className="w-4 h-4 text-emerald-400" />
          <span>Gestor SSL Certbot (app.pasquared.space)</span>
        </button>

        <button
          onClick={() => setActiveTab('calibration')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
            activeTab === 'calibration'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4 text-rose-400" />
          <span>Calibração Quântica do Kernel</span>
        </button>
      </div>

      {/* TAB 1: Gestão de Clientes, Cadastros & Ações */}
      {activeTab === 'tenants_mgmt' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-cyan-400" />
                <span>Base Cadastral de Empresas & Isolamento Multi-Tenant</span>
              </h3>
              <p className="text-xs text-slate-400">
                Visualize dados cadastrais completos (CNPJ, DPO/TI, Razão Social), ative, desative, edite ou exclua tenants.
              </p>
            </div>

            <button
              onClick={() => setShowAddTenantModal(true)}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition self-start sm:self-auto shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Nova Empresa</span>
            </button>
          </div>

          {/* Tenants Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
            {tenants.map((t) => {
              const cData = t.cadastralData;
              const acqData = t.acquisitionData;
              return (
                <div
                  key={t.id}
                  className={`quantum-card-glow rounded-2xl p-5 space-y-4 border transition-all ${
                    t.status === 'active'
                      ? 'border-cyan-500/30 bg-slate-900/90'
                      : 'border-rose-500/30 bg-slate-950/90 opacity-90'
                  }`}
                >
                  {/* Top bar with Name, Tier & Status */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-white tracking-tight">{t.name}</h4>
                        <span className="bg-cyan-500/20 text-cyan-300 text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-cyan-500/30">
                          {t.tier}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 font-mono">
                        CNPJ: <strong className="text-slate-200">{cData?.cnpj || '12.345.678/0001-90'}</strong> • Slug: <span className="text-cyan-400">{t.slug}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleToggleTenantStatus(t.id)}
                        className={`text-[11px] font-mono font-bold px-2.5 py-1 rounded-full border transition flex items-center gap-1.5 ${
                          t.status === 'active'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                            : 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
                        }`}
                        title="Clique para ativar/desativar este cliente"
                      >
                        <span className={`w-2 h-2 rounded-full ${t.status === 'active' ? 'bg-emerald-400' : 'bg-rose-400'}`}></span>
                        <span>{t.status === 'active' ? 'ATIVO' : 'DESATIVADO'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Cadastral Summary Box */}
                  <div className="bg-slate-950/80 rounded-xl p-3.5 border border-slate-800 space-y-2 text-xs">
                    <div className="grid grid-cols-2 gap-2 text-slate-300">
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase font-mono">Setor & Porte:</span>
                        <strong className="text-slate-200">{cData?.setor || 'Tecnologia'} ({cData?.porte || 'Enterprise'})</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase font-mono">Admin Responsável:</span>
                        <strong className="text-cyan-300">{cData?.adminName || 'Admin TI'}</strong>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-slate-300 pt-1 border-t border-slate-900">
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase font-mono">E-mail Corporativo:</span>
                        <span className="text-slate-300 font-mono text-[11px] truncate block">{cData?.adminEmail || `admin@${t.slug}.com.br`}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px] uppercase font-mono">Telefone / WhatsApp:</span>
                        <span className="text-slate-300 font-mono text-[11px]">{cData?.adminPhone || '+55 11 98765-4321'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Quotas & Consumption Pill Bar */}
                  <div className="bg-slate-950/90 rounded-xl p-3 border border-slate-800/80 grid grid-cols-3 gap-2 text-center text-xs font-mono">
                    <div className="p-1.5 rounded-lg bg-slate-900/60">
                      <span className="text-[10px] text-slate-500 block">Tokens Mês</span>
                      <strong className="text-cyan-300">{(t.quotas.usedTokens / 1000000).toFixed(1)}M / {(t.quotas.monthlyTokens / 1000000).toFixed(0)}M</strong>
                    </div>
                    <div className="p-1.5 rounded-lg bg-slate-900/60">
                      <span className="text-[10px] text-slate-500 block">Usuários</span>
                      <strong className="text-emerald-300">{t.quotas.usedUsers} / {t.quotas.maxUsers}</strong>
                    </div>
                    <div className="p-1.5 rounded-lg bg-slate-900/60">
                      <span className="text-[10px] text-slate-500 block">Storage</span>
                      <strong className="text-amber-300">{t.quotas.usedStorageGB}GB / {t.quotas.maxStorageGB}GB</strong>
                    </div>
                  </div>

                  {/* Actions Row */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                    <button
                      onClick={() => setSelectedTenantForDossier(t)}
                      className="text-xs text-cyan-300 hover:text-cyan-200 bg-cyan-950/60 hover:bg-cyan-900/80 px-3 py-1.5 rounded-lg border border-cyan-500/30 flex items-center gap-1.5 transition font-semibold"
                    >
                      <Eye className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Visualizar Dossiê Completo</span>
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditingTenant(t)}
                        className="text-xs text-amber-300 hover:text-amber-200 bg-amber-950/60 hover:bg-amber-900/80 px-3 py-1.5 rounded-lg border border-amber-500/30 flex items-center gap-1.5 transition font-semibold"
                        title="Editar Dados Cadastrais e Cotas"
                      >
                        <Edit className="w-3.5 h-3.5 text-amber-400" />
                        <span>Editar</span>
                      </button>

                      <button
                        onClick={() => setDeletingTenantId(t.id)}
                        className="text-xs text-rose-300 hover:text-rose-200 bg-rose-950/60 hover:bg-rose-900/80 p-1.5 rounded-lg border border-rose-500/30 flex items-center gap-1.5 transition"
                        title="Excluir Tenant Permanentemente"
                      >
                        <Trash2 className="w-4 h-4 text-rose-400" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: Planos Ativos, Módulos & Dados de Aquisição do Sistema */}
      {activeTab === 'active_plans_acquisition' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-amber-400" />
                <span>Planos Ativos, Módulos Operacionais & Dados de Aquisição</span>
              </h3>
              <p className="text-xs text-slate-400">
                Lista detalhada dos módulos contratados/ativos por empresa, valores de assinatura, SLA e telemetria de consumo.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1.5 rounded-xl">
                MRR Global: <strong>R$ 140.400,00 / mês</strong>
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {tenants.map((t) => {
              const modules = t.activeModules || {
                poko_kernel: true,
                mved_pruning: true,
                ai_gateway: true,
                ai_agents: true,
                governance_iga: true,
                risk_matrix_5x5: true,
                pre_ledger_audit: true,
                enterprise_connectors: true,
                algorithmic_calibration: true
              };
              const acq = t.acquisitionData || {
                contractValueFormatted: 'R$ 38.000,00 / mês',
                billingCycle: 'monthly',
                contractStartDate: t.createdAt.split('T')[0],
                contractRenewalDate: '2027-01-15',
                paymentStatus: 'paid',
                paymentMethod: 'Boleto Corporativo D+30',
                slaLevel: '99.99% com suporte 24/7'
              };

              const moduleList: Array<{ key: keyof TenantModulesConfig; name: string; desc: string }> = [
                { key: 'poko_kernel', name: 'Kernel POKO (Ω)', desc: 'Ontologia e vetores cognitivos' },
                { key: 'mved_pruning', name: 'Poda MVED (ICI)', desc: 'Eliminação de alucinações' },
                { key: 'ai_gateway', name: 'Multi-Model AI Gateway', desc: 'Roteador universal multi-provedor' },
                { key: 'ai_agents', name: 'Agentes Orquestrados', desc: 'Fluxo investigativo e perguntas' },
                { key: 'governance_iga', name: 'Governança IGA & Políticas', desc: 'Limiares e barreiras de segurança' },
                { key: 'risk_matrix_5x5', name: 'Matriz de Risco 5x5', desc: 'Probabilidade × Impacto' },
                { key: 'pre_ledger_audit', name: 'Pre-Ledger PRE', desc: 'Trilha criptográfica imutável' },
                { key: 'enterprise_connectors', name: 'Conectores TI (SAP/SQL)', desc: 'Ingestão de dados corporativos' },
                { key: 'algorithmic_calibration', name: 'Calibração Algorítmica', desc: 'Ajuste fino de pesos α, β, ε' }
              ];

              return (
                <div key={t.id} className="quantum-card-glow rounded-2xl p-6 border border-slate-800 space-y-4">
                  {/* Top Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-white">{t.name}</h4>
                        <span className="bg-amber-500/20 text-amber-300 text-xs font-mono px-2.5 py-0.5 rounded border border-amber-500/30 font-bold">
                          Plano {t.tier}
                        </span>
                        <span className="bg-emerald-500/20 text-emerald-300 text-xs font-mono px-2 py-0.5 rounded border border-emerald-500/30">
                          {acq.paymentStatus === 'paid' ? 'PAGAMENTO EM DIA' : 'PENDENTE'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 font-mono mt-0.5">
                        Contrato: <strong className="text-amber-300">{acq.contractValueFormatted}</strong> ({acq.billingCycle}) • Início: {acq.contractStartDate} • Renovação: {acq.contractRenewalDate}
                      </p>
                    </div>

                    <div className="text-right font-mono text-xs text-slate-300">
                      <div>SLA Contratado: <strong className="text-cyan-300">{acq.slaLevel}</strong></div>
                      <div>Método: <span className="text-slate-400">{acq.paymentMethod}</span></div>
                    </div>
                  </div>

                  {/* Modules Matrix with Live Toggle */}
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                      Módulos do Sistema (Clique para Ativar / Desativar individualmente):
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                      {moduleList.map((m) => {
                        const isModActive = modules[m.key];
                        return (
                          <div
                            key={m.key}
                            onClick={() => handleToggleTenantModule(t.id, m.key)}
                            className={`p-2.5 rounded-xl border cursor-pointer transition flex items-start justify-between gap-2 ${
                              isModActive
                                ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-200'
                                : 'bg-slate-950 border-slate-800 text-slate-500 opacity-60 hover:opacity-100'
                            }`}
                          >
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5">
                                {isModActive ? (
                                  <CheckSquare className="w-3.5 h-3.5 text-cyan-400" />
                                ) : (
                                  <XSquare className="w-3.5 h-3.5 text-slate-600" />
                                )}
                                <span className={`text-xs font-bold ${isModActive ? 'text-white' : 'text-slate-400'}`}>
                                  {m.name}
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-400 block leading-tight">{m.desc}</span>
                            </div>

                            <span
                              className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${
                                isModActive ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-500'
                              }`}
                            >
                              {isModActive ? 'ATIVO' : 'OFF'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Live Consumption Row */}
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono text-slate-300">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Tokens Usados:</span>
                      <strong className="text-cyan-300">{t.quotas.usedTokens.toLocaleString()}</strong> / {t.quotas.monthlyTokens.toLocaleString()}
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Armazenamento:</span>
                      <strong className="text-amber-300">{t.quotas.usedStorageGB} GB</strong> / {t.quotas.maxStorageGB} GB
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Assentos de Usuários:</span>
                      <strong className="text-emerald-300">{t.quotas.usedUsers}</strong> / {t.quotas.maxUsers}
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Agentes de IA:</span>
                      <strong className="text-indigo-300">{t.quotas.usedAgents}</strong> / {t.quotas.maxAgents}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: Global Monitoring */}
      {activeTab === 'monitoring' && (
        <div className="space-y-6">
          <div className="quantum-card-glow rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white">Telemetria de Carga & Eficiência dos Clusters</h3>
                <p className="text-xs text-slate-400">
                  Desempenho em tempo real dos nós de inferência, taxa de podamento MVED e acurácia epistêmica.
                </p>
              </div>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-lg">
                Throughput: 4,820 req/s • Latência Média: 142ms
              </span>
            </div>

            <div className="h-80 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={fullSystemMonitoringData} margin={{ top: 10, right: 10, left: -20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="item" tick={{ fill: '#94a3b8', fontSize: 11 }} angle={-25} textAnchor="end" />
                  <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} domain={[0, 100]} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }} />
                  <Legend />
                  <Bar dataKey="carga" name="Carga (%)" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="memoriaRAM" name="Uso RAM (%)" fill="#818cf8" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="podamentoMVED" name="Poda MVED (%)" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Gateways & Compute Infrastructure */}
      {activeTab === 'gateways_infra' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Gateways de Modelos & Computação Distribuída</h3>
              <p className="text-xs text-slate-400">
                Status de comunicação dos provedores de IA e nós Kubernetes do Kernel.
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full">
              Todos os Provedores Conectados
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {models.map((m) => (
              <div key={m.id} className="quantum-card-glow rounded-2xl p-5 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
                      <Boxes className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{m.name}</h4>
                      <span className="text-[11px] text-cyan-300 font-mono uppercase">{m.provider}</span>
                    </div>
                  </div>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono px-2 py-0.5 rounded-full">
                    {m.status.toUpperCase()}
                  </span>
                </div>

                <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono text-slate-400">
                  <div>Latência: <strong className="text-cyan-300">{m.latencyMs}ms</strong></div>
                  <div>Custo/1k: <strong className="text-white">${m.costPer1kTokens}</strong></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: SSL Certbot Manager */}
      {activeTab === 'ssl_certbot' && (
        <div className="space-y-6">
          <div className="quantum-card-glow rounded-2xl p-6 space-y-6 border-amber-500/30">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-emerald-400" />
                  <span>Certificado SSL Let's Encrypt & Certbot (app.pasquared.space)</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Gerenciamento de chaves criptográficas SSL/TLS 1.3 para o domínio de produção e e-mail de segurança.
                </p>
              </div>

              <button
                onClick={handleRenewSSL}
                disabled={isTestingSSL}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition self-start sm:self-auto"
              >
                <RefreshCw className={`w-4 h-4 ${isTestingSSL ? 'animate-spin' : ''}`} />
                <span>{isTestingSSL ? 'Executando Certbot...' : 'Renovar Certificado SSL Agora'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
                <label className="text-xs font-semibold text-cyan-300">FQDN Domínio SSL:</label>
                <input
                  type="text"
                  value={sslDomain}
                  onChange={(e) => setSslDomain(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400"
                />
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
                <label className="text-xs font-semibold text-emerald-300">E-mail de Segurança Certbot:</label>
                <input
                  type="text"
                  value={sslSecurityEmail}
                  onChange={(e) => setSslSecurityEmail(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-emerald-300 focus:border-emerald-400"
                />
              </div>
            </div>

            {/* Live Logs Terminal */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-400">Log de Execução Certbot & Apache SSL:</span>
              <div className="bg-black/90 rounded-xl p-4 border border-slate-800 font-mono text-xs text-emerald-400 space-y-1 max-h-56 overflow-y-auto">
                {sslLogs.map((l, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-slate-600 select-none">&gt;</span>
                    <span>{l}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: Algorithmic Calibration */}
      {activeTab === 'calibration' && (
        <div className="space-y-6">
          <div className="quantum-card-glow rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white">Calibração Algorítmica do Kernel POKO</h3>
                <p className="text-xs text-slate-400">
                  Ajuste dos pesos da probabilidade de ativação cognitiva e tolerâncias de convergência.
                </p>
              </div>

              <button
                onClick={handleSaveCalibration}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-2 transition shadow-md self-start sm:self-auto"
              >
                <Check className="w-4 h-4" />
                <span>{saveSuccess ? 'Salvo no Kernel!' : 'Salvar Calibração Root'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-slate-400 font-semibold block">Peso Evidência (α):</span>
                <input
                  type="number"
                  step="0.05"
                  value={calibration.alpha}
                  onChange={(e) => setCalibration({ ...calibration, alpha: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-slate-400 font-semibold block">Contexto Local (β):</span>
                <input
                  type="number"
                  step="0.05"
                  value={calibration.beta}
                  onChange={(e) => setCalibration({ ...calibration, beta: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-slate-400 font-semibold block">Memória Histórica (γ):</span>
                <input
                  type="number"
                  step="0.05"
                  value={calibration.gamma}
                  onChange={(e) => setCalibration({ ...calibration, gamma: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-slate-400 font-semibold block">Salvaguarda / Risco (δ):</span>
                <input
                  type="number"
                  step="0.05"
                  value={calibration.delta}
                  onChange={(e) => setCalibration({ ...calibration, delta: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: Dossiê Cadastral Completo */}
      {selectedTenantForDossier && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#030d1a] border border-cyan-500/40 rounded-3xl p-6 sm:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto space-y-6 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-start border-b border-slate-800 pb-4">
              <div>
                <span className="bg-cyan-500/20 text-cyan-300 text-[10px] font-mono font-bold px-2.5 py-0.5 rounded border border-cyan-500/30">
                  DOSSIÊ CADASTRAL CORPORATIVO
                </span>
                <h3 className="text-xl font-bold text-white mt-1">{selectedTenantForDossier.name}</h3>
                <p className="text-xs text-slate-400 font-mono">ID Tenant: {selectedTenantForDossier.id}</p>
              </div>
              <button
                onClick={() => setSelectedTenantForDossier(null)}
                className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-900 hover:bg-slate-800 transition"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Dados da Empresa */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-cyan-300 text-sm flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  <span>Dados Cadastrais da Empresa</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-300">
                  <div><span className="text-slate-500 block text-[10px]">Razão Social:</span> <strong className="text-white">{selectedTenantForDossier.cadastralData?.razaoSocial || selectedTenantForDossier.name}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Nome Fantasia:</span> <strong className="text-white">{selectedTenantForDossier.cadastralData?.nomeFantasia || selectedTenantForDossier.name}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">CNPJ:</span> <strong className="text-amber-300 font-mono">{selectedTenantForDossier.cadastralData?.cnpj || '12.345.678/0001-90'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Inscrição Estadual:</span> <strong className="text-slate-300 font-mono">{selectedTenantForDossier.cadastralData?.inscricaoEstadual || 'Isento / Não inf.'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Setor de Atuação:</span> <strong className="text-slate-200">{selectedTenantForDossier.cadastralData?.setor || 'Tecnologia'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Porte da Empresa:</span> <strong className="text-slate-200">{selectedTenantForDossier.cadastralData?.porte || 'Enterprise'}</strong></div>
                  <div className="sm:col-span-2"><span className="text-slate-500 block text-[10px]">Endereço Completo:</span> <strong className="text-slate-300">{selectedTenantForDossier.cadastralData?.endereco || 'Av. Paulista, 2100'}, {selectedTenantForDossier.cadastralData?.cidade || 'São Paulo'}-{selectedTenantForDossier.cadastralData?.estado || 'SP'}, {selectedTenantForDossier.cadastralData?.pais || 'Brasil'}</strong></div>
                </div>
              </div>

              {/* Responsável Técnico & DPO */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-amber-300 text-sm flex items-center gap-2">
                  <UserCheck className="w-4 h-4" />
                  <span>Responsável Técnico / DPO / Administrador</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-300">
                  <div><span className="text-slate-500 block text-[10px]">Nome Completo:</span> <strong className="text-white">{selectedTenantForDossier.cadastralData?.adminName || 'Admin TI'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Cargo Corporativo:</span> <strong className="text-slate-200">{selectedTenantForDossier.cadastralData?.adminRole || 'CTO'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">E-mail Corporativo:</span> <strong className="text-cyan-300 font-mono">{selectedTenantForDossier.cadastralData?.adminEmail || `admin@${selectedTenantForDossier.slug}.com.br`}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Telefone / WhatsApp:</span> <strong className="text-slate-200 font-mono">{selectedTenantForDossier.cadastralData?.adminPhone || '+55 11 98765-4321'}</strong></div>
                </div>
              </div>

              {/* Dados de Aquisição e Contrato */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-emerald-300 text-sm flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  <span>Plano, Contrato & Aquisição</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-300">
                  <div><span className="text-slate-500 block text-[10px]">Tier / Plano:</span> <strong className="text-cyan-300">{selectedTenantForDossier.tier}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Valor do Contrato:</span> <strong className="text-amber-300">{selectedTenantForDossier.acquisitionData?.contractValueFormatted || 'R$ 38.000,00 / mês'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Data de Início:</span> <strong className="text-slate-200">{selectedTenantForDossier.acquisitionData?.contractStartDate || selectedTenantForDossier.createdAt.split('T')[0]}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Data de Renovação:</span> <strong className="text-slate-200">{selectedTenantForDossier.acquisitionData?.contractRenewalDate || '2027-01-15'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">SLA Garantido:</span> <strong className="text-emerald-400">{selectedTenantForDossier.acquisitionData?.slaLevel || '99.99%'}</strong></div>
                  <div><span className="text-slate-500 block text-[10px]">Status Financeiro:</span> <strong className="text-emerald-400 uppercase">{selectedTenantForDossier.acquisitionData?.paymentStatus || 'paid'}</strong></div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => {
                  setEditingTenant(selectedTenantForDossier);
                  setSelectedTenantForDossier(null);
                }}
                className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Editar estes Dados</span>
              </button>
              <button
                onClick={() => setSelectedTenantForDossier(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs rounded-xl transition"
              >
                Fechar Dossiê
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Editar / Salvar Dados Cadastrais */}
      {editingTenant && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#030d1a] border border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Edit className="w-4 h-4 text-amber-400" />
                <span>Editar Dados Cadastrais & Cotas • {editingTenant.name}</span>
              </h3>
              <button onClick={() => setEditingTenant(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSaveEditedTenant} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300">Razão Social:</label>
                  <input
                    type="text"
                    value={editingTenant.cadastralData?.razaoSocial || editingTenant.name}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      cadastralData: {
                        ...(editingTenant.cadastralData || {} as any),
                        razaoSocial: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Nome Fantasia:</label>
                  <input
                    type="text"
                    value={editingTenant.name}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      name: e.target.value,
                      cadastralData: {
                        ...(editingTenant.cadastralData || {} as any),
                        nomeFantasia: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">CNPJ / Tax ID:</label>
                  <input
                    type="text"
                    value={editingTenant.cadastralData?.cnpj || ''}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      cadastralData: {
                        ...(editingTenant.cadastralData || {} as any),
                        cnpj: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-amber-300 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Setor de Atuação:</label>
                  <input
                    type="text"
                    value={editingTenant.cadastralData?.setor || ''}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      cadastralData: {
                        ...(editingTenant.cadastralData || {} as any),
                        setor: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Admin Responsável / DPO:</label>
                  <input
                    type="text"
                    value={editingTenant.cadastralData?.adminName || ''}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      cadastralData: {
                        ...(editingTenant.cadastralData || {} as any),
                        adminName: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">E-mail Corporativo Admin:</label>
                  <input
                    type="email"
                    value={editingTenant.cadastralData?.adminEmail || ''}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      cadastralData: {
                        ...(editingTenant.cadastralData || {} as any),
                        adminEmail: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-cyan-300 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Telefone / WhatsApp:</label>
                  <input
                    type="text"
                    value={editingTenant.cadastralData?.adminPhone || ''}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      cadastralData: {
                        ...(editingTenant.cadastralData || {} as any),
                        adminPhone: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Plano / Tier:</label>
                  <select
                    value={editingTenant.tier}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      tier: e.target.value as TenantTier
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  >
                    <option value="Starter">Starter</option>
                    <option value="Business">Business</option>
                    <option value="Enterprise">Enterprise</option>
                    <option value="Dedicated/On-Prem">Dedicated / On-Prem (Quantum Soberano)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Cota Mensal de Tokens:</label>
                  <input
                    type="number"
                    value={editingTenant.quotas.monthlyTokens}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      quotas: {
                        ...editingTenant.quotas,
                        monthlyTokens: Number(e.target.value)
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Valor do Contrato:</label>
                  <input
                    type="text"
                    value={editingTenant.acquisitionData?.contractValueFormatted || 'R$ 38.000,00 / mês'}
                    onChange={(e) => setEditingTenant({
                      ...editingTenant,
                      acquisitionData: {
                        ...(editingTenant.acquisitionData || {} as any),
                        contractValueFormatted: e.target.value
                      }
                    })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-amber-300 font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingTenant(null)}
                  className="px-4 py-2 bg-slate-800 text-xs rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20"
                >
                  Salvar Dados Cadastrais
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Confirmação de Exclusão */}
      {deletingTenantId && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0f0408] border border-rose-500/50 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-in zoom-in-95 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center mx-auto shadow-[0_0_25px_rgba(244,63,94,0.3)]">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Excluir Empresa Permanentemente?</h3>
              <p className="text-xs text-slate-300">
                Esta ação removerá todas as cotas, configurações e chaves de acesso deste tenant da infraestrutura do Kernel.
              </p>
            </div>

            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingTenantId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs rounded-xl font-semibold transition"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleDeleteTenant(deletingTenantId)}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition"
              >
                Confirmar Exclusão
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: Provisionar Novo Cliente/Tenant */}
      {showAddTenantModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#040d1a] border border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-400" />
                <span>Provisionar Nova Empresa no PASQUARED</span>
              </h3>
              <button onClick={() => setShowAddTenantModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddTenant} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300">Razão Social:</label>
                  <input
                    type="text"
                    value={newRazaoSocial}
                    onChange={(e) => setNewRazaoSocial(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    placeholder="Ex: Sigma Tech Serviços S.A."
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Nome Fantasia:</label>
                  <input
                    type="text"
                    value={newNomeFantasia}
                    onChange={(e) => setNewNomeFantasia(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    placeholder="Ex: Sigma Tech"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">CNPJ / Tax ID:</label>
                  <input
                    type="text"
                    value={newCnpj}
                    onChange={(e) => setNewCnpj(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    placeholder="00.000.000/0001-00"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Setor de Atuação:</label>
                  <select
                    value={newSetor}
                    onChange={(e) => setNewSetor(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Tecnologia & IA">Tecnologia & IA</option>
                    <option value="Fintech & Bancário">Fintech & Bancário</option>
                    <option value="Saúde & Medicina">Saúde & Medicina</option>
                    <option value="Indústria 4.0">Indústria 4.0</option>
                    <option value="Varejo & E-commerce">Varejo & E-commerce</option>
                    <option value="Jurídico & Compliance">Jurídico & Compliance</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Admin Responsável / CTO:</label>
                  <input
                    type="text"
                    value={newAdminName}
                    onChange={(e) => setNewAdminName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                    placeholder="Nome do Administrador Técnico"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">E-mail Corporativo Admin:</label>
                  <input
                    type="email"
                    value={newAdminEmail}
                    onChange={(e) => setNewAdminEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-cyan-300 font-mono"
                    placeholder="admin@empresa.com.br"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Telefone / WhatsApp:</label>
                  <input
                    type="text"
                    value={newAdminPhone}
                    onChange={(e) => setNewAdminPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                    placeholder="+55 11 99999-0000"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Plano / Tier:</label>
                  <select
                    value={newTenantTier}
                    onChange={(e) => setNewTenantTier(e.target.value as TenantTier)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  >
                    <option value="Starter">Starter (R$ 4.900/mês)</option>
                    <option value="Business">Business (R$ 14.500/mês)</option>
                    <option value="Enterprise">Enterprise (R$ 38.000/mês)</option>
                    <option value="Dedicated/On-Prem">Dedicated On-Prem Soberano (R$ 75.000/mês)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Cota Mensal de Tokens:</label>
                  <input
                    type="number"
                    value={newTenantTokens}
                    onChange={(e) => setNewTenantTokens(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Valor de Faturamento:</label>
                  <input
                    type="text"
                    value={newContractValue}
                    onChange={(e) => setNewContractValue(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-amber-300 font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddTenantModal(false)}
                  className="px-4 py-2 bg-slate-900 text-xs rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20"
                >
                  Provisionar Empresa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
