import React, { useState, useEffect, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import {
  Activity,
  Zap,
  Clock,
  Cpu,
  RefreshCw,
  Play,
  Pause,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  AlertCircle,
  Server,
  Layers,
  BarChart3,
  Gauge,
  Sliders,
  Download,
  Wifi
} from 'lucide-react';
import { Tenant } from '../types/pasquared';

interface HealthDataPoint {
  time: string;
  timestamp: number;
  apiLatency: number;
  p95Latency: number;
  tokenThroughput: number;
  systemRps: number;
  kernelDecisionsPerSec: number;
  mvedPrunedPerSec: number;
  geminiLatency: number;
  azureLatency: number;
  ibmLatency: number;
  localLatency: number;
}

interface DashboardWidgetProps {
  tenant?: Tenant;
  onNavigateToGateway?: () => void;
  onNavigateToKernel?: () => void;
}

export const DashboardWidget: React.FC<DashboardWidgetProps> = ({
  tenant,
  onNavigateToGateway,
  onNavigateToKernel
}) => {
  const [isLive, setIsLive] = useState<boolean>(true);
  const [refreshIntervalMs, setRefreshIntervalMs] = useState<number>(2000);
  const [activeTab, setActiveTab] = useState<'overview' | 'latency' | 'tokens' | 'throughput'>('overview');
  const [isPinging, setIsPinging] = useState<boolean>(false);
  const [lastPingStatus, setLastPingStatus] = useState<string | null>(null);

  // Generate initial historical points (last 20 points)
  const initialHistory = useMemo(() => {
    const points: HealthDataPoint[] = [];
    const now = Date.now();
    for (let i = 20; i >= 0; i--) {
      const t = new Date(now - i * 2000);
      const timeStr = t.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const baseLat = 135 + Math.sin(i * 0.5) * 20;
      points.push({
        time: timeStr,
        timestamp: t.getTime(),
        apiLatency: Math.round(baseLat + (Math.random() * 25 - 12)),
        p95Latency: Math.round(baseLat * 1.6 + (Math.random() * 30 - 15)),
        tokenThroughput: Math.round(4200 + Math.sin(i * 0.8) * 800 + Math.random() * 400),
        systemRps: Math.round(140 + Math.sin(i * 0.4) * 35 + Math.random() * 15),
        kernelDecisionsPerSec: Math.round(35 + Math.sin(i * 0.4) * 8 + Math.random() * 4),
        mvedPrunedPerSec: Math.round(11 + Math.random() * 5),
        geminiLatency: Math.round(110 + Math.random() * 20),
        azureLatency: Math.round(260 + Math.random() * 40),
        ibmLatency: Math.round(180 + Math.random() * 30),
        localLatency: Math.round(42 + Math.random() * 12)
      });
    }
    return points;
  }, []);

  const [history, setHistory] = useState<HealthDataPoint[]>(initialHistory);

  // Live real-time metric updates
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      
      setHistory(prev => {
        const last = prev[prev.length - 1] || initialHistory[0];
        // subtle random walk for realism
        const newLat = Math.max(85, Math.min(260, Math.round(last.apiLatency + (Math.random() * 24 - 12))));
        const newP95 = Math.round(newLat * 1.55 + (Math.random() * 20 - 10));
        const newTokens = Math.max(2800, Math.min(6500, Math.round(last.tokenThroughput + (Math.random() * 400 - 200))));
        const newRps = Math.max(80, Math.min(220, Math.round(last.systemRps + (Math.random() * 16 - 8))));
        const newKernel = Math.max(20, Math.min(60, Math.round(newRps * 0.26 + Math.random() * 4)));
        const newMved = Math.max(6, Math.min(25, Math.round(newKernel * 0.32 + Math.random() * 2)));

        const newPoint: HealthDataPoint = {
          time: timeStr,
          timestamp: now.getTime(),
          apiLatency: newLat,
          p95Latency: newP95,
          tokenThroughput: newTokens,
          systemRps: newRps,
          kernelDecisionsPerSec: newKernel,
          mvedPrunedPerSec: newMved,
          geminiLatency: Math.round(105 + Math.random() * 25),
          azureLatency: Math.round(250 + Math.random() * 45),
          ibmLatency: Math.round(175 + Math.random() * 30),
          localLatency: Math.round(40 + Math.random() * 14)
        };

        // Keep maximum 25 items in buffer
        return [...prev.slice(1), newPoint];
      });
    }, refreshIntervalMs);

    return () => clearInterval(interval);
  }, [isLive, refreshIntervalMs, initialHistory]);

  const currentMetric = history[history.length - 1] || initialHistory[0];
  const previousMetric = history[history.length - 2] || currentMetric;

  const latencyDelta = currentMetric.apiLatency - previousMetric.apiLatency;
  const tokenDelta = currentMetric.tokenThroughput - previousMetric.tokenThroughput;
  const rpsDelta = currentMetric.systemRps - previousMetric.systemRps;

  // Synthetic ping diagnostic
  const handleSyntheticPing = () => {
    setIsPinging(true);
    setLastPingStatus('Enviando sondas de integridade para 4 clusters...');
    setTimeout(() => {
      setIsPinging(false);
      setLastPingStatus(`Ping OK: 4/4 provedores saudáveis (Ronda completa em ${currentMetric.apiLatency}ms)`);
      setTimeout(() => setLastPingStatus(null), 5000);
    }, 900);
  };

  // Export telemetry snapshot
  const handleExportTelemetry = () => {
    const exportData = {
      tenant: tenant?.name || 'Default Tenant',
      generatedAt: new Date().toISOString(),
      currentSnapshot: currentMetric,
      historicalPoints: history
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pasquared-telemetry-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div id="dashboard-health-widget" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
      {/* Header bar of the widget */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white tracking-tight">
                Métricas de Saúde & Telemetria em Tempo Real
              </h3>
              <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium ${
                isLive
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                  : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${isLive ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`}></span>
                {isLive ? 'STREAM ATIVO' : 'PAUSADO'}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Monitoramento contínuo de latência da API, vazão de tokens e throughput do PASQUARED-OS.
            </p>
          </div>
        </div>

        {/* Action and controls toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Pause / Resume Button */}
          <button
            onClick={() => setIsLive(!isLive)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition border ${
              isLive
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500'
            }`}
            title={isLive ? 'Pausar atualização em tempo real' : 'Retomar fluxo'}
          >
            {isLive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isLive ? 'Pausar' : 'Retomar'}</span>
          </button>

          {/* Interval selector */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
            <span className="px-2 text-slate-400 text-[11px] font-mono">Taxa:</span>
            {[1000, 2000, 5000].map(ms => (
              <button
                key={ms}
                onClick={() => setRefreshIntervalMs(ms)}
                className={`px-2 py-1 rounded text-[11px] font-semibold transition ${
                  refreshIntervalMs === ms
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {ms / 1000}s
              </button>
            ))}
          </div>

          {/* Ping Diagnostic Button */}
          <button
            onClick={handleSyntheticPing}
            disabled={isPinging}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
            title="Executar teste de conectividade e ping sintético"
          >
            <Wifi className={`w-3.5 h-3.5 text-cyan-400 ${isPinging ? 'animate-spin' : ''}`} />
            <span>{isPinging ? 'Testando...' : 'Testar Ping'}</span>
          </button>

          {/* Export Telemetry Snapshot */}
          <button
            onClick={handleExportTelemetry}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg text-xs transition"
            title="Exportar dados de telemetria em JSON"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Synthetic ping feedback message if active */}
      {lastPingStatus && (
        <div className="bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 px-3.5 py-2 rounded-xl text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{lastPingStatus}</span>
        </div>
      )}

      {/* 3 Core Metric KPI Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: API Latency */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 relative overflow-hidden group hover:border-slate-700 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              Latência Média da API
            </span>
            <span className="text-[11px] font-mono bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded">
              p95: {currentMetric.p95Latency}ms
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white tracking-tight font-mono">
                {currentMetric.apiLatency}
              </span>
              <span className="text-xs text-slate-400 font-semibold">ms</span>
            </div>

            <div className={`flex items-center text-xs font-semibold ${
              latencyDelta <= 0 ? 'text-emerald-400' : 'text-amber-400'
            }`}>
              {latencyDelta <= 0 ? (
                <ArrowDownRight className="w-4 h-4" />
              ) : (
                <ArrowUpRight className="w-4 h-4" />
              )}
              <span>{Math.abs(latencyDelta)}ms</span>
            </div>
          </div>

          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>SLA Alvo: &lt; 500ms</span>
            <span className="text-emerald-400 font-medium flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              99.98% no SLA
            </span>
          </div>

          {/* Mini Sparkline Chart */}
          <div className="h-10 w-full mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="latencyGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="apiLatency"
                  stroke="#818cf8"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#latencyGrad)"
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Metric 2: Token Usage & Throughput */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 relative overflow-hidden group hover:border-slate-700 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Vazão de Tokens (Live)
            </span>
            <span className="text-[11px] font-mono bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2 py-0.5 rounded">
              {(currentMetric.tokenThroughput * 60 / 1000).toFixed(0)}k/min
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white tracking-tight font-mono">
                {currentMetric.tokenThroughput.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400 font-semibold">tokens/s</span>
            </div>

            <div className={`flex items-center text-xs font-semibold ${
              tokenDelta >= 0 ? 'text-emerald-400' : 'text-slate-400'
            }`}>
              {tokenDelta >= 0 ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
              <span>{Math.abs(tokenDelta)}</span>
            </div>
          </div>

          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Split: 68% Prompt / 32% Compl.</span>
            <span className="text-amber-400 font-medium">~$0.038 / min</span>
          </div>

          {/* Mini Sparkline Chart */}
          <div className="h-10 w-full mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="tokenGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="tokenThroughput"
                  stroke="#fbbf24"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#tokenGrad)"
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Metric 3: System Throughput & Kernel RPS */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 relative overflow-hidden group hover:border-slate-700 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              Throughput do Sistema (RPS)
            </span>
            <span className="text-[11px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 px-2 py-0.5 rounded">
              {currentMetric.kernelDecisionsPerSec} EKO/s
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white tracking-tight font-mono">
                {currentMetric.systemRps}
              </span>
              <span className="text-xs text-slate-400 font-semibold">req/s</span>
            </div>

            <div className={`flex items-center text-xs font-semibold ${
              rpsDelta >= 0 ? 'text-cyan-400' : 'text-slate-400'
            }`}>
              {rpsDelta >= 0 ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
              <span>{Math.abs(rpsDelta)} req</span>
            </div>
          </div>

          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Poda MVED: {currentMetric.mvedPrunedPerSec} hip/s</span>
            <span className="text-cyan-400 font-medium">Erro: 0.00%</span>
          </div>

          {/* Mini Sparkline Chart */}
          <div className="h-10 w-full mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="rpsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="systemRps"
                  stroke="#22d3ee"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#rpsGrad)"
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tab Navigation for Detailed Views */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            activeTab === 'overview'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Provedores & Gateway
        </button>
        <button
          onClick={() => setActiveTab('latency')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            activeTab === 'latency'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Gráfico de Latência Contínua
        </button>
        <button
          onClick={() => setActiveTab('tokens')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            activeTab === 'tokens'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Vazão e Histórico de Tokens
        </button>
        <button
          onClick={() => setActiveTab('throughput')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            activeTab === 'throughput'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Throughput do Kernel & MVED
        </button>
      </div>

      {/* Tab 1: Provedores & Gateway Matrix */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Provider 1: Google Gemini 2.5 */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Google Gemini 2.5</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Latência:</span>
              <span className="font-mono text-indigo-300 font-semibold">{currentMetric.geminiLatency} ms</span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Status:</span>
              <span className="text-emerald-400 font-medium">99.99% Disponível</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-indigo-500 h-full rounded-full" style={{ width: '42%' }}></div>
            </div>
            <div className="text-[10px] text-slate-500 text-right">Carga: 42%</div>
          </div>

          {/* Provider 2: Azure OpenAI GPT-4o */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Azure OpenAI GPT-4o</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Latência:</span>
              <span className="font-mono text-cyan-300 font-semibold">{currentMetric.azureLatency} ms</span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Status:</span>
              <span className="text-emerald-400 font-medium">99.95% Disponível</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-cyan-500 h-full rounded-full" style={{ width: '68%' }}></div>
            </div>
            <div className="text-[10px] text-slate-500 text-right">Carga: 68%</div>
          </div>

          {/* Provider 3: IBM Watsonx Granite */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">IBM Granite 3.0</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Latência:</span>
              <span className="font-mono text-amber-300 font-semibold">{currentMetric.ibmLatency} ms</span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Status:</span>
              <span className="text-emerald-400 font-medium">100% Operacional</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-amber-500 h-full rounded-full" style={{ width: '25%' }}></div>
            </div>
            <div className="text-[10px] text-slate-500 text-right">Carga: 25%</div>
          </div>

          {/* Provider 4: Local Llama-3 Cluster */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Local K8s Llama-3</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Latência:</span>
              <span className="font-mono text-emerald-300 font-semibold">{currentMetric.localLatency} ms</span>
            </div>
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-400">Status:</span>
              <span className="text-emerald-400 font-medium">Ultra-baixa latência</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full" style={{ width: '54%' }}></div>
            </div>
            <div className="text-[10px] text-slate-500 text-right">Carga: 54%</div>
          </div>
        </div>
      )}

      {/* Tab 2: Latency Full Chart */}
      {activeTab === 'latency' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Série temporal de Latência Média vs Percentil p95 (ms)</span>
            <span className="font-mono text-slate-300">Tempo de Resposta End-to-End</span>
          </div>
          <div className="h-56 w-full bg-slate-950/50 rounded-xl p-2 border border-slate-800">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} domain={['auto', 'auto']} unit="ms" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                />
                <Line type="monotone" dataKey="apiLatency" name="Latência Média" stroke="#818cf8" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="p95Latency" name="Percentil p95" stroke="#f43f5e" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                <Line type="monotone" dataKey="localLatency" name="Cluster Local K8s" stroke="#10b981" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Tab 3: Token Throughput Chart */}
      {activeTab === 'tokens' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Volume de Tokens Processados por Segundo</span>
            <span className="font-mono text-amber-400 font-medium">Taxa média: ~4,250 tokens/s</span>
          </div>
          <div className="h-56 w-full bg-slate-950/50 rounded-xl p-2 border border-slate-800">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="tokenFullGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="tokenThroughput" name="Tokens/segundo" stroke="#f59e0b" strokeWidth={2} fill="url(#tokenFullGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Tab 4: System Throughput & MVED Pruning Chart */}
      {activeTab === 'throughput' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Requisições por Segundo (RPS) vs Decisões do Kernel & Poda MVED</span>
            <span className="font-mono text-cyan-400 font-medium">Kernel PASQUARED v1.0</span>
          </div>
          <div className="h-56 w-full bg-slate-950/50 rounded-xl p-2 border border-slate-800">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                />
                <Line type="monotone" dataKey="systemRps" name="RPS Geral" stroke="#06b6d4" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="kernelDecisionsPerSec" name="Decisões Epistêmicas/s" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="mvedPrunedPerSec" name="Poda MVED/s" stroke="#ef4444" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Bottom Summary Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-slate-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 text-indigo-400" />
            <span>Nós Ativos: <strong>12 Workers K8s</strong></span>
          </span>
          <span className="flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Buffer de Memória: <strong>4.2 GB / 32 GB</strong></span>
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Integridade PRE: <strong>100% Verificado</strong></span>
          </span>
        </div>

        {onNavigateToGateway && (
          <button
            onClick={onNavigateToGateway}
            className="text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 transition"
          >
            <span>Gerenciar Conexões no AI Gateway</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
