/**
 * PASQUARED Enterprise AI Governance & PASQUARED-OS
 * Formal Ontological & Architectural Types
 */

// 1. Fundamental Ontology: Ω = (O, U, R, C, M, H, S)
export interface ObserverProfile {
  id: string;
  name: string;
  role: string;
  P: number; // Perception index (0 - 1)
  E: number; // Emotional state index (0 - 1)
  K: number; // Accumulated knowledge index (0 - 1)
  B: number; // Belief / bias disposition index (0 - 1)
  domainAffinity: string[];
}

export type UCIType = 
  | 'text' 
  | 'image' 
  | 'audio' 
  | 'video' 
  | 'memory' 
  | 'emotion' 
  | 'symbol' 
  | 'concept' 
  | 'event' 
  | 'database';

export type RelationType = 
  | 'causal' 
  | 'temporal' 
  | 'semantic' 
  | 'emotional' 
  | 'spatial' 
  | 'symbolic' 
  | 'logical';

export interface UCI {
  uid: string;
  content: string;
  type: UCIType;
  source: string;
  category: string;
  theme: string;
  group: string;
  subGroup?: string;
  w: number;  // Cognitive base weight (0 - 1)
  ct: number; // Local context factor (0 - 1)
  mi: number; // Memory reinforcement (0 - 1)
  ei: number; // Emotional intensity (0 - 1)
  timestamp: string;
  confidence: number;
  sensoryMode?: string;
  relevanceScore?: number;
  pac?: number; // Calculated Probability of Cognitive Activation
}

export interface CognitiveRelation {
  fromUid: string;
  toUid: string;
  type: RelationType;
  w: number; // Connection strength (0 - 1)
  description?: string;
}

export interface CognitiveGraph {
  nodes: UCI[];
  edges: CognitiveRelation[];
  associationMatrix?: number[][];
  matrixLabels?: string[];
}

export interface CognitiveVector {
  p: number; // Percepção (0 - 1)
  c: number; // Contexto (0 - 1)
  m: number; // Memória (0 - 1)
  e: number; // Emoção (0 - 1)
  l: number; // Coerência Lógica (0 - 1)
}

export interface Hypothesis {
  id: string;
  statement: string;
  domain: string;
  vector: CognitiveVector;
  priorProbability: number; // P(Hi)
  likelihood: number;       // P(U | Hi, C, M)
  posteriorP: number;       // P(Hi | U, C, M) - MPAC
  igaScore: number;         // Global Abstraction Index
  status: 'active' | 'validated' | 'eliminated' | 'selected';
  eliminationReason?: string;
  evidences: string[];
  counterEvidences: string[];
}

export interface CognitiveDNA {
  primaryDomain: string;
  secondaryDomains: string[];
  origin: string;
  context: string;
  modality: UCIType;
  initialReliability: number;
  granularity: 'micro' | 'meso' | 'macro';
  sensitivity: 'public' | 'internal' | 'confidential' | 'restricted';
  hashCID: string;
}

export interface UCLObject {
  objectID: string;
  sourceID: string;
  inputType: UCIType;
  language: string;
  category: string;
  theme: string;
  group: string;
  subGroup?: string;
  timestamp: string;
  context: string;
  content: string;
  metadata: Record<string, any>;
  relationships: string[];
  confidence: number;
  priority: 'low' | 'medium' | 'high' | 'critical';
  executionID: string;
  version: string;
  cdna: CognitiveDNA;
}

export interface DynamicInsight {
  insightID: string;
  originEkoID: string;
  category: string;
  theme: string;
  group: string;
  subGroup?: string;
  noveltyScore: number;
  confidence: number;
  impact: 'low' | 'medium' | 'high' | 'transformational';
  statement: string;
  derivedClusters: string[];
  relatedHypotheses: string[];
  timestamp: string;
}

export interface EKO {
  id: string;
  version: string;
  title: string;
  domain: string;
  ucis: string[]; // UID list
  hypotheses: Hypothesis[];
  evidences: string[];
  graph: CognitiveGraph;
  confidence: number;
  maturity: 'draft' | 'provisional' | 'consolidated' | 'immutable';
  insights: DynamicInsight[];
  selectedMeaning: string;
  iga: number;
  ici: number;
  timestamp: string;
}

export interface CalibrationParams {
  // PAC coefficients (alpha + beta + gamma + delta = 1)
  alpha: number; // Weight influence
  beta: number;  // Context intensity
  gamma: number; // Memory influence
  delta: number; // Emotional intensity

  // IGA coefficients (lambda1 to lambda5 = 1)
  lambda1: number; // Perception
  lambda2: number; // Context
  lambda3: number; // Memory
  lambda4: number; // Emotion
  lambda5: number; // Logic

  // Thresholds
  epsilon: number;           // Convergence criterion ΔI < ε
  mvedThreshold: number;     // Minimum ICI for validation (e.g. 0.70)
  hypothesisPruneRatio: number; // Elimination cutoff
  confidenceFloor: number;   // Minimum acceptable confidence
}

export type KernelState = 
  | 'READY'
  | 'RECEIVING'
  | 'NORMALIZING'
  | 'CLASSIFYING'
  | 'CONSULTING'
  | 'ABSTRACTING'
  | 'VALIDATING'
  | 'LEARNING'
  | 'RESPONDING';

export interface SACStage {
  level: number;
  name: string;
  description: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  metrics?: Record<string, any>;
  outputSummary?: string;
}

export interface EpistemicTraceRecord {
  id: string;
  executionId: string;
  timestamp: string;
  kernelState: KernelState;
  sacLevel: number;
  inputCID: string;
  actionTaken: string;
  activeClusters: string[];
  igaDelta: number;
  currentIGA: number;
  currentICI: number;
  signatureHash: string;
  previousHash: string;
}

export interface CognitiveCluster {
  id: string;
  name: string;
  domain: string;
  subdomains: string[];
  loadPercentage: number;
  activeEKOs: number;
  accuracyRate: number;
  status: 'online' | 'busy' | 'syncing' | 'offline';
  workerNode: string;
}

// Enterprise SaaS Multi-Tenant & Governance Types
export type TenantTier = 'Starter' | 'Business' | 'Enterprise' | 'Dedicated/On-Prem';

export interface TenantCadastralData {
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  inscricaoEstadual?: string;
  setor: string;
  porte: string;
  numColaboradores: string;
  endereco: string;
  cidade: string;
  estado: string;
  pais: string;
  adminName: string;
  adminRole: string;
  adminEmail: string;
  adminPhone: string;
}

export interface TenantAcquisitionData {
  contractValueFormatted: string;
  billingCycle: 'monthly' | 'annual';
  contractStartDate: string;
  contractRenewalDate: string;
  paymentStatus: 'paid' | 'pending' | 'overdue';
  paymentMethod: string;
  slaLevel: string;
}

export interface TenantModulesConfig {
  poko_kernel: boolean;
  mved_pruning: boolean;
  ai_gateway: boolean;
  ai_agents: boolean;
  governance_iga: boolean;
  risk_matrix_5x5: boolean;
  pre_ledger_audit: boolean;
  enterprise_connectors: boolean;
  algorithmic_calibration: boolean;
}

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  domain?: string;
  tier: TenantTier;
  createdAt: string;
  status: 'active' | 'suspended' | 'trial';
  quotas: {
    maxUsers: number;
    usedUsers: number;
    monthlyTokens: number;
    usedTokens: number;
    maxAgents: number;
    usedAgents: number;
    maxStorageGB: number;
    usedStorageGB: number;
  };
  clusterAllocations: string[];
  customCalibration?: Partial<CalibrationParams>;
  cadastralData?: TenantCadastralData;
  acquisitionData?: TenantAcquisitionData;
  activeModules?: TenantModulesConfig;
}

export interface KnowledgeBaseSource {
  id: string;
  tenantId?: string; // empty or global for public, or specific tenantId for private
  name: string;
  area: 'Jurídico & Regulatório' | 'Financeiro & Bancário' | 'Saúde & Medicina' | 'Tecnologia & Cibersegurança' | 'Indústria & Engenharia' | 'Governança & Risco' | 'Geral / Multidisciplinar';
  scope: 'public' | 'private';
  sourceUrlOrHost: string;
  authMethod: 'public_no_auth' | 'bearer_token' | 'api_key' | 'mtls' | 'oauth2';
  recordsCount: number;
  lastSyncedAt: string;
  status: 'connected' | 'disconnected' | 'syncing' | 'error';
  description: string;
  mappedDimension: 'Evidência (α)' | 'Contexto Local (β)' | 'Memória Histórica (γ)' | 'Salvaguarda & Risco (δ)';
  autoSync: boolean;
  format: 'PDF/Docs' | 'SQL Data Lake' | 'REST Feed' | 'Vector Embedding' | 'Ontological Graph';
}

export interface User {
  id: string;
  tenantId: string;
  name: string;
  email: string;
  role: 'SuperAdmin' | 'TenantAdmin' | 'ComplianceOfficer' | 'RiskManager' | 'AIEngineer' | 'Auditor' | 'Viewer';
  avatar?: string;
  department: string;
  mfaEnabled: boolean;
  status: 'active' | 'inactive';
  permissions?: string[];
  password?: string;
  phone?: string;
  dob?: string;
  generatedPassword?: string;
}

export interface AIGatewayModel {
  id: string;
  name: string;
  provider: 'Google' | 'Microsoft' | 'IBM' | 'OpenAI' | 'Local-Cluster';
  modelFamily: string;
  endpoint: string;
  contextWindow: number;
  latencyMs: number;
  costPer1kTokens: number;
  status: 'available' | 'degraded' | 'maintenance';
  isPasquaredProtected: boolean;
  pasquaredInterceptionRules: string[];
}

export interface AIAgent {
  id: string;
  tenantId: string;
  name: string;
  role: string;
  description: string;
  modelId: string;
  clusterTarget: string;
  systemPrompt: string;
  status: 'active' | 'paused' | 'evaluating';
  governanceLimits: {
    maxTokensPerCall: number;
    allowHighRiskActions: boolean;
    requireHumanApprovalThreshold: number;
  };
  totalCalls: number;
  avgConfidence: number;
}

export interface GovernancePolicy {
  id: string;
  tenantId: string;
  name: string;
  description: string;
  category: 'Safety' | 'Privacy & PII' | 'Hallucination & Grounding' | 'Bias & Fairness' | 'Regulatory';
  severity: 'low' | 'medium' | 'high' | 'critical';
  actionOnViolation: 'warn' | 'block' | 'require_approval' | 're-route';
  isActive: boolean;
  violationsCount: number;
  ruleDefinition: string;
}

export interface RiskItem {
  id: string;
  tenantId: string;
  title: string;
  category: 'Regulatory' | 'Operational' | 'Model Performance' | 'Security & Data' | 'Ethical';
  probability: 1 | 2 | 3 | 4 | 5; // 1 (rare) to 5 (almost certain)
  impact: 1 | 2 | 3 | 4 | 5;      // 1 (negligible) to 5 (catastrophic)
  score: number;                   // probability * impact (1 to 25)
  status: 'identified' | 'assessing' | 'mitigated' | 'accepted';
  mitigationPlan: string;
  associatedAgentId?: string;
  lastAssessed: string;
}

export interface ComplianceControl {
  id: string;
  framework: 'EU AI Act' | 'ISO/IEC 42001' | 'NIST AI RMF' | 'LGPD/GDPR' | 'SOC2 Type II';
  controlCode: string;
  title: string;
  description: string;
  status: 'compliant' | 'in_progress' | 'non_compliant' | 'not_applicable';
  evidenceCount: number;
  lastAuditDate: string;
}

export interface DecisionRecord {
  id: string;
  tenantId: string;
  requestPrompt: string;
  observerId: string;
  selectedMeaning: string;
  rejectedHypotheses: Array<{ statement: string; reason: string; score: number }>;
  activeClusters: string[];
  iga: number;
  ici: number;
  riskScore: number;
  policyStatus: 'PASSED' | 'WARNING' | 'HUMAN_APPROVAL_REQUIRED';
  aiProviderUsed: string;
  executionTimeMs: number;
  timestamp: string;
  hashCID: string;
}

export interface AutomationWorkflow {
  id: string;
  tenantId: string;
  name: string;
  triggerEvent: 'NEW_DATA_INGEST' | 'RISK_THRESHOLD_EXCEEDED' | 'POLICY_VIOLATION' | 'SCHEDULED_AUDIT';
  steps: string[];
  status: 'active' | 'draft' | 'paused';
  executionsCount: number;
  lastRun: string;
}

// Enterprise Registration & IT Parameterization Types
export interface CompanyRegistrationForm {
  // Company essential fields
  razaoSocial: string;
  nomeFantasia: string;
  cnpjTaxId: string;
  inscricaoEstadual?: string;
  setorAtuacao: 'Fintech & Bancário' | 'Saúde & Hospitalar' | 'Energia & Utilities' | 'Indústria 4.0' | 'Varejo & E-commerce' | 'Logística' | 'Setor Público' | 'Jurídico & Compliance' | 'Telecomunicações';
  porteEmpresa: 'Startup' | 'PME' | 'Middle Market' | 'Enterprise Global';
  numColaboradores: string;
  pais: string;
  estadoUf: string;
  cidade: string;
  endereco: string;
  
  // IT Admin & Security Manager
  adminNomeCompleto: string;
  adminCargo: 'CTO' | 'VP of Engineering' | 'Head de TI' | 'Arquiteto de IA' | 'DPO / Encarregado LGPD' | 'CISO / Segurança' | 'Gerente de Infraestrutura';
  adminEmailCorporativo: string;
  adminTelefoneWhatsapp: string;
  
  // Credentials
  usuarioLogin: string;
  senha: string;
  confirmacaoSenha: string;
  mfaHabilitado: boolean;
  
  // Initial PASQUARED Configuration
  iaPrimariaDesejada: 'Google (Gemini 2.5 Flash/Pro)' | 'Microsoft (Azure OpenAI GPT-4o)' | 'IBM (Watsonx Granite 3.0)' | 'Cluster Local On-Premise K8s';
  nivelRigorSalvaguarda: 'Standard' | 'Strict EU AI Act (High Risk)' | 'High-Assurance Defesa/Financeiro';
  aceiteTermosGovernanca: boolean;
  aceiteSLA: boolean;
}

export type ConnectorSourceType = 
  | 'rest_api'
  | 'webhook'
  | 'database_sql'
  | 'data_lake'
  | 'erp_crm'
  | 'hubspot_crm'
  | 'iot_telemetry'
  | 'document_ucl';

export interface EnterpriseDataConnector {
  id: string;
  tenantId: string;
  name: string;
  sourceType: ConnectorSourceType;
  endpointUrlOrHost: string;
  authMethod: 'bearer_token' | 'api_key' | 'oauth2' | 'mtls' | 'basic';
  frequency: 'real_time_stream' | 'every_1_min' | 'every_5_min' | 'hourly' | 'batch_daily';
  status: 'active' | 'paused' | 'error' | 'syncing';
  recordsIngested: number;
  lastSyncAt: string;
  mappedCognitiveDimension: 'Evidência (α)' | 'Contexto Local (β)' | 'Memória Histórica (γ)' | 'Salvaguarda & Risco (δ)';
  targetClusterDomain: string;
  samplePayloadFormat: string;
  confidenceWeight: number; // 0.1 to 1.0
}

export interface DecisionParameterizationConfig {
  tenantId: string;
  decisionDomain: string;
  alphaEvidenceWeight: number;    // α
  betaContextWeight: number;     // β
  gammaMemoryWeight: number;     // γ
  deltaSafeguardWeight: number;  // δ
  mvedThreshold: number;         // 0.40 - 0.95
  igaMinimumForAutoApproval: number; // 0.70 - 0.99
  humanInTheLoopThreshold: number;   // 0.40 - 0.75
  observationTimeWindowMinutes: number;
  autoPruneInvalidHypotheses: boolean;
  quarantineHighRiskOutputs: boolean;
  activeDataFeedIds: string[];
}
