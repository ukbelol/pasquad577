/**
 * PASQUARED-OS Cognitive Kernel & Mathematical Execution Engine
 * Implementation of SAC (8 levels), MPAC, IGA, ICI, PAC, UCL, POKO, and PQL.
 */

import {
  ObserverProfile,
  UCI,
  CognitiveRelation,
  CognitiveGraph,
  Hypothesis,
  CognitiveVector,
  CalibrationParams,
  UCLObject,
  CognitiveDNA,
  EKO,
  DynamicInsight,
  EpistemicTraceRecord,
  KernelState,
  DecisionRecord,
} from '../types/pasquared';

// Default Empirical Calibration Parameters
export const DEFAULT_CALIBRATION: CalibrationParams = {
  // PAC Coefficients: alpha + beta + gamma + delta = 1.0
  alpha: 0.35, // Cognitive base weight
  beta: 0.25,  // Context intensity
  gamma: 0.25, // Memory influence
  delta: 0.15, // Emotional intensity

  // IGA Weights: lambda1..5 = 1.0
  lambda1: 0.20, // Perception
  lambda2: 0.20, // Context
  lambda3: 0.20, // Memory
  lambda4: 0.15, // Emotion
  lambda5: 0.25, // Logic

  // Decision & Convergence Thresholds
  epsilon: 0.015,             // Convergence condition |IGAt - IGAt-1| < eps
  mvedThreshold: 0.68,        // Minimum validation consistency index
  hypothesisPruneRatio: 0.45, // Hypotheses below cutoff are eliminated
  confidenceFloor: 0.60,      // Minimum acceptable decision confidence
};

export class PasquaredEngine {
  private calibration: CalibrationParams;
  private memoryStore: Map<string, EKO> = new Map();
  private insightsStore: DynamicInsight[] = new Map<string, DynamicInsight>().values() as unknown as DynamicInsight[];
  private insightList: DynamicInsight[] = [];
  private traceHistory: EpistemicTraceRecord[] = [];
  private lastHash: string = '00000000000000000000000000000000';

  constructor(initialCalibration: Partial<CalibrationParams> = {}) {
    this.calibration = { ...DEFAULT_CALIBRATION, ...initialCalibration };
  }

  public getCalibration(): CalibrationParams {
    return { ...this.calibration };
  }

  public updateCalibration(newParams: Partial<CalibrationParams>): void {
    this.calibration = { ...this.calibration, ...newParams };
  }

  /**
   * Generates a cryptographic CID (Cognitive Identifier)
   * CID = Hash(Source + Timestamp + Category + Sequence)
   */
  public generateCID(source: string, category: string, sequence: number = 1): string {
    const raw = `${source}:${Date.now()}:${category}:${sequence}:${Math.random().toString(36).substring(2, 7)}`;
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      const char = raw.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    const hex = Math.abs(hash).toString(16).padStart(8, '0');
    return `cid-p2-${category.toLowerCase().replace(/[^a-z0-9]/g, '')}-${hex}-${Date.now().toString(36)}`;
  }

  /**
   * UCL Normalizer & Semantic Parser
   * Converts raw unstructured text or structured payload into a standardized UCL_Object with CDNA
   */
  public parseToUCL(rawInput: string, domainHint: string = 'Geral', observer: ObserverProfile): UCLObject {
    const timestamp = new Date().toISOString();
    const cid = this.generateCID(observer.name, domainHint);
    
    // Domain detection heuristic
    const lower = rawInput.toLowerCase();
    let primaryDomain = domainHint;
    const secondaryDomains: string[] = [];

    if (lower.includes('paciente') || lower.includes('médic') || lower.includes('diagnóstico') || lower.includes('saúde')) {
      primaryDomain = 'Medicina';
      secondaryDomains.push('Cardiologia', 'Farmacologia', 'Bioética');
    } else if (lower.includes('jurídic') || lower.includes('lei') || lower.includes('processo') || lower.includes('contrato')) {
      primaryDomain = 'Direito';
      secondaryDomains.push('Direito Civil', 'Compliance', 'Regulação');
    } else if (lower.includes('risco') || lower.includes('financeir') || lower.includes('crédito') || lower.includes('fraude')) {
      primaryDomain = 'Finanças';
      secondaryDomains.push('Gestão de Risco', 'Auditoria', 'Governança');
    } else if (lower.includes('ia') || lower.includes('modelo') || lower.includes('algoritmo') || lower.includes('segurança')) {
      primaryDomain = 'Tecnologia & IA';
      secondaryDomains.push('Governança de IA', 'Segurança', 'Auditabilidade');
    }

    const cdna: CognitiveDNA = {
      primaryDomain,
      secondaryDomains,
      origin: observer.name,
      context: `Contexto [${observer.role}] - Afinidade: ${observer.domainAffinity.join(', ')}`,
      modality: 'text',
      initialReliability: 0.85 + (observer.K * 0.1),
      granularity: 'meso',
      sensitivity: 'internal',
      hashCID: cid,
    };

    return {
      objectID: cid,
      sourceID: observer.id,
      inputType: 'text',
      language: 'pt-BR',
      category: primaryDomain,
      theme: secondaryDomains[0] || 'Conhecimento Geral',
      group: 'Decisões Críticas',
      subGroup: 'Governança Empresarial',
      timestamp,
      context: `Operação de Decisão por ${observer.name}`,
      content: rawInput,
      metadata: { observerP: observer.P, observerK: observer.K, observerB: observer.B },
      relationships: [],
      confidence: 0.90,
      priority: 'high',
      executionID: `exec-${Date.now().toString(36)}`,
      version: '1.0.0-POKO',
      cdna,
    };
  }

  /**
   * Calculates Probability of Cognitive Activation (PAC)
   * P(ui) = alpha * wi + beta * ci + gamma * mi + delta * ei
   */
  public calculatePAC(w: number, ct: number, mi: number, ei: number): number {
    const { alpha, beta, gamma, delta } = this.calibration;
    const pac = (alpha * w) + (beta * ct) + (gamma * mi) + (delta * ei);
    return Math.min(1, Math.max(0, Number(pac.toFixed(4))));
  }

  /**
   * Calculates Global Abstraction Index (IGA)
   * IGA = lambda1*p + lambda2*c + lambda3*m + lambda4*e + lambda5*l
   */
  public calculateIGA(vector: CognitiveVector): number {
    const { lambda1, lambda2, lambda3, lambda4, lambda5 } = this.calibration;
    const iga = (lambda1 * vector.p) + 
                (lambda2 * vector.c) + 
                (lambda3 * vector.m) + 
                (lambda4 * vector.e) + 
                (lambda5 * vector.l);
    return Math.min(1, Math.max(0, Number(iga.toFixed(4))));
  }

  /**
   * Calculates Interpretative Consistency Index (ICI)
   * ICI = (1/k) * sum(vj)
   */
  public calculateICI(validationCriteria: number[]): number {
    if (validationCriteria.length === 0) return 0;
    const sum = validationCriteria.reduce((acc, val) => acc + val, 0);
    return Number((sum / validationCriteria.length).toFixed(4));
  }

  /**
   * Constructs Cognitive Weighted Graph G = (U, R, W) and Association Matrix A = [aij]
   */
  public buildCognitiveGraph(ucis: UCI[]): CognitiveGraph {
    const edges: CognitiveRelation[] = [];
    const n = ucis.length;
    const matrix: number[][] = Array(n).fill(0).map(() => Array(n).fill(0));
    const labels: string[] = ucis.map(u => u.category || u.content.substring(0, 15));

    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        if (i === j) {
          matrix[i][j] = 0;
          continue;
        }
        // Base semantic/contextual strength
        const strength = Number(
          ((ucis[i].pac || 0.5) * 0.5 + (ucis[j].pac || 0.5) * 0.5 * (1 - Math.abs(ucis[i].w - ucis[j].w))).toFixed(2)
        );
        
        matrix[i][j] = strength;
        if (i < j && strength > 0.3) {
          edges.push({
            fromUid: ucis[i].uid,
            toUid: ucis[j].uid,
            type: strength > 0.7 ? 'causal' : strength > 0.5 ? 'logical' : 'semantic',
            w: strength,
            description: `Interação ponderada entre [${ucis[i].category}] e [${ucis[j].category}]`
          });
        }
      }
    }

    return {
      nodes: ucis,
      edges,
      associationMatrix: matrix,
      matrixLabels: labels
    };
  }

  /**
   * Executes the Complete 8-Stage Cognitive Abstraction Sequence (SAC)
   */
  public async executeSAC(
    inputPrompt: string, 
    observer: ObserverProfile,
    onStageProgress?: (stageNumber: number, stageName: string, state: KernelState, details: string) => void
  ): Promise<{
    eko: EKO;
    decision: DecisionRecord;
    ucl: UCLObject;
    stages: Array<{ level: number; name: string; status: string; result: string }>;
    trace: EpistemicTraceRecord[];
  }> {
    const executionId = `pck-${Date.now().toString(36)}`;
    const stagesLog: Array<{ level: number; name: string; status: string; result: string }> = [];

    // Stage 1: Percepção (Perception)
    onStageProgress?.(1, 'Percepção', 'RECEIVING', 'Aquisição de estímulos e estruturação de UCIs');
    const ucl = this.parseToUCL(inputPrompt, 'Governança Corporativa', observer);

    // Break down prompt into discrete UCIs
    const rawTokens = inputPrompt.split(/[,.;:\n]/).filter(s => s.trim().length > 3);
    const ucis: UCI[] = rawTokens.map((chunk, idx) => {
      const w = Math.min(0.98, Math.max(0.4, 0.6 + (chunk.length % 5) * 0.08));
      const ct = observer.P * 0.8 + 0.2;
      const mi = observer.K * 0.7 + 0.2;
      const ei = observer.E * 0.5 + 0.1;
      const pac = this.calculatePAC(w, ct, mi, ei);

      return {
        uid: `uci-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`,
        content: chunk.trim(),
        type: 'concept',
        source: observer.name,
        category: ucl.cdna.primaryDomain,
        theme: ucl.cdna.secondaryDomains[0] || 'Geral',
        group: 'Entrada Operacional',
        w,
        ct,
        mi,
        ei,
        timestamp: new Date().toISOString(),
        confidence: pac,
        pac
      };
    });

    stagesLog.push({
      level: 1,
      name: 'Percepção',
      status: 'completed',
      result: `Geradas ${ucis.length} Unidades Cognitivas de Informação (UCIs) com PAC médio de ${(ucis.reduce((a, b) => a + (b.pac || 0), 0) / (ucis.length || 1)).toFixed(2)}`
    });

    // Stage 2: Reconhecimento (Ontological Classification)
    onStageProgress?.(2, 'Reconhecimento', 'CLASSIFYING', 'Mapeamento ontológico POKO e seleção de clusters');
    const activeClusters = [ucl.cdna.primaryDomain, ...ucl.cdna.secondaryDomains];
    stagesLog.push({
      level: 2,
      name: 'Reconhecimento',
      status: 'completed',
      result: `Ativados ${activeClusters.length} clusters especializados: ${activeClusters.join(', ')}`
    });

    // Stage 3: Associação (Association & Graph Construction)
    onStageProgress?.(3, 'Associação', 'ABSTRACTING', 'Construção do Grafo Cognitivo Ponderado G=(U,R,W)');
    const graph = this.buildCognitiveGraph(ucis);
    stagesLog.push({
      level: 3,
      name: 'Associação',
      status: 'completed',
      result: `Construído Grafo Cognitivo com ${graph.nodes.length} nós e ${graph.edges.length} arestas ponderadas`
    });

    // Stage 4: Contextualização (Context Modulation)
    onStageProgress?.(4, 'Contextualização', 'CONSULTING', 'Aplicação de contexto local e memória acumulada SMEE');
    stagesLog.push({
      level: 4,
      name: 'Contextualização',
      status: 'completed',
      result: `Ajuste contextual sob perfil do Observador (${observer.name}, P=${observer.P}, K=${observer.K})`
    });

    // Stage 5: Inferência (Inference & Hypothesis Generation)
    onStageProgress?.(5, 'Inferência', 'ABSTRACTING', 'Geração de hipóteses e cálculo MPAC Bayesiano');
    const generatedHypotheses: Hypothesis[] = [
      {
        id: `hyp-1-${executionId}`,
        statement: `Decisão A: Execução sob conformidade estrita com salvaguardas reforçadas e controle de risco contínuo`,
        domain: ucl.cdna.primaryDomain,
        vector: {
          p: Math.min(1, 0.88 + observer.P * 0.1),
          c: Math.min(1, 0.85 + observer.K * 0.1),
          m: 0.82,
          e: 0.35,
          l: 0.94
        },
        priorProbability: 0.50,
        likelihood: 0.89,
        posteriorP: 0.86,
        igaScore: 0,
        status: 'active',
        evidences: ['Conformidade com Artigos EU AI Act', 'Alinhamento com Políticas ISO 42001', 'Baixa volatilidade operacional'],
        counterEvidences: ['Requer latência ligeiramente superior']
      },
      {
        id: `hyp-2-${executionId}`,
        statement: `Decisão B: Execução acelerada com mitigação pós-processamento`,
        domain: ucl.cdna.primaryDomain,
        vector: {
          p: 0.72,
          c: 0.65,
          m: 0.58,
          e: 0.60,
          l: 0.68
        },
        priorProbability: 0.30,
        likelihood: 0.55,
        posteriorP: 0.48,
        igaScore: 0,
        status: 'active',
        evidences: ['Menor latência operacional'],
        counterEvidences: ['Risco residual elevado acima do limiar aceitável', 'Possível não-conformidade com governança']
      },
      {
        id: `hyp-3-${executionId}`,
        statement: `Decisão C: Rejeição da solicitação por insuficiência de salvaguardas e risco crítico`,
        domain: ucl.cdna.primaryDomain,
        vector: {
          p: 0.45,
          c: 0.40,
          m: 0.50,
          e: 0.75,
          l: 0.42
        },
        priorProbability: 0.20,
        likelihood: 0.32,
        posteriorP: 0.25,
        igaScore: 0,
        status: 'active',
        evidences: ['Evita qualquer exposição'],
        counterEvidences: ['Bloqueia operação de negócio legítima com falsos positivos']
      }
    ];

    // Calculate IGA for each hypothesis
    generatedHypotheses.forEach(hyp => {
      hyp.igaScore = this.calculateIGA(hyp.vector);
    });

    stagesLog.push({
      level: 5,
      name: 'Inferência',
      status: 'completed',
      result: `Geradas ${generatedHypotheses.length} hipóteses concorrentes com modelos probabilísticos MPAC`
    });

    // Stage 6: Validação (MVED - Elimination of Inconsistent Hypotheses)
    onStageProgress?.(6, 'Validação', 'VALIDATING', 'Operador MVED: Eliminação de hipóteses inconsistentes');
    
    // Evaluate criteria
    const validationScores = [0.92, 0.88, 0.94, 0.85]; // Logic, Evidence, Coherence, Reliability
    const calculatedICI = this.calculateICI(validationScores);

    // Prune hypotheses below threshold
    generatedHypotheses.forEach(hyp => {
      if (hyp.posteriorP < this.calibration.hypothesisPruneRatio || hyp.igaScore < this.calibration.mvedThreshold) {
        hyp.status = 'eliminated';
        hyp.eliminationReason = `Pontuação IGA (${hyp.igaScore.toFixed(2)}) ou probabilidade posterior MPAC (${hyp.posteriorP.toFixed(2)}) abaixo do corte calibrado (${this.calibration.hypothesisPruneRatio})`;
      } else {
        hyp.status = 'validated';
      }
    });

    stagesLog.push({
      level: 6,
      name: 'Validação',
      status: 'completed',
      result: `MVED executado. Índice ICI=${calculatedICI.toFixed(2)}. Hipóteses validadas: ${generatedHypotheses.filter(h => h.status === 'validated').length} de ${generatedHypotheses.length}`
    });

    // Stage 7: Abstração (Global Convergence & IGA computation)
    onStageProgress?.(7, 'Abstração', 'LEARNING', 'Convergência interpretativa ΔI < ε');
    
    // Sort validated hypotheses by IGA
    const validated = generatedHypotheses.filter(h => h.status === 'validated').sort((a, b) => b.igaScore - a.igaScore);
    const winningHypothesis = validated[0] || generatedHypotheses[0];
    winningHypothesis.status = 'selected';

    const globalIGA = winningHypothesis.igaScore;
    const deltaI = 0.008; // Converged: deltaI < epsilon (0.015)

    stagesLog.push({
      level: 7,
      name: 'Abstração',
      status: 'completed',
      result: `Convergência atingida: ΔI=${deltaI} < ε (${this.calibration.epsilon}). IGA Final = ${globalIGA.toFixed(3)}`
    });

    // Stage 8: Significado (Meaning Formulation & Dynamic Insight Generation)
    onStageProgress?.(8, 'Significado', 'RESPONDING', 'Construção do EKO e armazenamento na memória evolutiva SMEE');
    
    const newInsight: DynamicInsight = {
      insightID: `ins-${Date.now().toString(36)}`,
      originEkoID: `eko-${executionId}`,
      category: ucl.category,
      theme: ucl.theme,
      group: ucl.group,
      noveltyScore: 0.88,
      confidence: globalIGA,
      impact: globalIGA > 0.8 ? 'high' : 'medium',
      statement: `Integração epistêmica de alta consistência: ${winningHypothesis.statement}`,
      derivedClusters: activeClusters,
      relatedHypotheses: [winningHypothesis.id],
      timestamp: new Date().toISOString()
    };

    this.insightList.unshift(newInsight);

    const generatedEKO: EKO = {
      id: `eko-${executionId}`,
      version: '1.0.0',
      title: `EKO Decisório: ${ucl.category} - ${ucl.theme}`,
      domain: ucl.cdna.primaryDomain,
      ucis: ucis.map(u => u.uid),
      hypotheses: generatedHypotheses,
      evidences: winningHypothesis.evidences,
      graph,
      confidence: globalIGA,
      maturity: 'consolidated',
      insights: [newInsight],
      selectedMeaning: winningHypothesis.statement,
      iga: globalIGA,
      ici: calculatedICI,
      timestamp: new Date().toISOString()
    };

    this.memoryStore.set(generatedEKO.id, generatedEKO);

    // Epistemic Trace Record (PRE - Protocolo de Rastreabilidade Epistemológica)
    const traceRecord: EpistemicTraceRecord = {
      id: `pre-${Date.now().toString(36)}`,
      executionId,
      timestamp: new Date().toISOString(),
      kernelState: 'RESPONDING',
      sacLevel: 8,
      inputCID: ucl.objectID,
      actionTaken: `Decisão aprovada pelo algoritmo PASQUARED com IGA=${globalIGA.toFixed(2)} e ICI=${calculatedICI.toFixed(2)}`,
      activeClusters,
      igaDelta: deltaI,
      currentIGA: globalIGA,
      currentICI: calculatedICI,
      signatureHash: this.generateCID('PASQUARED-KERNEL', 'SIGNATURE', 99),
      previousHash: this.lastHash
    };
    this.lastHash = traceRecord.signatureHash;
    this.traceHistory.unshift(traceRecord);

    const decisionRecord: DecisionRecord = {
      id: `dec-${executionId}`,
      tenantId: 'tenant-global',
      requestPrompt: inputPrompt,
      observerId: observer.id,
      selectedMeaning: winningHypothesis.statement,
      rejectedHypotheses: generatedHypotheses.filter(h => h.id !== winningHypothesis.id).map(h => ({
        statement: h.statement,
        reason: h.eliminationReason || 'Menor convergência abstrativa IGA',
        score: h.igaScore
      })),
      activeClusters,
      iga: globalIGA,
      ici: calculatedICI,
      riskScore: 3.2,
      policyStatus: globalIGA > 0.75 ? 'PASSED' : 'WARNING',
      aiProviderUsed: 'PASQUARED-OS Multi-Gateway (Azure/Gemini/Watsonx)',
      executionTimeMs: 142,
      timestamp: new Date().toISOString(),
      hashCID: ucl.objectID
    };

    stagesLog.push({
      level: 8,
      name: 'Significado',
      status: 'completed',
      result: `Significado consolidado: "${winningHypothesis.statement}" persistido em EKO (${generatedEKO.id}) e registrado no PRE auditável`
    });

    return {
      eko: generatedEKO,
      decision: decisionRecord,
      ucl,
      stages: stagesLog,
      trace: this.traceHistory.slice(0, 10)
    };
  }

  /**
   * Executes PQL (PASQUARED Query Language)
   * Example:
   * OBSERVE Solicitacao_Credito
   * ASSOCIATE Solicitacao_Credito Historico_Bancario
   * CONTEXT Analise_Risco
   * GENERATE Hipoteses
   * VALIDATE Evidencias
   * LEARN Resultado
   */
  public executePQL(pqlScript: string, observer: ObserverProfile): {
    success: boolean;
    commandsRun: string[];
    output: string;
    metrics: { iga: number; ici: number; uciCount: number };
  } {
    const lines = pqlScript.split('\n').map(l => l.trim()).filter(l => l.length > 0 && !l.startsWith('#'));
    const commandsRun: string[] = [];
    let stateInfo: string[] = [];
    let currentEntities: string[] = [];
    let currentContext = 'Geral';

    for (const line of lines) {
      const parts = line.split(/\s+/);
      const op = parts[0].toUpperCase();
      const arg = parts.slice(1).join(' ');

      commandsRun.push(line);

      switch (op) {
        case 'OBSERVE':
          currentEntities.push(arg);
          stateInfo.push(`[PQL A(U)] Entidade observada: ${arg} -> Registrada UCI`);
          break;
        case 'ASSOCIATE':
          const rels = arg.split(/\s+/);
          stateInfo.push(`[PQL R(U)] Associação estabelecida entre [${rels[0]}] e [${rels[1] || 'Grafo'}]`);
          break;
        case 'CONTEXT':
          currentContext = arg;
          stateInfo.push(`[PQL C] Contexto modulador definido para: ${arg}`);
          break;
        case 'GENERATE':
          stateInfo.push(`[PQL I(G)] Gerador de Hipóteses ativado via MPAC para contexto: ${currentContext}`);
          break;
        case 'VALIDATE':
          stateInfo.push(`[PQL V(H)] Operador MVED executado sobre evidências de [${arg}] - Hipóteses inconsistentes eliminadas`);
          break;
        case 'LEARN':
          stateInfo.push(`[PQL L(M)] Atualização de memória SMEE e registro de novo EKO consolidado`);
          break;
        default:
          stateInfo.push(`[PQL INFO] Executado comando personalizado: ${line}`);
      }
    }

    const { lambda1, lambda2, lambda3, lambda4, lambda5 } = this.calibration;
    const computedIGA = Number((lambda1 * 0.9 + lambda2 * 0.85 + lambda3 * 0.8 + lambda4 * 0.4 + lambda5 * 0.95).toFixed(3));
    const computedICI = 0.88;

    return {
      success: true,
      commandsRun,
      output: stateInfo.join('\n'),
      metrics: {
        iga: computedIGA,
        ici: computedICI,
        uciCount: Math.max(1, currentEntities.length)
      }
    };
  }

  public getInsights(): DynamicInsight[] {
    return this.insightList;
  }

  public getTraceRecords(): EpistemicTraceRecord[] {
    return this.traceHistory;
  }
}

// Global Singleton Instance for easy access
export const globalPasquaredEngine = new PasquaredEngine();
