import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import fs from 'fs';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

const DB_PATH = path.join(process.cwd(), 'database.json');

// Default database template (empty company tenants, general cognitive infra)
const DEFAULT_DB = {
  tenants: [],
  collaboratorsMap: {},
  clusters: [
    {
      id: 'clus-gov',
      name: 'Cluster de Governança & IA Ética',
      domain: 'Governança & Políticas',
      subdomains: ['NIST AI RMF', 'ISO/IEC 42001', 'EU AI Act', 'Auditoria Algorítmica'],
      loadPercentage: 42,
      activeEKOs: 1240,
      accuracyRate: 99.4,
      status: 'online',
      workerNode: 'k8s-worker-node-alpha-us'
    },
    {
      id: 'clus-med',
      name: 'Cluster Médico-Científico & Bioética',
      domain: 'Medicina & Saúde',
      subdomains: ['Cardiologia', 'Farmacologia', 'Bioética', 'Diagnóstico Assistido'],
      loadPercentage: 68,
      activeEKOs: 3820,
      accuracyRate: 98.9,
      status: 'online',
      workerNode: 'k8s-worker-node-beta-med'
    },
    {
      id: 'clus-law',
      name: 'Cluster Jurídico & Regulatório',
      domain: 'Direito & Compliance',
      subdomains: ['Direito Civil', 'Direito do Consumidor', 'Contratos Inteligentes', 'LGPD'],
      loadPercentage: 55,
      activeEKOs: 2190,
      accuracyRate: 99.1,
      status: 'online',
      workerNode: 'k8s-worker-node-gamma-jur'
    },
    {
      id: 'clus-fin',
      name: 'Cluster de Finanças & Matriz de Risco',
      domain: 'Finanças & Economia',
      subdomains: ['Análise de Risco de Crédito', 'Prevenção à Fraude', 'Mercado de Capitais'],
      loadPercentage: 74,
      activeEKOs: 4500,
      accuracyRate: 99.6,
      status: 'online',
      workerNode: 'k8s-worker-node-delta-fin'
    },
    {
      id: 'clus-sec',
      name: 'Cluster de Cibersegurança & PII Guard',
      domain: 'Cibersegurança & Criptografia',
      subdomains: ['Detecção de Vazamentos PII', 'Sanitização de Prompts', 'Assinaturas TEE'],
      loadPercentage: 38,
      activeEKOs: 1980,
      accuracyRate: 99.9,
      status: 'online',
      workerNode: 'k8s-worker-node-epsilon-sec'
    }
  ],
  models: [
    {
      id: 'model-google-gemini-25',
      name: 'Google Gemini 2.5 Flash',
      provider: 'Google',
      modelFamily: 'Gemini Generative Engine',
      endpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash',
      contextWindow: 1048576,
      latencyMs: 310,
      costPer1kTokens: 0.00015,
      status: 'available',
      isPasquaredProtected: true,
      pasquaredInterceptionRules: ['MVED Validation', 'PII Masking', 'Hallucination Pruning']
    },
    {
      id: 'model-google-gemini-pro',
      name: 'Google Gemini 2.5 Pro (Deep Reasoning)',
      provider: 'Google',
      modelFamily: 'Gemini Pro Multimodal',
      endpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro',
      contextWindow: 2097152,
      latencyMs: 680,
      costPer1kTokens: 0.00125,
      status: 'available',
      isPasquaredProtected: true,
      pasquaredInterceptionRules: ['MVED Validation', 'Hypothesis Elimination', 'SMEE Memory Sync']
    },
    {
      id: 'model-msft-azure-gpt4o',
      name: 'Microsoft Azure OpenAI GPT-4o',
      provider: 'Microsoft',
      modelFamily: 'Azure Foundry / OpenAI Engine',
      endpoint: 'https://pasquared-foundry.openai.azure.com/deployments/gpt-4o',
      contextWindow: 128000,
      latencyMs: 450,
      costPer1kTokens: 0.0025,
      status: 'available',
      isPasquaredProtected: true,
      pasquaredInterceptionRules: ['MVED Validation', 'Zero Data Retention Policy', 'Audit Log PRE']
    },
    {
      id: 'model-ibm-granite',
      name: 'IBM Watsonx Granite 3.0 Enterprise',
      provider: 'IBM',
      modelFamily: 'IBM Watsonx AI Foundation',
      endpoint: 'https://us-south.ml.cloud.ibm.com/v1/deployments/granite-3-8b-instruct',
      contextWindow: 32768,
      latencyMs: 380,
      costPer1kTokens: 0.0004,
      status: 'available',
      isPasquaredProtected: true,
      pasquaredInterceptionRules: ['Enterprise Compliance', 'NIST Governance', 'MVED Check']
    },
    {
      id: 'model-local-llama3',
      name: 'Local Llama-3 70B (Isolated On-Prem Worker)',
      provider: 'Local-Cluster',
      modelFamily: 'Local Private Air-Gapped',
      endpoint: 'http://k8s-cluster.internal:8000/v1/completions',
      contextWindow: 8192,
      latencyMs: 190,
      costPer1kTokens: 0.0,
      status: 'available',
      isPasquaredProtected: true,
      pasquaredInterceptionRules: ['Total Air-Gap Isolation', 'Strict EKO Storage']
    }
  ],
  agents: [],
  policies: [],
  risks: [],
  complianceControls: [
    {
      id: 'comp-eu-09',
      framework: 'EU AI Act',
      controlCode: 'Art. 9 (Risk Management System)',
      title: 'Sistema Contínuo de Gestão de Riscos',
      description: 'Manter sistema iterativo de identificação, análise e mitigação de riscos ao longo do ciclo de vida da IA',
      status: 'compliant',
      evidenceCount: 42,
      lastAuditDate: '2026-08-10'
    },
    {
      id: 'comp-eu-10',
      framework: 'EU AI Act',
      controlCode: 'Art. 10 (Data & Data Governance)',
      title: 'Governança e Qualidade dos Dados de Treinamento e Ingestão',
      description: 'Garantir que os datasets passem por validação ontológica POKO e testes estatísticos de viés',
      status: 'compliant',
      evidenceCount: 28,
      lastAuditDate: '2026-08-12'
    },
    {
      id: 'comp-eu-14',
      framework: 'EU AI Act',
      controlCode: 'Art. 14 (Human Oversight)',
      title: 'Supervisão Humana Efetiva e Capacidade de Intervenção',
      description: 'Interface clara com capacidade de parada de emergência e aprovação de ações críticas',
      status: 'compliant',
      evidenceCount: 56,
      lastAuditDate: '2026-08-15'
    },
    {
      id: 'comp-iso-42001',
      framework: 'ISO/IEC 42001',
      controlCode: 'A.6.2 (AI System Lifecycle)',
      title: 'Trilha de Auditoria e Rastreabilidade do Ciclo de Decisão',
      description: 'Registro criptográfico imutável de todas as transformações de UCIs em EKOs no PRE',
      status: 'compliant',
      evidenceCount: 89,
      lastAuditDate: '2026-08-18'
    },
    {
      id: 'comp-nist-gov',
      framework: 'NIST AI RMF',
      controlCode: 'GOVERN 1.2',
      title: 'Papeis, Responsabilidades e Transparência Organizacional',
      description: 'Definição formal de perfis de Observadores O=(P,E,K,B) e matriz RACI na governança',
      status: 'compliant',
      evidenceCount: 19,
      lastAuditDate: '2026-08-05'
    },
    {
      id: 'comp-lgpd-art6',
      framework: 'LGPD/GDPR',
      controlCode: 'Art. 6 (Finalidade & Necessidade)',
      title: 'Minimização de Dados e Tratamento Estrito ao Contexto',
      description: 'UCL Parser descarta metadados não autorizados e aplica anonimização instantânea',
      status: 'compliant',
      evidenceCount: 37,
      lastAuditDate: '2026-08-14'
    }
  ],
  ekos: [
    {
      id: 'eko-fin-001',
      version: '1.2.0',
      title: 'Política de Risco de Crédito Imobiliário com Garantia Real',
      domain: 'Finanças & Economia',
      ucis: ['uci-fin-01', 'uci-fin-02', 'uci-fin-03'],
      hypotheses: [
        {
          id: 'hyp-fin-1',
          statement: 'Aprovar financiamento com taxa bonificada se LTV < 60% e DTI < 30%',
          domain: 'Finanças',
          vector: { p: 0.95, c: 0.90, m: 0.88, e: 0.20, l: 0.98 },
          priorProbability: 0.60,
          likelihood: 0.94,
          posteriorP: 0.92,
          igaScore: 0.91,
          status: 'selected',
          evidences: ['Histórico bancário favorável', 'Garantia com matrícula registrada'],
          counterEvidences: []
        }
      ],
      evidences: ['Resolução BACEN 4.676', 'Histórico de 10 anos de inadimplência < 1.2%'],
      graph: {
        nodes: [
          {
            uid: 'uci-fin-01',
            content: 'LTV (Loan to Value) máximo de 60%',
            type: 'concept',
            source: 'Manual de Risco de Crédito',
            category: 'Finanças',
            theme: 'Garantias',
            group: 'Risco',
            w: 0.95,
            ct: 0.90,
            mi: 0.85,
            ei: 0.10,
            timestamp: '2026-08-01T00:00:00Z',
            confidence: 0.96,
            pac: 0.92
          },
          {
            uid: 'uci-fin-02',
            content: 'DTI (Debt to Income) máximo de 30% da renda líquida familiar',
            type: 'concept',
            source: 'Manual de Risco de Crédito',
            category: 'Finanças',
            theme: 'Capacidade de Pagamento',
            group: 'Risco',
            w: 0.90,
            ct: 0.85,
            mi: 0.80,
            ei: 0.10,
            timestamp: '2026-08-01T00:00:00Z',
            confidence: 0.93,
            pac: 0.88
          }
        ],
        edges: [
          {
            fromUid: 'uci-fin-01',
            toUid: 'uci-fin-02',
            type: 'logical',
            w: 0.88,
            description: 'Relação de solvência e cobertura mútua de risco'
          }
        ]
      },
      confidence: 0.93,
      maturity: 'consolidated',
      insights: [
        {
          insightID: 'ins-fin-001',
          originEkoID: 'eko-fin-001',
          category: 'Finanças',
          theme: 'Crédito Imobiliário',
          group: 'Mitigação de Inadimplência',
          noveltyScore: 0.72,
          confidence: 0.93,
          impact: 'high',
          statement: 'A vinculação estrita de LTV e DTI sob validação MVED reduz o risco de inadimplência em 84% frente ao modelo linear tradicional.',
          derivedClusters: ['clus-fin', 'clus-gov'],
          relatedHypotheses: ['hyp-fin-1'],
          timestamp: '2026-08-02T10:00:00Z'
        }
      ],
      selectedMeaning: 'Aprovação de crédito condicionada estritamente aos parâmetros de segurança LTV e DTI com rastreabilidade auditável.',
      iga: 0.91,
      ici: 0.94,
      timestamp: '2026-08-02T10:00:00Z'
    }
  ],
  workflows: [],
  knowledgeBases: [
    {
      id: 'kb-pub-legal-eu',
      name: 'União Europeia • EU AI Act & GDPR Corpus Oficial',
      area: 'Jurídico & Regulatório',
      scope: 'public',
      sourceUrlOrHost: 'https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R1689',
      authMethod: 'public_no_auth',
      recordsCount: 14820,
      lastSyncedAt: '2026-08-20T14:30:00Z',
      status: 'connected',
      description: 'Corpus integral do Regulamento (UE) 2024/1689 (EU AI Act), diretrizes de classificação de risco e obrigações de transparência.',
      mappedDimension: 'Salvaguarda & Risco (δ)',
      autoSync: true,
      format: 'PDF/Docs'
    },
    {
      id: 'kb-pub-fin-bacen',
      name: 'BACEN / CVM • Normativas de Risco, Open Finance & Pix',
      area: 'Financeiro & Bancário',
      scope: 'public',
      sourceUrlOrHost: 'https://www.bcb.gov.br/estabilidadefinanceira/buscanormas',
      authMethod: 'public_no_auth',
      recordsCount: 38400,
      lastSyncedAt: '2026-08-20T16:00:00Z',
      status: 'connected',
      description: 'Resoluções CMN, instruções normativas BACEN para risco de crédito, prevenção à lavagem de dinheiro (PLD-FT) e Basileia III.',
      mappedDimension: 'Evidência (α)',
      autoSync: true,
      format: 'REST Feed'
    },
    {
      id: 'kb-pub-med-pubmed',
      name: 'PubMed / NIH • Diretrizes Clínicas & Farmacopeia Global',
      area: 'Saúde & Medicina',
      scope: 'public',
      sourceUrlOrHost: 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils',
      authMethod: 'public_no_auth',
      recordsCount: 92150,
      lastSyncedAt: '2026-08-19T22:15:00Z',
      status: 'connected',
      description: 'Artigos indexados, interações medicamentosas, ensaios clínicos controlados e protocolos terapêuticos validados pela OMS/ANVISA.',
      mappedDimension: 'Evidência (α)',
      autoSync: true,
      format: 'Ontological Graph'
    },
    {
      id: 'kb-pub-tech-nist',
      name: 'NIST AI RMF & ISO/IEC 42001 Standard Frameworks',
      area: 'Tecnologia & Cibersegurança',
      scope: 'public',
      sourceUrlOrHost: 'https://csrc.nist.gov/publications/detail/white-paper/2023/01/26/ai-risk-management-framework',
      authMethod: 'public_no_auth',
      recordsCount: 8900,
      lastSyncedAt: '2026-08-20T11:00:00Z',
      status: 'connected',
      description: 'Mapas de controles de segurança, mitigação de vieses algorítmicos e frameworks de governança de inteligência artificial.',
      mappedDimension: 'Salvaguarda & Risco (δ)',
      autoSync: true,
      format: 'PDF/Docs'
    },
    {
      id: 'kb-pub-gov-lgpd',
      name: 'ANPD / Planalto • LGPD & Direito Civil Brasileiro',
      area: 'Governança & Risco',
      scope: 'public',
      sourceUrlOrHost: 'https://www.gov.br/anpd/pt-br/assuntos/legislacao-e-normas',
      authMethod: 'public_no_auth',
      recordsCount: 12450,
      lastSyncedAt: '2026-08-20T09:45:00Z',
      status: 'connected',
      description: 'Legislação nacional sobre proteção de dados pessoais (Lei nº 13.709/2018), guias orientativos de legítimo interesse e DPO.',
      mappedDimension: 'Salvaguarda & Risco (δ)',
      autoSync: true,
      format: 'PDF/Docs'
    }
  ]
};

// GET whole database
app.get('/api/db', (req, res) => {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2), 'utf-8');
    }
    const data = fs.readFileSync(DB_PATH, 'utf-8');
    res.json({ success: true, db: JSON.parse(data) });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST whole or partial updates to database
app.post('/api/db/save', (req, res) => {
  try {
    let currentDb = DEFAULT_DB;
    if (fs.existsSync(DB_PATH)) {
      currentDb = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    }
    const updatedDb = { ...currentDb, ...req.body };
    fs.writeFileSync(DB_PATH, JSON.stringify(updatedDb, null, 2), 'utf-8');
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Lazy Google GenAI initialization
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    system: 'PASQUARED Enterprise AI Governance',
    version: '2.5.0-ENTERPRISE',
    kernel: 'PASQUARED-OS PCK v1.0',
    timestamp: new Date().toISOString()
  });
});

// PASQUARED AI Interception & Gateway Generation Route
app.post('/api/gateway/generate', async (req, res) => {
  try {
    const { prompt, modelId, systemPrompt, pasquaredValidation } = req.body;

    const ai = getGenAI();
    let generatedText = '';
    let usedProvider = 'Local/Simulated PASQUARED Cluster';

    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            systemInstruction: systemPrompt || 'Você é o motor de execução cognitiva do PASQUARED Enterprise AI Governance. Forneça respostas estruturadas com justificativas epistemológicas.',
          }
        });
        generatedText = response.text || '';
        usedProvider = 'Google Gemini 2.5 Flash via PASQUARED Gateway';
      } catch (err: any) {
        console.warn('Gemini API call failed, falling back to cognitive synthesis:', err.message);
        generatedText = `[Síntese Cognitiva PASQUARED]: Processamento executado com base nos postulados da ontologia POKO. A solicitação "${prompt.substring(0, 60)}..." foi validada pelo operador MVED com índice de consistência satisfatório.`;
      }
    } else {
      generatedText = `[Síntese Cognitiva PASQUARED]: Processamento executado com base nos postulados da ontologia POKO. A solicitação "${prompt.substring(0, 60)}..." foi validada pelo operador MVED com índice de consistência satisfatório.`;
    }

    res.json({
      success: true,
      text: generatedText,
      provider: usedProvider,
      latencyMs: Math.floor(Math.random() * 250) + 120,
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Automated System Installer Generator Route
app.get('/api/installer/script', (req, res) => {
  const scriptPath = path.join(process.cwd(), 'install-pasq.sh');
  if (fs.existsSync(scriptPath)) {
    const scriptContent = fs.readFileSync(scriptPath, 'utf-8');
    res.setHeader('Content-Type', 'text/x-shellscript');
    res.setHeader('Content-Disposition', 'attachment; filename="install-pasq.sh"');
    return res.send(scriptContent);
  }

  res.setHeader('Content-Type', 'text/x-shellscript');
  res.setHeader('Content-Disposition', 'attachment; filename="install-pasq.sh"');
  res.send(`#!/usr/bin/env bash
# PASQUARED-OS Automated Installer
DOMAIN="app.pasquared.space"
echo "Installing PASQUARED-OS for https://\${DOMAIN}..."
`);
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PASQUARED Enterprise AI Governance running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
