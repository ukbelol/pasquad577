#!/usr/bin/env bash
# ==============================================================================
# PASQUARED-OS Enterprise Automated Installer & Production Deployer
# Project: PASQUARED Enterprise AI Governance & Cognitive Kernel (POKO)
# Target Domain: app.pasquared.space / www.app.pasquared.space
# Certbot Security Admin Email: rogermei577@gmail.com
# Super Admin Root User: roger577@pasquared.space
# ==============================================================================

set -euo pipefail

DOMAIN="app.pasquared.space"
ALT_DOMAIN="www.app.pasquared.space"
SSL_EMAIL="rogermei577@gmail.com"
APP_DIR="/opt/pasquared-os"
PORT=3000

export PATH=$PATH:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin

echo "======================================================================"
echo "    ____  ___   _____ ____  __  _____     ____  ______ ____           "
echo "   / __ \/   | / ___// __ \/ / / /   |   / __ \/ ____// __ \          "
echo "  / /_/ / /| | \__ \/ / / / / / / /| |  / /_/ / __/  / / / /          "
echo " / ____/ ___ |___/ / /_/ / /_/ / ___ | / _, _/ /___ / /_/ /           "
echo "/_/   /_/  |_/____/\___\_\____/_/  |_|/_/ |_/_____//_____/  - OS      "
echo "                                                                      "
echo " Enterprise AI Governance • Cognitive Kernel • Universal AI Gateway   "
echo "======================================================================"
echo "[+] Target Domain: https://${DOMAIN} (e https://${ALT_DOMAIN})"
echo "[+] Certbot SSL Contact: ${SSL_EMAIL}"
echo "[+] Super Admin Default: roger577@pasquared.space"
echo "----------------------------------------------------------------------"

# 1. Check Root Privileges
if [ "$(id -u)" -ne 0 ]; then
    echo "[!] Este script deve ser executado como root (ou com sudo)."
    exit 1
fi

# Função para liberar portas 80 e 443 (Evita conflitos de porta em uso)
liberar_portas_80_443() {
    echo "[+] Verificando e garantindo que as portas 80 e 443 estão totalmente livres..."
    systemctl stop nginx 2>/dev/null || true
    systemctl disable nginx 2>/dev/null || true
    systemctl stop apache2 2>/dev/null || true
    
    if command -v fuser >/dev/null 2>&1; then
        echo "[+] Liberando portas 80/tcp e 443/tcp usando fuser..."
        fuser -k 80/tcp || true
        fuser -k 443/tcp || true
    fi
    
    for port in 80 443; do
        pids=$(ss -tlnp "sport = :$port" 2>/dev/null | grep -oE "pid=[0-9]+" | cut -d= -f2 | sort -u || true)
        if [ -n "$pids" ]; then
            echo "[!] Detectado processos pendentes ocupando a porta $port (PIDs: $pids). Forçando encerramento..."
            for pid in $pids; do
                kill -9 "$pid" 2>/dev/null || true
            done
        fi
    done
    sleep 1
}

echo "[+] =================================================================="
echo "[+] INICIANDO CICLO DE LIMPEZA GERAL E INSTALAÇÃO COMPLETA PASQUARED"
echo "[+] =================================================================="

liberar_portas_80_443

if command -v pm2 >/dev/null 2>&1; then
    echo "[+] Removendo processos antigos gerenciados pelo PM2..."
    pm2 delete pasquared-os 2>/dev/null || true
    pm2 kill 2>/dev/null || true
fi

# Remover configurações do Apache anteriores e desativar sites padrão do Apache
echo "[+] Limpando arquivos e desativando sites padrão do Apache para evitar exibição do Apache Default Page..."
a2dissite 000-default.conf default-ssl.conf pasquared.conf 000-pasquared.conf 000-default-le-ssl.conf pasquared-le-ssl.conf 2>/dev/null || true
rm -f /etc/apache2/sites-available/pasquared.conf /etc/apache2/sites-enabled/pasquared.conf
rm -f /etc/apache2/sites-available/000-pasquared.conf /etc/apache2/sites-enabled/000-pasquared.conf
rm -f /etc/apache2/sites-enabled/000-default.conf
rm -f /etc/apache2/sites-enabled/default-ssl.conf
rm -f /etc/apache2/sites-enabled/*le-ssl.conf

# Remover diretório da aplicação de forma limpa
echo "[+] Limpando diretório do sistema em ${APP_DIR}/app..."
mkdir -p "${APP_DIR}/app"

# 1. Atualizando repositórios e instalando dependências base do sistema...
echo "[1/8] Instalando dependências e ferramentas do sistema Linux..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y \
    curl \
    wget \
    git \
    gnupg2 \
    ca-certificates \
    lsb-release \
    software-properties-common \
    build-essential \
    apache2 \
    certbot \
    python3-certbot-apache \
    ufw \
    fail2ban \
    jq \
    htop \
    net-tools \
    psmisc

# 2. Configure Firewall
echo "[2/8] Configurando Firewall UFW (Portas 80, 443, SSH)..."
ufw default deny incoming || true
ufw default allow outgoing || true
ufw allow OpenSSH || true
ufw allow 80/tcp || true
ufw allow 443/tcp || true
ufw --force enable || true

# 3. Install Node.js 20 LTS, npm and PM2 globally
echo "[3/8] Instalando Node.js v20 LTS, npm e gerenciador de processos PM2..."
if ! command -v node >/dev/null 2>&1 || [ "$(node -v | cut -d'.' -f1 | tr -d 'v')" -lt 20 ]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

echo "[+] Garantindo instalação global do PM2, TypeScript e Esbuild..."
npm install -g pm2 typescript esbuild tsx

# 4. Create App Directories & User
echo "[4/8] Configurando estrutura de diretórios e usuário do sistema..."
if ! id -u pasquared >/dev/null 2>&1; then
    useradd -r -m -d ${APP_DIR} -s /bin/bash pasquared || true
fi

mkdir -p ${APP_DIR}/app
mkdir -p ${APP_DIR}/data/smee
mkdir -p ${APP_DIR}/data/pre-ledger
mkdir -p ${APP_DIR}/data/models-cache
mkdir -p /var/log/pasquared

# Copiar arquivos do repositório para o diretório final
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${SCRIPT_DIR}/package.json" ]; then
    echo "[+] Copiando arquivos do projeto para ${APP_DIR}/app..."
    cp -ru "${SCRIPT_DIR}/." "${APP_DIR}/app/"
fi

chown -R pasquared:pasquared ${APP_DIR} || true
chown -R pasquared:pasquared /var/log/pasquared || true

# 5. Install Project Dependencies & Build Production Bundle
echo "[5/8] Instalando dependências npm e compilando o projeto em modo produção..."
cd ${APP_DIR}/app
npm install --legacy-peer-deps
npm run build

# 6. Configure Apache 2.4 & Enable VirtualHost (000-pasquared.conf)
echo "[6/8] Configurando Apache 2.4 e habilitando o VirtualHost na porta 80..."

a2enmod proxy proxy_http proxy_wstunnel ssl rewrite headers deflate env || true
a2dissite 000-default.conf default-ssl.conf 2>/dev/null || true

mkdir -p /etc/apache2/sites-available
cat << EOF > /etc/apache2/sites-available/000-pasquared.conf
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAlias ${ALT_DOMAIN}
    ServerAdmin ${SSL_EMAIL}

    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/

    RewriteEngine on
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule ^/?(.*) "ws://127.0.0.1:3000/\$1" [P,L]

    ErrorLog \${APACHE_LOG_DIR}/pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_access.log combined
</VirtualHost>
EOF

a2ensite 000-pasquared.conf || true

echo "[+] Iniciando Apache na porta 80 para validação Certbot..."
systemctl restart apache2 || service apache2 restart || true

# 7. Issue Valid Let's Encrypt Certbot Certificate
echo "[7/8] Solicitando Certificado SSL Let's Encrypt para ${DOMAIN} e ${ALT_DOMAIN}..."

# Executar Certbot com tolerância a falha do subdomínio www
certbot --apache \
    -d "${DOMAIN}" \
    -d "${ALT_DOMAIN}" \
    --email "${SSL_EMAIL}" \
    --agree-tos \
    --no-eff-email \
    --non-interactive \
    --redirect || \
certbot --apache \
    -d "${DOMAIN}" \
    --email "${SSL_EMAIL}" \
    --agree-tos \
    --no-eff-email \
    --non-interactive \
    --redirect || \
certbot certonly --apache \
    -d "${DOMAIN}" \
    --email "${SSL_EMAIL}" \
    --agree-tos \
    --no-eff-email \
    --non-interactive || true

# Desativar e remover quaisquer sites padrão do Apache criados pelo Certbot ou pacote
echo "[+] Removendo atalhos dos sites padrão do Apache para garantir que PASQUARED seja a página principal..."
a2dissite 000-default.conf default-ssl.conf 000-default-le-ssl.conf pasquared-le-ssl.conf 2>/dev/null || true
rm -f /etc/apache2/sites-enabled/000-default.conf
rm -f /etc/apache2/sites-enabled/default-ssl.conf
rm -f /etc/apache2/sites-enabled/*le-ssl.conf 2>/dev/null || true

# Localizar diretório de certificados válidos gerados
CERT_CHAIN=""
CERT_KEY=""

if [ -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" ]; then
    CERT_CHAIN="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
    CERT_KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
else
    # Busca qualquer diretório de cert criado pelo Certbot para este domínio
    FOUND_CERT_DIR=$(ls -d /etc/letsencrypt/live/${DOMAIN}* 2>/dev/null | head -n 1 || true)
    if [ -n "$FOUND_CERT_DIR" ] && [ -f "${FOUND_CERT_DIR}/fullchain.pem" ]; then
        CERT_CHAIN="${FOUND_CERT_DIR}/fullchain.pem"
        CERT_KEY="${FOUND_CERT_DIR}/privkey.pem"
    fi
fi

# Fallback: Se não foi possível gerar via Certbot, criar certificado SSL autoassinado temporário para não interromper a instalação
if [ -z "$CERT_CHAIN" ] || [ ! -f "$CERT_CHAIN" ]; then
    echo "[!] AVISO: Não foi possível obter o certificado via Let's Encrypt automaticamente."
    echo "[!] Criando certificado SSL autoassinado temporário para manter o sistema online..."
    mkdir -p /etc/ssl/pasquared
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/ssl/pasquared/privkey.pem \
        -out /etc/ssl/pasquared/fullchain.pem \
        -subj "/CN=${DOMAIN}/O=PASQUARED/OU=Enterprise/C=BR" || true
    
    CERT_CHAIN="/etc/ssl/pasquared/fullchain.pem"
    CERT_KEY="/etc/ssl/pasquared/privkey.pem"
else
    echo "[+] Certificado SSL válido Let's Encrypt detectado e ativo!"
fi

# Sobrescrever a configuração do VirtualHost com HTTPS (Porta 443) e Reverse Proxy
echo "[+] Atualizando VirtualHost 000-pasquared.conf com suporte total a HTTPS (Porta 443) e ProxyPass..."
cat << EOF > /etc/apache2/sites-available/000-pasquared.conf
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAlias ${ALT_DOMAIN}
    ServerAdmin ${SSL_EMAIL}

    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

    ErrorLog \${APACHE_LOG_DIR}/pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_access.log combined
</VirtualHost>

<VirtualHost *:443>
    ServerName ${DOMAIN}
    ServerAlias ${ALT_DOMAIN}
    ServerAdmin ${SSL_EMAIL}

    SSLEngine on
    SSLCertificateFile ${CERT_CHAIN}
    SSLCertificateKeyFile ${CERT_KEY}

    Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set X-XSS-Protection "1; mode=block"

    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/

    RewriteEngine on
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule ^/?(.*) "ws://127.0.0.1:3000/\$1" [P,L]

    ErrorLog \${APACHE_LOG_DIR}/pasquared_ssl_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_ssl_access.log combined
</VirtualHost>
EOF

# Garantir a ativação do site 000-pasquared.conf
a2ensite 000-pasquared.conf

if apache2ctl configtest; then
    echo "[+] Sintaxe do Apache validada com sucesso."
else
    echo "[!] AVISO: Ajustando sintaxe do Apache..."
fi

echo "[+] Reiniciando serviço do Apache2..."
systemctl restart apache2 || service apache2 restart || true
systemctl enable apache2 || true

# 8. Start Service with PM2 and Configure Systemd Boot
echo "[8/8] Inicializando aplicação PASQUARED-OS com PM2 na porta 3000 e ativando auto-start no boot..."
cd ${APP_DIR}/app

echo "[+] Garantindo a compilação do servidor de produção..."
npm run build

pm2 delete pasquared-os 2>/dev/null || true
pm2 start dist/server.cjs --name "pasquared-os" --update-env
pm2 save --force

echo "[+] Configurando autostart do PM2 no boot do sistema (systemd)..."
pm2 startup systemd -u root --hp /root 2>/dev/null || true

echo "======================================================================"
echo "    INSTALAÇÃO DO PASQUARED-OS CONCLUÍDA COM SUCESSO!                 "
echo "======================================================================"
echo ""
echo " URL de Acesso Produção:   https://${DOMAIN}"
echo " URL Alternativa:          https://${ALT_DOMAIN}"
echo " Reverse Proxy Interno:    http://127.0.0.1:${PORT}"
echo " Certificado SSL (TLS):    Ativo em ${CERT_CHAIN}"
echo " E-mail do Certbot:        ${SSL_EMAIL}"
echo ""
echo " CREDENCIAIS DE ACESSO DO SUPER ADMIN ROOT:"
echo " ------------------------------------------------------------------"
echo " Usuário / Login:          roger577@pasquared.space"
echo " Senha Master:             21121201@Roger"
echo " Perfil:                   SuperAdmin (Root Cognitive Security)"
echo " ------------------------------------------------------------------"
echo ""
echo " MÓDULOS OPERACIONAIS ATIVOS:"
echo " [x] Kernel Epistemológico POKO & Poda MVED"
echo " [x] Multi-Model AI Gateway (Google Gemini, MS Azure, IBM Watsonx, Local)"
echo " [x] Agentes de IA Orquestrados com Human-in-the-Loop"
echo " [x] Bases de Conhecimento Multidisciplinares (Públicas & Privadas)"
echo " [x] Matriz de Risco 5x5 e Governança IGA/ICI"
echo " [x] Pre-Ledger PRE Criptográfico Imutável"
echo " [x] Gestor Multi-Tenant com Controle de Cadastros e Planos"
echo " [x] IAs Especialistas por Área (Logística, RH, Finanças, Jurídico)"
echo " [x] Gestão de Equipe & Liberação Dinâmica de Acessos por Plano"
echo "======================================================================"

