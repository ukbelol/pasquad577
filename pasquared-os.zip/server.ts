import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import geoip from "geoip-lite";
import { UCIType, RelationType, UCI, Relation, Hypothesis, EKO, CognitiveState } from "./src/types";
import { db } from "./server/db";

dotenv.config();

const app = express();
const PORT = 3000;

// Increased limit for image uploads
app.use(express.json({ limit: '50mb' }));

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

/**
 * PASQUARED Cognitive Kernel (PCK)
 */
class PasquaredKernel {
  private memory: EKO[] = [];

  async process(input: string, domain: string = "general", image?: { data: string, mimeType: string }, language: string = "pt"): Promise<{ response: string; state: CognitiveState }> {
    // 1. Acquisition A(U)
    const uci: UCI = {
      uid: `uci-${Date.now()}`,
      type: image ? UCIType.IMAGE : UCIType.TEXT,
      source: "user",
      weight: 0.9,
      contextLocal: domain,
      timestamp: Date.now(),
      content: input
    };

    // 2. Association R(U) & Inference I(G)
    const systemInstruction = `
      You are the PASQUARED Cognitive Kernel (PCK).
      Your goal is to process the input through the PASQUARED architecture.
      
      DOMAIN CONTEXT: ${domain === 'Medicine' ? 'Act as a high-fidelity medical AI integrated with public medical databases. Provide technical reports on symptoms, diagnoses, and imaging (X-ray, MRI, CT).' : domain}
      LANGUAGE: Respond in ${language === 'pt' ? 'Portuguese' : language === 'es' ? 'Spanish' : 'English'}.
      
      ONTOLOGY: S=(O,U,R,C,M,H,S)
      UCI: Ui=(T,F,W,Ct)
      OPERATORS: Acquisition, Association, Inference, Validation, Learning.
      
      Respond in JSON format following this schema:
      {
        "response": "The natural language response to the user. For medical images, provide a detailed technical report.",
        "hypotheses": [
          {
            "description": "Short hypothesis name",
            "probability": 0.0 to 1.0,
            "vectors": { "perception": 0.0-1.0, "context": 0.0-1.0, "memory": 0.0-1.0, "emotion": 0.0-1.0, "logic": 0.0-1.0 }
          }
        ],
        "graph": {
          "relatedConcepts": [
            { "concept": "Concept Name", "weight": 0.0-1.0, "relationType": "causal|temporal|semântica|emocional|espacial|simbólica|lógica" }
          ]
        },
        "metrics": {
          "iga": 0.0-1.0, // Global Abstraction Index
          "ici": 0.0-1.0  // Interpretive Consistency Index
        }
      }
    `;

    const contents: any[] = [`Process the following input: "${input}" in the domain of "${domain}"`];
    if (image) {
      contents.push({
        inlineData: {
          data: image.data,
          mimeType: image.mimeType
        }
      });
    }

    const result = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: contents.map(c => typeof c === 'string' ? { text: c } : c),
      config: {
        systemInstruction,
        responseMimeType: "application/json"
      }
    });

    const responseText = result.text;
    const cognitiveOutput = JSON.parse(responseText || "{}");

    // 3. Construct the Cognitive State
    const nodes: UCI[] = [uci];
    const edges: Relation[] = [];

    cognitiveOutput.graph?.relatedConcepts?.forEach((rel: any, index: number) => {
      const newNode: UCI = {
        uid: `uci-concept-${index}`,
        type: UCIType.CONCEPT,
        source: "kernel",
        weight: rel.weight,
        contextLocal: domain,
        timestamp: Date.now(),
        content: rel.concept
      };
      nodes.push(newNode);
      edges.push({
        sourceUid: uci.uid,
        targetUid: newNode.uid,
        weight: rel.weight,
        type: rel.relationType as RelationType
      });
    });

    const state: CognitiveState = {
      iga: cognitiveOutput.metrics?.iga || 0.5,
      ici: cognitiveOutput.metrics?.ici || 0.5,
      activeGraph: { nodes, edges },
      hypotheses: cognitiveOutput.hypotheses?.map((h: any, i: number) => ({
        id: `h-${i}`,
        ...h,
        evidenceUids: [uci.uid]
      })) || []
    };

    // 4. Learning L(M)
    const eko: EKO = {
      id: `eko-${Date.now()}`,
      version: "1.0",
      ucis: nodes.map(n => n.uid),
      hypotheses: state.hypotheses,
      confidence: state.ici,
      timestamp: Date.now(),
      meaning: cognitiveOutput.response
    };
    this.memory.push(eko);

    return { response: cognitiveOutput.response, state };
  }
}

const kernel = new PasquaredKernel();

async function startServer() {
  // API routes
  app.get("/api/config", (req, res) => {
    const ip = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || "").split(',')[0];
    const geo = geoip.lookup(ip);
    let lang = "en";
    if (geo) {
      if (geo.country === "BR" || geo.country === "PT") lang = "pt";
      else if (["ES", "MX", "AR", "CO", "CL"].includes(geo.country)) lang = "es";
    }
    res.json({ lang, geo });
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { message, domain, image, language } = req.body;
      const result = await kernel.process(message, domain, image, language);
      res.json(result);
    } catch (error: any) {
      console.error("Kernel Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/admin/stats", (req, res) => {
    const data = db.getData();
    // Simulated cluster and architecture monitoring data integrated with persistent DB status
    const stats = {
      clusters: [
        { name: "Medicine", status: "Active", load: Math.random() * 80 + 10, workers: 12 },
        { name: "Law", status: "Standby", load: Math.random() * 20, workers: 4 },
        { name: "Physics", status: "Active", load: Math.random() * 50 + 5, workers: 8 },
        { name: "Logic", status: "Active", load: Math.random() * 30 + 5, workers: 6 },
        { name: "SMEE Memory", status: "Synced", load: 15, workers: 2 }
      ],
      globalMetrics: {
        requestsPerMinute: Math.floor(Math.random() * 500 + 100),
        cpuUsage: 42,
        memoryUsage: 68,
        uptime: "14d 06h 22m",
        totalIngestedRecords: data.systemConfig.totalRecordsIngested,
        dbStatus: data.systemConfig.dbStatus
      }
    };
    res.json(stats);
  });

  // Super Admin Authentication & Persistent DB Routes
  app.post("/api/admin/login", (req, res) => {
    const { email, password } = req.body;
    if (db.authenticate(email, password)) {
      db.addLog("SECURITY", `Successful Super Admin login for ${email}`, email);
      res.json({
        success: true,
        token: `pasquared-token-${Date.now()}`,
        email,
        db: db.getData()
      });
    } else {
      db.addLog("SECURITY", `Failed Super Admin login attempt for ${email}`, "UNKNOWN");
      res.status(401).json({ success: false, error: "Credenciais de Super Admin inválidas." });
    }
  });

  app.get("/api/admin/db", (req, res) => {
    res.json({ db: db.getData() });
  });

  app.post("/api/admin/load-knowledge", (req, res) => {
    const result = db.loadKnowledgeBase();
    res.json({ success: true, result, db: db.getData() });
  });

  app.post("/api/admin/add-knowledge", (req, res) => {
    const { title, source, region, domain, abstract } = req.body;
    if (!title || !source) {
      return res.status(400).json({ error: "Título e Fonte são obrigatórios." });
    }
    const item = db.addCustomKnowledge(title, source, region || "South America", domain || "General", abstract || "");
    res.json({ success: true, item, db: db.getData() });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Pasquared-OS running on http://localhost:${PORT}`);
  });
}

startServer();
