#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

# ==============================================================================
# PASQUARED OS - INSTALADOR AUTOMATIZADO COMPLETO (install-full.sh)
# Domínio: app.pasquared.space
# E-mail: rogermei577@gmail.com
# Serviços: Node.js 22, Vite, Apache2, Certbot SSL, PM2, Microsoft AI Foundry
# ==============================================================================

PASQ_DOMAIN="${PASQ_DOMAIN:-app.pasquared.space}"
PASQ_EMAIL="${PASQ_EMAIL:-rogermei577@gmail.com}"
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NODE_PORT="${NODE_PORT:-3000}"
NODE_MAJOR="${NODE_MAJOR:-22}"

export DEBIAN_FRONTEND=noninteractive

log() { printf '\n\033[1;36m==> [PASQUARED INSTALL] %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[AVISO] %s\033[0m\n' "$*" >&2; }
error() { printf '\033[1;31m[ERRO] %s\033[0m\n' "$*" >&2; exit 1; }

trap 'error "Falha na execução na linha $LINENO. Verifique as mensagens acima."' ERR

# 1. Verificar permissões de administrador (root)
if [[ "$EUID" -ne 0 ]]; then
  error "Este script precisa ser executado como root. Execute: sudo bash install-full.sh"
fi

log "Iniciando instalador automatizado do sistema para $PASQ_DOMAIN..."
log "Diretório de trabalho: $APP_DIR"

# 2. Atualizar repositórios e instalar utilitários base do sistema
log "Etapa 1/8: Atualizando pacotes e instalando dependências de sistema..."
apt-get update -y
apt-get install -y --no-install-recommends \
  ca-certificates \
  curl \
  gnupg \
  openssl \
  build-essential \
  git \
  unzip \
  zip \
  jq \
  ufw \
  software-properties-common \
  lsb-release

# 3. Instalar Node.js 22.x e npm via NodeSource
log "Etapa 2/8: Configurando Node.js ${NODE_MAJOR}.x e npm..."
if ! command -v node >/dev/null 2>&1 || [[ $(node -v | cut -d'.' -f1 | tr -d 'v') -lt 20 ]]; then
  install -d -m 0755 /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key \
    | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
  chmod 0644 /etc/apt/keyrings/nodesource.gpg
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_${NODE_MAJOR}.x nodistro main" \
    > /etc/apt/sources.list.d/nodesource.list
  apt-get update -y
  apt-get install -y nodejs
fi

log "Node.js versão: $(node -v)"
log "NPM versão: $(npm -v)"

# 4. Instalar Apache2, Certbot e módulos de proxy
log "Etapa 3/8: Instalando Apache2, Certbot e plugin Apache..."
apt-get install -y \
  apache2 \
  certbot \
  python3-certbot-apache

# Habilitar módulos necessários no Apache2
log "Habilitando módulos proxy, ssl, rewrite e headers do Apache2..."
a2enmod proxy proxy_http proxy_wstunnel ssl rewrite headers

# 5. Configurar ferramentas Microsoft Foundry / Azure SDKs
log "Etapa 4/8: Instalando CLI e bibliotecas Microsoft AI Foundry..."
if ! command -v az >/dev/null 2>&1; then
  log "Instalando Azure CLI para suporte ao Microsoft AI Foundry..."
  curl -sL https://aka.ms/InstallAzureCLIDeb | bash || warn "Azure CLI não pode ser instalado diretamente via script, prosseguindo com pacotes npm Microsoft Foundry."
fi

# 6. Instalar PM2 para gerenciamento continuo de processos
log "Etapa 5/8: Instalando PM2 globalmente..."
npm install -g pm2

# 7. Instalar dependências da aplicação Vite, React, Express e Microsoft Foundry
log "Etapa 6/8: Instalando pacotes npm da aplicação..."
cd "$APP_DIR"
npm install --legacy-peer-deps

# Garantir dependências do Microsoft AI Foundry no projeto
npm install @azure/ai-projects @azure/identity @azure/core-auth @azure-rest/ai-inference --legacy-peer-deps

log "Compilando projeto Vite para produção..."
npm run build

# 8. Configurar Apache Virtual Host para o domínio app.pasquared.space
log "Etapa 7/8: Configurando Virtual Host no Apache2 para $PASQ_DOMAIN..."

mkdir -p /var/www/html/.well-known/acme-challenge
chown -R www-data:www-data /var/www/html/.well-known

APACHE_CONF="/etc/apache2/sites-available/${PASQ_DOMAIN}.conf"

cat > "$APACHE_CONF" <<EOF
<VirtualHost *:80>
    ServerName ${PASQ_DOMAIN}
    ServerAdmin ${PASQ_EMAIL}

    DocumentRoot /var/www/html

    # Permitir o desafio HTTP-01 do Certbot sem bloqueios
    <Directory /var/www/html/.well-known/acme-challenge/>
        Options FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>

    # Configuração de Proxy Reverso para o servidor Node/Vite (PM2 rodando na porta ${NODE_PORT})
    ProxyPreserveHost On
    ProxyPass /.well-known/acme-challenge/ !
    ProxyPass / http://127.0.0.1:${NODE_PORT}/
    ProxyPassReverse / http://127.0.0.1:${NODE_PORT}/

    # Suporte a WebSockets
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule /(.*) ws://127.0.0.1:${NODE_PORT}/\$1 [P,L]

    ErrorLog \${APACHE_LOG_DIR}/${PASQ_DOMAIN}_error.log
    CustomLog \${APACHE_LOG_DIR}/${PASQ_DOMAIN}_access.log combined
</VirtualHost>
EOF

# Ativar site no Apache e desativar default se presente
a2ensite "${PASQ_DOMAIN}.conf"
a2dissite 000-default.conf || true

# Validar sintaxe da configuração do Apache e reiniciar serviço
apache2ctl configtest
systemctl restart apache2

# 9. Gerar Certificado SSL Válido com Certbot
log "Etapa 8/8: Emitindo certificado SSL Válido com Certbot para ${PASQ_DOMAIN}..."
if [ -d "/etc/letsencrypt/live/${PASQ_DOMAIN}" ]; then
  log "Certificado SSL para ${PASQ_DOMAIN} já existe. Renovando/validando..."
  certbot renew --quiet || true
else
  log "Executando desafio do Certbot para obter certificado SSL HTTPS..."
  certbot --apache \
    -d "${PASQ_DOMAIN}" \
    --non-interactive \
    --agree-tos \
    -m "${PASQ_EMAIL}" \
    --redirect \
    --no-eff-email || warn "Certbot não concluiu a emissão automatizada (verifique se o DNS de ${PASQ_DOMAIN} aponta para este servidor)."
fi

# Recarregar Apache para aplicar certificado SSL
systemctl reload apache2 || systemctl restart apache2

# 10. Gerenciar a aplicação via PM2 e colocar o sistema online
log "Iniciando aplicação no PM2 e configurando inicialização automática..."
pm2 delete pasquared-app 2>/dev/null || true

# Iniciar servidor Node
pm2 start server.js --name "pasquared-app" --watch false
pm2 save

# Configurar autostart do PM2 no boot do sistema
env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u root --hp /root || true

# Liberar portas no firewall se o UFW estiver habilitado
if command -v ufw >/dev/null 2>&1; then
  ufw allow 80/tcp || true
  ufw allow 443/tcp || true
  ufw allow 22/tcp || true
fi

log "=========================================================================="
log " INSTALAÇÃO E SISTEMA ONLINE COM SUCESSO!"
log "=========================================================================="
log " URL do Sistema: https://${PASQ_DOMAIN}"
log " E-mail SSL / Segurança: ${PASQ_EMAIL}"
log " Porta da Aplicação Interna: ${NODE_PORT}"
log " Gerenciador de Processo: PM2 (Processo: pasquared-app)"
log " Tecnologias Instaladas: Node.js ${NODE_MAJOR}, Vite, Apache2, Certbot SSL, Microsoft AI Foundry"
log "=========================================================================="
pm2 status
