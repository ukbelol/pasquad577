import fs from "fs";
import path from "path";

export interface KnowledgeSource {
  id: string;
  name: string;
  region: "South America" | "North America";
  domain: string;
  status: "Active" | "Syncing" | "Offline";
  lastSync: string;
  recordCount: number;
  url: string;
}

export interface KnowledgeItem {
  id: string;
  title: string;
  source: string;
  region: string;
  domain: string;
  timestamp: number;
  abstract: string;
  status: string;
}

export interface SystemLog {
  id: string;
  timestamp: number;
  type: "INFO" | "INGESTION" | "SECURITY" | "KERNEL";
  message: string;
  user: string;
}

export interface DBData {
  admin: {
    email: string;
    passwordHash: string;
  };
  sources: KnowledgeSource[];
  knowledgeItems: KnowledgeItem[];
  logs: SystemLog[];
  systemConfig: {
    version: string;
    lastKnowledgeLoad: string | null;
    totalRecordsIngested: number;
    dbStatus: string;
  };
}

const DB_PATH = path.join(process.cwd(), "data", "pasquared_db.json");

const INITIAL_DATA: DBData = {
  admin: {
    email: "rogermei577@pasquared.space",
    passwordHash: "21121201@Roger-Pasq"
  },
  sources: [
    {
      id: "scielo",
      name: "SciELO (Scientific Electronic Library Online)",
      region: "South America",
      domain: "Multidisciplinary Science & Health",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 1420000,
      url: "https://scielo.org"
    },
    {
      id: "lilacs",
      name: "LILACS (América Latina e Caribe)",
      region: "South America",
      domain: "Medicine & Health Sciences",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 890000,
      url: "https://lilacs.bvsalud.org"
    },
    {
      id: "sus_data",
      name: "SUS Open Data (Ministério da Saúde - Brasil)",
      region: "South America",
      domain: "Public Health & Epidemiology",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 3500000,
      url: "https://datasus.saude.gov.br"
    },
    {
      id: "redalyc",
      name: "Redalyc (Red Iberoamericana)",
      region: "South America",
      domain: "Scientific Journals",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 750000,
      url: "https://redalyc.org"
    },
    {
      id: "pubmed",
      name: "PubMed / National Library of Medicine",
      region: "North America",
      domain: "Biomedical Literature & Life Sciences",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 35000000,
      url: "https://pubmed.ncbi.nlm.nih.gov"
    },
    {
      id: "nih",
      name: "NIH (National Institutes of Health)",
      region: "North America",
      domain: "Genomics & Clinical Trials",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 12000000,
      url: "https://nih.gov"
    },
    {
      id: "cdc",
      name: "CDC (Centers for Disease Control)",
      region: "North America",
      domain: "Epidemiology & Global Health",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 4500000,
      url: "https://cdc.gov"
    },
    {
      id: "mayo",
      name: "Mayo Clinic Research Database",
      region: "North America",
      domain: "Clinical Research & Diagnostics",
      status: "Active",
      lastSync: new Date().toISOString(),
      recordCount: 2100000,
      url: "https://mayoclinic.org/research"
    }
  ],
  knowledgeItems: [
    {
      id: "k-101",
      title: "Análise Epidemiológica das Arboviroses Tropicais",
      source: "SUS Open Data",
      region: "South America",
      domain: "Medicine",
      timestamp: Date.now() - 3600000,
      abstract: "Mapeamento genômico e de contágio das arboviroses no ecossistema Neotropical.",
      status: "Verified & Ingested"
    },
    {
      id: "k-102",
      title: "CRISPR-Cas9 Therapeutic Targets in Oncology",
      source: "PubMed",
      region: "North America",
      domain: "Medicine",
      timestamp: Date.now() - 7200000,
      abstract: "High-throughput genomic sequencing data for targeting solid tumor mutations.",
      status: "Verified & Ingested"
    },
    {
      id: "k-103",
      title: "Direito Ambiental Transnacional e Mudanças Climáticas",
      source: "SciELO",
      region: "South America",
      domain: "Law",
      timestamp: Date.now() - 10800000,
      abstract: "Análise comparativa das legislações ambientais do Cone Sul.",
      status: "Verified & Ingested"
    }
  ],
  logs: [
    {
      id: "log-1",
      timestamp: Date.now() - 100000,
      type: "SECURITY",
      message: "Super Admin Authentication System Initialized for rogermei577@pasquared.space",
      user: "SYSTEM"
    },
    {
      id: "log-2",
      timestamp: Date.now() - 50000,
      type: "INGESTION",
      message: "Persistent Database pasquared_db.json successfully mounted.",
      user: "KERNEL"
    }
  ],
  systemConfig: {
    version: "PCK-v1.6-PERSISTENT",
    lastKnowledgeLoad: new Date().toISOString(),
    totalRecordsIngested: 60160000,
    dbStatus: "Persistent File Storage Mounted"
  }
};

export class PersistentDatabase {
  private data: DBData;

  constructor() {
    this.data = this.load();
  }

  private ensureDirectory() {
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  private load(): DBData {
    try {
      this.ensureDirectory();
      if (fs.existsSync(DB_PATH)) {
        const raw = fs.readFileSync(DB_PATH, "utf-8");
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error("Error reading database, resetting to initial:", e);
    }
    const initial = { ...INITIAL_DATA };
    this.save(initial);
    return initial;
  }

  public save(data?: DBData) {
    try {
      this.ensureDirectory();
      const dataToSave = data || this.data;
      fs.writeFileSync(DB_PATH, JSON.stringify(dataToSave, null, 2), "utf-8");
    } catch (e) {
      console.error("Error saving persistent database:", e);
    }
  }

  public getData(): DBData {
    return this.data;
  }

  public authenticate(email: string, pass: string): boolean {
    return (
      email === this.data.admin.email &&
      pass === this.data.admin.passwordHash
    );
  }

  public addLog(type: "INFO" | "INGESTION" | "SECURITY" | "KERNEL", message: string, user: string = "SYSTEM") {
    const log: SystemLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      type,
      message,
      user
    };
    this.data.logs.unshift(log);
    if (this.data.logs.length > 200) this.data.logs.pop();
    this.save();
  }

  public loadKnowledgeBase(): { added: number; updatedSources: number } {
    const newItems: KnowledgeItem[] = [
      {
        id: `k-${Date.now()}-1`,
        title: "Protocolo Clínico Oncologia de Precisão (SciELO 2026)",
        source: "SciELO",
        region: "South America",
        domain: "Medicine",
        timestamp: Date.now(),
        abstract: "Novas abordagens imunoterapêuticas para tratamento de neoplasias em hospitais públicos.",
        status: "Ingested via UCL"
      },
      {
        id: `k-${Date.now()}-2`,
        title: "Real-World Evidence in Multi-Center Vaccine Evaluation",
        source: "CDC / NIH",
        region: "North America",
        domain: "Medicine",
        timestamp: Date.now(),
        abstract: "Comprehensive retrospective analysis of public health intervention efficacy.",
        status: "Ingested via UCL"
      },
      {
        id: `k-${Date.now()}-3`,
        title: "Banco de Dados de Mapeamento Epidemiológico Dengue & Zika (Datasus)",
        source: "SUS Open Data",
        region: "South America",
        domain: "Medicine",
        timestamp: Date.now(),
        abstract: "Série temporal de incidência e geolocalização de vetores nas regiões Norte e Nordeste.",
        status: "Ingested via UCL"
      },
      {
        id: `k-${Date.now()}-4`,
        title: "Mayo Clinic Diagnostic Biomarkers for Early Neurological Assessment",
        source: "Mayo Clinic",
        region: "North America",
        domain: "Medicine",
        timestamp: Date.now(),
        abstract: "Quantitative plasma biomarker indicators for early neurodegenerative detection.",
        status: "Ingested via UCL"
      }
    ];

    this.data.knowledgeItems.unshift(...newItems);
    let totalAddedCount = 150000;
    
    this.data.sources.forEach(src => {
      src.recordCount += Math.floor(Math.random() * 20000 + 5000);
      src.lastSync = new Date().toISOString();
      src.status = "Active";
    });

    this.data.systemConfig.totalRecordsIngested += totalAddedCount;
    this.data.systemConfig.lastKnowledgeLoad = new Date().toISOString();

    this.addLog("INGESTION", `Carregada Base de Conhecimento das Américas (América do Sul e América do Norte). +${totalAddedCount} registros sintetizados em CDNA.`, "SuperAdmin");

    this.save();
    return { added: newItems.length, updatedSources: this.data.sources.length };
  }

  public addCustomKnowledge(title: string, source: string, region: string, domain: string, abstract: string) {
    const item: KnowledgeItem = {
      id: `k-custom-${Date.now()}`,
      title,
      source,
      region,
      domain,
      timestamp: Date.now(),
      abstract,
      status: "Custom Ingested"
    };
    this.data.knowledgeItems.unshift(item);
    this.addLog("INGESTION", `Novo conhecimento personalizado adicionado: "${title}" (${domain}).`, "SuperAdmin");
    this.save();
    return item;
  }
}

export const db = new PersistentDatabase();
