# Guia de Implantação Automatizada e Migração VPS — app.pasquared

Este guia descreve o procedimento para clonar, migrar e executar o **app.pasquared** (com Kernel Cognitivo PASQUARED, Anamnese Investigativa Médica, Análise de Exames/Imagens e Banco de Dados Persistente) em qualquer VPS com **Debian 12 (Bookworm)**.

---

## 📋 Pré-requisitos
- Um servidor VPS com **Debian 12** limpo ou configurado.
- Acesso SSH como usuário `root` ou com privilégios `sudo`.
- Apontamento DNS do domínio `app.pasquared.space` para o endereço IP do seu VPS.
- Chave da API Gemini (`GEMINI_API_KEY`).

---

## ⚡ Passo 1: Preparar o VPS Debian 12

Acesse seu servidor por SSH:
```bash
ssh root@app.pasquared.space
```

Crie o diretório de destino da aplicação:
```bash
sudo mkdir -p /var/www/app.pasquared
sudo chown -R $USER:$USER /var/www/app.pasquared
cd /var/www/app.pasquared
```

---

## 📦 Passo 2: Copiar / Clonar os Arquivos do Projeto

Copie a pasta inteira do projeto (ou clone do repositório Git):
```bash
git clone <URL_DO_REPOSITORIO_GIT> .
```

Garantir que a permissão do script de instalação seja executável:
```bash
chmod +x install-pasq.sh
```

---

## 🚀 Passo 3: Executar o Instalador Automático `install-pasq.sh`

Defina a chave da API Gemini e execute o script de instalação automatizado:

```bash
export GEMINI_API_KEY="SUA_CHAVE_GEMINI_AQUI"
./install-pasq.sh
```

---

## 🔍 O que o Instalador `install-pasq.sh` Executa Automaticamente:

1. **Atualização de Pacotes do Sistema**: Executa `apt update && apt upgrade` no Debian 12.
2. **Instalação do Node.js 20.x, Git e Build Tools**: Garante a runtime oficial do Node.js v20 e compiladores nativos.
3. **Instalação Global do PM2**: Gerenciador de processos nativo para manter a API ativa 24/7.
4. **Liberação de Portas e Limpeza**: Interrompe Nginx/Apache concorrentes e libera as portas 80/443.
5. **Configuração de Banco de Dados Persistente**: Prepara a pasta `data/pasquared_db.json` com permissões de leitura e escrita.
6. **Compilação de Ativos e API**:
   - `npm install` para instalar todas as dependências.
   - `npm run build` para gerar a compilação do frontend com Vite e empacotar o servidor backend Node/Express (`server.ts`) em um único arquivo CJS (`dist/server.cjs`).
7. **Reverse Proxy Apache2**:
   - Cria o arquivo `/etc/apache2/sites-available/app-pasquared.conf`.
   - Mapeia as requisições de `app.pasquared.space` para `127.0.0.1:3000`.
   - Habilita suporte a WebSockets e SSE.
8. **SSL Automático com Let's Encrypt / Certbot**:
   - Gera e instala o certificado SSL para `app.pasquared.space`.
   - Configura o redirecionamento automático HTTP -> HTTPS.
   - Ativa o `certbot.timer` para renovação automática dos certificados.
9. **Gerenciador de Inicialização PM2**:
   - Inicia o serviço `app-pasquared` rodando `dist/server.cjs`.
   - Configura a inicialização automática no boot do sistema Debian 12 com `systemd`.

---

## 🔑 Credenciais e Endpoints Ativos

- **URL do Sistema**: `https://app.pasquared.space`
- **Painel Restrito Super Admin**: `https://app.pasquared.space/rootsuperadmin`
- **E-mail Super Admin**: `rogermei577@pasquared.space`
- **Senha Super Admin**: `21121201@Roger-Pasq`
- **Arquivo do Banco Persistente**: `data/pasquared_db.json`
- **Recursos**: Anamnese Investigativa com Diagnóstico Progressivo, Análise de Exames/Imagens Médicas, Protocolo UCL v1.6.

---

## 🛠️ Comandos de Manutenção no VPS

### Verificar status da aplicação
```bash
pm2 status app-pasquared
```

### Visualizar logs da API em tempo real
```bash
pm2 logs app-pasquared
```

### Reiniciar a aplicação
```bash
pm2 restart app-pasquared
```

### Verificar status do servidor web Apache2
```bash
sudo systemctl status apache2
```
