# Manual de Instalação no VPS Linux Debian 12 — app.pasquared

Este guia instrui a migração e implantação completa do **app.pasquared** (Kernel Cognitivo PASQUARED com Anamnese Investigativa, Análise Médica de Imagens e Banco Persistente) em um VPS rodando **Debian 12 (Bookworm)**.

---

## 🚀 Passo a Passo de Instalação Automatizada

### 1. Acesse seu VPS Debian 12 via SSH
```bash
ssh root@app.pasquared.space
```

### 2. Baixe ou Copie os Arquivos do Projeto para o VPS
Copie a pasta inteira do projeto para o VPS (por exemplo, em `/var/www/app.pasquared` ou no diretório home do seu usuário):
```bash
sudo mkdir -p /var/www/app.pasquared
sudo chown -R $USER:$USER /var/www/app.pasquared
cd /var/www/app.pasquared
```

### 3. Defina a Chave da API Gemini (Se houver) e Execute o Instalador
```bash
export GEMINI_API_KEY="SUA_CHAVE_GEMINI_AQUI"
chmod +x install-pasq.sh
./install-pasq.sh
```

---

## 🛠️ O que o script `install-pasq.sh` faz automaticamente:

1. **Limpeza e Liberação de Portas**: Desativa serviços conflitantes (Nginx) e libera as portas 80/443.
2. **Atualização do Sistema**: Atualiza os repositórios oficiais do Debian 12 (`apt update && apt upgrade`).
3. **Dependências**: Instala Node.js 20, Apache2, Certbot, `python3-certbot-apache`, e ferramentas de build.
4. **Módulos Apache2**: Habilita `proxy`, `proxy_http`, `ssl`, `rewrite` e `headers`.
5. **Compilação da Aplicação**: Compila os ativos estáticos do frontend com Vite e empacota o backend Node/Express com `esbuild` gerando `dist/server.cjs`.
6. **Banco Persistente**: Cria e concede permissões ao diretório `data/pasquared_db.json`.
7. **VirtualHost Apache**: Configura `/etc/apache2/sites-available/app-pasquared.conf` direcionando o tráfego de `app.pasquared.space` para `127.0.0.1:3000` e ignorando a validação ACME do Certbot (`/.well-known/acme-challenge/`).
8. **Certificado SSL Let's Encrypt**: Emite o certificado SSL válido para `app.pasquared.space` e ativa o redirecionamento automático HTTP -> HTTPS.
9. **Gerenciador de Processos PM2**: Inicia a aplicação no PM2 e habilita a inicialização automática no boot do sistema Debian 12.

---

## 🔑 Acesso e Credenciais

- **URL Pública**: `https://app.pasquared.space`
- **Painel Restrito Super Admin**: `https://app.pasquared.space/rootsuperadmin`
- **E-mail Super Admin**: `rogermei577@pasquared.space`
- **Senha Super Admin**: `21121201@Roger-Pasq`
- **Banco de Dados Persistente**: `data/pasquared_db.json`
