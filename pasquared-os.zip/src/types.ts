export interface ServiceHealth {
  name: string;
  port: number;
  status: 'online' | 'degraded' | 'offline';
  latencyMs: number;
  role: string;
}

export interface SystemMetrics {
  ekosCount: number;
  insightsCount: number;
  ucisCount: number;
  sessionsCount: number;
  postgresConnected: boolean;
  gatewayStatus: boolean;
}

export interface PQLCommand {
  op: 'OBSERVE' | 'ASSOCIATE' | 'CONTEXT' | 'GENERATE' | 'VALIDATE' | 'LEARN' | 'SELECT';
  value?: string;
  from?: string;
  to?: string;
  rtype?: string;
  weight?: number;
  kv?: Record<string, string | number>;
  what?: string;
  using?: string;
  top?: number;
  target?: string;
  policy?: string;
  criteria?: string;
  threshold?: number;
}

export interface UCLObject {
  ObjectID: string;
  SourceID: string;
  InputType: string;
  Language: string;
  Category: string;
  Theme: string;
  Timestamp: string;
  Context: Record<string, unknown>;
  Content: Record<string, unknown>;
  Metadata: Record<string, unknown>;
  Version: string;
  Confidence?: number;
  CDNA?: Record<string, unknown>;
}

export interface EKOItem {
  id: string;
  domain: string;
  hypotheses: Array<{ id: string; description: string; domain: string }>;
  evidence?: Record<string, unknown>;
  status: 'validado' | 'parcialmente-validado' | 'refutado' | 'inconclusivo';
  confidence: number;
  created_at: string;
}

export interface InsightItem {
  id: string;
  ekoId: string;
  category: string;
  theme: string;
  noveltyScore: number;
  confidence: number;
  impact: number;
  created_at: string;
}

export interface TriageQA {
  id: string;
  text: string;
  key: string;
  type: 'choice' | 'yesno' | 'text';
  choices?: string[];
  next?: Record<string, string>;
}

export interface BugFixLog {
  title: string;
  component: string;
  errorCode: string;
  cause: string;
  fix: string;
}

export type AppViewMode =
  | 'landing'
  | 'patient_form'
  | 'patient_consultation'
  | 'doctor_portal'
  | 'admin_login'
  | 'admin_dashboard';

export interface PatientData {
  nome: string;
  sobrenome: string;
  dataNascimento: string; // YYYY-MM-DD
  cpf: string; // Formatted 000.000.000-00 or unmasked digits
}

export interface AttachmentItem {
  id: string;
  type: 'document' | 'audio' | 'video';
  name: string;
  dataUrl: string; // base64 or blob URL
  uploadedAt: string;
  size?: string;
}

export interface ConsultationChatMessage {
  id: string;
  sender: 'ai' | 'patient';
  text: string;
  timestamp: string;
  isQuestion?: boolean;
}

export interface PreAssessmentReport {
  complaintSummary: string;
  investigatedSymptoms: string[];
  riskLevel: 'VERDE - Baixo Risco' | 'AMARELO - Risco Médio / Atenção' | 'VERMELHO - Risco Alto (Urgência Medica)';
  diagnosticHypotheses: string[];
  recommendations: string;
  suggestedExamTypes?: string[];
  cognitiveConfidence: number;
}

export interface UserProfile {
  id: string;
  role: 'patient' | 'doctor';
  nome: string;
  sobrenome: string;
  dataNascimento: string; // YYYY-MM-DD
  cpf: string; // Formatted 000.000.000-00 or unmasked digits
  email: string;
  telefone: string;
  telefonesAdicionais?: string[];
  cep: string;
  rua: string;
  numero: string;
  bairro: string;
  cidade: string;
  uf: string;
  senha: string;
  nomeMae?: string;
  nomePai?: string;
  crm?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DoctorReviewDecision {
  status: 'aprovado' | 'desaprovado';
  parecer: string;
  doctorCpf: string;
  doctorName: string;
  reviewedAt: string;
}

export interface ConsultationRecord {
  id: string; // e.g. CONS-89210
  patient: PatientData;
  patientCpf?: string;
  messages: ConsultationChatMessage[];
  attachments: AttachmentItem[];
  preAssessment: PreAssessmentReport | null;
  status: 'em_andamento' | 'concluida' | 'revisada_doutor';
  doctorDecision?: DoctorReviewDecision;
  doctorNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MsFoundryConfig {
  apiKey: string;
  endpoint: string;
  deploymentName: string;
  apiVersion: string;
  isEnabled: boolean;
}

export interface MedicalKnowledgeBase {
  id: string;
  name: string;
  region: 'América do Sul' | 'América Central' | 'América do Norte';
  country: string;
  type: 'Base Aberta / Open Access' | 'Repositório de Pesquisas' | 'Diretrizes Médicas / OMS';
  status: 'online' | 'sincronizando' | 'offline';
  articlesIndexedCount: number;
  lastSyncAt: string;
  nextSyncInMinutes: number; // countdown towards 12h auto-sync
  autoSyncIntervalHours: number; // 12
  description: string;
  url: string;
}

export interface ExcludedHypothesis {
  hypothesis: string;
  reason: string;
  ruledOutBySymptom: string;
}

export interface DynamicDifferentialDiagnosis {
  candidateHypotheses: Array<{ hypothesis: string; probability: number }>;
  excludedHypotheses: ExcludedHypothesis[];
  investigatedPoints: string[];
  cognitiveConfidence: number;
  isConclusive: boolean;
}

export interface SuperAdminGlobalConfig {
  cognitiveThreshold: number; // default 80%
  walkieTalkieEnabled: boolean; // default true
  autoSyncIntervalHours: number; // default 12
  allowAnyFileType: boolean; // default true
  aiAutoPruningEnabled: boolean; // default true
  systemStatus: 'operacional' | 'manutencao' | 'otimizado';
  lastSavedAt: string;
}

