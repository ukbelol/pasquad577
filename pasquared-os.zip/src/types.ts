/**
 * PASQUARED-OS Type Definitions
 * Based on the PASQUARED Cognitive Architecture
 */

export enum UCIType {
  TEXT = "texto",
  IMAGE = "imagem",
  SOUND = "som",
  SMELL = "cheiro",
  MEMORY = "memória",
  EMOTION = "emoção",
  SYMBOL = "símbolo",
  CONCEPT = "conceito",
  EVENT = "evento"
}

export interface UCI {
  uid: string;
  type: UCIType;
  source: string;
  weight: number; // 0 to 1
  contextLocal: string;
  timestamp: number;
  content: string;
}

export enum RelationType {
  CAUSAL = "causal",
  TEMPORAL = "temporal",
  SEMANTIC = "semântica",
  EMOTIONAL = "emocional",
  SPATIAL = "espacial",
  SYMBOLIC = "simbólica",
  LOGICAL = "lógica"
}

export interface Relation {
  sourceUid: string;
  targetUid: string;
  weight: number; // Force of the relation
  type: RelationType;
}

export interface Observer {
  id: string;
  perception: number;
  emotionalState: number;
  knowledgeAccumulated: number;
  beliefs: number;
}

export interface Hypothesis {
  id: string;
  description: string;
  probability: number;
  evidenceUids: string[];
  vectors: {
    perception: number;
    context: number;
    memory: number;
    emotion: number;
    logic: number;
  };
}

export interface EKO {
  id: string;
  version: string;
  ucis: string[];
  hypotheses: Hypothesis[];
  confidence: number;
  timestamp: number;
  meaning: string;
}

export interface CognitiveState {
  iga: number; // Global Abstraction Index
  ici: number; // Interpretive Consistency Index
  activeGraph: {
    nodes: UCI[];
    edges: Relation[];
  };
  hypotheses: Hypothesis[];
}

export interface UCLMessage {
  header: {
    objectId: string;
    timestamp: number;
    priority: number;
  };
  payload: {
    content: string;
    context: string;
    domain: string;
  };
  metadata: {
    cdna: string; // Cognitive DNA
  };
}
