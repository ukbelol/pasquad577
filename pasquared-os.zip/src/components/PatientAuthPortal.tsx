import React, { useState, useEffect } from 'react';
import {
  User,
  Calendar,
  CreditCard,
  Mail,
  Phone,
  MapPin,
  Lock,
  Search,
  CheckCircle2,
  Plus,
  Trash2,
  Save,
  FileText,
  Stethoscope,
  Clock,
  ArrowRight,
  ArrowLeft,
  LogOut,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  KeyRound,
  HelpCircle,
  ShieldQuestion,
} from 'lucide-react';
import { UserProfile, PatientData, ConsultationRecord } from '../types';
import {
  authenticateUser,
  saveUser,
  getActiveSession,
  setActiveSession,
  fetchAddressByCep,
  verifySecurityAnswers,
} from '../lib/userStore';
import { getStoredConsultations } from '../lib/consultationStore';

interface PatientAuthPortalProps {
  onStartConsultation: (patient: PatientData) => void;
  onBackToLanding: () => void;
}

export const PatientAuthPortal: React.FC<PatientAuthPortalProps> = ({
  onStartConsultation,
  onBackToLanding,
}) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'recovery'>('login');
  const [loggedPatient, setLoggedPatient] = useState<UserProfile | null>(null);

  // Sub-view toggles in Logged Dashboard
  const [activeSection, setActiveSection] = useState<'consulta' | 'historico' | 'conta'>('consulta');
  const [showHistory, setShowHistory] = useState(false);

  // Form states for Login
  const [loginCpf, setLoginCpf] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginSuccess, setLoginSuccess] = useState('');

  // Form states for Registration (Cadastro PA)
  const [nome, setNome] = useState('');
  const [sobrenome, setSobrenome] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [cpf, setCpf] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [cep, setCep] = useState('');
  const [rua, setRua] = useState('');
  const [numero, setNumero] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [uf, setUf] = useState('');
  const [senha, setSenha] = useState('');
  const [nomeMae, setNomeMae] = useState('');
  const [nomePai, setNomePai] = useState('');

  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [cepMessage, setCepMessage] = useState('');
  const [regError, setRegError] = useState('');

  // Form states for Password Recovery (Recuperação de Senha PA)
  const [recoveryStep, setRecoveryStep] = useState<'questions' | 'new_password'>('questions');
  const [recoveryCpf, setRecoveryCpf] = useState('');
  const [recoveryMae, setRecoveryMae] = useState('');
  const [recoveryPai, setRecoveryPai] = useState('');
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryError, setRecoveryError] = useState('');
  const [recoveryUser, setRecoveryUser] = useState<UserProfile | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Editable Account Form states
  const [editEmail, setEditEmail] = useState('');
  const [editTelefone, setEditTelefone] = useState('');
  const [editTelefonesAdicionais, setEditTelefonesAdicionais] = useState<string[]>([]);
  const [newExtraPhone, setNewExtraPhone] = useState('');
  const [editCep, setEditCep] = useState('');
  const [editRua, setEditRua] = useState('');
  const [editNumero, setEditNumero] = useState('');
  const [editBairro, setEditBairro] = useState('');
  const [editCidade, setEditCidade] = useState('');
  const [editUf, setEditUf] = useState('');
  const [saveSuccess, setSaveSuccess] = useState('');

  // History consultations
  const [patientConsultations, setPatientConsultations] = useState<ConsultationRecord[]>([]);

  // Selected consultation detail modal/expansion
  const [selectedConsultation, setSelectedConsultation] = useState<ConsultationRecord | null>(null);

  // Auto load active session on mount
  useEffect(() => {
    const session = getActiveSession();
    if (session && session.role === 'patient') {
      setLoggedPatient(session);
      initAccountForm(session);
      loadConsultations(session.cpf);
    }
  }, []);

  const initAccountForm = (user: UserProfile) => {
    setEditEmail(user.email);
    setEditTelefone(user.telefone);
    setEditTelefonesAdicionais(user.telefonesAdicionais || []);
    setEditCep(user.cep);
    setEditRua(user.rua);
    setEditNumero(user.numero);
    setEditBairro(user.bairro);
    setEditCidade(user.cidade);
    setEditUf(user.uf);
  };

  const loadConsultations = (patientCpf: string) => {
    const all = getStoredConsultations();
    const clean = patientCpf.replace(/\D/g, '');
    const filtered = all.filter((c) => {
      const cCpf = (c.patientCpf || c.patient.cpf).replace(/\D/g, '');
      return cCpf === clean;
    });
    setPatientConsultations(filtered);
  };

  // Mask helper for CPF
  const handleCpfFormatting = (value: string, setter: (val: string) => void) => {
    let clean = value.replace(/\D/g, '');
    if (clean.length > 11) clean = clean.slice(0, 11);

    if (clean.length > 9) {
      clean = clean.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');
    } else if (clean.length > 6) {
      clean = clean.replace(/^(\d{3})(\d{3})(\d{1,3})$/, '$1.$2.$3');
    } else if (clean.length > 3) {
      clean = clean.replace(/^(\d{3})(\d{1,3})$/, '$1.$2');
    }
    setter(clean);
  };

  // CEP lookup via API
  const handleSearchCep = async (cepInput: string, isEdit = false) => {
    const clean = cepInput.replace(/\D/g, '');
    if (clean.length !== 8) {
      setCepMessage('Digite um CEP com 8 dígitos para consultar.');
      return;
    }
    setIsSearchingCep(true);
    setCepMessage('');

    const res = await fetchAddressByCep(clean);
    setIsSearchingCep(false);

    if (res.success) {
      if (!isEdit) {
        setRua(res.rua);
        setBairro(res.bairro);
        setCidade(res.cidade);
        setUf(res.uf);
      } else {
        setEditRua(res.rua);
        setEditBairro(res.bairro);
        setEditCidade(res.cidade);
        setEditUf(res.uf);
      }
      setCepMessage('✅ Endereço preenchido automaticamente pela API.');
    } else {
      setCepMessage(res.error || 'CEP não encontrado. Preencha manualmente.');
    }
  };

  // Handle Registration Submit
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (
      !nome.trim() ||
      !sobrenome.trim() ||
      !dataNascimento.trim() ||
      !cpf.trim() ||
      !email.trim() ||
      !telefone.trim() ||
      !cep.trim() ||
      !numero.trim() ||
      !senha.trim() ||
      !nomeMae.trim() ||
      !nomePai.trim()
    ) {
      setRegError('Por favor, preencha todos os campos obrigatórios do cadastro, incluindo as perguntas de segurança.');
      return;
    }

    if (cpf.replace(/\D/g, '').length < 11) {
      setRegError('CPF inválido. Deve possuir 11 dígitos.');
      return;
    }

    const newUser: UserProfile = {
      id: `usr_pat_${Date.now()}`,
      role: 'patient',
      nome: nome.trim(),
      sobrenome: sobrenome.trim(),
      dataNascimento: dataNascimento.trim(),
      cpf: cpf.trim(),
      email: email.trim(),
      telefone: telefone.trim(),
      telefonesAdicionais: [],
      cep: cep.trim(),
      rua: rua.trim() || 'Logradouro não informado',
      numero: numero.trim(),
      bairro: bairro.trim() || 'Bairro',
      cidade: cidade.trim() || 'Cidade',
      uf: uf.trim() || 'UF',
      senha: senha.trim(),
      nomeMae: nomeMae.trim(),
      nomePai: nomePai.trim(),
      createdAt: new Date().toISOString().slice(0, 16),
      updatedAt: new Date().toISOString().slice(0, 16),
    };

    saveUser(newUser);

    // Reset registration form & redirect to Login form
    setLoginSuccess(`Cadastro efetuado com sucesso para ${nome}! Faça seu login informando seu CPF e senha.`);
    setLoginCpf(cpf.trim());
    setActiveTab('login');
  };

  // Handle Security Questions Verification Submit
  const handleVerifySecurityQuestions = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    const res = verifySecurityAnswers(
      recoveryCpf,
      'patient',
      recoveryMae,
      recoveryPai,
      recoveryEmail
    );

    if (res.success && res.user) {
      setRecoveryUser(res.user);
      setRecoveryStep('new_password');
    } else {
      setRecoveryError(res.error || 'Respostas incorretas. Verifique as informações.');
    }
  };

  // Handle Save New Password Submit
  const handleSaveNewPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    if (!newPassword.trim()) {
      setRecoveryError('Por favor, informe a nova senha.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setRecoveryError('A confirmação de senha não confere com a nova senha digitada.');
      return;
    }

    if (!recoveryUser) {
      setRecoveryError('Erro ao recuperar usuário. Tente novamente.');
      return;
    }

    const updatedUser: UserProfile = {
      ...recoveryUser,
      senha: newPassword.trim(),
      updatedAt: new Date().toISOString().slice(0, 16),
    };

    saveUser(updatedUser);

    // Redirecionamento para a tela de login
    setLoginSuccess(`Senha redefinida com sucesso para ${recoveryUser.nome}! Informe seu CPF e sua nova senha para entrar.`);
    setLoginCpf(recoveryUser.cpf);
    setLoginPassword('');
    setActiveTab('login');
    // Reset recovery state
    setRecoveryStep('questions');
    setRecoveryCpf('');
    setRecoveryMae('');
    setRecoveryPai('');
    setRecoveryEmail('');
    setNewPassword('');
    setConfirmPassword('');
    setRecoveryUser(null);
  };

  // Handle Login Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginSuccess('');

    const res = authenticateUser(loginCpf, loginPassword, 'patient');
    if (res.success && res.user) {
      setLoggedPatient(res.user);
      initAccountForm(res.user);
      loadConsultations(res.user.cpf);
    } else {
      setLoginError(res.error || 'Falha na autenticação.');
    }
  };

  // Logout Patient
  const handleLogout = () => {
    setActiveSession(null);
    setLoggedPatient(null);
    setLoginPassword('');
    setLoginSuccess('');
    setLoginError('');
  };

  // Handle Account Updates Save
  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loggedPatient) return;

    const updatedUser: UserProfile = {
      ...loggedPatient,
      email: editEmail.trim(),
      telefone: editTelefone.trim(),
      telefonesAdicionais: editTelefonesAdicionais,
      cep: editCep.trim(),
      rua: editRua.trim(),
      numero: editNumero.trim(),
      bairro: editBairro.trim(),
      cidade: editCidade.trim(),
      uf: editUf.trim(),
      updatedAt: new Date().toISOString().slice(0, 16),
    };

    saveUser(updatedUser);
    setActiveSession(updatedUser);
    setLoggedPatient(updatedUser);
    setSaveSuccess('✅ Todos os seus dados foram salvos de forma persistente no banco de dados!');
    setTimeout(() => setSaveSuccess(''), 4000);
  };

  const handleAddExtraPhone = () => {
    if (!newExtraPhone.trim()) return;
    setEditTelefonesAdicionais((prev) => [...prev, newExtraPhone.trim()]);
    setNewExtraPhone('');
  };

  const handleRemoveExtraPhone = (index: number) => {
    setEditTelefonesAdicionais((prev) => prev.filter((_, i) => i !== index));
  };

  const handleTriggerConsultationPage = () => {
    if (!loggedPatient) return;
    onStartConsultation({
      nome: loggedPatient.nome,
      sobrenome: loggedPatient.sobrenome,
      dataNascimento: loggedPatient.dataNascimento,
      cpf: loggedPatient.cpf,
    });
  };

  return (
    <div className="max-w-4xl mx-auto py-6 space-y-6">
      {/* Top Header Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLanding}
          className="flex items-center gap-2 text-xs font-mono font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar à Página Inicial
        </button>

        {loggedPatient && (
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 hover:bg-rose-900 transition-colors cursor-pointer text-xs font-mono"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sair da Conta (PA)
          </button>
        )}
      </div>

      {/* UNAUTHENTICATED: LOGIN & CADASTRO PA */}
      {!loggedPatient ? (
        <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="w-12 h-12 bg-indigo-600/20 border border-indigo-500/40 rounded-xl flex items-center justify-center text-indigo-400">
              <User className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
                ÁREA DO PACIENTE (PA)
              </span>
              <h2 className="text-2xl font-bold text-white mt-0.5">Acesso e Cadastro ao Sistema</h2>
            </div>
          </div>

          {/* Tabs Switcher: Entrar / Cadastrar-se / Recuperar Senha */}
          <div className="flex bg-[#0D1117] p-1.5 rounded-2xl border border-slate-800 gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('login')}
              className={`flex-1 py-3 rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
                activeTab === 'login'
                  ? 'bg-indigo-600 text-white shadow-lg border border-indigo-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Lock className="w-4 h-4" />
              Entrar (Login PA)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('register')}
              className={`flex-1 py-3 rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
                activeTab === 'register'
                  ? 'bg-indigo-600 text-white shadow-lg border border-indigo-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <User className="w-4 h-4" />
              Cadastrar-se (PA)
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('recovery');
                setRecoveryStep('questions');
                setRecoveryError('');
              }}
              className={`flex-1 py-3 rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
                activeTab === 'recovery'
                  ? 'bg-amber-600 text-white shadow-lg border border-amber-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <KeyRound className="w-4 h-4 text-amber-300" />
              Recuperar Senha
            </button>
          </div>

          {loginSuccess && (
            <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 font-mono text-xs flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <span>{loginSuccess}</span>
            </div>
          )}

          {/* TAB 1: FORMULÁRIO DE LOGIN */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4 pt-2">
              {loginError && (
                <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 font-mono text-xs">
                  {loginError}
                </div>
              )}

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                  Usuário (CPF) *
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={loginCpf}
                    onChange={(e) => handleCpfFormatting(e.target.value, setLoginCpf)}
                    placeholder="000.000.000-00"
                    maxLength={14}
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                    Senha Cadastrada *
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('recovery');
                      setRecoveryStep('questions');
                      setRecoveryCpf(loginCpf);
                      setRecoveryError('');
                    }}
                    className="text-xs font-mono text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
                  >
                    Esqueci minha senha
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Sua senha alfanumérica"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
              >
                <ShieldCheck className="w-4 h-4" />
                Entrar no Painel do Paciente
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* TAB 2: FORMULÁRIO DE CADASTRO PA */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4 pt-2">
              {regError && (
                <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 font-mono text-xs">
                  {regError}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Nome *
                  </label>
                  <input
                    type="text"
                    required
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Ex: Carlos"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Sobrenome *
                  </label>
                  <input
                    type="text"
                    required
                    value={sobrenome}
                    onChange={(e) => setSobrenome(e.target.value)}
                    placeholder="Ex: Eduardo Silva"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Data de Nascimento *
                  </label>
                  <input
                    type="date"
                    required
                    value={dataNascimento}
                    onChange={(e) => setDataNascimento(e.target.value)}
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    CPF (Usuário) *
                  </label>
                  <input
                    type="text"
                    required
                    value={cpf}
                    onChange={(e) => handleCpfFormatting(e.target.value, setCpf)}
                    placeholder="000.000.000-00"
                    maxLength={14}
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="paciente@exemplo.com"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Telefone *
                  </label>
                  <input
                    type="text"
                    required
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    placeholder="(11) 98765-4321"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
              </div>

              {/* ENDEREÇO COM VIA CEP */}
              <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-indigo-400 uppercase flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-indigo-400" />
                    Endereço (Consulta via API de CEP)
                  </span>
                  {isSearchingCep && <span className="text-[11px] font-mono text-amber-400 animate-pulse">Consultando ViaCEP...</span>}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={cep}
                    onChange={(e) => {
                      setCep(e.target.value);
                      if (e.target.value.replace(/\D/g, '').length === 8) {
                        handleSearchCep(e.target.value, false);
                      }
                    }}
                    placeholder="CEP (ex: 01001-000)"
                    maxLength={9}
                    className="flex-1 bg-[#161B22] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2 text-xs font-mono text-slate-200 outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleSearchCep(cep, false)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <Search className="w-3.5 h-3.5" />
                    Buscar CEP
                  </button>
                </div>

                {cepMessage && <p className="text-[11px] font-mono text-indigo-300">{cepMessage}</p>}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Rua / Logradouro</label>
                    <input
                      type="text"
                      value={rua}
                      onChange={(e) => setRua(e.target.value)}
                      placeholder="Praça da Sé (Auto ViaCEP)"
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Número *</label>
                    <input
                      type="text"
                      required
                      value={numero}
                      onChange={(e) => setNumero(e.target.value)}
                      placeholder="Nº 123"
                      className="w-full bg-[#161B22] border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Bairro</label>
                    <input
                      type="text"
                      value={bairro}
                      onChange={(e) => setBairro(e.target.value)}
                      placeholder="Bairro"
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Cidade</label>
                    <input
                      type="text"
                      value={cidade}
                      onChange={(e) => setCidade(e.target.value)}
                      placeholder="Cidade"
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Estado (UF)</label>
                    <input
                      type="text"
                      value={uf}
                      onChange={(e) => setUf(e.target.value)}
                      placeholder="UF"
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* PERGUNTAS DE SEGURANÇA PARA RECUPERAÇÃO DE SENHA */}
              <div className="p-4 bg-[#0D1117] border border-amber-500/30 rounded-2xl space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldQuestion className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-mono font-bold text-amber-400 uppercase">
                    Perguntas de Segurança (para Recuperação de Senha)
                  </span>
                </div>
                <p className="text-[11px] font-mono text-slate-400">
                  Estas respostas serão solicitadas caso precise redefinir sua senha no futuro.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-mono font-bold text-slate-300 uppercase mb-1">
                      Pergunta 1: Qual o nome da mãe? *
                    </label>
                    <input
                      type="text"
                      required
                      value={nomeMae}
                      onChange={(e) => setNomeMae(e.target.value)}
                      placeholder="Informe a resposta"
                      className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono font-bold text-slate-300 uppercase mb-1">
                      Pergunta 2: Qual o nome do pai? *
                    </label>
                    <input
                      type="text"
                      required
                      value={nomePai}
                      onChange={(e) => setNomePai(e.target.value)}
                      placeholder="Informe a resposta"
                      className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                </div>

                <div className="text-[11px] font-mono text-slate-400 bg-[#161B22] p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                  <HelpCircle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                  <span>Pergunta 3: Qual é o E-mail cadastrado? (Será verificado com o E-mail informado acima)</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                  Senha Alfanumérica para Login *
                </label>
                <input
                  type="password"
                  required
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  placeholder="Crie sua senha alfanumérica"
                  className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
              >
                <CheckCircle2 className="w-4 h-4" />
                Finalizar Cadastro de Paciente
              </button>
            </form>
          )}

          {/* TAB 3: RECUPERAÇÃO DE SENHA (ETAPA 1: RESPOSTAS DE SEGURANÇA E ETAPA 2: NOVA SENHA) */}
          {activeTab === 'recovery' && (
            <div className="space-y-4 pt-2">
              {recoveryError && (
                <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-300 font-mono text-xs">
                  {recoveryError}
                </div>
              )}

              {/* ETAPA 1: VERIFICAÇÃO DAS PERGUNTAS DE SEGURANÇA */}
              {recoveryStep === 'questions' && (
                <form onSubmit={handleVerifySecurityQuestions} className="space-y-4">
                  <div className="p-4 bg-[#0D1117] border border-amber-500/30 rounded-2xl space-y-1">
                    <span className="text-xs font-mono font-bold text-amber-400 uppercase flex items-center gap-2">
                      <KeyRound className="w-4 h-4" />
                      Recuperação de Senha - Paciente (PA)
                    </span>
                    <p className="text-xs font-mono text-slate-300">
                      Responda às perguntas de segurança e confirme seu E-mail cadastrado para prosseguir com a redefinição de senha.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1 uppercase">
                      CPF do Paciente (Usuário) *
                    </label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        required
                        value={recoveryCpf}
                        onChange={(e) => handleCpfFormatting(e.target.value, setRecoveryCpf)}
                        placeholder="000.000.000-00"
                        maxLength={14}
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-3 p-4 bg-[#0D1117] border border-slate-800 rounded-2xl">
                    <span className="text-xs font-mono font-bold text-slate-200 uppercase flex items-center gap-2">
                      <ShieldQuestion className="w-4 h-4 text-amber-400" />
                      Verificação das Respostas de Segurança
                    </span>

                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1">
                        Pergunta 1: Qual o nome da mãe? *
                      </label>
                      <input
                        type="text"
                        required
                        value={recoveryMae}
                        onChange={(e) => setRecoveryMae(e.target.value)}
                        placeholder="Informe a resposta"
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1">
                        Pergunta 2: Qual o nome do pai? *
                      </label>
                      <input
                        type="text"
                        required
                        value={recoveryPai}
                        onChange={(e) => setRecoveryPai(e.target.value)}
                        placeholder="Informe a resposta"
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1">
                        Pergunta 3: Qual é o E-mail cadastrado? *
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                        <input
                          type="email"
                          required
                          value={recoveryEmail}
                          onChange={(e) => setRecoveryEmail(e.target.value)}
                          placeholder="Informe o e-mail cadastrado"
                          className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Validar Respostas e Redirecionar
                  </button>
                </form>
              )}

              {/* ETAPA 2: REDIRECIONAMENTO PARA INFORMAR A NOVA SENHA */}
              {recoveryStep === 'new_password' && (
                <form onSubmit={handleSaveNewPassword} className="space-y-4">
                  <div className="p-4 bg-emerald-950/80 border border-emerald-800 rounded-2xl space-y-1 text-emerald-200">
                    <span className="text-xs font-mono font-bold uppercase flex items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" />
                      Respostas de Segurança Confirmadas!
                    </span>
                    <p className="text-xs font-mono">
                      Usuário verificado: <strong className="text-white">{recoveryUser?.nome} {recoveryUser?.sobrenome}</strong> (CPF: {recoveryUser?.cpf}). Por favor, informe sua nova senha alfanumérica.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                      Digite a Nova Senha Alfanumérica *
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="password"
                        required
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Sua nova senha alfanumérica"
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                      Confirme a Nova Senha *
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="password"
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Repita a nova senha"
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Salvar Nova Senha e Ir para Tela de Login
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      ) : (
        /* LOGGED IN PATIENT DASHBOARD */
        <div className="space-y-6">
          {/* Welcome User Banner */}
          <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-md">
                {loggedPatient.nome.charAt(0)}
              </div>
              <div>
                <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-widest">
                  PACIENTE LOGADO (PA)
                </span>
                <h2 className="text-2xl font-bold text-white">
                  {loggedPatient.nome} {loggedPatient.sobrenome}
                </h2>
                <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-slate-400 mt-1">
                  <span>CPF: {loggedPatient.cpf}</span>
                  <span>•</span>
                  <span>{loggedPatient.email}</span>
                </div>
              </div>
            </div>

            {/* Navigation Buttons for Logged Patient */}
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {/* Botão CONSULTA */}
              <button
                onClick={handleTriggerConsultationPage}
                className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase transition-all cursor-pointer shadow-lg flex items-center gap-2"
              >
                <Stethoscope className="w-4 h-4 text-amber-300" />
                <span>Consulta (Pasquared)</span>
              </button>

              {/* Botão HISTÓRICO DE CONSULTAS (Alterna visibilidade) */}
              <button
                onClick={() => {
                  setShowHistory((prev) => !prev);
                  setActiveSection('historico');
                }}
                className={`px-4 py-3 rounded-xl border font-mono font-bold text-xs uppercase transition-all cursor-pointer flex items-center gap-2 ${
                  showHistory
                    ? 'bg-amber-600 border-amber-500 text-white'
                    : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4 text-amber-400" />
                <span>Histórico de Consultas</span>
                {showHistory ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              {/* Botão CONTA */}
              <button
                onClick={() => {
                  setShowHistory(false);
                  setActiveSection('conta');
                }}
                className={`px-4 py-3 rounded-xl border font-mono font-bold text-xs uppercase transition-all cursor-pointer flex items-center gap-2 ${
                  activeSection === 'conta' && !showHistory
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <User className="w-4 h-4 text-emerald-400" />
                <span>Conta / Meus Dados</span>
              </button>
            </div>
          </div>

          {/* SECTION: HISTÓRICO DE CONSULTAS (Mostrado apenas se acionado) */}
          {showHistory && (
            <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2 font-mono font-bold text-amber-400 uppercase text-xs">
                  <Clock className="w-4 h-4" />
                  <span>Histórico de Consultas do Paciente ({patientConsultations.length})</span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">Exibindo registros de {loggedPatient.cpf}</span>
              </div>

              {patientConsultations.length === 0 ? (
                <div className="p-8 text-center text-slate-400 font-mono text-xs border border-dashed border-slate-800 rounded-2xl space-y-3">
                  <p>Nenhuma consulta realizada até o momento.</p>
                  <button
                    onClick={handleTriggerConsultationPage}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold uppercase cursor-pointer"
                  >
                    Iniciar Primeira Anamnese com Pasquared
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {patientConsultations.map((c) => (
                    <div
                      key={c.id}
                      className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs font-mono hover:border-slate-700 transition-colors"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{c.id}</span>
                          <span className="text-slate-400">({c.createdAt})</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              c.status === 'revisada_doutor'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-indigo-950 text-indigo-400 border border-indigo-800'
                            }`}
                          >
                            {c.status.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-slate-300 mt-1 line-clamp-2">
                          {c.preAssessment?.complaintSummary || 'Anamnese em andamento'}
                        </p>
                      </div>

                      <button
                        onClick={() => setSelectedConsultation(selectedConsultation?.id === c.id ? null : c)}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold cursor-pointer"
                      >
                        {selectedConsultation?.id === c.id ? 'Ocultar Detalhes' : 'Ver Detalhes'}
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Detail view modal/accordion if selected */}
              {selectedConsultation && (
                <div className="mt-4 p-5 bg-[#0D1117] border border-amber-500/30 rounded-2xl space-y-3 font-mono text-xs">
                  <div className="font-bold text-amber-400 border-b border-slate-800 pb-2">
                    📄 Transcrição e Pré-Avaliação Pasquared ({selectedConsultation.id})
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold">Resumo da Queixa:</span>
                    <p className="text-slate-200 mt-0.5">{selectedConsultation.preAssessment?.complaintSummary}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold">Nível de Risco:</span>
                    <p className="text-amber-300 font-bold mt-0.5">{selectedConsultation.preAssessment?.riskLevel}</p>
                  </div>
                  {selectedConsultation.doctorNotes && (
                    <div className="p-3 bg-emerald-950/60 border border-emerald-800 rounded-xl text-emerald-200">
                      <span className="font-bold uppercase">Parecer do Médico:</span>
                      <p className="mt-1">{selectedConsultation.doctorNotes}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* SECTION: CONTA (Exibição e Edição de Dados com Persistência) */}
          {activeSection === 'conta' && (
            <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2 font-mono font-bold text-emerald-400 uppercase text-xs">
                  <User className="w-4 h-4" />
                  <span>Dados Cadastrais da Conta (Edição & Persistência)</span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">Usuário CPF: {loggedPatient.cpf}</span>
              </div>

              {saveSuccess && (
                <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 font-mono text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{saveSuccess}</span>
                </div>
              )}

              <form onSubmit={handleSaveAccount} className="space-y-5">
                {/* Fixed read-only data */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-[#0D1117] border border-slate-800 rounded-2xl text-xs font-mono">
                  <div>
                    <span className="text-slate-500 uppercase block text-[10px]">Nome Completo</span>
                    <span className="font-bold text-white text-sm">
                      {loggedPatient.nome} {loggedPatient.sobrenome}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 uppercase block text-[10px]">CPF (Usuário)</span>
                    <span className="font-bold text-indigo-300">{loggedPatient.cpf}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 uppercase block text-[10px]">Data de Nascimento</span>
                    <span className="font-bold text-slate-200">{loggedPatient.dataNascimento}</span>
                  </div>
                </div>

                {/* Editable Fields: E-mail & Telefone Principal */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase">
                      E-mail (Editável)
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="email"
                        required
                        value={editEmail}
                        onChange={(e) => setEditEmail(e.target.value)}
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase">
                      Telefone Principal (Editável)
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        required
                        value={editTelefone}
                        onChange={(e) => setEditTelefone(e.target.value)}
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* ADICIONAR TELEFONE SECUNDÁRIO */}
                <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-emerald-400 uppercase flex items-center gap-2">
                      <Phone className="w-4 h-4 text-emerald-400" />
                      Telefones Adicionais / Recados
                    </span>
                  </div>

                  {editTelefonesAdicionais.length > 0 && (
                    <div className="space-y-2">
                      {editTelefonesAdicionais.map((phone, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between px-3 py-2 bg-[#161B22] border border-slate-800 rounded-xl text-xs font-mono"
                        >
                          <span className="text-slate-200">{phone}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveExtraPhone(idx)}
                            className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newExtraPhone}
                      onChange={(e) => setNewExtraPhone(e.target.value)}
                      placeholder="Adicionar outro telefone (ex: (11) 91111-2222)"
                      className="flex-1 bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleAddExtraPhone}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Adicionar
                    </button>
                  </div>
                </div>

                {/* EDITAR ENDEREÇO */}
                <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-emerald-400 uppercase flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400" />
                      Endereço Cadastrado (Consulta via ViaCEP API)
                    </span>
                    {isSearchingCep && <span className="text-[11px] font-mono text-amber-400 animate-pulse">Consultando ViaCEP...</span>}
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={editCep}
                      onChange={(e) => setEditCep(e.target.value)}
                      placeholder="CEP"
                      className="flex-1 bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => handleSearchCep(editCep, true)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Search className="w-3.5 h-3.5" />
                      Atualizar via CEP
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Rua / Logradouro</label>
                      <input
                        type="text"
                        value={editRua}
                        onChange={(e) => setEditRua(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Número</label>
                      <input
                        type="text"
                        value={editNumero}
                        onChange={(e) => setEditNumero(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Bairro</label>
                      <input
                        type="text"
                        value={editBairro}
                        onChange={(e) => setEditBairro(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Cidade</label>
                      <input
                        type="text"
                        value={editCidade}
                        onChange={(e) => setEditCidade(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Estado (UF)</label>
                      <input
                        type="text"
                        value={editUf}
                        onChange={(e) => setEditUf(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* BOTÃO DE SALVAR EDITAR PERSISTENTE */}
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                >
                  <Save className="w-4 h-4" />
                  Salvar Alterações do Cadastro (Persistente no Banco)
                </button>
              </form>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
