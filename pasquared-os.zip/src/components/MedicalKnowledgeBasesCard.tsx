import React, { useState, useEffect } from 'react';
import { MedicalKnowledgeBase } from '../types';
import { INITIAL_MEDICAL_KNOWLEDGE_BASES } from '../data/medicalBases';
import {
  Database,
  RefreshCw,
  Globe,
  CheckCircle2,
  Clock,
  Search,
  BookOpen,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Radio,
  Layers
} from 'lucide-react';

export const MedicalKnowledgeBasesCard: React.FC = () => {
  const [bases, setBases] = useState<MedicalKnowledgeBase[]>(() => {
    try {
      const saved = localStorage.getItem('pasquared_medical_kb_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading medical KB state:', e);
    }
    return INITIAL_MEDICAL_KNOWLEDGE_BASES;
  });

  const [selectedRegion, setSelectedRegion] = useState<'Todas' | 'América do Sul' | 'América Central' | 'América do Norte'>('Todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [syncingBaseId, setSyncingBaseId] = useState<string | null>(null);
  const [lastGlobalSync, setLastGlobalSync] = useState<string>('Sincronizado via Cron (Ciclo 12h)');

  // Auto-decrement nextSyncInMinutes simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setBases((prevBases) =>
        prevBases.map((b) => {
          const next = b.nextSyncInMinutes > 1 ? b.nextSyncInMinutes - 1 : 720; // 12 hours = 720 minutes
          return {
            ...b,
            nextSyncInMinutes: next,
          };
        })
      );
    }, 60000); // every minute

    return () => clearInterval(timer);
  }, []);

  // Save to localStorage when state changes
  useEffect(() => {
    try {
      localStorage.setItem('pasquared_medical_kb_v1', JSON.stringify(bases));
    } catch (e) {
      console.error('Failed to persist KB state:', e);
    }
  }, [bases]);

  const totalArticles = bases.reduce((acc, b) => acc + b.articlesIndexedCount, 0);
  const onlineCount = bases.filter((b) => b.status === 'online').length;

  const handleSyncSingle = (id: string) => {
    setSyncingBaseId(id);
    setTimeout(() => {
      setBases((prev) =>
        prev.map((b) => {
          if (b.id === id) {
            const added = Math.floor(Math.random() * 800) + 120;
            return {
              ...b,
              articlesIndexedCount: b.articlesIndexedCount + added,
              lastSyncAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
              nextSyncInMinutes: 720, // Reset 12h countdown
              status: 'online',
            };
          }
          return b;
        })
      );
      setSyncingBaseId(null);
    }, 1200);
  };

  const handleSyncAll = () => {
    setIsSyncingAll(true);
    setTimeout(() => {
      setBases((prev) =>
        prev.map((b) => {
          const added = Math.floor(Math.random() * 1500) + 350;
          return {
            ...b,
            articlesIndexedCount: b.articlesIndexedCount + added,
            lastSyncAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
            nextSyncInMinutes: 720, // Reset 12h countdown
            status: 'online',
          };
        })
      );
      setIsSyncingAll(false);
      setLastGlobalSync(`Sincronização manual concluída (${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })})`);
    }, 2000);
  };

  const filteredBases = bases.filter((b) => {
    const matchesRegion = selectedRegion === 'Todas' || b.region === selectedRegion;
    const matchesQuery =
      searchQuery === '' ||
      b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRegion && matchesQuery;
  });

  return (
    <div id="medical-knowledge-bases-section" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl text-slate-100">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Conexões Ativas em Tempo Real
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center gap-1">
              <Clock className="w-3 h-3" /> Auto-update 12h
            </span>
          </div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-indigo-400" />
            Bases de Conhecimentos Médicos das Américas
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Conexão automática com repositórios abertos de saúde e artigos clínicos da América do Sul, América Central e América do Norte.
          </p>
        </div>

        <button
          onClick={handleSyncAll}
          disabled={isSyncingAll}
          className="self-start md:self-auto flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition-all cursor-pointer"
        >
          <RefreshCw className={`w-4 h-4 ${isSyncingAll ? 'animate-spin' : ''}`} />
          {isSyncingAll ? 'Sincronizando 8 Repositórios...' : 'Sincronizar Todas as Bases Agora'}
        </button>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 my-6">
        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
          <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-lg">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400">Total Indice Clínico</div>
            <div className="text-lg font-bold text-white tracking-tight">
              {totalArticles.toLocaleString('pt-BR')} <span className="text-xs font-normal text-slate-400">docs</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-lg">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400">Status das Conexões</div>
            <div className="text-lg font-bold text-emerald-400 flex items-center gap-1.5">
              {onlineCount} de {bases.length} Online
              <span className="text-[10px] font-normal px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded">100%</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-lg">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400">Ciclo de Atualização</div>
            <div className="text-sm font-semibold text-white">
              A cada 12 Horas <span className="text-xs font-normal text-amber-400">(Automático)</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-3.5 flex items-center gap-3">
          <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-lg">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400">Garantia Médica</div>
            <div className="text-xs font-medium text-purple-300">
              Fontes Abertas & Validadas (OMS/PAHO)
            </div>
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-5">
        {/* Region Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 w-full sm:w-auto overflow-x-auto">
          {(['Todas', 'América do Sul', 'América Central', 'América do Norte'] as const).map((region) => (
            <button
              key={region}
              onClick={() => setSelectedRegion(region)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedRegion === region
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {region}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por base ou país..."
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Base Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredBases.map((base) => {
          const isSyncingThis = syncingBaseId === base.id;
          const hoursLeft = Math.floor(base.nextSyncInMinutes / 60);
          const minsLeft = base.nextSyncInMinutes % 60;
          const progressPercent = Math.round(((720 - base.nextSyncInMinutes) / 720) * 100);

          return (
            <div
              key={base.id}
              className="bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 rounded-xl p-4 transition-all flex flex-col justify-between group relative overflow-hidden"
            >
              {/* Top Row */}
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-medium border ${
                        base.region === 'América do Sul'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : base.region === 'América Central'
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                      }`}
                    >
                      {base.region}
                    </span>
                    <span className="text-xs text-slate-400">{base.country}</span>
                  </div>

                  <a
                    href={base.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-500 hover:text-indigo-400 transition-colors p-1"
                    title="Acessar base em nova aba"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                <h3 className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-indigo-400 shrink-0" />
                  {base.name}
                </h3>

                <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                  {base.description}
                </p>
              </div>

              {/* Bottom Row Details */}
              <div className="mt-4 pt-3 border-t border-slate-900 flex flex-col gap-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 flex items-center gap-1">
                    <BookOpen className="w-3 h-3 text-slate-500" />
                    Indexed Articles:
                  </span>
                  <span className="font-semibold text-indigo-300">
                    {base.articlesIndexedCount.toLocaleString('pt-BR')}
                  </span>
                </div>

                {/* Auto Sync Timer Progress Bar */}
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                    <span className="flex items-center gap-1 text-slate-400">
                      <Clock className="w-3 h-3 text-amber-400" />
                      Próximo ciclo 12h:
                    </span>
                    <span className="text-slate-300 font-medium">
                      em {hoursLeft}h {minsLeft}m
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-500"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Action Footer */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-slate-500">
                    Última sincronização: {base.lastSyncAt}
                  </span>

                  <button
                    onClick={() => handleSyncSingle(base.id)}
                    disabled={isSyncingThis || isSyncingAll}
                    className="flex items-center gap-1 text-[11px] font-medium text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 px-2.5 py-1 rounded-lg border border-indigo-500/20 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3 h-3 ${isSyncingThis ? 'animate-spin' : ''}`} />
                    {isSyncingThis ? 'Atualizando...' : 'Sincronizar'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            {lastGlobalSync}
          </span>
        </div>
        <div className="text-[11px] text-slate-500">
          As bases médicas abertas alimentam continuamente o algoritmo de dedução diagnóstica e entrevista investigativa.
        </div>
      </div>
    </div>
  );
};
