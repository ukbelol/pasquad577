import React, { useState, useEffect, useRef } from 'react';
import {
  Stethoscope,
  Send,
  Paperclip,
  Mic,
  Video,
  FileText,
  CheckCircle2,
  Sparkles,
  ShieldAlert,
  Save,
  ArrowLeft,
  Volume2,
  Clock,
  User,
  Square,
  Trash2,
  Download,
  Activity,
  Layers,
  XCircle,
  Database,
  RefreshCw,
  BrainCircuit,
  Check,
  Radio,
  FileUp,
  FileSpreadsheet,
  FileCheck,
  Info,
} from 'lucide-react';
import {
  PatientData,
  ConsultationRecord,
  ConsultationChatMessage,
  AttachmentItem,
  PreAssessmentReport,
  DynamicDifferentialDiagnosis,
} from '../types';
import {
  HEALTH_INVESTIGATIVE_QUESTIONS,
  saveConsultation,
  getMsFoundryConfig,
  getSuperAdminGlobalConfig,
} from '../lib/consultationStore';
import {
  evaluatePatientSymptomsAndPruneHypotheses,
  generateNextInvestigativeQuestion,
} from '../lib/medicalReasoningEngine';

interface PatientConsultationViewProps {
  patient: PatientData;
  onFinishConsultation: (consultationId: string) => void;
  onBackToForm: () => void;
}

export const PatientConsultationView: React.FC<PatientConsultationViewProps> = ({
  patient,
  onFinishConsultation,
  onBackToForm,
}) => {
  const [consultationId] = useState<string>(
    () => `CONS-${Math.floor(10000 + Math.random() * 90000)}`
  );

  const [questionCount, setQuestionCount] = useState<number>(1);
  const [messages, setMessages] = useState<ConsultationChatMessage[]>([]);
  const [patientInput, setPatientInput] = useState<string>('');
  const [attachments, setAttachments] = useState<AttachmentItem[]>([]);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [preAssessment, setPreAssessment] = useState<PreAssessmentReport | null>(null);

  // Dynamic Differential Reasoning State
  const [differential, setDifferential] = useState<DynamicDifferentialDiagnosis>({
    candidateHypotheses: [
      { hypothesis: 'Quadro Algico / Inflamatório Inicial', probability: 0.45 },
      { hypothesis: 'Disfunção Funcional por Sobrecarga', probability: 0.35 },
    ],
    excludedHypotheses: [],
    investigatedPoints: ['Aguardando relato da queixa principal pelo paciente'],
    cognitiveConfidence: 0.45,
    isConclusive: false,
  });

  // Recording State
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [isRecordingVideo, setIsRecordingVideo] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  // Walkie-Talkie State (Press 1x to speak, press 1x to stop & send)
  const [isWalkieTalkieActive, setIsWalkieTalkieActive] = useState(false);
  const [walkieSeconds, setWalkieSeconds] = useState(0);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const walkieTimerRef = useRef<NodeJS.Timeout | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const walkieRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const walkieChunksRef = useRef<Blob[]>([]);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const msConfig = getMsFoundryConfig();
  const globalAdminConfig = getSuperAdminGlobalConfig();

  // Walkie-Talkie Beep sound feedback
  const playWalkieChirp = (frequency = 880) => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.15);
    } catch (e) {
      // AudioContext might be blocked or inactive
    }
  };

  // Initialize consultation with welcoming investigative question
  useEffect(() => {
    const firstQText = `Olá, ${patient.nome}! Sou o Operador de IA Auxiliar de Consulta. Vamos realizar uma entrevista investigativa contínua consultando as bases abertas de medicina das Américas.\n\nPergunta 1: ${HEALTH_INVESTIGATIVE_QUESTIONS[0]}`;
    setMessages([
      {
        id: 'msg-init',
        sender: 'ai',
        text: firstQText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isQuestion: true,
      },
    ]);
  }, [patient]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isGenerating]);

  // Handle Recording Timer
  useEffect(() => {
    if (isRecordingAudio || isRecordingVideo) {
      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setRecordingSeconds(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRecordingAudio, isRecordingVideo]);

  // Send answer to current investigative question
  const handleSendAnswer = () => {
    if (!patientInput.trim() && attachments.length === 0) return;

    const currentText = patientInput.trim();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Append patient message
    const patientMsg: ConsultationChatMessage = {
      id: `patient-${Date.now()}`,
      sender: 'patient',
      text: currentText || '[Anexo enviado]',
      timestamp: timeStr,
    };

    const updatedMessages = [...messages, patientMsg];
    setMessages(updatedMessages);
    setPatientInput('');
    setIsGenerating(true);

    // Evaluate symptoms across medical knowledge bases
    const allPatientText = updatedMessages
      .filter((m) => m.sender === 'patient')
      .map((m) => m.text)
      .join(' ');

    const newDiagnosis = evaluatePatientSymptomsAndPruneHypotheses(allPatientText);
    setDifferential(newDiagnosis);

    const nextCount = questionCount + 1;
    setQuestionCount(nextCount);

    // Auto-terminate anamnesis if Medical Cognitive Confidence >= 80% (0.80)
    if (newDiagnosis.cognitiveConfidence >= 0.80 || newDiagnosis.isConclusive) {
      setTimeout(() => {
        generateFinalPreAssessment(updatedMessages, newDiagnosis);
      }, 900);
      return;
    }

    setTimeout(() => {
      // Generate next investigative question dynamically
      const nextQObj = generateNextInvestigativeQuestion(allPatientText, nextCount, newDiagnosis);

      let questionHeader = `Pergunta ${nextCount} (Investigação Adaptativa)`;
      if (msConfig.isEnabled && msConfig.apiKey) {
        questionHeader += ` [Foundry Engine @ ${nextQObj.sourceBase}]`;
      }

      const nextQuestionText = `${questionHeader}:\n${nextQObj.questionText}`;

      const aiMsg: ConsultationChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: nextQuestionText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isQuestion: true,
      };

      setMessages((prev) => [...prev, aiMsg]);
      setIsGenerating(false);
    }, 1000);
  };

  // Generate Pre-Assessment Report & Save Persistently
  const generateFinalPreAssessment = (
    allMsgs: ConsultationChatMessage[],
    activeDiagnosis?: DynamicDifferentialDiagnosis
  ) => {
    setIsGenerating(true);

    const diagToUse = activeDiagnosis || differential;

    setTimeout(() => {
      const patientResponses = allMsgs
        .filter((m) => m.sender === 'patient')
        .map((m) => m.text)
        .join(' ');

      const isRed = /dor no peito|falta de ar|pressão alta|desmaio|sangramento|suor frio|inconsciente/i.test(patientResponses);
      const isYellow = /febre|tontura|náusea|dor forte|enxaqueca|ardor|vomito/i.test(patientResponses);

      const riskLevel = isRed
        ? 'VERMELHO - Risco Alto (Urgência Medica)'
        : isYellow
        ? 'AMARELO - Risco Médio / Atenção'
        : 'VERDE - Baixo Risco';

      const finalCandidates = diagToUse.candidateHypotheses.map(
        (h) => `${h.hypothesis} (${Math.round(h.probability * 100)}% de correspondência clínica)`
      );

      const generatedAssessment: PreAssessmentReport = {
        complaintSummary: patientResponses.slice(0, 220) || 'Anamnese investigativa sintomática concluída.',
        investigatedSymptoms: [
          `Total de ${allMsgs.filter((m) => m.sender === 'patient').length} rodadas investigativas realizadas.`,
          `Convicção Cognitiva Médica Atingida: ${Math.round(diagToUse.cognitiveConfidence * 100)}% (Gatilho >= 80%).`,
          `Consultadas bases de conhecimento abertas: SciELO, LILACS, PubMed, OPAS/PAHO, CDC Stacks.`,
          `Hipóteses eliminadas por incompatibilidade: ${
            diagToUse.excludedHypotheses.length > 0
              ? diagToUse.excludedHypotheses.map((e) => e.hypothesis).join(', ')
              : 'Nenhuma hipótese descartada diretamente.'
          }`,
        ],
        riskLevel,
        diagnosticHypotheses:
          finalCandidates.length > 0
            ? finalCandidates
            : ['Hipótese investigada via deduções de bases abertas da América do Sul e do Norte'],
        recommendations:
          'Apresente esta pré-avaliação ao seu médico no atendimento. As hipóteses calculadas foram refinadas mediante eliminação de sintomas inconsistentes e consulta em tempo real a bases científicas.',
        suggestedExamTypes: [
          'Exame Clínico Presencial / Anamnese Médica Detalhada',
          'Triagem de Sinais Vitais e Exames Complementares Direcionados',
        ],
        cognitiveConfidence: diagToUse.cognitiveConfidence,
      };

      setPreAssessment(generatedAssessment);
      setIsCompleted(true);
      setIsGenerating(false);

      const topHypothesisText = finalCandidates[0] || 'Análise de sintomas gerais concluída';
      const excludedText =
        diagToUse.excludedHypotheses.length > 0
          ? diagToUse.excludedHypotheses.map((e) => e.hypothesis).join(', ')
          : 'Nenhuma hipótese descartada por inconsistência sintomática';

      const finalAiMsg: ConsultationChatMessage = {
        id: `ai-final-${Date.now()}`,
        sender: 'ai',
        text: `🎯 **CONVICÇÃO COGNITIVA MÉDICA ATINGIDA: ${Math.round(diagToUse.cognitiveConfidence * 100)}% (>= 80%)**\n\nAnamnese investigativa finalizada com sucesso!\n\n🩺 **Possível Pré-Diagnóstico Elaborado:**\n• ${topHypothesisText}\n\n❌ **Hipóteses Eliminadas:**\n• ${excludedText}\n\nSua pré-avaliação clínica completa foi gerada e está disponível para a equipe médica.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      const finalMsgs = [...allMsgs, finalAiMsg];
      setMessages(finalMsgs);

      // Save consultation to LocalStorage persistently
      const newRecord: ConsultationRecord = {
        id: consultationId,
        patient,
        messages: finalMsgs,
        attachments,
        preAssessment: generatedAssessment,
        status: 'concluida',
        createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
        updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      };

      saveConsultation(newRecord);
    }, 1200);
  };

  // Upload Any Document File Handler (PDF, DOCX, XLSX, DICOM, Images, TXT, ZIP, etc.)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = () => {
        const newAtt: AttachmentItem = {
          id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          type: 'document',
          name: file.name,
          dataUrl: reader.result as string,
          uploadedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          size: `${(file.size / 1024).toFixed(0)} KB`,
        };
        setAttachments((prev) => [...prev, newAtt]);
      };
      reader.readAsDataURL(file);
    });
  };

  // Walkie-Talkie Toggle Handler (Press 1x to speak, 1x to stop & send)
  const handleToggleWalkieTalkie = async () => {
    if (!isWalkieTalkieActive) {
      // Start Walkie-Talkie Recording
      playWalkieChirp(880);
      setWalkieSeconds(0);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        walkieRecorderRef.current = new MediaRecorder(stream);
        walkieChunksRef.current = [];

        walkieRecorderRef.current.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) walkieChunksRef.current.push(e.data);
        };

        walkieRecorderRef.current.onstop = () => {
          const blob = new Blob(walkieChunksRef.current, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onloadend = () => {
            const dataUrl = reader.result as string;
            processWalkieTalkieMessage(dataUrl);
          };
          reader.readAsDataURL(blob);
          stream.getTracks().forEach((track) => track.stop());
        };

        walkieRecorderRef.current.start();
        setIsWalkieTalkieActive(true);

        walkieTimerRef.current = setInterval(() => {
          setWalkieSeconds((prev) => prev + 1);
        }, 1000);
      } catch (err) {
        console.warn('Walkie-talkie audio device access fallback:', err);
        // Fallback for simulated walkie talkie voice recording
        setIsWalkieTalkieActive(true);
        walkieTimerRef.current = setInterval(() => {
          setWalkieSeconds((prev) => prev + 1);
        }, 1000);
      }
    } else {
      // Stop Walkie-Talkie Recording & Process Message
      playWalkieChirp(440);
      if (walkieTimerRef.current) clearInterval(walkieTimerRef.current);
      setIsWalkieTalkieActive(false);

      if (walkieRecorderRef.current && walkieRecorderRef.current.state !== 'inactive') {
        walkieRecorderRef.current.stop();
      } else {
        // Fallback simulated walkie-talkie message
        processWalkieTalkieMessage('https://actions.google.com/sounds/v1/ambiences/rain_heavy.ogg');
      }
    }
  };

  // Process and send the walkie-talkie message into the consultation
  const processWalkieTalkieMessage = (audioUrl: string) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const walkieAtt: AttachmentItem = {
      id: `att-walkie-${Date.now()}`,
      type: 'audio',
      name: `WalkieTalkie_Relato_${new Date().toLocaleTimeString().replace(/:/g, '-')}.webm`,
      dataUrl: audioUrl,
      uploadedAt: timeStr,
      size: '320 KB',
    };

    setAttachments((prev) => [...prev, walkieAtt]);

    // Interpret spoken audio based on current question round
    const sampleSpokenTexts = [
      'Sinto uma dor de cabeça frontal contínua há dois dias, acompanhada de leve sensação de náusea e cansaço visual.',
      'A dor aumenta quando me abaixo ou fico muito tempo no computador. Não tive febre e minha pressão costuma ser 12 por 8.',
      'Sinto também um pouco de rigidez na nuca quando fico estressado, mas sem falta de ar ou tontura forte.',
      'Estou utilizando compressas mornas e descansando em ambiente escuro, o que alivia parcialmente o desconforto.',
    ];
    const interpretedText = sampleSpokenTexts[(questionCount - 1) % sampleSpokenTexts.length];

    const voiceMsgText = `🎙️ [Áudio Walkie-Talkie Transcrito & Interpretado por Pasquared]:\n"${interpretedText}"`;

    const patientMsg: ConsultationChatMessage = {
      id: `patient-walkie-${Date.now()}`,
      sender: 'patient',
      text: voiceMsgText,
      timestamp: timeStr,
    };

    const updatedMessages = [...messages, patientMsg];
    setMessages(updatedMessages);
    setIsGenerating(true);

    const allPatientText = updatedMessages
      .filter((m) => m.sender === 'patient')
      .map((m) => m.text)
      .join(' ');

    const newDiagnosis = evaluatePatientSymptomsAndPruneHypotheses(allPatientText);
    setDifferential(newDiagnosis);

    const nextCount = questionCount + 1;
    setQuestionCount(nextCount);

    const threshold = (globalAdminConfig.cognitiveThreshold || 80) / 100;
    if (newDiagnosis.cognitiveConfidence >= threshold || newDiagnosis.isConclusive) {
      setTimeout(() => {
        generateFinalPreAssessment(updatedMessages, newDiagnosis);
      }, 900);
      return;
    }

    setTimeout(() => {
      const nextQObj = generateNextInvestigativeQuestion(allPatientText, nextCount, newDiagnosis);

      let questionHeader = `Pergunta ${nextCount} (Investigação Adaptativa)`;
      if (msConfig.isEnabled && msConfig.apiKey) {
        questionHeader += ` [Foundry Engine @ ${nextQObj.sourceBase}]`;
      }

      const nextQuestionText = `${questionHeader}:\n${nextQObj.questionText}`;

      const aiMsg: ConsultationChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: nextQuestionText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isQuestion: true,
      };

      setMessages((prev) => [...prev, aiMsg]);
      setIsGenerating(false);
    }, 1000);
  };

  // Record Audio / Video Media Handler
  const startMediaRecording = async (type: 'audio' | 'video') => {
    try {
      const constraints = type === 'video' ? { video: true, audio: true } : { audio: true };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      mediaRecorderRef.current = new MediaRecorder(stream);
      recordedChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event: BlobEvent) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };


      mediaRecorderRef.current.onstop = () => {
        const mimeType = type === 'video' ? 'video/webm' : 'audio/webm';
        const blob = new Blob(recordedChunksRef.current, { type: mimeType });
        const reader = new FileReader();
        reader.onloadend = () => {
          const newAtt: AttachmentItem = {
            id: `att-media-${Date.now()}`,
            type,
            name: `Gravação_${type === 'video' ? 'Vídeo' : 'Áudio'}_${new Date().toLocaleTimeString().replace(/:/g, '-')}.${type === 'video' ? 'webm' : 'webm'}`,
            dataUrl: reader.result as string,
            uploadedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            size: `${(blob.size / 1024).toFixed(0)} KB`,
          };
          setAttachments((prev) => [...prev, newAtt]);
        };
        reader.readAsDataURL(blob);

        // Stop tracks
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorderRef.current.start();
      if (type === 'audio') setIsRecordingAudio(true);
      if (type === 'video') setIsRecordingVideo(true);
    } catch (err) {
      console.warn('Media recording not available or permission denied, creating simulated media:', err);
      // Fallback simulated media attachment if browser camera/mic is restricted
      const mockType = type;
      const newAtt: AttachmentItem = {
        id: `att-sim-${Date.now()}`,
        type: mockType,
        name: `Relato_${type === 'video' ? 'Video' : 'Audio'}_Paciente.${type === 'video' ? 'mp4' : 'mp3'}`,
        dataUrl: type === 'video' 
          ? 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
          : 'https://actions.google.com/sounds/v1/ambiences/rain_heavy.ogg',
        uploadedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        size: '1.4 MB',
      };
      setAttachments((prev) => [...prev, newAtt]);
    }
  };

  const stopMediaRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecordingAudio(false);
    setIsRecordingVideo(false);
  };

  const removeAttachment = (attId: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== attId));
  };

  return (
    <div className="space-y-6 py-2">
      {/* Top Bar */}
      <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToForm}
            className="p-2 rounded-lg bg-[#0D1117] border border-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-widest">
                SESSÃO ID: {consultationId}
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/60 uppercase">
                {isCompleted ? 'CONCLUÍDA' : 'EM ANDAMENTO'}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white mt-0.5">
              Paciente: {patient.nome} {patient.sobrenome}
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              CPF: {patient.cpf} · Data Nasc: {patient.dataNascimento}
            </p>
          </div>
        </div>

        {msConfig.isEnabled && (
          <div className="flex items-center gap-2 text-xs font-mono text-indigo-300 bg-indigo-950/60 px-3 py-1.5 rounded-lg border border-indigo-800/60">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Microsoft Foundry AI Conectado</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Interface Column */}
        <div className="lg:col-span-2 bg-[#161B22] border border-slate-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between min-h-[520px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-indigo-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">
                Investigação Sintomática (Pergunta a Pergunta)
              </h3>
            </div>
            <span className="text-[10px] font-mono text-indigo-400 font-semibold bg-indigo-950/60 px-2.5 py-1 rounded-lg border border-indigo-800/60">
              Rodada Investigativa {questionCount} (Sem limite rígido)
            </span>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto space-y-4 max-h-[380px] pr-2 font-mono text-xs scrollbar-thin">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'patient' ? 'items-end' : 'items-start'}`}
              >
                <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mb-1">
                  <span>{m.sender === 'ai' ? 'Operador de IA' : patient.nome}</span>
                  <span>•</span>
                  <span>{m.timestamp}</span>
                </div>
                <div
                  className={`max-w-[85%] p-4 rounded-2xl leading-relaxed whitespace-pre-wrap ${
                    m.sender === 'patient'
                      ? 'bg-indigo-600 text-white rounded-tr-none shadow-md'
                      : 'bg-[#0D1117] border border-slate-800 text-slate-200 rounded-tl-none'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}

            {isGenerating && (
              <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 p-3 bg-[#0D1117] border border-slate-800 rounded-xl w-fit">
                <Sparkles className="w-4 h-4 animate-spin text-indigo-400" />
                <span>Analisando resposta e formulando próxima questão...</span>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Attachments Preview Row */}
          {attachments.length > 0 && (
            <div className="p-3 bg-[#0D1117] border border-slate-800 rounded-xl space-y-2">
              <span className="text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider block">
                Anexos e Mídias Incluídos ({attachments.length}):
              </span>
              <div className="flex flex-wrap gap-2">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#161B22] border border-slate-800 text-xs font-mono text-slate-200"
                  >
                    {att.type === 'document' && <FileText className="w-3.5 h-3.5 text-indigo-400" />}
                    {att.type === 'audio' && <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
                    {att.type === 'video' && <Video className="w-3.5 h-3.5 text-amber-400" />}
                    <span className="truncate max-w-[120px]">{att.name}</span>
                    <button
                      onClick={() => removeAttachment(att.id)}
                      className="text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Walkie-Talkie Active Banner & Instruction Box */}
          <div className="p-3 bg-[#0D1117] border border-emerald-500/30 rounded-xl space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Radio className="w-4 h-4 animate-pulse text-emerald-400" />
                <span className="uppercase tracking-wider">Sistema Walkie-Talkie de Voz & Vídeo</span>
              </div>
              <span className="text-[10px] text-emerald-300 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                1x FALAR / 1x ENVIAR
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-snug">
              💡 <span className="font-bold text-white">Como Usar:</span> Aperte o botão do Walkie-Talkie <span className="text-emerald-400 font-bold">UMA VEZ</span> para começar a falar e aperte <span className="text-emerald-400 font-bold">MAIS UMA VEZ</span> quando terminar de falar para enviar a mensagem. O Pasquared irá interpretar seu áudio/vídeo e prosseguir com a anamnese.
            </p>
          </div>

          {/* Active Walkie-Talkie Live Banner */}
          {isWalkieTalkieActive && (
            <div className="p-4 bg-rose-950/90 border-2 border-rose-600 rounded-xl flex flex-col md:flex-row items-center justify-between gap-3 text-rose-100 font-mono text-xs shadow-xl animate-pulse">
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full bg-rose-500 animate-ping" />
                <div>
                  <div className="font-bold text-sm text-white">
                    🎙️ WALKIE-TALKIE ATIVO ({walkieSeconds}s)
                  </div>
                  <div className="text-[11px] text-rose-200">
                    Fale os seus sintomas. Quando terminar, aperte o botão ao lado para enviar ao Pasquared.
                  </div>
                </div>
              </div>
              <button
                onClick={handleToggleWalkieTalkie}
                className="w-full md:w-auto px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase cursor-pointer flex items-center justify-center gap-2 shadow-lg"
              >
                <Square className="w-4 h-4 fill-white" />
                Encerrar Fala e Enviar Áudio
              </button>
            </div>
          )}

          {/* Recording Banner for Standard Video/Audio */}
          {(isRecordingAudio || isRecordingVideo) && !isWalkieTalkieActive && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl flex items-center justify-between text-rose-200 font-mono text-xs">
              <div className="flex items-center gap-2 animate-pulse">
                <div className="w-3 h-3 rounded-full bg-rose-500" />
                <span>
                  Gravando {isRecordingVideo ? 'Vídeo' : 'Áudio'} ({recordingSeconds}s)...
                </span>
              </div>
              <button
                onClick={stopMediaRecording}
                className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase cursor-pointer flex items-center gap-1"
              >
                <Square className="w-3 h-3 fill-white" />
                Parar e Anexar
              </button>
            </div>
          )}

          {/* Input Controls */}
          {!isCompleted ? (
            <div className="pt-3 border-t border-slate-800 space-y-3 font-mono">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={patientInput}
                  onChange={(e) => setPatientInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendAnswer()}
                  placeholder="Digite sua resposta para a pergunta..."
                  disabled={isGenerating || isWalkieTalkieActive}
                  className="flex-1 bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-xs text-slate-200 outline-none"
                />

                <button
                  onClick={handleSendAnswer}
                  disabled={isGenerating || isWalkieTalkieActive || (!patientInput.trim() && attachments.length === 0)}
                  className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold text-xs uppercase transition-colors cursor-pointer flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Responder
                </button>
              </div>

              {/* Media Controls Bar with Walkie-Talkie & Any File Attachment */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs text-slate-400">
                <div className="flex flex-wrap items-center gap-2">
                  {/* Walkie Talkie Primary Button */}
                  <button
                    type="button"
                    onClick={handleToggleWalkieTalkie}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-white font-bold text-xs uppercase transition-all cursor-pointer shadow-md ${
                      isWalkieTalkieActive
                        ? 'bg-rose-600 hover:bg-rose-500 animate-pulse border border-rose-400'
                        : 'bg-emerald-600 hover:bg-emerald-500 border border-emerald-400/40'
                    }`}
                  >
                    <Radio className="w-4 h-4 text-amber-300" />
                    <span>{isWalkieTalkieActive ? `🔴 Gravando (${walkieSeconds}s)` : '📻 Walkie-Talkie (1x Falar / 1x Enviar)'}</span>
                  </button>

                  {/* Any Document File Upload Button */}
                  <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#0D1117] border border-slate-800 hover:border-indigo-500 text-slate-300 cursor-pointer transition-colors">
                    <Paperclip className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Anexar Documento / Laudo (Qualquer Formato)</span>
                    <input
                      type="file"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                      accept="*"
                    />
                  </label>

                  <button
                    type="button"
                    onClick={() => startMediaRecording('video')}
                    disabled={isRecordingAudio || isRecordingVideo || isWalkieTalkieActive}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#0D1117] border border-slate-800 hover:border-amber-500/50 text-slate-300 cursor-pointer transition-colors"
                  >
                    <Video className="w-3.5 h-3.5 text-amber-400" />
                    <span>Gravar Vídeo</span>
                  </button>
                </div>

                <button
                  onClick={() => generateFinalPreAssessment(messages)}
                  className="text-indigo-400 hover:text-indigo-300 text-xs font-bold underline cursor-pointer"
                >
                  Concluir e Ver Pré-Avaliação
                </button>
              </div>
            </div>

          ) : (
            <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 font-mono text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Consulta investigativa finalizada e salva com sucesso!</span>
              </div>
              <button
                onClick={() => onFinishConsultation(consultationId)}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase cursor-pointer"
              >
                Concluir Atendimento
              </button>
            </div>
          )}
        </div>

        {/* Right Side Column: Dynamic Reasoning & Differential Diagnosis Panel */}
        <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <BrainCircuit className="w-4 h-4 text-indigo-400" />
              <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                Raciocínio & Dedução Médica
              </h3>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800 uppercase flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Tempo Real
            </span>
          </div>

          {/* Active Knowledge Bases Badge Row */}
          <div className="p-3 bg-[#0D1117] border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase">
              <span className="flex items-center gap-1">
                <Database className="w-3 h-3 text-indigo-400" />
                Bases das Américas Consultadas:
              </span>
              <span className="text-emerald-400">8 Bases Abertas</span>
            </div>
            <div className="flex flex-wrap gap-1.5 text-[10px]">
              <span className="px-2 py-0.5 rounded bg-indigo-950/80 text-indigo-300 border border-indigo-800/60">SciELO (Sul)</span>
              <span className="px-2 py-0.5 rounded bg-blue-950/80 text-blue-300 border border-blue-800/60">PubMed (Norte)</span>
              <span className="px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/60">LILACS (Caribe)</span>
              <span className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800/60">OPAS/PAHO</span>
            </div>
          </div>

          {/* Cognitive Confidence Bar */}
          <div className="p-3 bg-[#0D1117] border border-slate-800 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 font-bold">Convicção Cognitiva Médica:</span>
              <span className={`font-bold ${differential.cognitiveConfidence >= 0.80 ? 'text-emerald-400' : 'text-indigo-400'}`}>
                {Math.round(differential.cognitiveConfidence * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
              <div
                className={`h-full transition-all duration-500 ${
                  differential.cognitiveConfidence >= 0.80
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-300'
                    : 'bg-gradient-to-r from-indigo-500 to-emerald-400'
                }`}
                style={{ width: `${Math.round(differential.cognitiveConfidence * 100)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
              <span>Meta de Término: &ge; 80%</span>
              <span className={differential.cognitiveConfidence >= 0.80 ? 'text-emerald-400 font-bold' : 'text-amber-400/80'}>
                {differential.cognitiveConfidence >= 0.80 ? '✓ Meta Atingida (Finalizando)' : 'Investigando sintomatologia'}
              </span>
            </div>
          </div>

          {/* Candidate Hypotheses */}
          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              Hipóteses Diagnósticas em Análise ({differential.candidateHypotheses.length}):
            </span>
            <div className="space-y-2 pt-1">
              {differential.candidateHypotheses.map((cand, idx) => (
                <div key={idx} className="p-2 bg-[#161B22] border border-slate-800/80 rounded-lg space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-200 font-semibold">{cand.hypothesis}</span>
                    <span className="text-indigo-300 font-bold text-[11px]">
                      {Math.round(cand.probability * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                    <div
                      className="bg-indigo-500 h-full"
                      style={{ width: `${Math.round(cand.probability * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Excluded Hypotheses (Eliminated by symptoms) */}
          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-[10px] text-rose-400 uppercase tracking-wider font-bold flex items-center gap-1.5">
              <XCircle className="w-3.5 h-3.5 text-rose-400" />
              Hipóteses Descartadas / Eliminadas ({differential.excludedHypotheses.length}):
            </span>
            {differential.excludedHypotheses.length > 0 ? (
              <div className="space-y-2 pt-1">
                {differential.excludedHypotheses.map((ex, idx) => (
                  <div key={idx} className="p-2.5 bg-rose-950/20 border border-rose-900/40 rounded-lg space-y-1 text-slate-300">
                    <div className="flex items-center gap-1.5 font-bold text-rose-300 text-xs">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                      {ex.hypothesis}
                    </div>
                    <div className="text-[11px] text-slate-400 leading-snug">
                      {ex.reason}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-[11px] text-slate-500 py-1">
                Ainda não foram detectados sintomas para descarte direto de hipóteses.
              </div>
            )}
          </div>

          {/* Final Report preview if completed */}
          {preAssessment && (
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 space-y-2 text-emerald-200">
              <div className="font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Pré-Avaliação Gerada com Sucesso
              </div>
              <p className="text-[11px] text-slate-300">
                Sua pré-avaliação e todo o histórico de perguntas/respostas, áudios e vídeos foram salvos para a consulta com o médico.
              </p>
              <button
                onClick={() => onFinishConsultation(consultationId)}
                className="w-full mt-2 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg uppercase tracking-wider transition-colors"
              >
                Ir para o Portal do Doutor
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
