import React, { useState } from 'react';
import { UCLObject } from '../types';
import { Send, CheckCircle2, ShieldCheck, FileJson, AlertCircle, Sparkles } from 'lucide-react';

interface UclGeneratorTabProps {
  onProcessUCL: (ucl: UCLObject) => void;
}

export const UclGeneratorTab: React.FC<UclGeneratorTabProps> = ({ onProcessUCL }) => {
  const [uclData, setUclData] = useState<UCLObject>({
    ObjectID: `ucl-med-${Date.now().toString(36)}`,
    SourceID: 'pubmed:38291024',
    InputType: 'text',
    Language: 'pt-BR',
    Category: 'Medicina',
    Theme: 'Anticoagulação na Fibrilação Atrial',
    Timestamp: new Date().toISOString(),
    Context: { fonte: 'Diretriz de Cardiologia 2026', prioridade: 'alta' },
    Content: {
      titulo: 'Eficácia dos Anticoagulantes Orais de Ação Direta (DOACs)',
      resumo: 'Adoção de DOACs reduz eventos tromboembólicos com menor incidência de sangramento intracraniano.',
    },
    Metadata: { version: '1.0.0', modulo: 'harvester-med' },
    Version: 'UCL-1.0',
    Confidence: 0.92,
  });

  const [validationResult, setValidationResult] = useState<{
    valid: boolean;
    errors?: string[];
  } | null>(null);

  const [jsonText, setJsonText] = useState(JSON.stringify(uclData, null, 2));
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleValidateSchema = () => {
    try {
      const parsed = JSON.parse(jsonText) as UCLObject;
      const required = [
        'ObjectID',
        'SourceID',
        'InputType',
        'Language',
        'Category',
        'Theme',
        'Timestamp',
        'Context',
        'Content',
        'Metadata',
        'Version',
      ];

      const missing = required.filter((req) => !(req in parsed));

      if (missing.length === 0) {
        setValidationResult({ valid: true });
        setUclData(parsed);
      } else {
        setValidationResult({
          valid: false,
          errors: missing.map((f) => `Campo obrigatório ausente: ${f}`),
        });
      }
    } catch (e) {
      setValidationResult({
        valid: false,
        errors: [`Erro de Sintaxe JSON: ${(e as Error).message}`],
      });
    }
  };

  const handleDispatch = () => {
    setIsSubmitting(true);
    handleValidateSchema();

    setTimeout(() => {
      try {
        const parsed = JSON.parse(jsonText) as UCLObject;
        onProcessUCL(parsed);
        setValidationResult({ valid: true });
      } catch (e) {
        // Handled in validate
      }
      setIsSubmitting(false);
    }, 300);
  };

  return (
    <div className="space-y-6">
      {/* Header Bento Card */}
      <div className="bg-[#161B22] rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
            MÓDULO USR & PCK (UNIVERSAL COGNITIVE LAYER)
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">
            Gerador & Validador de Objeto UCL
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Gere, valide em relação ao esquema USR (ucl-1.0.json) e submeta um objeto cognitivo para o pipeline PCK.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* JSON Editor Bento Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <FileJson className="w-4 h-4 text-indigo-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">Objeto UCL (UCL-1.0 Schema)</h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">SCHEMA: UCL-1.0</span>
          </div>

          <textarea
            value={jsonText}
            onChange={(e) => setJsonText(e.target.value)}
            rows={14}
            spellCheck={false}
            className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl p-4 text-slate-200 font-mono text-xs leading-relaxed outline-none resize-y"
          />

          <div className="flex gap-3">
            <button
              onClick={handleValidateSchema}
              className="flex-1 py-2.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-200 font-mono text-xs font-bold hover:bg-slate-700 transition-colors cursor-pointer uppercase"
            >
              Validar Esquema USR
            </button>
            <button
              onClick={handleDispatch}
              disabled={isSubmitting}
              className="flex-1 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 uppercase"
            >
              <Send className="w-3.5 h-3.5" />
              {isSubmitting ? 'Injetando no PCK...' : 'Disparar Ciclo Cognitivo'}
            </button>
          </div>
        </div>

        {/* Validation Output Bento Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h3 className="font-bold text-white text-xs uppercase tracking-wider">Relatório do Servidor USR (:3020)</h3>
            </div>
          </div>

          {validationResult === null ? (
            <div className="py-16 text-center text-slate-500 space-y-2">
              <FileJson className="w-8 h-8 mx-auto text-slate-600" />
              <p>Clique em "Validar Esquema USR" para inspecionar o payload.</p>
            </div>
          ) : validationResult.valid ? (
            <div className="p-4 rounded-xl border border-emerald-800 bg-[#0D1117] text-emerald-300 space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                Objeto UCL Válido perante o Esquema USR!
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Todos os 11 campos obrigatórios foram validados com sucesso pelo validador Ajv do serviço USR na porta 3020.
              </p>
            </div>
          ) : (
            <div className="p-4 rounded-xl border border-rose-800 bg-[#0D1117] text-rose-300 space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold">
                <AlertCircle className="w-5 h-5 text-rose-400" />
                Falha na Validação de Esquema
              </div>
              <ul className="list-disc list-inside text-[11px] text-slate-300 space-y-1">
                {validationResult.errors?.map((err, idx) => (
                  <li key={idx}>{err}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
