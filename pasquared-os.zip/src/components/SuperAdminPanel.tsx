import React, { useState, useEffect } from "react";
import { Lock, Shield, Database, RefreshCw, Server, Plus, Download, CheckCircle2, AlertTriangle, ArrowLeft, Globe, FileText, Activity } from "lucide-react";
import { motion } from "motion/react";

interface SuperAdminPanelProps {
  onBackToApp: () => void;
}

export function SuperAdminPanel({ onBackToApp }: SuperAdminPanelProps) {
  const [email, setEmail] = useState("rogermei577@pasquared.space");
  const [password, setPassword] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [loginError, setLoginError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const [dbData, setDbData] = useState<any>(null);
  const [isLoadingKnowledge, setIsLoadingKnowledge] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Manual Ingestion Form
  const [customTitle, setCustomTitle] = useState("");
  const [customSource, setCustomSource] = useState("SciELO");
  const [customRegion, setCustomRegion] = useState("South America");
  const [customDomain, setCustomDomain] = useState("Medicine");
  const [customAbstract, setCustomAbstract] = useState("");

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsLoading(true);
    setLoginError("");

    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setIsAuthenticated(true);
        setAuthToken(data.token);
        setDbData(data.db);
        setNotification("Acesso Concedido ao Cluster Super Admin.");
      } else {
        setLoginError(data.error || "Senha ou usuário incorretos.");
      }
    } catch (err) {
      setLoginError("Erro ao comunicar com o servidor de autenticação.");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchDbData = async () => {
    try {
      const res = await fetch("/api/admin/db");
      const data = await res.json();
      if (data.db) setDbData(data.db);
    } catch (e) {
      console.error(e);
    }
  };

  const handleLoadKnowledge = async () => {
    setIsLoadingKnowledge(true);
    try {
      const res = await fetch("/api/admin/load-knowledge", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setDbData(data.db);
        setNotification("Base de conhecimento atualizada com sucesso (+150.000 novos registros sintetizados).");
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingKnowledge(false);
    }
  };

  const handleAddCustomKnowledge = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle || !customAbstract) return;

    try {
      const res = await fetch("/api/admin/add-knowledge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: customTitle,
          source: customSource,
          region: customRegion,
          domain: customDomain,
          abstract: customAbstract
        })
      });
      const data = await res.json();
      if (data.success) {
        setDbData(data.db);
        setCustomTitle("");
        setCustomAbstract("");
        setNotification(`Novo conhecimento registrado no banco persistente: "${customTitle}".`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const downloadDbBackup = () => {
    if (!dbData) return;
    const blob = new Blob([JSON.stringify(dbData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pasquared_db_backup_${Date.now()}.json`;
    a.click();
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#050507] text-white flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans">
        {/* Background glow effects */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-cyan-600/10 via-purple-600/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="w-full max-w-md relative z-10 space-y-6">
          <div className="flex justify-between items-center mb-2">
            <button
              onClick={onBackToApp}
              className="flex items-center gap-2 text-xs text-white/50 hover:text-white transition-colors"
            >
              <ArrowLeft size={14} /> Voltar ao App
            </button>
            <span className="text-[10px] uppercase font-mono tracking-widest text-cyan-400 bg-cyan-400/10 px-2.5 py-1 rounded-full border border-cyan-400/20">
              Restricted Area
            </span>
          </div>

          <div className="bg-[#0c0c10] border border-white/10 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-cyan-500" />
            
            <div className="text-center space-y-3 mb-8">
              <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto text-cyan-400 shadow-inner">
                <Shield size={28} />
              </div>
              <h1 className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-cyan-300 to-purple-400">
                PASQUARED ROOT ADMIN
              </h1>
              <p className="text-xs text-white/40 font-mono">
                app.pasquared.space/rootsuperadmin
              </p>
            </div>

            {loginError && (
              <div className="mb-6 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center gap-2">
                <AlertTriangle size={16} />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-white/40 tracking-wider mb-1.5">
                  Usuário / E-mail Super Admin
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-400 transition-colors font-mono"
                  placeholder="rogermei577@pasquared.space"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-white/40 tracking-wider mb-1.5">
                  Senha do Kernel
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-400 transition-colors font-mono"
                  placeholder="••••••••••••"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-purple-600 text-black font-bold text-sm rounded-xl hover:opacity-90 transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(34,211,238,0.3)] disabled:opacity-50 mt-6"
              >
                <Lock size={16} />
                {isLoading ? "Autenticando..." : "Acessar Cluster Super Admin"}
              </button>
            </form>

            <div className="mt-6 pt-6 border-t border-white/5 text-center">
              <p className="text-[10px] text-white/30 font-mono">
                Credenciais de Teste: <span className="text-cyan-400">21121201@Roger-Pasq</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050507] text-white font-sans flex flex-col">
      {/* Top Admin Header */}
      <header className="h-16 border-b border-white/10 bg-[#0a0a0e] px-8 flex items-center justify-between sticky top-0 z-50 backdrop-blur-md">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Shield size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white">PASQUARED ROOT SUPER ADMIN</span>
              <span className="text-[9px] bg-green-500/20 text-green-400 px-2 py-0.5 rounded border border-green-500/30 font-mono">
                PERSISTENT DB MOUNTED
              </span>
            </div>
            <p className="text-[10px] text-white/40 font-mono">rogermei577@pasquared.space</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={downloadDbBackup}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-white/80 transition-colors"
          >
            <Download size={14} /> Exportar Banco JSON
          </button>
          <button
            onClick={onBackToApp}
            className="px-4 py-1.5 bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-bold rounded-lg hover:bg-red-500/30 transition-all"
          >
            Sair do Admin
          </button>
        </div>
      </header>

      {/* Main Admin Dashboard */}
      <main className="flex-1 p-8 max-w-7xl mx-auto w-full space-y-8">
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-sm flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <CheckCircle2 size={18} />
              <span>{notification}</span>
            </div>
            <button onClick={() => setNotification(null)} className="text-white/40 hover:text-white text-xs">✕</button>
          </motion.div>
        )}

        {/* Database Metrics & Control Bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-5 space-y-2">
            <span className="text-[10px] text-white/40 font-bold uppercase tracking-wider block">Status do Banco Persistente</span>
            <div className="flex items-center gap-2 text-green-400 font-mono text-sm font-bold">
              <Server size={16} />
              <span>{dbData?.systemConfig?.dbStatus || "Mounted"}</span>
            </div>
            <p className="text-[10px] text-white/30 font-mono">data/pasquared_db.json</p>
          </div>

          <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-5 space-y-2">
            <span className="text-[10px] text-white/40 font-bold uppercase tracking-wider block">Registros Mapeados em CDNA</span>
            <div className="text-2xl font-mono font-bold text-cyan-400">
              {dbData?.systemConfig?.totalRecordsIngested?.toLocaleString() || "60,160,000"}
            </div>
            <p className="text-[10px] text-white/30">Artigos, genomas e jurisprudências</p>
          </div>

          <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-5 space-y-2">
            <span className="text-[10px] text-white/40 font-bold uppercase tracking-wider block">Fontes Ativas das Américas</span>
            <div className="text-2xl font-mono font-bold text-purple-400">
              {dbData?.sources?.length || 8} Repositórios
            </div>
            <p className="text-[10px] text-white/30">América do Sul & América do Norte</p>
          </div>

          <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-5 flex flex-col justify-between">
            <span className="text-[10px] text-white/40 font-bold uppercase tracking-wider block">Ingestão Rápida</span>
            <button
              onClick={handleLoadKnowledge}
              disabled={isLoadingKnowledge}
              className="w-full py-2.5 bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(34,211,238,0.4)] disabled:opacity-50"
            >
              <RefreshCw size={14} className={isLoadingKnowledge ? "animate-spin" : ""} />
              {isLoadingKnowledge ? "Sintetizando..." : "Carregar Base de Conhecimento"}
            </button>
          </div>
        </div>

        {/* How to Feed Real Data Guide */}
        <div className="bg-[#0d0d12] border border-cyan-500/20 rounded-2xl p-6 space-y-4 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 text-cyan-500/10 pointer-events-none">
            <Globe size={120} />
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <FileText size={20} />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Como Alimentar a IA Cognitiva Pasquared com Dados Reais da Internet</h2>
              <p className="text-xs text-white/50">Guia de Ingestão do Protocolo UCL & Normalização em CDNA</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-2">
              <span className="text-xs font-bold text-cyan-400">1. Repositórios Científicos & Médicos</span>
              <p className="text-[11px] text-white/60 leading-relaxed">
                Conecte APIs públicas de fontes como <b>PubMed</b> e <b>SciELO</b> via endpoints REST JSON. Os resumos clínicos e artigos completos são vetorizados automaticamente.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-2">
              <span className="text-xs font-bold text-purple-400">2. Dados Abertos Governamentais</span>
              <p className="text-[11px] text-white/60 leading-relaxed">
                Importe datasets de dados abertos do <b>SUS Open Data</b> e <b>CDC</b> para treinar modelos preditivos de vigilância epidemiológica e saúde pública.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-2">
              <span className="text-xs font-bold text-green-400">3. Ingestão Personalizada Direct-UCL</span>
              <p className="text-[11px] text-white/60 leading-relaxed">
                Insira textos, relatórios e URLs de portais de notícias no formulário de Ingestão Manual abaixo para alimentar a memória de longo prazo (EKO).
              </p>
            </div>
          </div>
        </div>

        {/* Repositories / Sources Grid: South America & North America */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Globe size={16} className="text-cyan-400" /> Repositórios de Conhecimento Ativos (América do Sul & América do Norte)
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* South America Sources */}
            <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-6 space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-white/5">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" /> Fontes América do Sul
                </span>
                <span className="text-[10px] text-white/40 font-mono">Brasil / Cone Sul / LatAm</span>
              </div>

              <div className="space-y-3">
                {dbData?.sources?.filter((s: any) => s.region === "South America")?.map((source: any) => (
                  <div key={source.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between hover:border-cyan-500/30 transition-all">
                    <div>
                      <p className="text-xs font-bold text-white/90">{source.name}</p>
                      <p className="text-[10px] text-white/40">{source.domain}</p>
                    </div>
                    <div className="text-right font-mono">
                      <span className="text-xs text-cyan-400 font-bold block">{source.recordCount.toLocaleString()}</span>
                      <span className="text-[9px] text-green-400 uppercase">● {source.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* North America Sources */}
            <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-6 space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-white/5">
                <span className="text-xs font-bold text-purple-400 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-400" /> Fontes América do Norte
                </span>
                <span className="text-[10px] text-white/40 font-mono">EUA / Canadá</span>
              </div>

              <div className="space-y-3">
                {dbData?.sources?.filter((s: any) => s.region === "North America")?.map((source: any) => (
                  <div key={source.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between hover:border-purple-500/30 transition-all">
                    <div>
                      <p className="text-xs font-bold text-white/90">{source.name}</p>
                      <p className="text-[10px] text-white/40">{source.domain}</p>
                    </div>
                    <div className="text-right font-mono">
                      <span className="text-xs text-purple-400 font-bold block">{source.recordCount.toLocaleString()}</span>
                      <span className="text-[9px] text-green-400 uppercase">● {source.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Manual Knowledge Ingestion & Recent Ingested Items */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Form */}
          <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-6 space-y-4 md:col-span-1">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Plus size={14} className="text-cyan-400" /> Inserção Manual de Conhecimento
            </h3>

            <form onSubmit={handleAddCustomKnowledge} className="space-y-3">
              <div>
                <label className="block text-[10px] uppercase font-bold text-white/40 mb-1">Título do Artigo / Relatório</label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="Ex: Novo Protocolo Oncológico 2026"
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-white/40 mb-1">Fonte</label>
                  <input
                    type="text"
                    value={customSource}
                    onChange={(e) => setCustomSource(e.target.value)}
                    placeholder="SciELO / PubMed / Custom"
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-bold text-white/40 mb-1">Região</label>
                  <select
                    value={customRegion}
                    onChange={(e) => setCustomRegion(e.target.value)}
                    className="w-full bg-[#121218] border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none"
                  >
                    <option value="South America">América do Sul</option>
                    <option value="North America">América do Norte</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-white/40 mb-1">Domínio</label>
                <select
                  value={customDomain}
                  onChange={(e) => setCustomDomain(e.target.value)}
                  className="w-full bg-[#121218] border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none"
                >
                  <option value="Medicine">Medicine</option>
                  <option value="Law">Law</option>
                  <option value="Physics">Physics</option>
                  <option value="History">History</option>
                  <option value="Logic">Logic</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-white/40 mb-1">Resumo / Conteúdo Sintético</label>
                <textarea
                  value={customAbstract}
                  onChange={(e) => setCustomAbstract(e.target.value)}
                  rows={3}
                  placeholder="Descreva as hipóteses, achados ou abstrações..."
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-purple-600 text-black font-bold text-xs rounded-lg hover:opacity-90 transition-all flex items-center justify-center gap-2"
              >
                <Database size={14} /> Ingerir no Banco Persistente
              </button>
            </form>
          </div>

          {/* Knowledge Items Table */}
          <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-6 space-y-4 md:col-span-2 flex flex-col">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Database size={14} className="text-cyan-400" /> Registro de Conhecimentos Sintetizados no Banco
            </h3>

            <div className="flex-1 overflow-y-auto space-y-2 max-h-[350px] pr-1">
              {dbData?.knowledgeItems?.map((item: any) => (
                <div key={item.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
                  <div className="flex justify-between items-start">
                    <h4 className="text-xs font-bold text-white">{item.title}</h4>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-mono">
                      {item.region}
                    </span>
                  </div>
                  <p className="text-[11px] text-white/60 line-clamp-2">{item.abstract}</p>
                  <div className="flex justify-between items-center text-[9px] text-white/30 pt-1 border-t border-white/5">
                    <span>Fonte: {item.source} • Domínio: {item.domain}</span>
                    <span className="text-green-400 font-mono">{item.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Security Audit Logs */}
        <div className="bg-[#0d0d12] border border-white/10 rounded-2xl p-6 space-y-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Activity size={14} className="text-cyan-400" /> Audit Logs do Kernel Persistente
          </h3>

          <div className="bg-black/50 rounded-xl p-3 font-mono text-[11px] space-y-1 max-h-48 overflow-y-auto border border-white/5">
            {dbData?.logs?.map((log: any) => (
              <div key={log.id} className="flex gap-3 text-white/70">
                <span className="text-white/30">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                <span className={log.type === "SECURITY" ? "text-purple-400 font-bold" : log.type === "INGESTION" ? "text-cyan-400 font-bold" : "text-green-400"}>
                  {log.type}
                </span>
                <span>{log.message}</span>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
