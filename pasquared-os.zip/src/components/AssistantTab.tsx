import React, { useState } from 'react';
import { TriageQA } from '../types';
import { Stethoscope, AlertOctagon, RotateCcw, Send, ShieldAlert, CheckCircle, MessageSquare } from 'lucide-react';

const TRIAGE_QUESTIONS: Record<string, TriageQA> = {
  q_start: {
    id: 'q_start',
    text: 'Qual é o seu principal sintoma ou queixa atual?',
    key: 'main_symptom',
    type: 'choice',
    choices: ['dor no peito', 'falta de ar', 'febre', 'dor abdominal', 'cefaleia'],
    next: { default: 'q_duration' },
  },
  q_duration: {
    id: 'q_duration',
    text: 'Há quanto tempo este sintoma começou?',
    key: 'duration',
    type: 'choice',
    choices: ['menos de 2 horas', '2 a 24 horas', 'mais de 24 horas'],
    next: { default: 'q_severity' },
  },
  q_severity: {
    id: 'q_severity',
    text: 'Como você classifica a intensidade deste sintoma?',
    key: 'severity',
    type: 'choice',
    choices: ['leve', 'moderada', 'intensa / severa'],
    next: { default: 'q_alarm' },
  },
  q_alarm: {
    id: 'q_alarm',
    text: 'Apresenta sinais de alarme como tontura forte, desmaio, dor opressiva que irradia para o braço ou lábios azulados?',
    key: 'alarms',
    type: 'yesno',
    next: { yes: 'end_emergency', no: 'q_follow' },
  },
  q_follow: {
    id: 'q_follow',
    text: 'Descreva histórico ou condições prévias importantes (ex: hipertensão, diabetes, uso de medicamentos).',
    key: 'history',
    type: 'text',
    next: { default: 'end_predx' },
  },
  end_emergency: {
    id: 'end_emergency',
    text: 'ALERTA CRÍTICO: Foram indicados sinais de alarme graves. Procure um serviço de emergência hospitalar imediatamente!',
    key: 'ack_emerg',
    type: 'yesno',
  },
  end_predx: {
    id: 'end_predx',
    text: 'Triagem concluída. O resultado é gerado pela inteligência cognitiva do Pasquared OS para fins educacionais.',
    key: 'ack',
    type: 'yesno',
  },
};

interface ChatMessage {
  id: string;
  sender: 'system' | 'user';
  text: string;
  isEmergency?: boolean;
}

export const AssistantTab: React.FC = () => {
  const [currentQuestionId, setCurrentQuestionId] = useState<string | null>('q_start');
  const [answers, setAnswers] = useState<Record<string, unknown>>({});
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'system',
      text: TRIAGE_QUESTIONS.q_start.text,
    },
  ]);
  const [textInput, setTextInput] = useState('');
  const [isDone, setIsDone] = useState(false);
  const [assessment, setAssessment] = useState<{ result: string; risk: string } | null>(null);

  const handleAnswer = (value: string | boolean) => {
    if (!currentQuestionId || isDone) return;

    const currentQ = TRIAGE_QUESTIONS[currentQuestionId];
    if (!currentQ) return;

    // Add user message
    const newMessages: ChatMessage[] = [
      ...messages,
      { id: Date.now().toString(), sender: 'user', text: String(value) },
    ];

    const updatedAnswers = { ...answers, [currentQ.key]: value };
    setAnswers(updatedAnswers);

    // Determine next question
    let nextId: string | undefined;
    if (currentQ.next) {
      if (typeof value === 'string' && currentQ.next[value]) {
        nextId = currentQ.next[value];
      } else if (typeof value === 'boolean' && currentQ.next[value ? 'yes' : 'no']) {
        nextId = currentQ.next[value ? 'yes' : 'no'];
      } else {
        nextId = currentQ.next.default;
      }
    }

    if (!nextId || currentQ.id === 'end_emergency' || nextId === 'end_predx') {
      setIsDone(true);
      setCurrentQuestionId(null);

      if (currentQ.id === 'end_emergency' || value === 'sim' || value === true) {
        newMessages.push({
          id: (Date.now() + 1).toString(),
          sender: 'system',
          text: 'EMERGÊNCIA MÉDICA DETECTADA: Sinais de alarme ativos. Procure pronto-socorro imediatamente ou ligue para o serviço de emergência (192).',
          isEmergency: true,
        });
        setAssessment({
          result: 'Sinais de alarme graves ativados no protocolo de triagem.',
          risk: 'CRÍTICO / ALTO',
        });
      } else {
        // Evaluate rule-based pre-diagnosis
        const symptom = updatedAnswers['main_symptom'];
        const severity = updatedAnswers['severity'];

        let res = 'Acompanhamento ambulatorial geral sugerido.';
        let r = 'Baixo';

        if (symptom === 'dor no peito') {
          res = 'Investigação de dor torácica atípica necessária com eletrocardiograma.';
          r = severity === 'intensa / severa' ? 'Moderado/Alto' : 'Moderado';
        } else if (symptom === 'falta de ar') {
          res = 'Avaliação funcional respiratória e saturação de oxigênio recomendadas.';
          r = 'Moderado';
        } else if (symptom === 'febre') {
          res = 'Acompanhamento de curva térmica e foco infeccioso recomendado.';
          r = 'Baixo/Moderado';
        }

        newMessages.push({
          id: (Date.now() + 1).toString(),
          sender: 'system',
          text: `Triagem Concluída.\nResultado Preliminar: ${res}\nClassificação de Risco: ${r}`,
        });
        setAssessment({ result: res, risk: r });
      }
    } else {
      setCurrentQuestionId(nextId);
      const nextQ = TRIAGE_QUESTIONS[nextId];
      if (nextQ) {
        newMessages.push({
          id: (Date.now() + 1).toString(),
          sender: 'system',
          text: nextQ.text,
        });
      }
    }

    setMessages(newMessages);
    setTextInput('');
  };

  const handleRestart = () => {
    setCurrentQuestionId('q_start');
    setAnswers({});
    setIsDone(false);
    setAssessment(null);
    setMessages([
      {
        id: Date.now().toString(),
        sender: 'system',
        text: TRIAGE_QUESTIONS.q_start.text,
      },
    ]);
  };

  const currentQ = currentQuestionId ? TRIAGE_QUESTIONS[currentQuestionId] : null;

  return (
    <div className="space-y-6">
      {/* Header Bento Card */}
      <div className="bg-[#161B22] rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
            MÓDULO DE TRIAGEM COGNITIVA MÉDICA
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">
            Assistente de Anamnese & Triagem
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Módulo interativo de protocolo clínico com mapeamento sintomático e estratificação de risco.
          </p>
        </div>

        <button
          onClick={handleRestart}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-200 text-xs font-mono font-bold hover:bg-slate-700 transition-colors cursor-pointer uppercase"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reiniciar Triagem
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Chat Window Bento Card */}
        <div className="lg:col-span-2 p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4 flex flex-col justify-between min-h-[460px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-emerald-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">Sessão Interativa de Atendimento</h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">
              PROTOCOLO ATIVO
            </span>
          </div>

          {/* Messages Stream */}
          <div className="space-y-3 overflow-y-auto max-h-[340px] pr-2 scrollbar-thin">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3.5 rounded-2xl font-mono text-xs leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-tr-none shadow-sm'
                      : m.isEmergency
                      ? 'bg-rose-950/80 border border-rose-600 text-rose-200'
                      : 'bg-[#0D1117] border border-slate-800 text-slate-200 rounded-tl-none'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
          </div>

          {/* Input Controls */}
          <div className="pt-3 border-t border-slate-800 space-y-3">
            {!isDone && currentQ && (
              <div>
                {currentQ.type === 'choice' && currentQ.choices && (
                  <div className="flex flex-wrap gap-2">
                    {currentQ.choices.map((c) => (
                      <button
                        key={c}
                        onClick={() => handleAnswer(c)}
                        className="px-3.5 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-200 font-mono text-xs font-bold hover:border-indigo-500 hover:bg-slate-700 transition-colors cursor-pointer capitalize"
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                )}

                {currentQ.type === 'yesno' && (
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleAnswer('sim')}
                      className="flex-1 py-2.5 rounded-lg border border-rose-800 bg-rose-950/60 text-rose-300 font-mono text-xs font-bold hover:bg-rose-900/60 cursor-pointer uppercase"
                    >
                      SIM
                    </button>
                    <button
                      onClick={() => handleAnswer('não')}
                      className="flex-1 py-2.5 rounded-lg border border-emerald-800 bg-emerald-950/60 text-emerald-300 font-mono text-xs font-bold hover:bg-emerald-900/60 cursor-pointer uppercase"
                    >
                      NÃO
                    </button>
                  </div>
                )}

                {currentQ.type === 'text' && (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && textInput.trim() && handleAnswer(textInput)}
                      placeholder="Digite a resposta..."
                      className="flex-1 bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-lg px-4 py-2.5 text-xs text-slate-200 font-mono outline-none"
                    />
                    <button
                      onClick={() => textInput.trim() && handleAnswer(textInput)}
                      className="px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}

            {isDone && (
              <button
                onClick={handleRestart}
                className="w-full py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase transition-colors cursor-pointer"
              >
                Iniciar Nova Triagem
              </button>
            )}

            <p className="text-[11px] text-slate-500 font-mono text-center">
              Aviso: Esta ferramenta é um protótipo educacional do Pasquared OS e não substitui consulta médica.
            </p>
          </div>
        </div>

        {/* Status Side Bento Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4 font-mono text-xs">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <ShieldAlert className="w-4 h-4 text-indigo-400" />
            <h3 className="font-bold text-white uppercase tracking-wider text-xs">Resultado da Avaliação</h3>
          </div>

          {assessment ? (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-[#0D1117] border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider">CLASSIFICAÇÃO DE RISCO:</span>
                <div
                  className={`text-sm font-bold ${
                    assessment.risk.includes('CRÍTICO') ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {assessment.risk}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0D1117] border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider">PARECER TÉCNICO:</span>
                <p className="text-slate-300 text-xs leading-relaxed">{assessment.result}</p>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <MessageSquare className="w-8 h-8 mx-auto text-slate-600" />
              <p>Responda às perguntas para gerar a classificação de risco.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
