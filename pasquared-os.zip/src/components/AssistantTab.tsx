import React, { useState, useRef, useEffect } from 'react';
import {
  Stethoscope,
  RotateCcw,
  Send,
  Radio,
  Paperclip,
  Trash2,
  FileText,
  Volume2,
  Video,
  BrainCircuit,
  Database,
  Layers,
  XCircle,
  CheckCircle2,
  Sparkles,
  Square,
  ShieldAlert,
} from 'lucide-react';
import {
  ConsultationChatMessage,
  AttachmentItem,
  DynamicDifferentialDiagnosis,
} from '../types';
import {
  HEALTH_INVESTIGATIVE_QUESTIONS,
  getMsFoundryConfig,
  getSuperAdminGlobalConfig,
} from '../lib/consultationStore';
import {
  evaluatePatientSymptomsAndPruneHypotheses,
  generateNextInvestigativeQuestion,
} from '../lib/medicalReasoningEngine';
import { queryMicrosoftFoundryAI, analyzeWalkieTalkieMedia } from '../lib/msFoundryApi';

export const AssistantTab: React.FC = () => {
  const [questionCount, setQuestionCount] = useState<number>(1);
  const [messages, setMessages] = useState<ConsultationChatMessage[]>([
    {
      id: 'init-msg',
      sender: 'ai',
      text: `Olá! Sou o Operador de IA para Triagem do Pasquared OS. Vamos realizar uma entrevista investigativa sintomática contínua.\n\nPergunta 1: ${HEALTH_INVESTIGATIVE_QUESTIONS[0]}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isQuestion: true,
    },
  ]);
  const [inputVal, setInputVal] = useState('');
  const [attachments, setAttachments] = useState<AttachmentItem[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  // Dynamic Differential Diagnosis
  const [differential, setDifferential] = useState<DynamicDifferentialDiagnosis>({
    candidateHypotheses: [
      { hypothesis: 'Quadro Algico / Inflamatório Inicial', probability: 0.45 },
      { hypothesis: 'Disfunção Funcional por Sobrecarga', probability: 0.35 },
    ],
    excludedHypotheses: [],
    investigatedPoints: ['Aguardando relato do paciente'],
    cognitiveConfidence: 0.45,
    isConclusive: false,
  });

  // Walkie Talkie state (Voice & Video)
  const [isWalkieActive, setIsWalkieActive] = useState(false);
  const [walkieMediaType, setWalkieMediaType] = useState<'audio' | 'video'>('audio');
  const [walkieSeconds, setWalkieSeconds] = useState(0);

  const walkieTimerRef = useRef<NodeJS.Timeout | null>(null);
  const walkieRecorderRef = useRef<MediaRecorder | null>(null);
  const walkieChunksRef = useRef<Blob[]>([]);
  const walkieStreamRef = useRef<MediaStream | null>(null);
  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const msConfig = getMsFoundryConfig();
  const globalAdminConfig = getSuperAdminGlobalConfig();

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isGenerating]);

  // Play Chirp sound feedback for Walkie Talkie
  const playChirp = (frequency = 880) => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.15);
    } catch (e) {
      // AudioContext fallback
    }
  };

  const handleSendResponse = async () => {
    if (!inputVal.trim() && attachments.length === 0) return;

    const userText = inputVal.trim();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const userMsg: ConsultationChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'patient',
      text: userText || '[Anexo enviado]',
      timestamp: timeStr,
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInputVal('');
    setIsGenerating(true);

    const allUserText = updatedMessages
      .filter((m) => m.sender === 'patient')
      .map((m) => m.text)
      .join(' ');

    const newDiagnosis = evaluatePatientSymptomsAndPruneHypotheses(allUserText);
    setDifferential(newDiagnosis);

    const nextCount = questionCount + 1;
    setQuestionCount(nextCount);

    const threshold = (globalAdminConfig.cognitiveThreshold || 80) / 100;
    if (newDiagnosis.cognitiveConfidence >= threshold || newDiagnosis.isConclusive) {
      setTimeout(() => {
        finishTriage(updatedMessages, newDiagnosis);
      }, 800);
      return;
    }

    // Try Microsoft AI Foundry API query if enabled
    if (msConfig.isEnabled && msConfig.apiKey) {
      const foundryRes = await queryMicrosoftFoundryAI(
        updatedMessages.map((m) => ({
          role: m.sender === 'ai' ? 'assistant' : 'user',
          content: m.text,
        })),
        `Você é o Operador de IA de Triagem Médica Pasquared OS. Elabore a Pergunta ${nextCount} de forma investigativa focando nas hipóteses: ${newDiagnosis.candidateHypotheses.map(h => h.hypothesis).join(', ')}.`
      );

      if (foundryRes.success && foundryRes.reply) {
        const aiMsg: ConsultationChatMessage = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: `Pergunta ${nextCount} (Microsoft AI Foundry):\n${foundryRes.reply}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isQuestion: true,
        };
        setMessages((prev) => [...prev, aiMsg]);
        setIsGenerating(false);
        return;
      }
    }

    // Fallback to Pasquared Medical Reasoning Engine
    setTimeout(() => {
      const nextQObj = generateNextInvestigativeQuestion(allUserText, nextCount, newDiagnosis);
      const aiMsg: ConsultationChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: `Pergunta ${nextCount} (Investigação Adaptativa [${nextQObj.sourceBase}]):\n${nextQObj.questionText}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isQuestion: true,
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsGenerating(false);
    }, 1000);
  };

  const finishTriage = (allMsgs: ConsultationChatMessage[], diag: DynamicDifferentialDiagnosis) => {
    setIsGenerating(false);
    setIsCompleted(true);

    const topHypothesis = diag.candidateHypotheses[0]?.hypothesis || 'Triagem sintomática geral concluída';
    const confidencePct = Math.round(diag.cognitiveConfidence * 100);

    const finalAiMsg: ConsultationChatMessage = {
      id: `ai-final-${Date.now()}`,
      sender: 'ai',
      text: `🎯 **CONVICÇÃO COGNITIVA MÉDICA ATINGIDA: ${confidencePct}% (>= ${globalAdminConfig.cognitiveThreshold}%)**\n\nTriagem investigativa finalizada!\n\n🩺 **Hipótese diagnóstica principal:**\n• ${topHypothesis}\n\n❌ **Hipóteses eliminadas por divergência:**\n• ${
        diag.excludedHypotheses.length > 0
          ? diag.excludedHypotheses.map((e) => e.hypothesis).join(', ')
          : 'Nenhuma hipótese descartada'
      }`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages([...allMsgs, finalAiMsg]);
  };

  // Walkie Talkie Voice & Video Recording Toggle
  const toggleWalkieTalkie = async (type: 'audio' | 'video' = 'audio') => {
    if (!isWalkieActive) {
      playChirp(880);
      setWalkieMediaType(type);
      setWalkieSeconds(0);
      try {
        const constraints: MediaStreamConstraints =
          type === 'video'
            ? { video: { width: 640, height: 480 }, audio: true }
            : { audio: true };

        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        walkieStreamRef.current = stream;
        walkieRecorderRef.current = new MediaRecorder(stream);
        walkieChunksRef.current = [];

        if (type === 'video' && videoPreviewRef.current) {
          videoPreviewRef.current.srcObject = stream;
          videoPreviewRef.current.play().catch(() => {});
        }

        walkieRecorderRef.current.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) walkieChunksRef.current.push(e.data);
        };

        walkieRecorderRef.current.onstop = async () => {
          const mimeType = type === 'video' ? 'video/webm' : 'audio/webm';
          const blob = new Blob(walkieChunksRef.current, { type: mimeType });
          const reader = new FileReader();
          reader.onloadend = async () => {
            await processWalkieMedia(reader.result as string, type);
          };
          reader.readAsDataURL(blob);

          if (walkieStreamRef.current) {
            walkieStreamRef.current.getTracks().forEach((track) => track.stop());
            walkieStreamRef.current = null;
          }
        };

        walkieRecorderRef.current.start();
        setIsWalkieActive(true);

        walkieTimerRef.current = setInterval(() => {
          setWalkieSeconds((prev) => prev + 1);
        }, 1000);
      } catch (err) {
        console.warn('Erro ao acessar mídia para Walkie-Talkie:', err);
        setIsWalkieActive(true);
        walkieTimerRef.current = setInterval(() => {
          setWalkieSeconds((prev) => prev + 1);
        }, 1000);
      }
    } else {
      playChirp(440);
      if (walkieTimerRef.current) clearInterval(walkieTimerRef.current);
      setIsWalkieActive(false);

      if (walkieRecorderRef.current && walkieRecorderRef.current.state !== 'inactive') {
        walkieRecorderRef.current.stop();
      } else {
        await processWalkieMedia('data:audio/webm;base64,dummyData', walkieMediaType);
      }
    }
  };

  const processWalkieMedia = async (mediaDataUrl: string, type: 'audio' | 'video') => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setIsGenerating(true);

    // Call Multimodal Analysis API / Pasquared Engine
    const analysis = await analyzeWalkieTalkieMedia(
      mediaDataUrl,
      type,
      `WalkieTalkie_${type}_${Date.now()}.webm`,
      `Pergunta ${questionCount}`
    );

    const isVid = type === 'video';
    const mediaMsgText = `${isVid ? '📹 [Walkie-Talkie VÍDEO Interpretado]' : '🎙️ [Walkie-Talkie ÁUDIO Interpretado]'}:\n\n💬 **Relato Transcrito:**\n"${analysis.transcription}"\n\n👁️ **Análise Físico-Vocal:**\n${analysis.visualVocalObservations}\n\n🩺 **Sintomas Detectados:**\n${analysis.extractedSymptoms.map((s) => `• ${s}`).join('\n')}`;

    const userMsg: ConsultationChatMessage = {
      id: `user-walkie-${Date.now()}`,
      sender: 'patient',
      text: mediaMsgText,
      timestamp: timeStr,
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);

    // Process symptoms and prune hypotheses
    const allUserText = updatedMessages
      .filter((m) => m.sender === 'patient')
      .map((m) => m.text)
      .join(' ');

    const newDiagnosis = evaluatePatientSymptomsAndPruneHypotheses(allUserText);
    setDifferential(newDiagnosis);

    const nextCount = questionCount + 1;
    setQuestionCount(nextCount);

    const threshold = (globalAdminConfig.cognitiveThreshold || 80) / 100;
    if (newDiagnosis.cognitiveConfidence >= threshold || newDiagnosis.isConclusive) {
      setTimeout(() => {
        finishTriage(updatedMessages, newDiagnosis);
      }, 800);
      return;
    }

    if (msConfig.isEnabled && msConfig.apiKey) {
      const foundryRes = await queryMicrosoftFoundryAI(
        updatedMessages.map((m) => ({
          role: m.sender === 'ai' ? 'assistant' : 'user',
          content: m.text,
        })),
        `Você é o Operador de IA de Triagem Médica Pasquared OS. O paciente gravou um ${isVid ? 'vídeo' : 'áudio'} de anamnese. Elabore a Pergunta ${nextCount} de forma investigativa focando nas hipóteses: ${newDiagnosis.candidateHypotheses.map(h => h.hypothesis).join(', ')}.`
      );

      if (foundryRes.success && foundryRes.reply) {
        const aiMsg: ConsultationChatMessage = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: `Pergunta ${nextCount} (Microsoft AI Foundry):\n${foundryRes.reply}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isQuestion: true,
        };
        setMessages((prev) => [...prev, aiMsg]);
        setIsGenerating(false);
        return;
      }
    }

    setTimeout(() => {
      const nextQObj = generateNextInvestigativeQuestion(allUserText, nextCount, newDiagnosis);
      const aiMsg: ConsultationChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: `Pergunta ${nextCount} (Investigação Adaptativa [${nextQObj.sourceBase}]):\n${nextQObj.questionText}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isQuestion: true,
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsGenerating(false);
    }, 800);
  };


  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = () => {
        const newAtt: AttachmentItem = {
          id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          type: 'document',
          name: file.name,
          dataUrl: reader.result as string,
          uploadedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          size: `${(file.size / 1024).toFixed(0)} KB`,
        };
        setAttachments((prev) => [...prev, newAtt]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRestart = () => {
    setQuestionCount(1);
    setIsCompleted(false);
    setIsGenerating(false);
    setAttachments([]);
    setMessages([
      {
        id: 'init-msg',
        sender: 'ai',
        text: `Olá! Sou o Operador de IA para Triagem do Pasquared OS. Vamos realizar uma entrevista investigativa sintomática contínua.\n\nPergunta 1: ${HEALTH_INVESTIGATIVE_QUESTIONS[0]}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isQuestion: true,
      },
    ]);
  };

  return (
    <div className="space-y-6">
      {/* Header Bento Card */}
      <div className="bg-[#161B22] rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
              MÓDULO DE TRIAGEM COGNITIVA MÉDICA
            </span>
            {msConfig.isEnabled && (
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-400" />
                Microsoft Foundry
              </span>
            )}
          </div>
          <h2 className="text-2xl font-bold text-white mt-1">
            Assistente de Anamnese & Triagem
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Investigação pergunta a pergunta adaptativa com deduções sintomáticas e eliminação de hipóteses incompatíveis.
          </p>
        </div>

        <button
          onClick={handleRestart}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-200 text-xs font-mono font-bold hover:bg-slate-700 transition-colors cursor-pointer uppercase"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reiniciar Triagem
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Stream Column */}
        <div className="lg:col-span-2 p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4 flex flex-col justify-between min-h-[500px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-emerald-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">
                Anamnese Investigativa Interativa
              </h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">
              Rodada {questionCount}
            </span>
          </div>

          {/* Messages Stream */}
          <div className="space-y-4 overflow-y-auto max-h-[360px] pr-2 scrollbar-thin font-mono text-xs">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'patient' ? 'items-end' : 'items-start'}`}
              >
                <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mb-1">
                  <span>{m.sender === 'ai' ? 'Operador de IA' : 'Você'}</span>
                  <span>•</span>
                  <span>{m.timestamp}</span>
                </div>
                <div
                  className={`max-w-[85%] p-4 rounded-2xl leading-relaxed whitespace-pre-wrap ${
                    m.sender === 'patient'
                      ? 'bg-indigo-600 text-white rounded-tr-none shadow-md'
                      : 'bg-[#0D1117] border border-slate-800 text-slate-200 rounded-tl-none'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}

            {isGenerating && (
              <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 p-3 bg-[#0D1117] border border-slate-800 rounded-xl w-fit">
                <Sparkles className="w-4 h-4 animate-spin text-indigo-400" />
                <span>Formulando pergunta investigativa adaptativa...</span>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Attachments Row */}
          {attachments.length > 0 && (
            <div className="p-3 bg-[#0D1117] border border-slate-800 rounded-xl space-y-2 font-mono text-xs">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">
                Anexos ({attachments.length}):
              </span>
              <div className="flex flex-wrap gap-2">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#161B22] border border-slate-800 text-slate-200"
                  >
                    {att.type === 'document' && <FileText className="w-3.5 h-3.5 text-indigo-400" />}
                    {att.type === 'audio' && <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
                    <span className="truncate max-w-[120px]">{att.name}</span>
                    <button
                      onClick={() => setAttachments((prev) => prev.filter((a) => a.id !== att.id))}
                      className="text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Walkie Talkie Recording Active Banner */}
          {isWalkieActive && (
            <div className="p-4 bg-rose-950/90 border border-rose-600 rounded-2xl space-y-3 text-rose-100 font-mono text-xs shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
                  <span className="font-bold">
                    {walkieMediaType === 'video' ? '📹 WALKIE-TALKIE VÍDEO' : '🎙️ WALKIE-TALKIE ÁUDIO'} GRAVANDO ({walkieSeconds}s)
                  </span>
                </div>
                <button
                  onClick={() => toggleWalkieTalkie(walkieMediaType)}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold uppercase cursor-pointer flex items-center gap-1.5 shadow"
                >
                  <Square className="w-3.5 h-3.5 fill-white" />
                  <span>Enviar Gravação</span>
                </button>
              </div>

              {/* Video Camera Live Preview */}
              {walkieMediaType === 'video' && (
                <div className="relative rounded-xl overflow-hidden border border-rose-500 bg-black aspect-video max-h-48 flex items-center justify-center">
                  <video
                    ref={videoPreviewRef}
                    autoPlay
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 bg-rose-950/80 px-2.5 py-1 rounded-full text-[10px] font-bold text-rose-300 border border-rose-700 uppercase flex items-center gap-1">
                    <Video className="w-3 h-3 text-rose-400" />
                    Câmera Ao Vivo
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Input Controls */}
          {!isCompleted ? (
            <div className="pt-3 border-t border-slate-800 space-y-3 font-mono">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendResponse()}
                  placeholder="Digite sua resposta..."
                  disabled={isGenerating || isWalkieActive}
                  className="flex-1 bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-xs text-slate-200 outline-none"
                />
                <button
                  onClick={handleSendResponse}
                  disabled={isGenerating || isWalkieActive || (!inputVal.trim() && attachments.length === 0)}
                  className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold text-xs uppercase cursor-pointer flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Responder
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => toggleWalkieTalkie('audio')}
                    disabled={isWalkieActive && walkieMediaType !== 'audio'}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-white font-bold text-xs uppercase transition-all cursor-pointer ${
                      isWalkieActive && walkieMediaType === 'audio'
                        ? 'bg-rose-600 hover:bg-rose-500 animate-pulse'
                        : 'bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40'
                    }`}
                  >
                    <Radio className="w-3.5 h-3.5 text-amber-300" />
                    <span>{isWalkieActive && walkieMediaType === 'audio' ? '🔴 Gravando Áudio...' : '📻 Walkie Áudio'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleWalkieTalkie('video')}
                    disabled={isWalkieActive && walkieMediaType !== 'video'}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-white font-bold text-xs uppercase transition-all cursor-pointer ${
                      isWalkieActive && walkieMediaType === 'video'
                        ? 'bg-rose-600 hover:bg-rose-500 animate-pulse'
                        : 'bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40'
                    }`}
                  >
                    <Video className="w-3.5 h-3.5 text-indigo-200" />
                    <span>{isWalkieActive && walkieMediaType === 'video' ? '🔴 Gravando Vídeo...' : '📹 Walkie Vídeo'}</span>
                  </button>

                  <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#0D1117] border border-slate-800 hover:border-indigo-500 text-slate-300 cursor-pointer">
                    <Paperclip className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Anexar Arquivo</span>
                    <input
                      type="file"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                      accept="*"
                    />
                  </label>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 font-mono text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Triagem concluída e meta de convicção cognitiva atingida!</span>
              </div>
              <button
                onClick={handleRestart}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase cursor-pointer"
              >
                Nova Triagem
              </button>
            </div>
          )}
        </div>

        {/* Live Reasoning Side Card */}
        <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <BrainCircuit className="w-4 h-4 text-indigo-400" />
              <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                Painel de Raciocínio Clínico
              </h3>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800 uppercase">
              Pasquared OS Engine
            </span>
          </div>

          <div className="p-3 bg-[#0D1117] border border-slate-800 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 font-bold">Convicção Cognitiva:</span>
              <span className={`font-bold ${differential.cognitiveConfidence >= (globalAdminConfig.cognitiveThreshold / 100) ? 'text-emerald-400' : 'text-indigo-400'}`}>
                {Math.round(differential.cognitiveConfidence * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-indigo-500 h-full transition-all duration-500"
                style={{ width: `${Math.round(differential.cognitiveConfidence * 100)}%` }}
              />
            </div>
            <div className="text-[10px] text-slate-500 pt-0.5">
              Gatilho de Término: &ge; {globalAdminConfig.cognitiveThreshold}%
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              Hipóteses em Análise ({differential.candidateHypotheses.length}):
            </span>
            <div className="space-y-2 pt-1">
              {differential.candidateHypotheses.map((cand, idx) => (
                <div key={idx} className="p-2 bg-[#161B22] border border-slate-800 rounded-lg flex justify-between items-center text-xs">
                  <span className="text-slate-200 font-semibold">{cand.hypothesis}</span>
                  <span className="text-indigo-300 font-bold">{Math.round(cand.probability * 100)}%</span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-[10px] text-rose-400 uppercase tracking-wider font-bold flex items-center gap-1.5">
              <XCircle className="w-3.5 h-3.5 text-rose-400" />
              Hipóteses Eliminadas ({differential.excludedHypotheses.length}):
            </span>
            {differential.excludedHypotheses.length > 0 ? (
              <div className="space-y-2 pt-1">
                {differential.excludedHypotheses.map((ex, idx) => (
                  <div key={idx} className="p-2 bg-rose-950/20 border border-rose-900/40 rounded-lg text-slate-300 text-[11px]">
                    <span className="font-bold text-rose-300 block">{ex.hypothesis}</span>
                    <span className="text-slate-400 text-[10px]">{ex.reason}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-[11px] text-slate-500">
                Nenhum sintoma de descarte direto detectado.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
