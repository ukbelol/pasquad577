import React, { useState } from 'react';
import { ServiceHealth } from '../types';
import { Activity, Server, Database, RefreshCw, CheckCircle2, AlertTriangle, Shield, Terminal, ArrowRight, Layers } from 'lucide-react';

interface DashboardTabProps {
  services: ServiceHealth[];
  onRefreshServices: () => void;
  onSimulateCycle: () => void;
  isSimulating: boolean;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  services,
  onRefreshServices,
  onSimulateCycle,
  isSimulating,
}) => {
  const [selectedService, setSelectedService] = useState<ServiceHealth | null>(services[0] || null);

  return (
    <div className="space-y-6">
      {/* Hero Bento Section */}
      <div className="bg-[#161B22] rounded-2xl border border-slate-800 p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
            MÓDULO DE AUTOMAÇÃO & IMPLANTAÇÃO — DEBIAN 12 + POSTGRESQL 16
          </span>
          <h1 className="text-2xl md:text-3xl font-bold text-white mt-1.5 tracking-tight">
            Estruture. Relacione. Valide.
          </h1>
          <p className="text-sm text-slate-400 mt-2 max-w-2xl leading-relaxed">
            Painel de controle central do PASQUARED OS com orquestração de microserviços TypeScript,
            processamento cognitivo UCL/PQL, e banco relacional PostgreSQL 16.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onRefreshServices}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-bold transition-colors uppercase cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-300" />
            Sincronizar Status
          </button>
          <button
            onClick={onSimulateCycle}
            disabled={isSimulating}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-mono font-bold transition-colors uppercase cursor-pointer disabled:opacity-50"
          >
            <Activity className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
            {isSimulating ? 'Executando Ciclo...' : 'Simular Ciclo Cognitivo'}
          </button>
        </div>
      </div>

      {/* Grid of Microservices Bento Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {services.map((svc) => (
          <div
            key={svc.name}
            onClick={() => setSelectedService(svc)}
            className={`p-5 rounded-2xl border transition-all cursor-pointer ${
              selectedService?.name === svc.name
                ? 'border-indigo-500 bg-[#161B22] shadow-sm ring-1 ring-indigo-500/50'
                : 'border-slate-800 bg-[#161B22] hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Server className="w-4 h-4 text-indigo-400" />
                <span className="font-mono font-bold text-sm text-white uppercase">
                  {svc.name}
                </span>
                <span className="text-xs font-mono text-slate-500">:{svc.port}</span>
              </div>
              <span
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase border ${
                  svc.status === 'online'
                    ? 'bg-[#0D1117] text-emerald-400 border-slate-800'
                    : 'bg-[#0D1117] text-amber-400 border-slate-800'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${svc.status === 'online' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                {svc.status}
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-2.5 line-clamp-1">{svc.role}</p>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-4 pt-3 border-t border-slate-800/80">
              <span>Latência: <strong className="text-slate-200">{svc.latencyMs}ms</strong></span>
              <span className="text-emerald-400 font-semibold">HTTP 200 OK</span>
            </div>
          </div>
        ))}
      </div>

      {/* Architecture & Flow Overview Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* System Flow Diagram Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">
                Fluxo de Dados Cognitivos (PCK → SMEE → MVED)
              </h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">
              PIPELINE ATIVO
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0D1117] flex items-center justify-between">
              <div>
                <span className="text-indigo-400 font-bold">1. Entrada UCL (USR Service)</span>
                <p className="text-slate-400 text-[11px] mt-0.5">Validação do esquema JSON ucl-1.0 na porta 3020</p>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 shrink-0" />
            </div>

            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0D1117] flex items-center justify-between">
              <div>
                <span className="text-indigo-400 font-bold">2. Ciclo PCK & Geração de Hipóteses</span>
                <p className="text-slate-400 text-[11px] mt-0.5">Criação de EKOs e pontuação preliminar na porta 3010</p>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 shrink-0" />
            </div>

            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0D1117] flex items-center justify-between">
              <div>
                <span className="text-emerald-400 font-bold">3. Validação MVED (Motor de Evidências)</span>
                <p className="text-slate-400 text-[11px] mt-0.5">Cálculo do Índice de Consistência (ICI) na porta 3030</p>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 shrink-0" />
            </div>

            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0D1117] flex items-center justify-between">
              <div>
                <span className="text-emerald-400 font-bold">4. Persistência SMEE em PostgreSQL 16</span>
                <p className="text-slate-400 text-[11px] mt-0.5">Gravação das tabelas ekos, insights e ucis na porta 3040</p>
              </div>
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            </div>
          </div>
        </div>

        {/* Selected Service Detail Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">
                Inspeção de Serviço: {selectedService?.name || 'GATEWAY'}
              </h3>
            </div>
            <span className="text-[10px] font-mono text-indigo-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">
              PORT: :{selectedService?.port || 3000}
            </span>
          </div>

          {selectedService && (
            <div className="space-y-3 font-mono text-xs">
              <div className="grid grid-cols-2 gap-2 text-slate-300">
                <div className="p-3 rounded-xl bg-[#0D1117] border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase tracking-wider">SERVIÇO:</span>
                  <div className="text-white font-bold mt-0.5">{selectedService.name}</div>
                </div>
                <div className="p-3 rounded-xl bg-[#0D1117] border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase tracking-wider">ENDPOINT:</span>
                  <div className="text-indigo-400 font-bold mt-0.5">http://127.0.0.1:{selectedService.port}</div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0D1117] border border-slate-800 space-y-1 text-[11px]">
                <div className="text-indigo-400 font-bold uppercase tracking-wider">// Descrição Operacional:</div>
                <p className="text-slate-300 leading-relaxed">{selectedService.role}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0D1117] border border-slate-800 font-mono text-emerald-400 text-[11px] space-y-1">
                <div>[SYSTEMD] pasq-{selectedService.name.toLowerCase()}.service: active (running)</div>
                <div>[POSTGRES] Connected to postgresql://pasq@127.0.0.1:5432/pasquared</div>
                <div>[HTTP] GET /health - 200 OK ({selectedService.latencyMs}ms)</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
