import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Save,
  CheckCircle2,
  ShieldCheck,
  Radio,
  FileCheck,
  Brain,
  Clock,
  Sparkles,
  Server,
  RefreshCw,
  Cpu,
} from 'lucide-react';
import {
  getSuperAdminGlobalConfig,
  saveSuperAdminGlobalConfig,
  getMsFoundryConfig,
  saveMsFoundryConfig,
} from '../lib/consultationStore';
import { SuperAdminGlobalConfig, MsFoundryConfig } from '../types';

export const SuperAdminSettingsCard: React.FC = () => {
  const [globalConfig, setGlobalConfig] = useState<SuperAdminGlobalConfig>(getSuperAdminGlobalConfig());
  const [msConfig, setMsConfig] = useState<MsFoundryConfig>(getMsFoundryConfig());
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    setGlobalConfig(getSuperAdminGlobalConfig());
    setMsConfig(getMsFoundryConfig());
  }, []);

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    saveSuperAdminGlobalConfig(globalConfig);
    saveMsFoundryConfig(msConfig);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  return (
    <div className="bg-[#161B22] rounded-2xl border border-amber-500/40 p-6 space-y-6 shadow-lg font-mono">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-600/20 border border-amber-500/40 rounded-xl flex items-center justify-center text-amber-400">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-white text-sm uppercase tracking-wider">
                Painel de Configurações do Super Admin
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950/80 text-amber-400 border border-amber-800/60 uppercase flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-amber-400" />
                SISTEMA RESTRITO
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Gerencie todas as diretrizes de anamnese, modo Walkie-Talkie, limite de convicção e conexões de IA.
            </p>
          </div>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 bg-emerald-950/80 px-4 py-2 rounded-xl border border-emerald-800/80 animate-pulse">
            <CheckCircle2 className="w-4 h-4" />
            Todas as Configurações Foram Salvas com Sucesso!
          </div>
        )}
      </div>

      <form onSubmit={handleSaveAll} className="space-y-6 text-xs">
        {/* Grid 1: Anamnesis & Cognitive Threshold Rules */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-300 font-bold uppercase text-[11px] flex items-center gap-1.5">
                <Brain className="w-4 h-4 text-indigo-400" />
                Meta de Convicção Cognitiva
              </span>
              <span className="text-indigo-400 font-bold text-sm">{globalConfig.cognitiveThreshold}%</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-snug">
              Gatilho que encerra a anamnese e gera o pré-diagnóstico automaticamente.
            </p>
            <input
              type="range"
              min="50"
              max="95"
              step="5"
              value={globalConfig.cognitiveThreshold}
              onChange={(e) =>
                setGlobalConfig({ ...globalConfig, cognitiveThreshold: Number(e.target.value) })
              }
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-slate-500 font-semibold">
              <span>50% (Rápido)</span>
              <span className="text-emerald-400 font-bold">80% (Padrão)</span>
              <span>95% (Rigoroso)</span>
            </div>
          </div>

          <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-300 font-bold uppercase text-[11px] flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-emerald-400" />
                Sistema Walkie-Talkie
              </span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={globalConfig.walkieTalkieEnabled}
                  onChange={(e) =>
                    setGlobalConfig({ ...globalConfig, walkieTalkieEnabled: e.target.checked })
                  }
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>
            <p className="text-[10px] text-slate-400 leading-snug">
              Modo Pressione 1x para Falar e 1x para Enviar áudio/vídeo no chat da consulta.
            </p>
            <span className="inline-block text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60 font-semibold">
              {globalConfig.walkieTalkieEnabled ? '✓ Ativo no Formulário' : '✕ Desativado'}
            </span>
          </div>

          <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-300 font-bold uppercase text-[11px] flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-400" />
                Sincronização de Bases
              </span>
              <span className="text-amber-400 font-bold text-sm">
                A cada {globalConfig.autoSyncIntervalHours}h
              </span>
            </div>
            <p className="text-[10px] text-slate-400 leading-snug">
              Ciclo automático de atualização de artigos do SciELO, PubMed, LILACS e OPAS.
            </p>
            <select
              value={globalConfig.autoSyncIntervalHours}
              onChange={(e) =>
                setGlobalConfig({ ...globalConfig, autoSyncIntervalHours: Number(e.target.value) })
              }
              className="w-full bg-[#161B22] border border-slate-800 text-slate-200 rounded-lg px-2 py-1.5 outline-none text-xs"
            >
              <option value={6}>A cada 6 horas</option>
              <option value={12}>A cada 12 horas (Recomendado)</option>
              <option value={24}>A cada 24 horas</option>
            </select>
          </div>
        </div>

        {/* Grid 2: File Attachments & AI Pruning Toggles */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-xl flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-indigo-400" />
                <span className="text-slate-200 font-bold text-xs uppercase">
                  Aceitar Qualquer Tipo de Documento no Anexo
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                Permite upload de exames PDF, imagens JPG/PNG, laudos DOCX, planilhas CSV, laudos DICOM e compactados ZIP.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={globalConfig.allowAnyFileType}
                onChange={(e) =>
                  setGlobalConfig({ ...globalConfig, allowAnyFileType: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>

          <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-xl flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-emerald-400" />
                <span className="text-slate-200 font-bold text-xs uppercase">
                  Descarte Lógico de Hipóteses Incompatíveis
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                A IA descarta ativamente doenças cujos sintomas principais foram negados pelo paciente.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={globalConfig.aiAutoPruningEnabled}
                onChange={(e) =>
                  setGlobalConfig({ ...globalConfig, aiAutoPruningEnabled: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>
        </div>

        {/* Section 3: Microsoft Foundry Integration Keys */}
        <div className="p-4 bg-[#0D1117] border border-indigo-900/50 rounded-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2 text-indigo-300 font-bold uppercase text-xs">
              <Cpu className="w-4 h-4 text-indigo-400" />
              <span>Chaves de Conexão: Microsoft Foundry / Azure OpenAI</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-400">Ativar Foundry:</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={msConfig.isEnabled}
                  onChange={(e) => setMsConfig({ ...msConfig, isEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-400 font-bold mb-1 text-[10px] uppercase">
                Chave de API (Microsoft Foundry)
              </label>
              <input
                type="password"
                value={msConfig.apiKey}
                onChange={(e) => setMsConfig({ ...msConfig, apiKey: e.target.value })}
                placeholder="ms_foundry_sk_..."
                className="w-full bg-[#161B22] border border-slate-800 focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-bold mb-1 text-[10px] uppercase">
                Endpoint Azure / Foundry URL
              </label>
              <input
                type="text"
                value={msConfig.endpoint}
                onChange={(e) => setMsConfig({ ...msConfig, endpoint: e.target.value })}
                placeholder="https://instancia.openai.azure.com/"
                className="w-full bg-[#161B22] border border-slate-800 focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-bold mb-1 text-[10px] uppercase">
                Deployment / Nome do Modelo
              </label>
              <input
                type="text"
                value={msConfig.deploymentName}
                onChange={(e) => setMsConfig({ ...msConfig, deploymentName: e.target.value })}
                placeholder="gpt-4o-health-v1"
                className="w-full bg-[#161B22] border border-slate-800 focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Action Button & Status Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <div className="text-[10px] text-slate-500">
            <span>Último Salvamento: {globalConfig.lastSavedAt || 'Não registrado'}</span>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-lg"
          >
            <Save className="w-4 h-4" />
            Salvar Todas as Configurações do Super Admin
          </button>
        </div>
      </form>
    </div>
  );
};
