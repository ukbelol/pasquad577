import React, { useState, useEffect } from 'react';
import { Key, Server, Cpu, CheckCircle2, Save, Sparkles, ShieldCheck } from 'lucide-react';
import { getMsFoundryConfig, saveMsFoundryConfig } from '../lib/consultationStore';
import { MsFoundryConfig } from '../types';

export const MsFoundrySettingsCard: React.FC = () => {
  const [config, setConfig] = useState<MsFoundryConfig>(getMsFoundryConfig());
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    setConfig(getMsFoundryConfig());
  }, []);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveMsFoundryConfig(config);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="bg-[#161B22] rounded-2xl border border-indigo-500/30 p-6 space-y-4 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600/20 border border-indigo-500/40 rounded-xl flex items-center justify-center text-indigo-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-mono font-bold text-white text-sm uppercase tracking-wider">
                Configuração de IA: Microsoft Foundry / Entra ID
              </h3>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-950/80 text-indigo-400 border border-indigo-800/60 uppercase">
                ADMIN EXCLUSIVE
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Insira a Chave de API e Endpoint do modelo da Microsoft para acionar o chat do Auxiliar de Consulta.
            </p>
          </div>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-3 py-1.5 rounded-lg border border-emerald-800/60">
            <CheckCircle2 className="w-4 h-4" />
            Configuração Salva!
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-4 font-mono text-xs">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider text-[11px]">
              Chave de API (Microsoft Foundry Key)
            </label>
            <div className="relative">
              <Key className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="password"
                value={config.apiKey}
                onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                placeholder="ex: ms_foundry_sk_8291a0f9..."
                className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-lg pl-9 pr-3 py-2.5 text-xs text-slate-200 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider text-[11px]">
              Endpoint da API (Microsoft Azure / Foundry URL)
            </label>
            <div className="relative">
              <Server className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="text"
                value={config.endpoint}
                onChange={(e) => setConfig({ ...config, endpoint: e.target.value })}
                placeholder="https://sua-instancia.openai.azure.com/"
                className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-lg pl-9 pr-3 py-2.5 text-xs text-slate-200 outline-none"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider text-[11px]">
              Nome do Deployment / Modelo
            </label>
            <input
              type="text"
              value={config.deploymentName}
              onChange={(e) => setConfig({ ...config, deploymentName: e.target.value })}
              placeholder="gpt-4o-health-v1"
              className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-lg px-3 py-2.5 text-xs text-slate-200 outline-none"
            />
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-[#0D1117] border border-slate-800 self-end">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span className="text-slate-200 font-bold">Ativar Motor Microsoft Foundry</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={config.isEnabled}
                onChange={(e) => setConfig({ ...config, isEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md"
          >
            <Save className="w-4 h-4" />
            Salvar Parâmetros da IA
          </button>
        </div>
      </form>
    </div>
  );
};
