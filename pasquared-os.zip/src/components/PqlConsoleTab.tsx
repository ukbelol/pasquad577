import React, { useState } from 'react';
import { PQLCommand } from '../types';
import { Play, Code2, Terminal, Copy, Check, Info, Sparkles } from 'lucide-react';

export const PqlConsoleTab: React.FC = () => {
  const [script, setScript] = useState<string>(
    `OBSERVE "estrutura de informação e redes de evidência"
CONTEXT dominio=Medicina prioridade=0.85 autor=pasquared
GENERATE HYPOTHESES USING OBSERVATION TOP 3
VALIDATE H-1 POLICY=clinica-n3
SELECT MEANING CRITERIA=confidence THRESHOLD 0.78`
  );

  const [commands, setCommands] = useState<PQLCommand[]>([]);
  const [copied, setCopied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleParse = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const lines = script.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
      const parsed: PQLCommand[] = [];

      for (const line of lines) {
        if (/^OBSERVE\b/i.test(line)) {
          parsed.push({
            op: 'OBSERVE',
            value: line.replace(/^OBSERVE\s+/i, '').replace(/^["']|["']$/g, ''),
          });
        } else if (/^ASSOCIATE\b/i.test(line)) {
          const m = line.match(/^ASSOCIATE\s+(\S+)\s+(\S+)(?:\s+TYPE\s+(\S+))?(?:\s+WEIGHT\s+([\d.]+))?/i);
          if (m)
            parsed.push({
              op: 'ASSOCIATE',
              from: m[1],
              to: m[2],
              rtype: m[3],
              weight: m[4] ? Number(m[4]) : undefined,
            });
        } else if (/^CONTEXT\b/i.test(line)) {
          const kv: Record<string, string | number> = {};
          line
            .replace(/^CONTEXT\s+/i, '')
            .split(/[,\s]+/)
            .filter(Boolean)
            .forEach((p) => {
              const [k, raw] = p.split('=');
              if (k && raw) kv[k] = /^-?\d+(\.\d+)?$/.test(raw) ? Number(raw) : raw;
            });
          parsed.push({ op: 'CONTEXT', kv });
        } else if (/^GENERATE\b/i.test(line)) {
          const top = line.match(/\bTOP\s+(\d+)/i);
          const using = line.match(/\bUSING\s+(\S+)/i);
          parsed.push({
            op: 'GENERATE',
            what: 'HYPOTHESES',
            using: using?.[1],
            top: top ? Number(top[1]) : undefined,
          });
        } else if (/^VALIDATE\b/i.test(line)) {
          const policy = line.match(/\bPOLICY\s+(\S+)/i);
          const target = line.replace(/^VALIDATE\s+/i, '').split(/\s+/)[0] || '';
          parsed.push({ op: 'VALIDATE', target, policy: policy?.[1] });
        } else if (/^LEARN\b/i.test(line)) {
          parsed.push({ op: 'LEARN', target: line.replace(/^LEARN\s+/i, '').trim() || 'RESULT' });
        } else if (/^SELECT\b/i.test(line)) {
          const criteria = line.match(/\bCRITERIA\s+(\S+)/i);
          const threshold = line.match(/\bTHRESHOLD\s+([\d.]+)/i);
          parsed.push({
            op: 'SELECT',
            what: 'MEANING',
            criteria: criteria?.[1],
            threshold: threshold ? Number(threshold[1]) : undefined,
          });
        }
      }

      setCommands(parsed);
      setIsProcessing(false);
    }, 200);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify({ commands }, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const presetScripts = [
    {
      label: 'Análise de Risco Médico',
      code: `OBSERVE "sintomas de dor torácica aguda e histórico de hipertensão"
CONTEXT dominio=Cardiologia prioridade=1.0 emergência=true
GENERATE HYPOTHESES USING OBSERVATION TOP 3
VALIDATE H-01 POLICY=emergencia-cardiovascular
SELECT MEANING CRITERIA=confidence THRESHOLD 0.85`,
    },
    {
      label: 'Relacionamento de Conceitos',
      code: `OBSERVE "anticoagulantes e fibrilação atrial"
ASSOCIATE "anticoagulação" "prevenção-avc" TYPE causal WEIGHT 0.92
CONTEXT ambiente=ambulatorial
GENERATE HYPOTHESES TOP 2
LEARN RESULT`,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Bento Card */}
      <div className="bg-[#161B22] rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
            PASQUARED QUERY LANGUAGE (PQL PARSER)
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">Console PQL</h2>
          <p className="text-xs text-slate-400 mt-1">
            Linguagem de consulta declarativa para extração de significado, observações e geração de hipóteses.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {presetScripts.map((preset) => (
            <button
              key={preset.label}
              onClick={() => {
                setScript(preset.code);
                setCommands([]);
              }}
              className="text-xs font-mono font-bold px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-200 hover:border-indigo-500 hover:bg-slate-700 transition-colors cursor-pointer"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Editor Bento Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-indigo-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">Editor PQL</h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-indigo-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">SINTAXE PQL-v1</span>
          </div>

          <textarea
            value={script}
            onChange={(e) => setScript(e.target.value)}
            spellCheck={false}
            rows={10}
            className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl p-4 text-slate-200 font-mono text-xs leading-relaxed outline-none resize-y"
          />

          <button
            onClick={handleParse}
            disabled={isProcessing}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase transition-colors cursor-pointer"
          >
            <Play className={`w-4 h-4 ${isProcessing ? 'animate-spin' : ''}`} />
            {isProcessing ? 'Analisando Gramática PQL...' : 'Executar Análise PQL'}
          </button>
        </div>

        {/* Output Bento Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">Árvore do Parser AST (JSON)</h3>
            </div>

            {commands.length > 0 && (
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 text-xs font-mono font-bold text-indigo-400 hover:text-indigo-300 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copiado!' : 'Copiar AST'}
              </button>
            )}
          </div>

          <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4 min-h-[260px] font-mono text-xs text-emerald-400 overflow-auto">
            {commands.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 py-12 space-y-2">
                <Info className="w-6 h-6 text-slate-600" />
                <p>Aguardando execução. Clique em "Executar Análise PQL".</p>
              </div>
            ) : (
              <pre className="whitespace-pre-wrap">{JSON.stringify({ commands }, null, 2)}</pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
