import React, { useState } from 'react';
import { User, Calendar, CreditCard, ArrowRight, ArrowLeft, ShieldCheck, Stethoscope } from 'lucide-react';
import { PatientData } from '../types';

interface PatientFormViewProps {
  onStartConsultation: (patient: PatientData) => void;
  onBackToLanding: () => void;
}

export const PatientFormView: React.FC<PatientFormViewProps> = ({
  onStartConsultation,
  onBackToLanding,
}) => {
  const [nome, setNome] = useState('');
  const [sobrenome, setSobrenome] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [cpf, setCpf] = useState('');
  const [error, setError] = useState('');

  // Helper for masking CPF (000.000.000-00)
  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);

    if (value.length > 9) {
      value = value.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');
    } else if (value.length > 6) {
      value = value.replace(/^(\d{3})(\d{3})(\d{1,3})$/, '$1.$2.$3');
    } else if (value.length > 3) {
      value = value.replace(/^(\d{3})(\d{1,3})$/, '$1.$2');
    }

    setCpf(value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!nome.trim() || !sobrenome.trim() || !dataNascimento.trim() || !cpf.trim()) {
      setError('Por favor, preencha todos os campos obrigatórios para iniciar o atendimento.');
      return;
    }

    const cleanCpfDigits = cpf.replace(/\D/g, '');
    if (cleanCpfDigits.length < 11) {
      setError('O CPF informado deve conter os 11 dígitos.');
      return;
    }

    onStartConsultation({
      nome: nome.trim(),
      sobrenome: sobrenome.trim(),
      dataNascimento: dataNascimento.trim(),
      cpf: cpf.trim(),
    });
  };

  return (
    <div className="max-w-2xl mx-auto py-6 space-y-6">
      <button
        onClick={onBackToLanding}
        className="flex items-center gap-2 text-xs font-mono font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        Voltar à Página Inicial
      </button>

      {/* Main Bento Card */}
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="w-12 h-12 bg-indigo-600/20 border border-indigo-500/40 rounded-xl flex items-center justify-center text-indigo-400">
            <Stethoscope className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
              CADASTRO INICIAL PA / PACIENTE
            </span>
            <h2 className="text-2xl font-bold text-white mt-0.5">Identificação para Triagem</h2>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Preencha seus dados abaixo. Essas informações servirão para vincular de forma persistente a sua consulta e permitir que seu médico acesse seu histórico futuramente.
        </p>

        {error && (
          <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 font-mono text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                Nome *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Ex: Maria"
                  className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                Sobrenome *
              </label>
              <input
                type="text"
                required
                value={sobrenome}
                onChange={(e) => setSobrenome(e.target.value)}
                placeholder="Ex: das Dores Santos"
                className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-colors"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                Data de Nascimento *
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="date"
                  required
                  value={dataNascimento}
                  onChange={(e) => setDataNascimento(e.target.value)}
                  className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                CPF *
              </label>
              <div className="relative">
                <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  required
                  value={cpf}
                  onChange={handleCpfChange}
                  placeholder="000.000.000-00"
                  maxLength={14}
                  className="w-full bg-[#0D1117] border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-colors"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:shadow-indigo-500/20"
            >
              <ShieldCheck className="w-4 h-4" />
              Salvar e Ir para Consulta
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        <p className="text-[11px] font-mono text-slate-500 text-center">
          Seus dados são armazenados localmente de forma persistente com criptografia e isolamento por CPF.
        </p>
      </div>
    </div>
  );
};
