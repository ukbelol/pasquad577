import React from 'react';
import {
  Stethoscope,
  User,
  UserCheck,
  ShieldAlert,
  ArrowRight,
  Activity,
  FileText,
  Video,
  Mic,
  Lock,
  Cpu,
  CheckCircle2,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { AppViewMode } from '../types';

interface LandingViewProps {
  onSelectRole: (mode: AppViewMode) => void;
  onOpenAdminLogin: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onSelectRole,
  onOpenAdminLogin,
}) => {
  return (
    <div className="space-y-12 py-4">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-[#161B22] border border-slate-800 rounded-3xl p-8 md:p-12 shadow-2xl">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-950/80 border border-indigo-800/60 text-indigo-400 text-xs font-mono font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            OPERADOR DE IA PARA ANAMNESE E TRIAGEM CLÍNICA
          </div>

          <h1 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
            Auxiliar de Consulta em Saúde Inteligente
          </h1>

          <p className="text-slate-300 text-sm md:text-base leading-relaxed">
            Sistema cognitivo para investigação detalhada de queixas de saúde. Realiza perguntas investigativas pontuais (uma por vez), aceita anexos de documentos e gravações de áudio/vídeo, e gera uma pré-avaliação clínica completa com persistência segura para análise médica.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={() => onSelectRole('patient_form')}
              className="flex items-center gap-3 px-6 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-lg hover:shadow-indigo-500/25"
            >
              <User className="w-4 h-4" />
              Sou Paciente (Iniciar Consulta)
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onSelectRole('doctor_portal')}
              className="flex items-center gap-3 px-6 py-3.5 rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-mono font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-emerald-400" />
              Sou Doutor (Buscar por CPF)
            </button>
          </div>
        </div>
      </div>

      {/* Role Selection Bento Cards Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
            MÓDULOS E NÍVEIS DE ACESSO
          </span>
          <span className="text-xs font-mono text-slate-500">Selecione seu perfil de entrada</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Paciente PA */}
          <div className="bg-[#161B22] border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-6 space-y-4 transition-all group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <User className="w-6 h-6" />
              </div>
              <span className="inline-block text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-950 text-indigo-400 border border-indigo-800/60 uppercase">
                PORTAL PA / PACIENTE
              </span>
              <h3 className="text-xl font-bold text-white">Iniciar Nova Consulta</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Cadastre seus dados (Nome, Sobrenome, Data de Nascimento e CPF) para ser atendido pelo operador de IA. Responda às perguntas investigativas uma a uma.
              </p>

              <ul className="space-y-2 font-mono text-xs text-slate-300 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Anamnese guiada por IA</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Envio de documentos e exames</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Gravação de áudio e vídeo</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => onSelectRole('patient_form')}
              className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              Ir para Cadastro do Paciente
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Card 2: Doutor DR */}
          <div className="bg-[#161B22] border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-6 space-y-4 transition-all group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <UserCheck className="w-6 h-6" />
              </div>
              <span className="inline-block text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/60 uppercase">
                PORTAL DR / DOUTOR
              </span>
              <h3 className="text-xl font-bold text-white">Consultar Atendimentos</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Área médica para busca e recuperação de pré-avaliações salvas. Informe o CPF e Data de Nascimento do paciente para reproduzir mídias e dar parecer.
              </p>

              <ul className="space-y-2 font-mono text-xs text-slate-300 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Busca por CPF e Nasc.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Player de Áudio & Vídeo</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Emissão de Parecer Médico</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => onSelectRole('doctor_portal')}
              className="w-full py-3 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              Acessar Módulo Médico
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Card 3: Super Admin */}
          <div className="bg-[#161B22] border border-slate-800 hover:border-amber-500/50 rounded-2xl p-6 space-y-4 transition-all group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-600/20 border border-amber-500/40 flex items-center justify-center text-amber-400 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                <Lock className="w-6 h-6" />
              </div>
              <span className="inline-block text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-950 text-amber-400 border border-amber-800/60 uppercase">
                ÁREA RESTRITA SUPER ADMIN
              </span>
              <h3 className="text-xl font-bold text-white">Dashboard Pasquared OS</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Acesso exclusivo para administradores configurarem credenciais do Microsoft Foundry / Entra ID, inspecionarem microsserviços, PQL e catálogo EKO.
              </p>

              <ul className="space-y-2 font-mono text-xs text-slate-300 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Configuração de Chave MS Foundry</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Console PQL & Validador UCL</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Gerenciamento de Microsserviços</span>
                </li>
              </ul>
            </div>

            <button
              onClick={onOpenAdminLogin}
              className="w-full py-3 rounded-xl border border-amber-800/60 bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 font-mono font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              Autenticar Super Admin
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Feature Highlights Grid */}
      <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <Activity className="w-5 h-5 text-indigo-400" />
          <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">
            Fluxo da Consulta & Inteligência Clínica
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-indigo-400 font-bold text-sm">01. Cadastro PA</span>
            <p className="text-slate-400 leading-relaxed">
              O paciente fornece Nome, Sobrenome, Data de Nascimento e CPF para criar a sessão persistente.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-indigo-400 font-bold text-sm">02. Perguntas Investigativas</span>
            <p className="text-slate-400 leading-relaxed">
              A IA formula uma pergunta por vez para aprofundar os detalhes da queixa principal.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-indigo-400 font-bold text-sm">03. Anexos & Mídias</span>
            <p className="text-slate-400 leading-relaxed">
              Upload de laudos/exames e gravação de áudio ou vídeo explicativo pelo próprio paciente.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
            <span className="text-indigo-400 font-bold text-sm">04. Parecer DR</span>
            <p className="text-slate-400 leading-relaxed">
              O médico pesquisa pelo CPF + Nasc., assiste às mídias, analisa os laudos e conclui o parecer.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
