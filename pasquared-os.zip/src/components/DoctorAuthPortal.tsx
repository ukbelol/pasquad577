import React, { useState, useEffect } from 'react';
import {
  UserCheck,
  Calendar,
  CreditCard,
  Mail,
  Phone,
  MapPin,
  Lock,
  Search,
  CheckCircle2,
  XCircle,
  Plus,
  Trash2,
  Save,
  FileText,
  Clock,
  ArrowLeft,
  LogOut,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Download,
  Play,
  FileSpreadsheet,
  Stethoscope,
  Filter,
  KeyRound,
  HelpCircle,
  ShieldQuestion,
} from 'lucide-react';
import { UserProfile, ConsultationRecord, DoctorReviewDecision } from '../types';
import {
  authenticateUser,
  saveUser,
  getActiveSession,
  setActiveSession,
  fetchAddressByCep,
  verifySecurityAnswers,
} from '../lib/userStore';
import { getStoredConsultations, saveConsultation } from '../lib/consultationStore';

interface DoctorAuthPortalProps {
  onBackToLanding: () => void;
}

export const DoctorAuthPortal: React.FC<DoctorAuthPortalProps> = ({ onBackToLanding }) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'recovery'>('login');
  const [loggedDoctor, setLoggedDoctor] = useState<UserProfile | null>(null);

  // Sub-view in Logged Portal
  const [activeNav, setActiveNav] = useState<'atendimento' | 'historico_dr' | 'conta_dr'>('atendimento');
  const [showDrHistory, setShowDrHistory] = useState(false);

  // Login Form states
  const [loginCpf, setLoginCpf] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginSuccess, setLoginSuccess] = useState('');

  // Register Form states (Cadastro DR)
  const [nome, setNome] = useState('');
  const [sobrenome, setSobrenome] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [cpf, setCpf] = useState('');
  const [crm, setCrm] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [cep, setCep] = useState('');
  const [rua, setRua] = useState('');
  const [numero, setNumero] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [uf, setUf] = useState('');
  const [senha, setSenha] = useState('');
  const [nomeMae, setNomeMae] = useState('');
  const [nomePai, setNomePai] = useState('');

  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [cepMessage, setCepMessage] = useState('');
  const [regError, setRegError] = useState('');

  // Form states for Password Recovery (Recuperação de Senha DR)
  const [recoveryStep, setRecoveryStep] = useState<'questions' | 'new_password'>('questions');
  const [recoveryCpf, setRecoveryCpf] = useState('');
  const [recoveryMae, setRecoveryMae] = useState('');
  const [recoveryPai, setRecoveryPai] = useState('');
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryError, setRecoveryError] = useState('');
  const [recoveryUser, setRecoveryUser] = useState<UserProfile | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Account Edit Form states for Doctor
  const [editEmail, setEditEmail] = useState('');
  const [editTelefone, setEditTelefone] = useState('');
  const [editTelefonesAdicionais, setEditTelefonesAdicionais] = useState<string[]>([]);
  const [newExtraPhone, setNewExtraPhone] = useState('');
  const [editCep, setEditCep] = useState('');
  const [editRua, setEditRua] = useState('');
  const [editNumero, setEditNumero] = useState('');
  const [editBairro, setEditBairro] = useState('');
  const [editCidade, setEditCidade] = useState('');
  const [editUf, setEditUf] = useState('');
  const [saveSuccess, setSaveSuccess] = useState('');

  // Consultation Search States (DR)
  const [searchPatientCpf, setSearchPatientCpf] = useState('123.456.789-00'); // Default demo
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [searchedConsultations, setSearchedConsultations] = useState<ConsultationRecord[]>([]);
  const [activeConsultation, setActiveConsultation] = useState<ConsultationRecord | null>(null);
  const [doctorParecer, setDoctorParecer] = useState('');
  const [reviewNotice, setReviewNotice] = useState('');

  // Auto load active session on mount
  useEffect(() => {
    const session = getActiveSession();
    if (session && session.role === 'doctor') {
      setLoggedDoctor(session);
      initAccountForm(session);
      // Execute initial demo search
      handleSearchPatientRecords(session, '123.456.789-00', '', '');
    }
  }, []);

  const initAccountForm = (user: UserProfile) => {
    setEditEmail(user.email);
    setEditTelefone(user.telefone);
    setEditTelefonesAdicionais(user.telefonesAdicionais || []);
    setEditCep(user.cep);
    setEditRua(user.rua);
    setEditNumero(user.numero);
    setEditBairro(user.bairro);
    setEditCidade(user.cidade);
    setEditUf(user.uf);
  };

  // Mask helper for CPF
  const handleCpfFormatting = (value: string, setter: (val: string) => void) => {
    let clean = value.replace(/\D/g, '');
    if (clean.length > 11) clean = clean.slice(0, 11);

    if (clean.length > 9) {
      clean = clean.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');
    } else if (clean.length > 6) {
      clean = clean.replace(/^(\d{3})(\d{3})(\d{1,3})$/, '$1.$2.$3');
    } else if (clean.length > 3) {
      clean = clean.replace(/^(\d{3})(\d{1,3})$/, '$1.$2');
    }
    setter(clean);
  };

  // CEP Lookup via API
  const handleSearchCep = async (cepInput: string, isEdit = false) => {
    const clean = cepInput.replace(/\D/g, '');
    if (clean.length !== 8) {
      setCepMessage('Digite um CEP com 8 dígitos para consultar.');
      return;
    }
    setIsSearchingCep(true);
    setCepMessage('');

    const res = await fetchAddressByCep(clean);
    setIsSearchingCep(false);

    if (res.success) {
      if (!isEdit) {
        setRua(res.rua);
        setBairro(res.bairro);
        setCidade(res.cidade);
        setUf(res.uf);
      } else {
        setEditRua(res.rua);
        setEditBairro(res.bairro);
        setEditCidade(res.cidade);
        setEditUf(res.uf);
      }
      setCepMessage('✅ Endereço preenchido automaticamente pela API.');
    } else {
      setCepMessage(res.error || 'CEP não encontrado. Preencha manualmente.');
    }
  };

  // Doctor Registration Submit
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (
      !nome.trim() ||
      !sobrenome.trim() ||
      !dataNascimento.trim() ||
      !cpf.trim() ||
      !email.trim() ||
      !telefone.trim() ||
      !cep.trim() ||
      !numero.trim() ||
      !senha.trim() ||
      !nomeMae.trim() ||
      !nomePai.trim()
    ) {
      setRegError('Por favor, preencha todos os campos obrigatórios do cadastro do Doutor, incluindo as perguntas de segurança.');
      return;
    }

    if (cpf.replace(/\D/g, '').length < 11) {
      setRegError('CPF inválido. Deve possuir 11 dígitos.');
      return;
    }

    const newDoctor: UserProfile = {
      id: `usr_doc_${Date.now()}`,
      role: 'doctor',
      nome: nome.trim(),
      sobrenome: sobrenome.trim(),
      dataNascimento: dataNascimento.trim(),
      cpf: cpf.trim(),
      crm: crm.trim() || 'CRM/SP Em Análise',
      email: email.trim(),
      telefone: telefone.trim(),
      telefonesAdicionais: [],
      cep: cep.trim(),
      rua: rua.trim() || 'Logradouro',
      numero: numero.trim(),
      bairro: bairro.trim() || 'Bairro',
      cidade: cidade.trim() || 'Cidade',
      uf: uf.trim() || 'UF',
      senha: senha.trim(),
      nomeMae: nomeMae.trim(),
      nomePai: nomePai.trim(),
      createdAt: new Date().toISOString().slice(0, 16),
      updatedAt: new Date().toISOString().slice(0, 16),
    };

    saveUser(newDoctor);

    // Redirect to Doctor Login form with success notification
    setLoginSuccess(`Cadastro de Doutor(a) ${nome} efetuado com sucesso! Faça seu login com CPF e senha.`);
    setLoginCpf(cpf.trim());
    setActiveTab('login');
  };

  // Handle Security Questions Verification Submit for Doctor
  const handleVerifySecurityQuestions = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    const res = verifySecurityAnswers(
      recoveryCpf,
      'doctor',
      recoveryMae,
      recoveryPai,
      recoveryEmail
    );

    if (res.success && res.user) {
      setRecoveryUser(res.user);
      setRecoveryStep('new_password');
    } else {
      setRecoveryError(res.error || 'Respostas incorretas. Verifique as informações do médico.');
    }
  };

  // Handle Save New Password Submit for Doctor
  const handleSaveNewPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    if (!newPassword.trim()) {
      setRecoveryError('Por favor, informe a nova senha.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setRecoveryError('A confirmação de senha não confere com a nova senha digitada.');
      return;
    }

    if (!recoveryUser) {
      setRecoveryError('Erro ao recuperar usuário do médico. Tente novamente.');
      return;
    }

    const updatedUser: UserProfile = {
      ...recoveryUser,
      senha: newPassword.trim(),
      updatedAt: new Date().toISOString().slice(0, 16),
    };

    saveUser(updatedUser);

    // Redirecionamento para a tela de login
    setLoginSuccess(`Senha do(a) Dr(a). ${recoveryUser.nome} redefinida com sucesso! Informe seu CPF e sua nova senha para entrar.`);
    setLoginCpf(recoveryUser.cpf);
    setLoginPassword('');
    setActiveTab('login');
    // Reset recovery state
    setRecoveryStep('questions');
    setRecoveryCpf('');
    setRecoveryMae('');
    setRecoveryPai('');
    setRecoveryEmail('');
    setNewPassword('');
    setConfirmPassword('');
    setRecoveryUser(null);
  };

  // Doctor Login Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginSuccess('');

    const res = authenticateUser(loginCpf, loginPassword, 'doctor');
    if (res.success && res.user) {
      setLoggedDoctor(res.user);
      initAccountForm(res.user);
      handleSearchPatientRecords(res.user, searchPatientCpf, startDate, endDate);
    } else {
      setLoginError(res.error || 'Falha na autenticação do médico.');
    }
  };

  // Logout Doctor
  const handleLogout = () => {
    setActiveSession(null);
    setLoggedDoctor(null);
    setLoginPassword('');
    setLoginSuccess('');
    setLoginError('');
  };

  // Save Doctor Account edits
  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loggedDoctor) return;

    const updatedDoctor: UserProfile = {
      ...loggedDoctor,
      email: editEmail.trim(),
      telefone: editTelefone.trim(),
      telefonesAdicionais: editTelefonesAdicionais,
      cep: editCep.trim(),
      rua: editRua.trim(),
      numero: editNumero.trim(),
      bairro: editBairro.trim(),
      cidade: editCidade.trim(),
      uf: editUf.trim(),
      updatedAt: new Date().toISOString().slice(0, 16),
    };

    saveUser(updatedDoctor);
    setActiveSession(updatedDoctor);
    setLoggedDoctor(updatedDoctor);
    setSaveSuccess('✅ Todos os dados cadastrais do Doutor foram salvos com sucesso!');
    setTimeout(() => setSaveSuccess(''), 4000);
  };

  const handleAddExtraPhone = () => {
    if (!newExtraPhone.trim()) return;
    setEditTelefonesAdicionais((prev) => [...prev, newExtraPhone.trim()]);
    setNewExtraPhone('');
  };

  const handleRemoveExtraPhone = (index: number) => {
    setEditTelefonesAdicionais((prev) => prev.filter((_, i) => i !== index));
  };

  // Search Patient Consultations by CPF & Date Range
  const handleSearchPatientRecords = (
    doc: UserProfile | null,
    targetCpf: string,
    sDate: string,
    eDate: string
  ) => {
    const all = getStoredConsultations();
    const cleanTargetCpf = targetCpf.replace(/\D/g, '');

    const filtered = all.filter((c) => {
      const cCpf = (c.patientCpf || c.patient.cpf).replace(/\D/g, '');
      const matchesCpf = cleanTargetCpf ? cCpf.includes(cleanTargetCpf) : true;

      // Date Range Filtering
      let matchesDate = true;
      if (sDate) {
        matchesDate = matchesDate && c.createdAt >= sDate;
      }
      if (eDate) {
        matchesDate = matchesDate && c.createdAt <= `${eDate} 23:59`;
      }
      return matchesCpf && matchesDate;
    });

    setSearchedConsultations(filtered);
    if (filtered.length > 0) {
      setActiveConsultation(filtered[0]);
    } else {
      setActiveConsultation(null);
    }
  };

  // Doctor Decision Handler: Aprovar ou Desaprovar com Parecer
  const handleFinalizeDoctorReview = (decisionStatus: 'aprovado' | 'desaprovado') => {
    if (!activeConsultation || !loggedDoctor) return;

    if (!doctorParecer.trim()) {
      setReviewNotice('⚠️ Por favor, digite seu parecer clínico antes de finalizar o atendimento.');
      return;
    }

    const reviewDecision: DoctorReviewDecision = {
      status: decisionStatus,
      parecer: doctorParecer.trim(),
      doctorCpf: loggedDoctor.cpf,
      doctorName: `${loggedDoctor.nome} ${loggedDoctor.sobrenome}`,
      reviewedAt: new Date().toISOString().slice(0, 16),
    };

    const updatedConsultation: ConsultationRecord = {
      ...activeConsultation,
      status: 'revisada_doutor',
      doctorNotes: doctorParecer.trim(),
      doctorDecision: reviewDecision,
      updatedAt: new Date().toISOString().slice(0, 16),
    };

    saveConsultation(updatedConsultation);
    setActiveConsultation(updatedConsultation);

    // Refresh list
    handleSearchPatientRecords(loggedDoctor, searchPatientCpf, startDate, endDate);

    setReviewNotice(
      `✅ Atendimento ${decisionStatus.toUpperCase()} e parecer gravado com sucesso no prontuário do paciente e do médico!`
    );
    setTimeout(() => setReviewNotice(''), 5000);
  };

  return (
    <div className="max-w-5xl mx-auto py-6 space-y-6">
      {/* Top Header Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLanding}
          className="flex items-center gap-2 text-xs font-mono font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar à Página Inicial
        </button>

        {loggedDoctor && (
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 hover:bg-rose-900 transition-colors cursor-pointer text-xs font-mono"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sair do Portal Médico (DR)
          </button>
        )}
      </div>

      {/* UNAUTHENTICATED: LOGIN & CADASTRO DOUTOR (DR) */}
      {!loggedDoctor ? (
        <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="w-12 h-12 bg-emerald-600/20 border border-emerald-500/40 rounded-xl flex items-center justify-center text-emerald-400">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold tracking-widest text-emerald-400 uppercase">
                PORTAL MÉDICO (DR)
              </span>
              <h2 className="text-2xl font-bold text-white mt-0.5">Acesso e Cadastro de Doutores</h2>
            </div>
          </div>

          {/* Tabs Switcher: Entrar / Cadastrar-se / Recuperar Senha */}
          <div className="flex bg-[#0D1117] p-1.5 rounded-2xl border border-slate-800 gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('login')}
              className={`flex-1 py-3 rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
                activeTab === 'login'
                  ? 'bg-emerald-600 text-white shadow-lg border border-emerald-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Lock className="w-4 h-4" />
              Entrar (Login DR)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('register')}
              className={`flex-1 py-3 rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
                activeTab === 'register'
                  ? 'bg-emerald-600 text-white shadow-lg border border-emerald-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              Cadastrar-se (Doutor DR)
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('recovery');
                setRecoveryStep('questions');
                setRecoveryError('');
              }}
              className={`flex-1 py-3 rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
                activeTab === 'recovery'
                  ? 'bg-amber-600 text-white shadow-lg border border-amber-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <KeyRound className="w-4 h-4 text-amber-300" />
              Recuperar Senha
            </button>
          </div>

          {loginSuccess && (
            <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 font-mono text-xs flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <span>{loginSuccess}</span>
            </div>
          )}

          {/* TAB 1: FORMULÁRIO DE LOGIN DOUTOR */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4 pt-2">
              {loginError && (
                <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 font-mono text-xs">
                  {loginError}
                </div>
              )}

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                  Usuário (CPF do Médico) *
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={loginCpf}
                    onChange={(e) => handleCpfFormatting(e.target.value, setLoginCpf)}
                    placeholder="000.000.000-00"
                    maxLength={14}
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                    Senha Cadastrada *
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('recovery');
                      setRecoveryStep('questions');
                      setRecoveryCpf(loginCpf);
                      setRecoveryError('');
                    }}
                    className="text-xs font-mono text-emerald-400 hover:text-emerald-300 underline cursor-pointer"
                  >
                    Esqueci minha senha
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Sua senha alfanumérica"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
              >
                <ShieldCheck className="w-4 h-4" />
                Entrar no Portal do Doutor (DR)
              </button>
            </form>
          )}

          {/* TAB 2: FORMULÁRIO DE CADASTRO DOUTOR (DR) */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4 pt-2">
              {regError && (
                <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 font-mono text-xs">
                  {regError}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Nome *
                  </label>
                  <input
                    type="text"
                    required
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Ex: Dra. Ana"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Sobrenome *
                  </label>
                  <input
                    type="text"
                    required
                    value={sobrenome}
                    onChange={(e) => setSobrenome(e.target.value)}
                    placeholder="Ex: Beatriz Ramos"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Data de Nascimento *
                  </label>
                  <input
                    type="date"
                    required
                    value={dataNascimento}
                    onChange={(e) => setDataNascimento(e.target.value)}
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    CPF (Usuário) *
                  </label>
                  <input
                    type="text"
                    required
                    value={cpf}
                    onChange={(e) => handleCpfFormatting(e.target.value, setCpf)}
                    placeholder="000.000.000-00"
                    maxLength={14}
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    CRM / Registro Profissional
                  </label>
                  <input
                    type="text"
                    value={crm}
                    onChange={(e) => setCrm(e.target.value)}
                    placeholder="CRM/SP 123456"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    E-mail Médico *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="doutor@hospital.com"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Telefone *
                  </label>
                  <input
                    type="text"
                    required
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    placeholder="(11) 97777-8888"
                    className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                  />
                </div>
              </div>

              {/* ENDEREÇO COM VIA CEP */}
              <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-emerald-400 uppercase flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-400" />
                    Endereço Consultório/Residência (Consulta via ViaCEP API)
                  </span>
                  {isSearchingCep && <span className="text-[11px] font-mono text-amber-400 animate-pulse">Consultando ViaCEP...</span>}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={cep}
                    onChange={(e) => {
                      setCep(e.target.value);
                      if (e.target.value.replace(/\D/g, '').length === 8) {
                        handleSearchCep(e.target.value, false);
                      }
                    }}
                    placeholder="CEP (ex: 04001-000)"
                    maxLength={9}
                    className="flex-1 bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2 text-xs font-mono text-slate-200 outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleSearchCep(cep, false)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <Search className="w-3.5 h-3.5" />
                    Buscar CEP
                  </button>
                </div>

                {cepMessage && <p className="text-[11px] font-mono text-emerald-300">{cepMessage}</p>}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Rua / Logradouro</label>
                    <input
                      type="text"
                      value={rua}
                      onChange={(e) => setRua(e.target.value)}
                      placeholder="Rua Vergueiro (Auto ViaCEP)"
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Número *</label>
                    <input
                      type="text"
                      required
                      value={numero}
                      onChange={(e) => setNumero(e.target.value)}
                      placeholder="Nº 500"
                      className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Bairro</label>
                    <input
                      type="text"
                      value={bairro}
                      onChange={(e) => setBairro(e.target.value)}
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Cidade</label>
                    <input
                      type="text"
                      value={cidade}
                      onChange={(e) => setCidade(e.target.value)}
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase">Estado (UF)</label>
                    <input
                      type="text"
                      value={uf}
                      onChange={(e) => setUf(e.target.value)}
                      className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* PERGUNTAS DE SEGURANÇA PARA RECUPERAÇÃO DE SENHA DOUTOR */}
              <div className="p-4 bg-[#0D1117] border border-amber-500/30 rounded-2xl space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldQuestion className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-mono font-bold text-amber-400 uppercase">
                    Perguntas de Segurança (para Recuperação de Senha)
                  </span>
                </div>
                <p className="text-[11px] font-mono text-slate-400">
                  Estas respostas serão solicitadas caso precise redefinir sua senha de Doutor no futuro.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-mono font-bold text-slate-300 uppercase mb-1">
                      Pergunta 1: Qual o nome da mãe? *
                    </label>
                    <input
                      type="text"
                      required
                      value={nomeMae}
                      onChange={(e) => setNomeMae(e.target.value)}
                      placeholder="Informe a resposta"
                      className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono font-bold text-slate-300 uppercase mb-1">
                      Pergunta 2: Qual o nome do pai? *
                    </label>
                    <input
                      type="text"
                      required
                      value={nomePai}
                      onChange={(e) => setNomePai(e.target.value)}
                      placeholder="Informe a resposta"
                      className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                </div>

                <div className="text-[11px] font-mono text-slate-400 bg-[#161B22] p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                  <HelpCircle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                  <span>Pergunta 3: Qual é o E-mail cadastrado? (Será verificado com o E-mail informado acima)</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                  Senha Alfanumérica *
                </label>
                <input
                  type="password"
                  required
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  placeholder="Crie sua senha alfanumérica"
                  className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
              >
                <CheckCircle2 className="w-4 h-4" />
                Finalizar Cadastro do Doutor
              </button>
            </form>
          )}

          {/* TAB 3: RECUPERAÇÃO DE SENHA DOUTOR (DR) */}
          {activeTab === 'recovery' && (
            <div className="space-y-4 pt-2">
              {recoveryError && (
                <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-300 font-mono text-xs">
                  {recoveryError}
                </div>
              )}

              {/* ETAPA 1: VERIFICAÇÃO DAS PERGUNTAS DE SEGURANÇA */}
              {recoveryStep === 'questions' && (
                <form onSubmit={handleVerifySecurityQuestions} className="space-y-4">
                  <div className="p-4 bg-[#0D1117] border border-amber-500/30 rounded-2xl space-y-1">
                    <span className="text-xs font-mono font-bold text-amber-400 uppercase flex items-center gap-2">
                      <KeyRound className="w-4 h-4" />
                      Recuperação de Senha - Doutor (DR)
                    </span>
                    <p className="text-xs font-mono text-slate-300">
                      Responda às perguntas de segurança e confirme seu E-mail cadastrado de médico para prosseguir com a redefinição de senha.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1 uppercase">
                      CPF do Médico (Usuário) *
                    </label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        required
                        value={recoveryCpf}
                        onChange={(e) => handleCpfFormatting(e.target.value, setRecoveryCpf)}
                        placeholder="000.000.000-00"
                        maxLength={14}
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-3 p-4 bg-[#0D1117] border border-slate-800 rounded-2xl">
                    <span className="text-xs font-mono font-bold text-slate-200 uppercase flex items-center gap-2">
                      <ShieldQuestion className="w-4 h-4 text-amber-400" />
                      Verificação das Respostas de Segurança
                    </span>

                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1">
                        Pergunta 1: Qual o nome da mãe? *
                      </label>
                      <input
                        type="text"
                        required
                        value={recoveryMae}
                        onChange={(e) => setRecoveryMae(e.target.value)}
                        placeholder="Informe a resposta"
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1">
                        Pergunta 2: Qual o nome do pai? *
                      </label>
                      <input
                        type="text"
                        required
                        value={recoveryPai}
                        onChange={(e) => setRecoveryPai(e.target.value)}
                        placeholder="Informe a resposta"
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1">
                        Pergunta 3: Qual é o E-mail cadastrado? *
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                        <input
                          type="email"
                          required
                          value={recoveryEmail}
                          onChange={(e) => setRecoveryEmail(e.target.value)}
                          placeholder="Informe o e-mail cadastrado"
                          className="w-full bg-[#161B22] border border-slate-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Validar Respostas e Redirecionar
                  </button>
                </form>
              )}

              {/* ETAPA 2: REDIRECIONAMENTO PARA INFORMAR A NOVA SENHA */}
              {recoveryStep === 'new_password' && (
                <form onSubmit={handleSaveNewPassword} className="space-y-4">
                  <div className="p-4 bg-emerald-950/80 border border-emerald-800 rounded-2xl space-y-1 text-emerald-200">
                    <span className="text-xs font-mono font-bold uppercase flex items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" />
                      Respostas de Segurança Confirmadas!
                    </span>
                    <p className="text-xs font-mono">
                      Médico verificado: <strong className="text-white">Dr(a). {recoveryUser?.nome} {recoveryUser?.sobrenome}</strong> (CPF: {recoveryUser?.cpf}). Por favor, informe sua nova senha alfanumérica.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                      Digite a Nova Senha Alfanumérica *
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="password"
                        required
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Sua nova senha alfanumérica"
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                      Confirme a Nova Senha *
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="password"
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Repita a nova senha"
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Salvar Nova Senha e Ir para Tela de Login
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      ) : (
        /* LOGGED IN DOCTOR DASHBOARD */
        <div className="space-y-6">
          {/* Welcome Doctor Banner */}
          <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-emerald-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-md">
                Dr.
              </div>
              <div>
                <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest">
                  MÉDICO RESPONSÁVEL (DR)
                </span>
                <h2 className="text-2xl font-bold text-white">
                  {loggedDoctor.nome} {loggedDoctor.sobrenome}
                </h2>
                <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-slate-400 mt-1">
                  <span>CPF: {loggedDoctor.cpf}</span>
                  <span>•</span>
                  <span>{loggedDoctor.crm || 'CRM Ativo'}</span>
                  <span>•</span>
                  <span>{loggedDoctor.email}</span>
                </div>
              </div>
            </div>

            {/* Navigation Controls for Doctor */}
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {/* Botão CONSULTA / ATENDIMENTO */}
              <button
                onClick={() => {
                  setActiveNav('atendimento');
                  setShowDrHistory(false);
                }}
                className={`px-5 py-3 rounded-xl border font-mono font-bold text-xs uppercase transition-all cursor-pointer shadow-lg flex items-center gap-2 ${
                  activeNav === 'atendimento' && !showDrHistory
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <Stethoscope className="w-4 h-4 text-amber-300" />
                <span>Consulta / Atendimento Paciente</span>
              </button>

              {/* Botão HISTÓRICO DE ATENDIMENTOS (Aparece somente quando acionado) */}
              <button
                onClick={() => {
                  setShowDrHistory((prev) => !prev);
                  setActiveNav('historico_dr');
                }}
                className={`px-4 py-3 rounded-xl border font-mono font-bold text-xs uppercase transition-all cursor-pointer flex items-center gap-2 ${
                  showDrHistory
                    ? 'bg-amber-600 border-amber-500 text-white'
                    : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4 text-amber-400" />
                <span>Exibir Histórico de Atendimentos</span>
                {showDrHistory ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              {/* Botão CONTA */}
              <button
                onClick={() => {
                  setShowDrHistory(false);
                  setActiveNav('conta_dr');
                }}
                className={`px-4 py-3 rounded-xl border font-mono font-bold text-xs uppercase transition-all cursor-pointer flex items-center gap-2 ${
                  activeNav === 'conta_dr' && !showDrHistory
                    ? 'bg-indigo-600 border-indigo-500 text-white'
                    : 'bg-[#0D1117] border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <UserCheck className="w-4 h-4 text-indigo-400" />
                <span>Conta / Meus Dados</span>
              </button>
            </div>
          </div>

          {/* SECTION: EXIBIR HISTÓRICO DE ATENDIMENTOS (Ativado via botão) */}
          {showDrHistory && (
            <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2 font-mono font-bold text-amber-400 uppercase text-xs">
                  <Clock className="w-4 h-4" />
                  <span>Histórico Geral de Atendimentos do Doutor ({getStoredConsultations().length})</span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">Prontuário Unificado Pasquared</span>
              </div>

              <div className="space-y-3">
                {getStoredConsultations().map((c) => (
                  <div
                    key={c.id}
                    className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs font-mono hover:border-slate-700 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{c.patient.nome} {c.patient.sobrenome}</span>
                        <span className="text-slate-400">(CPF: {c.patient.cpf})</span>
                        <span className="text-slate-500">• {c.createdAt}</span>
                      </div>
                      <p className="text-slate-300 mt-1">
                        {c.preAssessment?.complaintSummary || 'Relato de Anamnese do Paciente'}
                      </p>
                      {c.doctorDecision && (
                        <div className="mt-2 text-[11px] text-emerald-400 font-bold flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Parecer: "{c.doctorDecision.parecer}" ({c.doctorDecision.status.toUpperCase()})
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        setSearchPatientCpf(c.patient.cpf);
                        setActiveConsultation(c);
                        setShowDrHistory(false);
                        setActiveNav('atendimento');
                      }}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5"
                    >
                      <Search className="w-3.5 h-3.5" />
                      Analisar Atendimento
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SECTION: CONSULTA / ATENDIMENTO DO PACIENTE (CPF + FILTRO DE DATA + PASQUARED TRANSCRIPTON + Embedded Media + Aprovar/Desaprovar) */}
          {activeNav === 'atendimento' && !showDrHistory && (
            <div className="space-y-6">
              {/* SEARCH BOX & DATE FILTER */}
              <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
                <div className="flex items-center gap-2 text-xs font-mono font-bold text-emerald-400 uppercase">
                  <Search className="w-4 h-4" />
                  <span>Busca de Prontuário por CPF do Paciente e Filtro de Datas</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                      Informe o CPF do Paciente *
                    </label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        value={searchPatientCpf}
                        onChange={(e) => handleCpfFormatting(e.target.value, setSearchPatientCpf)}
                        placeholder="Ex: 123.456.789-00"
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Data Inicial</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Data Final</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-200 outline-none"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleSearchPatientRecords(loggedDoctor, searchPatientCpf, startDate, endDate)}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Filter className="w-4 h-4" />
                  Buscar Histórico e Relato do Pasquared
                </button>
              </div>

              {/* RESULT DISPLAY AREA */}
              {searchedConsultations.length === 0 ? (
                <div className="p-8 bg-[#161B22] border border-slate-800 rounded-3xl text-center text-slate-400 font-mono text-xs space-y-2">
                  <p>Nenhum atendimento encontrado para o CPF {searchPatientCpf} no período selecionado.</p>
                  <p className="text-[11px] text-slate-500">Tente buscar o CPF demonstrativo: 123.456.789-00</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Left Column: Atendimentos List */}
                  <div className="space-y-3">
                    <span className="text-xs font-mono font-bold text-slate-400 uppercase">
                      Atendimentos Encontrados ({searchedConsultations.length})
                    </span>

                    {searchedConsultations.map((c) => (
                      <div
                        key={c.id}
                        onClick={() => setActiveConsultation(c)}
                        className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                          activeConsultation?.id === c.id
                            ? 'bg-emerald-950/60 border-emerald-500 shadow-lg'
                            : 'bg-[#161B22] border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs font-mono">
                          <span className="font-bold text-white">{c.id}</span>
                          <span className="text-slate-400 text-[10px]">{c.createdAt}</span>
                        </div>
                        <p className="text-xs text-slate-300 font-mono mt-1 line-clamp-2">
                          {c.preAssessment?.complaintSummary || 'Sintomas relatados ao Pasquared'}
                        </p>
                        <div className="mt-2 flex items-center gap-2">
                          <span className="text-[10px] font-mono px-2 py-0.5 bg-amber-950 text-amber-300 border border-amber-800 rounded font-bold">
                            {c.preAssessment?.riskLevel || 'AVALIAÇÃO'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Right Column: Full Pasquared Consultation Report, Embedded Player & Decision Form */}
                  {activeConsultation && (
                    <div className="lg:col-span-2 space-y-6">
                      <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 space-y-6 shadow-2xl">
                        {/* Header */}
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-4">
                          <div>
                            <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase">
                              PRONTUÁRIO INTEGRAL PASQUARED · ID: {activeConsultation.id}
                            </span>
                            <h3 className="text-xl font-bold text-white mt-0.5">
                              {activeConsultation.patient.nome} {activeConsultation.patient.sobrenome}
                            </h3>
                            <p className="text-xs font-mono text-slate-400">
                              CPF: {activeConsultation.patient.cpf} • Data Nasc: {activeConsultation.patient.dataNascimento}
                            </p>
                          </div>

                          <div className="text-right">
                            <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-950 text-amber-300 border border-amber-800">
                              {activeConsultation.preAssessment?.riskLevel}
                            </span>
                          </div>
                        </div>

                        {reviewNotice && (
                          <div className="p-4 rounded-xl bg-emerald-950/90 border border-emerald-800 text-emerald-200 font-mono text-xs">
                            {reviewNotice}
                          </div>
                        )}

                        {/* 1. SÍNTESE DO PASQUARED */}
                        <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-2 font-mono text-xs">
                          <span className="text-indigo-400 font-bold uppercase block">
                            🧠 Síntese da Pré-Avaliação Cognitiva
                          </span>
                          <p className="text-slate-200 leading-relaxed">
                            {activeConsultation.preAssessment?.complaintSummary}
                          </p>
                          <div className="pt-2">
                            <span className="text-slate-400 font-bold">Hipóteses Diagnósticas Mapeadas:</span>
                            <ul className="list-disc list-inside text-slate-300 mt-1 space-y-0.5">
                              {activeConsultation.preAssessment?.diagnosticHypotheses.map((h, i) => (
                                <li key={i}>{h}</li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* 2. TRANSCRIÇÃO COMPLETA DO ATENDIMENTO (Perguntas e Respostas) */}
                        <div className="space-y-3">
                          <span className="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
                            <FileText className="w-4 h-4 text-emerald-400" />
                            Transcrição Completa do Atendimento ({activeConsultation.messages.length} mensagens)
                          </span>

                          <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl max-h-80 overflow-y-auto space-y-3 font-mono text-xs scrollbar-thin">
                            {activeConsultation.messages.map((m) => (
                              <div
                                key={m.id}
                                className={`p-3 rounded-xl border ${
                                  m.sender === 'ai'
                                    ? 'bg-[#161B22] border-indigo-500/30 text-indigo-200'
                                    : 'bg-emerald-950/40 border-emerald-500/30 text-emerald-100 ml-4'
                                }`}
                              >
                                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1 font-bold">
                                  <span>{m.sender === 'ai' ? '🤖 Pasquared AI' : '👤 Paciente'}</span>
                                  <span>{m.timestamp}</span>
                                </div>
                                <p className="whitespace-pre-wrap">{m.text}</p>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* 3. MÍDIAS E ARQUIVOS COM PLAYER EMBUTIDO E DOWNLOAD */}
                        <div className="space-y-3">
                          <span className="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
                            <Play className="w-4 h-4 text-amber-400" />
                            Mídias e Documentos Anexados pelo Paciente ({activeConsultation.attachments.length})
                          </span>

                          {activeConsultation.attachments.length === 0 ? (
                            <p className="text-xs font-mono text-slate-500 italic">Nenhum anexo enviado.</p>
                          ) : (
                            <div className="space-y-4">
                              {activeConsultation.attachments.map((att) => (
                                <div
                                  key={att.id}
                                  className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-3 font-mono text-xs"
                                >
                                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                                    <div className="flex items-center gap-2 font-bold text-slate-200">
                                      <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                                      <span>{att.name}</span>
                                      <span className="text-[10px] text-slate-500">({att.size || '300 KB'})</span>
                                    </div>

                                    {/* Botão de Download */}
                                    <a
                                      href={att.dataUrl}
                                      download={att.name}
                                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-[11px] flex items-center gap-1.5 cursor-pointer"
                                    >
                                      <Download className="w-3.5 h-3.5" />
                                      Baixar Arquivo
                                    </a>
                                  </div>

                                  {/* EMBEDDED PLAYER FOR AUDIO */}
                                  {att.type === 'audio' && (
                                    <div className="bg-[#161B22] p-2 rounded-xl border border-slate-800">
                                      <span className="text-[10px] text-amber-400 font-bold block mb-1">
                                        🔊 Reprodução de Áudio On-line:
                                      </span>
                                      <audio controls src={att.dataUrl} className="w-full rounded-lg" />
                                    </div>
                                  )}

                                  {/* EMBEDDED PLAYER FOR VIDEO */}
                                  {att.type === 'video' && (
                                    <div className="bg-[#161B22] p-2 rounded-xl border border-slate-800">
                                      <span className="text-[10px] text-amber-400 font-bold block mb-1">
                                        🎥 Reprodução de Vídeo On-line:
                                      </span>
                                      <video controls src={att.dataUrl} className="w-full max-h-60 rounded-lg" />
                                    </div>
                                  )}

                                  {/* EMBEDDED PREVIEW FOR DOCUMENT OR IMAGE */}
                                  {att.type === 'document' && att.dataUrl.startsWith('data:image') && (
                                    <div className="bg-[#161B22] p-2 rounded-xl border border-slate-800">
                                      <span className="text-[10px] text-amber-400 font-bold block mb-1">
                                        🖼️ Visualização de Imagem:
                                      </span>
                                      <img
                                        src={att.dataUrl}
                                        alt={att.name}
                                        className="max-h-60 rounded-lg mx-auto object-contain"
                                      />
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* 4. AVALIAÇÃO DO MÉDICO: PARECER + APROVAR / DESAPROVAR */}
                        <div className="p-5 bg-[#0D1117] border border-emerald-500/30 rounded-2xl space-y-4 font-mono">
                          <span className="text-xs font-bold text-emerald-400 uppercase flex items-center gap-2">
                            <Stethoscope className="w-4 h-4 text-emerald-400" />
                            Parecer do Médico e Decisão da Consulta (Gravação em Prontuário)
                          </span>

                          {activeConsultation.doctorDecision && (
                            <div className="p-3 bg-emerald-950/80 border border-emerald-700 rounded-xl text-xs text-emerald-200">
                              <span className="font-bold uppercase">
                                Atendimento Anteriormente {activeConsultation.doctorDecision.status.toUpperCase()} por{' '}
                                {activeConsultation.doctorDecision.doctorName}
                              </span>
                              <p className="mt-1">"{activeConsultation.doctorDecision.parecer}"</p>
                              <span className="text-[10px] text-slate-400 block mt-1">
                                Data: {activeConsultation.doctorDecision.reviewedAt}
                              </span>
                            </div>
                          )}

                          <div>
                            <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase">
                              Digite o seu Parecer Médico / Diagnóstico Final:
                            </label>
                            <textarea
                              rows={4}
                              value={doctorParecer}
                              onChange={(e) => setDoctorParecer(e.target.value)}
                              placeholder="Ex: Paciente avaliado. Quadro compatível com cefaleia tensional. Prescrito analgésico sintomático e orientado repouso..."
                              className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl p-3 text-xs text-slate-200 outline-none"
                            />
                          </div>

                          <div className="flex flex-col md:flex-row gap-3">
                            <button
                              type="button"
                              onClick={() => handleFinalizeDoctorReview('aprovado')}
                              className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              Aprovar e Dar Parecer
                            </button>

                            <button
                              type="button"
                              onClick={() => handleFinalizeDoctorReview('desaprovado')}
                              className="flex-1 py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                            >
                              <XCircle className="w-4 h-4" />
                              Desaprovar e Dar Parecer
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* SECTION: CONTA / MEUS DADOS DO DOUTOR (Com Persistência e Adicionar Telefone) */}
          {activeNav === 'conta_dr' && !showDrHistory && (
            <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2 font-mono font-bold text-indigo-400 uppercase text-xs">
                  <UserCheck className="w-4 h-4" />
                  <span>Dados Cadastrais do Doutor (Edição & Persistência)</span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">CPF Médico: {loggedDoctor.cpf}</span>
              </div>

              {saveSuccess && (
                <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 font-mono text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{saveSuccess}</span>
                </div>
              )}

              <form onSubmit={handleSaveAccount} className="space-y-5">
                {/* Fixed data */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-[#0D1117] border border-slate-800 rounded-2xl text-xs font-mono">
                  <div>
                    <span className="text-slate-500 uppercase block text-[10px]">Nome do Doutor</span>
                    <span className="font-bold text-white text-sm">
                      {loggedDoctor.nome} {loggedDoctor.sobrenome}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 uppercase block text-[10px]">CPF / CRM</span>
                    <span className="font-bold text-emerald-300">
                      {loggedDoctor.cpf} ({loggedDoctor.crm || 'CRM Ativo'})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 uppercase block text-[10px]">Data de Nascimento</span>
                    <span className="font-bold text-slate-200">{loggedDoctor.dataNascimento}</span>
                  </div>
                </div>

                {/* Editable Fields: E-mail & Telefone */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase">
                      E-mail Médico (Editável)
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="email"
                        required
                        value={editEmail}
                        onChange={(e) => setEditEmail(e.target.value)}
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 mb-1.5 uppercase">
                      Telefone Principal (Editável)
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        required
                        value={editTelefone}
                        onChange={(e) => setEditTelefone(e.target.value)}
                        className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* ADICIONAR TELEFONE SECUNDÁRIO */}
                <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-3">
                  <span className="text-xs font-mono font-bold text-emerald-400 uppercase flex items-center gap-2">
                    <Phone className="w-4 h-4 text-emerald-400" />
                    Telefones Adicionais / Consultório / Emergência
                  </span>

                  {editTelefonesAdicionais.length > 0 && (
                    <div className="space-y-2">
                      {editTelefonesAdicionais.map((phone, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between px-3 py-2 bg-[#161B22] border border-slate-800 rounded-xl text-xs font-mono"
                        >
                          <span className="text-slate-200">{phone}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveExtraPhone(idx)}
                            className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newExtraPhone}
                      onChange={(e) => setNewExtraPhone(e.target.value)}
                      placeholder="Adicionar telefone de consultório ou secretária"
                      className="flex-1 bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleAddExtraPhone}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Adicionar
                    </button>
                  </div>
                </div>

                {/* EDITAR ENDEREÇO DO DOUTOR */}
                <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-emerald-400 uppercase flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400" />
                      Endereço do Consultório (Consulta via API ViaCEP)
                    </span>
                    {isSearchingCep && <span className="text-[11px] font-mono text-amber-400 animate-pulse">Consultando ViaCEP...</span>}
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={editCep}
                      onChange={(e) => setEditCep(e.target.value)}
                      placeholder="CEP"
                      className="flex-1 bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2 text-xs font-mono text-slate-200 outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => handleSearchCep(editCep, true)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Search className="w-3.5 h-3.5" />
                      Atualizar CEP
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Rua / Logradouro</label>
                      <input
                        type="text"
                        value={editRua}
                        onChange={(e) => setEditRua(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Número</label>
                      <input
                        type="text"
                        value={editNumero}
                        onChange={(e) => setEditNumero(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Bairro</label>
                      <input
                        type="text"
                        value={editBairro}
                        onChange={(e) => setEditBairro(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Cidade</label>
                      <input
                        type="text"
                        value={editCidade}
                        onChange={(e) => setEditCidade(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-slate-400 uppercase">Estado (UF)</label>
                      <input
                        type="text"
                        value={editUf}
                        onChange={(e) => setEditUf(e.target.value)}
                        className="w-full bg-[#161B22] border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* BOTÃO SALVAR PERSISTENTE */}
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                >
                  <Save className="w-4 h-4" />
                  Salvar Alterações do Doutor (Persistente no Banco)
                </button>
              </form>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
