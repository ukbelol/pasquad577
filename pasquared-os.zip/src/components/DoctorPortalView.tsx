import React, { useState } from 'react';
import {
  Search,
  UserCheck,
  Calendar,
  CreditCard,
  FileText,
  Volume2,
  Video,
  Play,
  Save,
  CheckCircle2,
  AlertTriangle,
  Stethoscope,
  ArrowLeft,
  Clock,
  Download,
  Eye,
  ShieldCheck,
  X,
} from 'lucide-react';
import { ConsultationRecord, AttachmentItem } from '../types';
import { findConsultationByCpfAndDob, saveConsultation } from '../lib/consultationStore';

interface DoctorPortalViewProps {
  onBackToLanding: () => void;
}

export const DoctorPortalView: React.FC<DoctorPortalViewProps> = ({ onBackToLanding }) => {
  const [cpfInput, setCpfInput] = useState('');
  const [dobInput, setDobInput] = useState('');
  const [searched, setSearched] = useState(false);
  const [consultation, setConsultation] = useState<ConsultationRecord | null>(null);
  const [doctorNotes, setDoctorNotes] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<AttachmentItem | null>(null);

  // Helper for formatting CPF input
  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);

    if (value.length > 9) {
      value = value.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');
    } else if (value.length > 6) {
      value = value.replace(/^(\d{3})(\d{3})(\d{1,3})$/, '$1.$2.$3');
    } else if (value.length > 3) {
      value = value.replace(/^(\d{3})(\d{1,3})$/, '$1.$2');
    }

    setCpfInput(value);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    const result = findConsultationByCpfAndDob(cpfInput, dobInput);
    setConsultation(result);
    if (result) {
      setDoctorNotes(result.doctorNotes || '');
    }
  };

  const handleSaveDoctorNotes = () => {
    if (!consultation) return;

    const updated: ConsultationRecord = {
      ...consultation,
      doctorNotes,
      status: 'revisada_doutor',
      updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
    };

    saveConsultation(updated);
    setConsultation(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // Helper to load sample consultation for quick demo preview
  const handleLoadSample = () => {
    setCpfInput('123.456.789-00');
    setDobInput('1985-06-14');
    const result = findConsultationByCpfAndDob('123.456.789-00', '1985-06-14');
    setSearched(true);
    setConsultation(result);
    if (result) {
      setDoctorNotes(result.doctorNotes || '');
    }
  };

  return (
    <div className="space-y-6 py-4 max-w-6xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLanding}
          className="flex items-center gap-2 text-xs font-mono font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar ao Início
        </button>

        <button
          onClick={handleLoadSample}
          className="text-xs font-mono font-bold text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
        >
          Carregar Exemplo de Demonstração (CPF: 123.456.789-00)
        </button>
      </div>

      {/* Search Bento Card */}
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="w-12 h-12 bg-emerald-600/20 border border-emerald-500/40 rounded-xl flex items-center justify-center text-emerald-400">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-mono font-bold tracking-widest text-emerald-400 uppercase">
              PORTAL DOUTOR (DR)
            </span>
            <h2 className="text-2xl font-bold text-white mt-0.5">Recuperação de Consulta e Atendimento</h2>
          </div>
        </div>

        <form onSubmit={handleSearch} className="space-y-4 font-mono text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                CPF do Paciente *
              </label>
              <div className="relative">
                <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  required
                  value={cpfInput}
                  onChange={handleCpfChange}
                  placeholder="000.000.000-00"
                  maxLength={14}
                  className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                Data de Nascimento do Paciente *
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="date"
                  required
                  value={dobInput}
                  onChange={(e) => setDobInput(e.target.value)}
                  className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 outline-none"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-lg"
          >
            <Search className="w-4 h-4" />
            Buscar Prontuário e Atendimento Persistido
          </button>
        </form>
      </div>

      {/* Search Results Display */}
      {searched && (
        <>
          {consultation ? (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Patient Header Card */}
              <div className="bg-[#161B22] border border-emerald-500/40 rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest">
                      PRONTUÁRIO ENCONTRADO #{consultation.id}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/60 uppercase">
                      {consultation.status === 'revisada_doutor' ? 'REVISADO POR MÉDICO' : 'DISPONÍVEL'}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-white">
                    {consultation.patient.nome} {consultation.patient.sobrenome}
                  </h3>
                  <div className="flex flex-wrap gap-4 text-xs font-mono text-slate-400">
                    <span>CPF: <strong className="text-slate-200">{consultation.patient.cpf}</strong></span>
                    <span>Nascimento: <strong className="text-slate-200">{consultation.patient.dataNascimento}</strong></span>
                    <span>Data Atendimento: <strong className="text-slate-200">{consultation.createdAt}</strong></span>
                  </div>
                </div>

                {savedSuccess && (
                  <div className="flex items-center gap-2 text-xs font-mono font-bold text-emerald-400 bg-emerald-950/80 px-4 py-2 rounded-xl border border-emerald-800">
                    <CheckCircle2 className="w-4 h-4" />
                    Parecer Salvo no Histórico!
                  </div>
                )}
              </div>

              {/* Grid 2 Columns: Report + Media / Transcript */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Pre-Assessment Summary & Doctor Notes */}
                <div className="space-y-6">
                  {/* Pre Assessment Card */}
                  <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 space-y-4 font-mono text-xs">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <Stethoscope className="w-4 h-4 text-emerald-400" />
                        <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                          Pré-Avaliação Clínica (Gerada por IA)
                        </h3>
                      </div>
                    </div>

                    {consultation.preAssessment && (
                      <div className="space-y-4">
                        <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-1">
                          <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">
                            ESTRATIFICAÇÃO DE RISCO
                          </span>
                          <div
                            className={`text-sm font-extrabold ${
                              consultation.preAssessment.riskLevel.includes('VERMELHO')
                                ? 'text-rose-400'
                                : consultation.preAssessment.riskLevel.includes('AMARELO')
                                ? 'text-amber-400'
                                : 'text-emerald-400'
                            }`}
                          >
                            {consultation.preAssessment.riskLevel}
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-1.5">
                          <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">
                            RESUMO DA QUEIXA PRINCIPAL
                          </span>
                          <p className="text-slate-300 leading-relaxed">
                            {consultation.preAssessment.complaintSummary}
                          </p>
                        </div>

                        <div className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2">
                          <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">
                            HIPÓTESES LEVANTADAS
                          </span>
                          <ul className="list-disc list-inside space-y-1 text-slate-300">
                            {consultation.preAssessment.diagnosticHypotheses.map((h, idx) => (
                              <li key={idx}>{h}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Doctor Notes Form */}
                  <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 space-y-4 font-mono text-xs">
                    <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                        Parecer Técnico & Conduta do Médico
                      </h3>
                    </div>

                    <textarea
                      rows={5}
                      value={doctorNotes}
                      onChange={(e) => setDoctorNotes(e.target.value)}
                      placeholder="Escreva seu parecer médico, prescrição ou orientações finais para o prontuário..."
                      className="w-full bg-[#0D1117] border border-slate-800 focus:border-emerald-500 rounded-xl p-4 text-xs text-slate-200 outline-none leading-relaxed"
                    />

                    <button
                      onClick={handleSaveDoctorNotes}
                      className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-md"
                    >
                      <Save className="w-4 h-4" />
                      Salvar Parecer e Atualizar Prontuário
                    </button>
                  </div>
                </div>

                {/* Media Players & Transcript */}
                <div className="space-y-6">
                  {/* Media Attachments Player Box */}
                  <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 space-y-4 font-mono text-xs">
                    <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                      <Video className="w-4 h-4 text-amber-400" />
                      <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                        Mídias & Documentos Enviados pelo Paciente
                      </h3>
                    </div>

                    {consultation.attachments && consultation.attachments.length > 0 ? (
                      <div className="space-y-4">
                        {consultation.attachments.map((att) => (
                          <div
                            key={att.id}
                            className="p-4 rounded-xl bg-[#0D1117] border border-slate-800 space-y-2"
                          >
                            <div className="flex items-center justify-between text-slate-300">
                              <div className="flex items-center gap-2">
                                {att.type === 'audio' && <Volume2 className="w-4 h-4 text-emerald-400" />}
                                {att.type === 'video' && <Video className="w-4 h-4 text-amber-400" />}
                                {att.type === 'document' && <FileText className="w-4 h-4 text-indigo-400" />}
                                <span className="font-bold text-white">{att.name}</span>
                              </div>
                              <span className="text-[10px] text-slate-500">{att.uploadedAt} ({att.size})</span>
                            </div>

                            {/* HTML5 Audio Player */}
                            {att.type === 'audio' && (
                              <div className="pt-2">
                                <audio controls src={att.dataUrl} className="w-full rounded-lg h-10" />
                              </div>
                            )}

                            {/* HTML5 Video Player */}
                            {att.type === 'video' && (
                              <div className="pt-2">
                                <video
                                  controls
                                  src={att.dataUrl}
                                  className="w-full rounded-xl border border-slate-800 max-h-[220px] bg-black"
                                />
                              </div>
                            )}

                            {/* Document Viewer Button */}
                            {att.type === 'document' && (
                              <div className="pt-2 flex gap-2">
                                <button
                                  onClick={() => setPreviewDoc(att)}
                                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] cursor-pointer"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                  Visualizar Documento
                                </button>
                                <a
                                  href={att.dataUrl}
                                  download={att.name}
                                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] cursor-pointer"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                  Baixar
                                </a>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-slate-500 text-center py-6">
                        Nenhuma mídia ou documento anexado nesta consulta.
                      </p>
                    )}
                  </div>

                  {/* Q&A Full Transcript */}
                  <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 space-y-4 font-mono text-xs">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-indigo-400" />
                        <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                          Transcrição da Anamnese Guiada
                        </h3>
                      </div>
                      <span className="text-[10px] text-slate-500">
                        {consultation.messages.length} mensagens
                      </span>
                    </div>

                    <div className="space-y-3 max-h-[340px] overflow-y-auto pr-2 scrollbar-thin">
                      {consultation.messages.map((m) => (
                        <div
                          key={m.id}
                          className={`p-3 rounded-xl border text-xs leading-relaxed ${
                            m.sender === 'patient'
                              ? 'bg-indigo-950/40 border-indigo-800/60 text-indigo-200 ml-4'
                              : 'bg-[#0D1117] border-slate-800 text-slate-300 mr-4'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[10px] font-bold text-slate-500 mb-1">
                            <span>{m.sender === 'ai' ? 'Operador IA' : consultation.patient.nome}</span>
                            <span>{m.timestamp}</span>
                          </div>
                          <p>{m.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-12 text-center space-y-4 font-mono text-xs">
              <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
              <h3 className="text-lg font-bold text-white">Nenhum Atendimento Encontrado</h3>
              <p className="text-slate-400 max-w-md mx-auto">
                Não localizamos nenhuma consulta salva para o CPF <strong className="text-white">{cpfInput}</strong> e Data de Nascimento <strong className="text-white">{dobInput}</strong>.
              </p>
              <button
                onClick={handleLoadSample}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs uppercase cursor-pointer"
              >
                Testar com Dados de Exemplo
              </button>
            </div>
          )}
        </>
      )}

      {/* Document Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-[#161B22] border border-slate-800 w-full max-w-2xl rounded-2xl p-6 space-y-4 relative">
            <button
              onClick={() => setPreviewDoc(null)}
              className="absolute top-4 right-4 text-slate-500 hover:text-white p-2 rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <FileText className="w-5 h-5 text-indigo-400" />
              <h3 className="font-bold text-white text-sm font-mono">{previewDoc.name}</h3>
            </div>

            <div className="p-4 bg-[#0D1117] border border-slate-800 rounded-xl max-h-[400px] overflow-auto font-mono text-xs text-slate-300">
              {previewDoc.dataUrl.startsWith('data:image') ? (
                <img src={previewDoc.dataUrl} alt={previewDoc.name} className="max-w-full rounded-lg mx-auto" />
              ) : (
                <div className="space-y-3 text-center py-8">
                  <FileText className="w-12 h-12 text-indigo-400 mx-auto" />
                  <p>Documento PDF / Laudo Anexado ({previewDoc.size})</p>
                  <a
                    href={previewDoc.dataUrl}
                    download={previewDoc.name}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    Baixar Arquivo Completo
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
