import React, { useState } from 'react';
import { BUG_FIXES, INSTALLER_SCRIPT_NAME, INSTALLER_SCRIPT_CONTENT } from '../data/installerScript';
import { Terminal, Copy, Check, Download, AlertTriangle, CheckCircle2, ShieldCheck, FileCode, Wrench } from 'lucide-react';

export const InstallerScriptTab: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyScript = () => {
    navigator.clipboard.writeText(INSTALLER_SCRIPT_CONTENT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([INSTALLER_SCRIPT_CONTENT], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = 'install-geral.sh';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-6">
      {/* Header Bento Card */}
      <div className="bg-[#161B22] rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
            CORREÇÃO COMPLETA & GERADOR DE INSTALADOR
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">
            Instalador Corrigido: <span className="text-emerald-400 font-mono">install-geral.sh</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Novo script de instalação corrigido para Debian 12 com tipos TypeScript, ordenação do monorepo e automação PostgreSQL 16/Apache.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={handleCopyScript}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-200 text-xs font-mono font-bold hover:bg-slate-700 transition-colors cursor-pointer uppercase"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-indigo-400" />}
            {copied ? 'Código Copiado!' : 'Copiar install-geral.sh'}
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono font-bold transition-colors cursor-pointer uppercase"
          >
            <Download className="w-4 h-4" />
            Baixar .sh
          </button>
        </div>
      </div>

      {/* Cause & Solution Breakdown Bento Card */}
      <div className="p-6 rounded-2xl border border-amber-800/80 bg-[#161B22] space-y-3 font-mono text-xs">
        <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          Análise do Erro Ocorrido no Script Anterior
        </div>

        <div className="p-4 rounded-xl bg-[#0D1117] border border-amber-900/50 text-rose-300 space-y-1 font-mono text-[11px] leading-relaxed">
          <div className="font-bold text-rose-400">
            src/index.ts:2:22 - error TS7016: Could not find a declaration file for module 'pg'.
          </div>
          <div>'/opt/pasquared-os/services/smee/node_modules/pg/lib/index.js' implicitly has an 'any' type.</div>
          <div>Try `npm i --save-dev @types/pg` if it exists...</div>
          <div className="text-amber-400 pt-1 font-bold">
            ERRO: Falha na linha 1674 (execução do `npm run build` no monorepo).
          </div>
        </div>

        <p className="text-slate-300 text-xs leading-relaxed">
          <strong className="text-amber-400">Causa Exata:</strong> O serviço <code className="text-indigo-300">@pasq/smee</code> e o <code className="text-indigo-300">@pasq/gateway</code> dependiam do driver PostgreSQL <code className="text-indigo-300">pg</code>, porém os pacotes de definições de tipos TypeScript <code className="text-emerald-400">@types/pg</code> e <code className="text-emerald-400">@types/node</code> não estavam instalados nas <code className="text-indigo-300">devDependencies</code>. Quando o compilador <code className="text-indigo-300">tsc</code> rodou, interrompeu a compilação. Além disso, a ordem de build do monorepo tentava compilar serviços antes dos pacotes dependentes.
        </p>
      </div>

      {/* Grid of Bug Fixes */}
      <div className="space-y-3">
        <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider flex items-center gap-2">
          <Wrench className="w-4 h-4 text-indigo-400" />
          Mudanças e Soluções Aplicadas no Novo <code className="text-emerald-400">install-geral.sh</code>:
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {BUG_FIXES.map((fix, idx) => (
            <div
              key={idx}
              className="p-5 rounded-2xl border border-slate-800 bg-[#161B22] space-y-2 font-mono text-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white">{fix.title}</span>
                <span className="text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full bg-[#0D1117] text-indigo-400 border border-slate-800">
                  {fix.component}
                </span>
              </div>

              <p className="text-[11px] text-slate-400">
                <strong className="text-rose-400">Sintoma:</strong> {fix.errorCode}
              </p>

              <p className="text-[11px] text-slate-300">
                <strong className="text-indigo-400">Solução:</strong> {fix.fix}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Script Source Viewer Bento Card */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-indigo-400" />
            <h3 className="font-bold text-white text-xs uppercase tracking-wider">Visualizador do Script: install-geral.sh</h3>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold font-mono text-emerald-400 bg-[#0D1117] px-2.5 py-1 rounded-full border border-slate-800 uppercase">
              PRONTO PARA DEBIAN 12
            </span>
          </div>
        </div>

        {/* Command instructions */}
        <div className="p-3.5 rounded-xl bg-[#0D1117] border border-slate-800 text-slate-200 text-xs space-y-1">
          <div className="text-indigo-400 font-bold">// Como executar no seu servidor Debian 12:</div>
          <div className="text-emerald-400 font-mono font-bold">
            sudo bash install-geral.sh
          </div>
        </div>

        <div className="bg-[#0D1117] border border-slate-800 rounded-xl p-4 max-h-[480px] overflow-auto text-emerald-400 text-xs leading-relaxed font-mono scrollbar-thin">
          <pre className="whitespace-pre-wrap">{INSTALLER_SCRIPT_CONTENT}</pre>
        </div>
      </div>
    </div>
  );
};
