import React, { useState } from 'react';
import { EKOItem, InsightItem } from '../types';
import { Database, Search, Filter, Sparkles, ShieldCheck, CheckCircle2, Clock } from 'lucide-react';

interface CatalogTabProps {
  ekos: EKOItem[];
  insights: InsightItem[];
}

export const CatalogTab: React.FC<CatalogTabProps> = ({ ekos, insights }) => {
  const [search, setSearch] = useState('');
  const [filterDomain, setFilterDomain] = useState<string>('all');

  const filteredEkos = ekos.filter(
    (e) =>
      (filterDomain === 'all' || e.domain.toLowerCase() === filterDomain.toLowerCase()) &&
      (e.id.toLowerCase().includes(search.toLowerCase()) || e.domain.toLowerCase().includes(search.toLowerCase()))
  );

  const filteredInsights = insights.filter(
    (i) =>
      (filterDomain === 'all' || i.category.toLowerCase() === filterDomain.toLowerCase()) &&
      (i.theme.toLowerCase().includes(search.toLowerCase()) || i.category.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* Header Bento Card */}
      <div className="bg-[#161B22] rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase">
            MÓDULO CATALOG (CATÁLOGO COGNITIVO)
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">
            EKOs & Insights Persistidos
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Visualização de Epistemic Knowledge Objects (EKOs) e conceitos validados gravados no PostgreSQL 16 via SMEE.
          </p>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-[#0D1117] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200">
            <Search className="w-3.5 h-3.5 text-indigo-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por ID ou tema..."
              className="bg-transparent outline-none w-36 md:w-48 text-white placeholder-slate-500"
            />
          </div>

          <div className="flex items-center gap-2 bg-[#0D1117] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200">
            <Filter className="w-3.5 h-3.5 text-indigo-400" />
            <select
              value={filterDomain}
              onChange={(e) => setFilterDomain(e.target.value)}
              className="bg-transparent outline-none text-white cursor-pointer"
            >
              <option value="all" className="bg-[#161B22] text-white">
                Todos Domínios
              </option>
              <option value="Medicina" className="bg-[#161B22] text-white">
                Medicina
              </option>
              <option value="Geral" className="bg-[#161B22] text-white">
                Geral
              </option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* EKOs Bento Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">EKOs ({filteredEkos.length})</h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-indigo-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">Tabela ekos</span>
          </div>

          <div className="space-y-3 overflow-y-auto max-h-[420px] pr-1 scrollbar-thin">
            {filteredEkos.length === 0 ? (
              <p className="text-xs font-mono text-slate-500 py-8 text-center">Nenhum EKO encontrado.</p>
            ) : (
              filteredEkos.map((eko) => (
                <div
                  key={eko.id}
                  className="p-4 rounded-xl border border-slate-800 bg-[#0D1117] font-mono text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-indigo-400 font-bold">{eko.id}</span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] uppercase font-bold border ${
                        eko.status === 'validado' || eko.status === 'parcialmente-validado'
                          ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/60'
                          : 'bg-amber-950/60 text-amber-400 border-amber-800/60'
                      }`}
                    >
                      {eko.status}
                    </span>
                  </div>

                  <div className="text-slate-400 text-[11px]">
                    Domínio: <span className="text-slate-200">{eko.domain}</span> | Confiança:{' '}
                    <span className="text-emerald-400 font-bold">{(eko.confidence * 100).toFixed(0)}%</span>
                  </div>

                  <div className="text-[11px] text-slate-500 pt-2 border-t border-slate-800/80 flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>{eko.created_at}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Insights Bento Card */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <h3 className="font-mono font-bold text-white text-xs uppercase tracking-wider">Insights ({filteredInsights.length})</h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-[#0D1117] border border-slate-800 px-2.5 py-1 rounded-full uppercase">Tabela insights</span>
          </div>

          <div className="space-y-3 overflow-y-auto max-h-[420px] pr-1 scrollbar-thin">
            {filteredInsights.length === 0 ? (
              <p className="text-xs font-mono text-slate-500 py-8 text-center">Nenhum insight encontrado.</p>
            ) : (
              filteredInsights.map((ins) => (
                <div
                  key={ins.id}
                  className="p-4 rounded-xl border border-slate-800 bg-[#0D1117] font-mono text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-white font-bold">{ins.theme}</span>
                    <span className="text-[10px] text-slate-500">{ins.id}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 pt-1">
                    <div className="p-2 rounded-lg bg-[#161B22] border border-slate-800/80 text-center">
                      <span className="block text-slate-500 font-bold">NOVIDADE</span>
                      <b className="text-indigo-400 text-xs mt-0.5 block">{(ins.noveltyScore * 100).toFixed(0)}%</b>
                    </div>
                    <div className="p-2 rounded-lg bg-[#161B22] border border-slate-800/80 text-center">
                      <span className="block text-slate-500 font-bold">CONFIANÇA</span>
                      <b className="text-emerald-400 text-xs mt-0.5 block">{(ins.confidence * 100).toFixed(0)}%</b>
                    </div>
                    <div className="p-2 rounded-lg bg-[#161B22] border border-slate-800/80 text-center">
                      <span className="block text-slate-500 font-bold">IMPACTO</span>
                      <b className="text-white text-xs mt-0.5 block">{(ins.impact * 100).toFixed(0)}%</b>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
