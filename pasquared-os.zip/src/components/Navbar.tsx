import React from 'react';
import { Activity, ShieldCheck, Cpu, Database, Home, User, UserCheck, Lock, LogOut } from 'lucide-react';
import { AppViewMode } from '../types';

interface NavbarProps {
  viewMode: AppViewMode;
  setViewMode: (mode: AppViewMode) => void;
  isAdminAuthenticated: boolean;
  onLogoutAdmin: () => void;
  onOpenAdminLogin: () => void;
  systemStatus: 'online' | 'degraded' | 'offline';
  ekosCount: number;
  insightsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  viewMode,
  setViewMode,
  isAdminAuthenticated,
  onLogoutAdmin,
  onOpenAdminLogin,
  systemStatus,
  ekosCount,
  insightsCount,
}) => {
  return (
    <header className="border-b border-slate-800/80 bg-[#0A0C10]/95 backdrop-blur-md sticky top-0 z-50 px-4 md:px-8 py-3.5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div
            onClick={() => setViewMode('landing')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white text-lg shadow-sm group-hover:bg-indigo-500 transition-colors">
              P²
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold tracking-tight text-white text-base md:text-lg">PASQUARED OS</span>
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full bg-slate-800 text-indigo-400 border border-slate-700">
                  v1.0.0
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono uppercase tracking-widest">
                Plataforma de Saúde & Inteligência
              </p>
            </div>
          </div>

          {/* Status Indicator Mobile */}
          <div className="flex md:hidden items-center gap-2 bg-[#161B22] px-3 py-1 rounded-full border border-slate-800 text-xs font-mono">
            <span
              className={`w-2 h-2 rounded-full ${
                systemStatus === 'online' ? 'bg-emerald-500' : 'bg-amber-500'
              }`}
            />
            <span className={systemStatus === 'online' ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
              {systemStatus.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Global Navigation Controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <button
            onClick={() => setViewMode('landing')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
              viewMode === 'landing'
                ? 'bg-indigo-600 border-indigo-500 text-white font-bold'
                : 'bg-[#161B22] border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>Início</span>
          </button>

          <button
            onClick={() => setViewMode('patient_form')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
              viewMode === 'patient_form' || viewMode === 'patient_consultation'
                ? 'bg-indigo-600 border-indigo-500 text-white font-bold'
                : 'bg-[#161B22] border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <User className="w-3.5 h-3.5 text-indigo-400" />
            <span>Paciente (PA)</span>
          </button>

          <button
            onClick={() => setViewMode('doctor_portal')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
              viewMode === 'doctor_portal'
                ? 'bg-emerald-600 border-emerald-500 text-white font-bold'
                : 'bg-[#161B22] border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Doutor (DR)</span>
          </button>

          {isAdminAuthenticated ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setViewMode('admin_dashboard')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
                  viewMode === 'admin_dashboard'
                    ? 'bg-amber-600 border-amber-500 text-white font-bold'
                    : 'bg-[#161B22] border-amber-800/80 text-amber-300 hover:bg-amber-950/60'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Dashboard Admin</span>
              </button>

              <button
                onClick={onLogoutAdmin}
                title="Sair da Área Restrita Admin"
                className="p-1.5 rounded-lg bg-rose-950/60 border border-rose-800/80 text-rose-300 hover:bg-rose-900 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAdminLogin}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-800 bg-[#161B22] text-slate-400 hover:text-amber-300 hover:border-amber-800 transition-colors cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Área Restrita</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

