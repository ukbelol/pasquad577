import React, { useState, useRef, useEffect } from "react";
import { Send, Brain, Database, Activity, ChevronRight, Share2, Info, Layers } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CognitiveState } from "./types";
import { translations } from "./translations";

export default function App() {
  const [messages, setMessages] = useState<{ role: "user" | "assistant", content: string, state?: CognitiveState }[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activeState, setActiveState] = useState<CognitiveState | null>(null);
  const [showDashboard, setShowDashboard] = useState(true);
  const [selectedDomain, setSelectedDomain] = useState("General");
  const [selectedImage, setSelectedImage] = useState<{ data: string, mimeType: string } | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminStats, setAdminStats] = useState<any>(null);
  const [lang, setLang] = useState("pt");
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = translations[lang] || translations.en;

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const res = await fetch("/api/config");
        const data = await res.json();
        if (data.lang) setLang(data.lang);
      } catch (e) { console.error("Config error:", e); }
    };
    fetchConfig();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (isAdmin) {
      const fetchStats = async () => {
        try {
          const res = await fetch("/api/admin/stats");
          const data = await res.json();
          setAdminStats(data);
        } catch (e) { console.error(e); }
      };
      fetchStats();
      const interval = setInterval(fetchStats, 5000);
      return () => clearInterval(interval);
    }
  }, [isAdmin]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage({
          data: (reader.result as string).split(',')[1],
          mimeType: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage) return;
    if (isLoading) return;

    // Check for admin login
    if (input === "rogermei577@pasquared.space" && !isAdmin) {
      setMessages(prev => [...prev, { role: "user", content: t.admin_login }]);
      setMessages(prev => [...prev, { role: "assistant", content: t.admin_interface }]);
      setInput("");
      return;
    }
    if (input === "roger577@21121201-Roger" && messages.length > 0 && messages[messages.length-1].content.includes(t.admin_interface.split('.')[0])) {
      setIsAdmin(true);
      setMessages(prev => [...prev, { role: "assistant", content: t.access_granted }]);
      setInput("");
      return;
    }

    const userMessage = input;
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMessage + (selectedImage ? " [Image Attached]" : "") }]);
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          message: userMessage || (selectedImage ? "Analyze this image." : ""), 
          domain: selectedDomain,
          image: selectedImage,
          language: lang
        }),
      });

      const data = await response.json();
      setMessages(prev => [...prev, { role: "assistant", content: data.response, state: data.state }]);
      setActiveState(data.state);
      setSelectedImage(null);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { role: "assistant", content: "Error: Could not connect to Pasquared Kernel." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#050507] text-[#e0e0e6] font-sans overflow-hidden">
      {/* Sidebar / Memory Clusters */}
      <div className="w-64 border-r border-white/5 bg-[#0a0a0c] flex flex-col hidden md:flex">
        <div className="p-6">
          <button className="w-full py-3 px-4 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3 hover:bg-white/10 transition-colors group">
            <div className="w-5 h-5 border-2 border-dashed border-cyan-400 rounded-full animate-[spin_10s_linear_infinite]" />
            <span className="text-sm font-medium">{t.new_conversation}</span>
          </button>
        </div>
        
        <div className="flex-1 px-4 py-2 space-y-6">
          <div>
            <p className="px-2 text-[10px] uppercase tracking-widest text-white/30 font-bold mb-4">{t.knowledge_clusters}</p>
            <div className="space-y-1">
              {["Medicine", "Law", "Physics", "History", "Logic"].map(cluster => (
                <button 
                  key={cluster} 
                  onClick={() => setSelectedDomain(cluster)}
                  className={`w-full text-left px-3 py-2 rounded-md transition-colors flex items-center justify-between group ${selectedDomain === cluster ? 'bg-cyan-500/20 text-cyan-400' : 'hover:bg-white/5 text-white/60 hover:text-white'}`}
                >
                  {cluster}
                  <ChevronRight size={14} className={`${selectedDomain === cluster ? 'opacity-100' : 'opacity-0'} group-hover:opacity-100 transition-opacity text-cyan-500`} />
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <p className="px-2 text-[10px] uppercase tracking-widest text-white/30 font-bold mb-4">{t.recent_abstractions}</p>
            <div className="space-y-2">
              <div className="p-3 rounded-lg bg-white/5 border-l-2 border-cyan-500/50 text-xs truncate">
                <p className="text-white/80">Quantum Interpretations</p>
                <p className="text-[10px] text-white/30 mt-1">2 mins ago</p>
              </div>
              <div className="p-3 rounded-lg hover:bg-white/5 text-xs truncate text-white/60">
                <p>Legal Precedent Analysis</p>
                <p className="text-[10px] text-white/20 mt-1">1 hour ago</p>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-white/5">
          <div className="flex items-center gap-3 p-2 rounded-xl bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-white/5">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-purple-500 flex items-center justify-center text-xs font-bold text-black">JD</div>
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-semibold truncate">UK Belol</p>
              <p className="text-[10px] text-white/40">Pasquared-OS v1.6</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col relative bg-[#050507]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(56,189,248,0.08)_0%,transparent_50%)] pointer-events-none"></div>
        
        <header className="h-16 flex items-center justify-between px-8 z-10 border-b border-white/5">
          <div className="flex items-center gap-3">
            <span className="text-xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white via-cyan-400 to-purple-400">PASQUARED</span>
            <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-[10px] text-cyan-300 border border-cyan-500/30 font-bold">V1.6 ALPHA</span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowDashboard(!showDashboard)}
              className={`p-2 rounded-xl transition-all ${showDashboard ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' : 'hover:bg-white/5 text-white/40'}`}
            >
              <Activity size={18} />
            </button>
            <div className="h-4 w-[1px] bg-white/10" />
            <div className="text-right hidden sm:block">
              <p className="text-[10px] text-white/40 uppercase tracking-tighter font-bold">{t.kernel_status}</p>
              <p className="text-xs font-mono text-cyan-400">{t.operational}</p>
            </div>
          </div>
        </header>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-10 scroll-smooth z-0">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto space-y-12">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-600 to-purple-700 flex items-center justify-center shadow-[0_0_30px_rgba(34,211,238,0.3)]"
              >
                <Brain size={40} className="text-white" />
              </motion.div>
              <div className="space-y-4">
                <h1 className="text-5xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white via-cyan-400 to-purple-400">
                  {t.nexus_cognitive}
                </h1>
                <p className="text-white/40 text-lg font-light tracking-wide max-w-md mx-auto">
                  {t.distributed_arch}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4 w-full max-w-xl">
                {[
                  "Analyze medical cross-interactions",
                  "Synthesize logical interpretations",
                  "Verify temporal causalities",
                  "Query knowledge clusters"
                ].map((prompt, i) => (
                  <button 
                    key={i} 
                    onClick={() => setInput(prompt)}
                    className="p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/10 transition-all text-sm text-white/50 text-left group"
                  >
                    <span className="group-hover:text-cyan-400 transition-colors">{prompt}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={i} 
              className={`flex items-start gap-5 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
            >
              <div className={`w-10 h-10 rounded-lg flex-shrink-0 flex items-center justify-center font-bold shadow-lg ${
                msg.role === "user" 
                  ? "bg-white/10 text-white" 
                  : "bg-gradient-to-br from-cyan-600 to-purple-700 text-white shadow-[0_0_15px_rgba(34,211,238,0.4)]"
              }`}>
                {msg.role === "user" ? "👤" : "N"}
              </div>
              
              <div className={`max-w-[70%] space-y-4`}>
                <div className={`p-5 rounded-2xl text-sm leading-relaxed ${
                  msg.role === "user" 
                    ? "bg-white/5 border border-white/10 text-white/80 rounded-tr-none" 
                    : "bg-white/5 border border-white/10 text-white/90 rounded-tl-none shadow-2xl"
                }`}>
                  {msg.role === "assistant" && (
                    <div className="flex items-center gap-2 mb-3 text-[10px] font-bold uppercase tracking-widest text-cyan-400">
                      <Brain size={12} />
                      <span>{t.neural_output}</span>
                    </div>
                  )}
                  <div className="whitespace-pre-wrap">
                    {msg.content}
                  </div>
                </div>

                {msg.state && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                      <h4 className="text-[10px] font-bold text-cyan-400 uppercase mb-1">IGA</h4>
                      <p className="text-xs font-mono text-white/60">{(msg.state.iga * 100).toFixed(1)}% {t.abstraction_level}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                      <h4 className="text-[10px] font-bold text-purple-400 uppercase mb-1">ICI</h4>
                      <p className="text-xs font-mono text-white/60">{(msg.state.ici * 100).toFixed(1)}% {t.validation_level}</p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
          
          {isLoading && (
            <div className="flex items-start gap-5">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-600 to-purple-700 flex-shrink-0 flex items-center justify-center shadow-[0_0_15px_rgba(34,211,238,0.4)] animate-pulse">
                <span className="text-white font-bold">N</span>
              </div>
              <div className="space-y-2 py-2">
                <p className="text-sm italic text-cyan-300/80 animate-pulse">{t.processing}</p>
                <div className="flex gap-1.5">
                  <div className="w-2 h-2 bg-cyan-500/40 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                  <div className="w-2 h-2 bg-cyan-500/40 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  <div className="w-2 h-2 bg-cyan-500/40 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-8 bg-gradient-to-t from-[#050507] via-[#050507]/95 to-transparent">
          <div className="max-w-3xl mx-auto relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 blur-xl opacity-50"></div>
            <div className="relative flex flex-col bg-[#0f0f12] border border-white/10 rounded-2xl p-2 shadow-2xl">
              {selectedImage && (
                <div className="px-4 py-2 flex items-center gap-2">
                  <div className="w-12 h-12 rounded bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden">
                    <img src={`data:${selectedImage.mimeType};base64,${selectedImage.data}`} alt="Preview" className="object-cover w-full h-full" />
                  </div>
                  <button onClick={() => setSelectedImage(null)} className="text-[10px] text-red-400 uppercase font-bold hover:text-red-300">{t.remove_image}</button>
                </div>
              )}
              <div className="flex items-center">
                <input 
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder={selectedDomain === 'Medicine' ? t.medicine_placeholder : t.query_placeholder}
                  className="flex-1 bg-transparent border-none outline-none text-sm px-4 text-white placeholder:text-white/20 py-3"
                />
                <div className="flex items-center gap-2 pr-2">
                  <input 
                    type="file" 
                    className="hidden" 
                    ref={fileInputRef} 
                    onChange={handleImageUpload}
                    accept="image/*"
                  />
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2 hover:bg-white/5 rounded-lg text-white/40 transition-colors"
                  >
                    📎
                  </button>
                  <button 
                    onClick={handleSend}
                    disabled={isLoading || (!input.trim() && !selectedImage)}
                    className="bg-white text-black px-4 py-2 rounded-xl text-sm font-bold shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:scale-105 active:scale-95 transition-all disabled:opacity-20 disabled:scale-100"
                  >
                    <Send size={18} strokeWidth={2.5} />
                  </button>
                </div>
              </div>
            </div>
            <p className="text-center text-[10px] text-white/20 mt-4 tracking-tight uppercase font-medium">
              {selectedDomain === 'Medicine' ? "PASQUARED Medical Engine • High-Fidelity Diagnostics Cluster Active" : t.hallucination_warning}
            </p>
          </div>
        </div>
      </main>

      {/* Cognitive Dashboard Sidebar */}
      <AnimatePresence>
        {showDashboard && (
          <motion.div 
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 350, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className="border-l border-white/5 bg-[#0a0a0c] overflow-hidden flex flex-col"
          >
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded bg-cyan-500/20 flex items-center justify-center">
                  <Layers size={14} className="text-cyan-400" />
                </div>
                <h2 className="font-bold text-xs uppercase tracking-widest text-white/80">{t.dashboard}</h2>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold uppercase border border-cyan-500/30">Live</span>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8 scroll-smooth">
              {isAdmin && adminStats ? (
                <div className="space-y-8">
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest">{t.global_monitor}</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white/[0.03] rounded-xl p-4 border border-cyan-500/20">
                        <span className="text-[8px] text-white/40 uppercase font-bold">{t.requests_min}</span>
                        <p className="text-xl font-mono font-bold text-white/90">{adminStats.globalMetrics.requestsPerMinute}</p>
                      </div>
                      <div className="bg-white/[0.03] rounded-xl p-4 border border-purple-500/20">
                        <span className="text-[8px] text-white/40 uppercase font-bold">{t.uptime}</span>
                        <p className="text-xs font-mono font-bold text-white/90">{adminStats.globalMetrics.uptime}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-white/30 uppercase tracking-widest">{t.active_clusters}</h3>
                    <div className="space-y-3">
                      {adminStats.clusters.map((c: any, i: number) => (
                        <div key={i} className="bg-white/[0.03] rounded-xl p-4 border border-white/5">
                          <div className="flex justify-between items-center mb-3">
                            <span className="text-xs font-bold text-white/80">{c.name}</span>
                            <span className={`text-[8px] px-1.5 py-0.5 rounded border ${c.status === 'Active' ? 'text-green-400 border-green-400/20 bg-green-400/10' : 'text-yellow-400 border-yellow-400/20 bg-yellow-400/10'}`}>
                              {c.status}
                            </span>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="flex-1">
                              <div className="flex justify-between text-[8px] text-white/30 uppercase font-bold mb-1">
                                <span>{t.load}</span>
                                <span>{c.load.toFixed(0)}%</span>
                              </div>
                              <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                                <motion.div animate={{ width: `${c.load}%` }} className="h-full bg-cyan-500" />
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-[8px] text-white/30 uppercase font-bold block">{t.workers}</span>
                              <span className="text-xs font-mono text-white/60">{c.workers}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <button onClick={() => setIsAdmin(false)} className="w-full py-2 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] uppercase font-bold rounded-lg hover:bg-red-500/20 transition-all">
                    {t.logout_admin}
                  </button>
                </div>
              ) : activeState ? (
                <>
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-white/30 uppercase tracking-widest">{t.performance_indices}</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white/[0.03] rounded-xl p-4 border border-white/5">
                        <div className="flex items-center gap-2 mb-2">
                          <Activity size={12} className="text-cyan-400" />
                          <span className="text-[10px] text-white/40 uppercase font-bold">IGA</span>
                        </div>
                        <p className="text-2xl font-mono font-bold text-white/90">{(activeState.iga * 100).toFixed(1)}%</p>
                        <div className="w-full h-1 bg-white/5 rounded-full mt-3 overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${activeState.iga * 100}%` }}
                            className="h-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.5)]"
                          />
                        </div>
                      </div>
                      <div className="bg-white/[0.03] rounded-xl p-4 border border-white/5">
                        <div className="flex items-center gap-2 mb-2">
                          <Info size={12} className="text-purple-400" />
                          <span className="text-[10px] text-white/40 uppercase font-bold">ICI</span>
                        </div>
                        <p className="text-2xl font-mono font-bold text-white/90">{(activeState.ici * 100).toFixed(1)}%</p>
                        <div className="w-full h-1 bg-white/5 rounded-full mt-3 overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${activeState.ici * 100}%` }}
                            className="h-full bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-white/30 uppercase tracking-widest">{t.active_hypotheses}</h3>
                    <div className="space-y-3">
                      {activeState.hypotheses.map((h, i) => (
                        <div key={i} className="bg-white/[0.03] rounded-xl p-4 border border-white/5 space-y-4">
                          <div className="flex justify-between items-start">
                            <h4 className="text-sm font-medium text-white/80 leading-tight pr-4">{h.description}</h4>
                            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-400/10 px-1.5 py-0.5 rounded border border-cyan-400/20">{(h.probability).toFixed(2)}</span>
                          </div>
                          <div className="grid grid-cols-5 gap-1 pt-2 border-t border-white/5">
                            {Object.entries(h.vectors).map(([key, val]) => (
                              <div key={key} className="flex flex-col items-center gap-1.5">
                                <div className="w-1.5 h-10 bg-white/5 rounded-full relative overflow-hidden">
                                  <motion.div 
                                    initial={{ height: 0 }}
                                    animate={{ height: `${(val as number) * 100}%` }}
                                    className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-purple-500 to-cyan-400" 
                                  />
                                </div>
                                <span className="text-[8px] text-white/20 uppercase font-bold">{key[0]}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-white/30 uppercase tracking-widest">{t.neural_map}</h3>
                    <div className="bg-[#050507] rounded-xl p-4 border border-white/5 relative h-64 overflow-hidden flex items-center justify-center">
                      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(56,189,248,0.05)_0%,transparent_70%)]" />
                      <div className="relative w-full h-full">
                        {activeState.activeGraph.nodes.map((node, i) => {
                          const angle = (i / activeState.activeGraph.nodes.length) * Math.PI * 2;
                          const r = 65;
                          const x = Math.cos(angle) * r + 110;
                          const y = Math.sin(angle) * r + 100;
                          
                          return (
                            <motion.div 
                              key={node.uid}
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ delay: i * 0.05 }}
                              className="absolute w-12 h-12 rounded-xl border border-white/10 bg-white/5 flex flex-col items-center justify-center cursor-help group/node hover:border-cyan-500/50 hover:bg-cyan-500/5 transition-all shadow-xl"
                              style={{ left: x, top: y }}
                            >
                              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 mb-1 shadow-[0_0_5px_rgba(34,211,238,0.8)]" />
                              <span className="text-[8px] font-bold text-center px-1 truncate w-full text-white/40">
                                {node.content}
                              </span>
                              <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-[#0f0f12] text-[10px] px-2 py-1 rounded border border-white/10 opacity-0 group-hover/node:opacity-100 transition-opacity z-20 whitespace-nowrap shadow-2xl">
                                {node.content} <span className="text-white/30 ml-1">{node.type}</span>
                              </div>
                            </motion.div>
                          );
                        })}
                        <div className="absolute inset-0 border border-cyan-500/[0.03] rounded-full m-12 animate-[spin_30s_linear_infinite]" />
                        <div className="absolute inset-0 border border-purple-500/[0.03] rounded-full m-6 animate-[spin_45s_linear_infinite_reverse]" />
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-30">
                  <Database size={48} strokeWidth={1} />
                  <p className="text-xs uppercase tracking-widest font-bold">{t.waiting_input}</p>
                </div>
              )}
            </div>

            <div className="p-6 border-t border-white/5 bg-gradient-to-br from-cyan-500/5 to-purple-500/5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-cyan-400 shadow-inner">
                  <Brain size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-white/80 uppercase tracking-widest">{t.ucl_protocol}</p>
                  <p className="text-[10px] text-white/30">Active • 128-bit Neural Stream</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
