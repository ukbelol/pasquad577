import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { LandingView } from './components/LandingView';
import { PatientFormView } from './components/PatientFormView';
import { PatientAuthPortal } from './components/PatientAuthPortal';
import { PatientConsultationView } from './components/PatientConsultationView';
import { DoctorPortalView } from './components/DoctorPortalView';
import { DoctorAuthPortal } from './components/DoctorAuthPortal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { MsFoundrySettingsCard } from './components/MsFoundrySettingsCard';
import { MedicalKnowledgeBasesCard } from './components/MedicalKnowledgeBasesCard';
import { SuperAdminSettingsCard } from './components/SuperAdminSettingsCard';
import { DashboardTab } from './components/DashboardTab';
import { PqlConsoleTab } from './components/PqlConsoleTab';
import { AssistantTab } from './components/AssistantTab';
import { CatalogTab } from './components/CatalogTab';
import { UclGeneratorTab } from './components/UclGeneratorTab';
import { InstallerScriptTab } from './components/InstallerScriptTab';
import {
  ServiceHealth,
  EKOItem,
  InsightItem,
  UCLObject,
  AppViewMode,
  PatientData,
} from './types';
import {
  Activity,
  Terminal,
  Stethoscope,
  Database,
  FileJson,
  FileCode,
  Lock,
} from 'lucide-react';

export default function App() {
  const [viewMode, setViewMode] = useState<AppViewMode>('landing');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [systemStatus, setSystemStatus] = useState<'online' | 'degraded'>('online');
  const [isSimulating, setIsSimulating] = useState(false);

  // Super Admin Auth State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);

  // Patient Registration State
  const [currentPatient, setCurrentPatient] = useState<PatientData | null>(null);

  // Initial Services Health
  const [services, setServices] = useState<ServiceHealth[]>([
    { name: 'Gateway', port: 3000, status: 'online', latencyMs: 12, role: 'API Proxy & Triagem' },
    { name: 'PCK', port: 3010, status: 'online', latencyMs: 18, role: 'Processador Cognitivo' },
    { name: 'USR', port: 3020, status: 'online', latencyMs: 14, role: 'Validador de Esquema UCL' },
    { name: 'MVED', port: 3030, status: 'online', latencyMs: 15, role: 'Motor de Validação de Evidências' },
    { name: 'SMEE', port: 3040, status: 'online', latencyMs: 22, role: 'Persistência PostgreSQL 16' },
    { name: 'Catalog', port: 3050, status: 'online', latencyMs: 16, role: 'Catálogo de EKOs & Insights' },
  ]);

  // Initial EKOs Mock Data
  const [ekos, setEkos] = useState<EKOItem[]>([
    {
      id: 'EKO-m28k1a-9f',
      domain: 'Medicina',
      status: 'parcialmente-validado',
      confidence: 0.88,
      created_at: '2026-08-11 18:30',
      hypotheses: [
        { id: 'H-01', description: 'Uso de Anticoagulants reduz taxa de AVC', domain: 'Medicina' },
        { id: 'H-02', description: 'Monitorar tempo de protrombina em terapia contínua', domain: 'Medicina' },
      ],
    },
    {
      id: 'EKO-k91s4z-3a',
      domain: 'Geral',
      status: 'validado',
      confidence: 0.95,
      created_at: '2026-08-11 17:45',
      hypotheses: [
        { id: 'H-03', description: 'Estruturas de informação reduzem desordem semântica', domain: 'Geral' },
      ],
    },
  ]);

  // Initial Insights Mock Data
  const [insights, setInsights] = useState<InsightItem[]>([
    {
      id: 'INS-a91s0-x1',
      ekoId: 'EKO-m28k1a-9f',
      category: 'Medicina',
      theme: 'Anticoagulação na Fibrilação Atrial',
      noveltyScore: 0.82,
      confidence: 0.88,
      impact: 0.91,
      created_at: '2026-08-11 18:31',
    },
    {
      id: 'INS-k02d1-b2',
      ekoId: 'EKO-k91s4z-3a',
      category: 'Geral',
      theme: 'Entropia de Informação UCL',
      noveltyScore: 0.76,
      confidence: 0.95,
      impact: 0.84,
      created_at: '2026-08-11 17:46',
    },
  ]);

  const handleSelectViewMode = (mode: AppViewMode) => {
    if (mode === 'admin_dashboard' && !isAdminAuthenticated) {
      setIsAdminLoginOpen(true);
    } else {
      setViewMode(mode);
    }
  };

  const handleAdminLoginSuccess = () => {
    setIsAdminAuthenticated(true);
    setIsAdminLoginOpen(false);
    setViewMode('admin_dashboard');
  };

  const handleLogoutAdmin = () => {
    setIsAdminAuthenticated(false);
    setViewMode('landing');
  };

  const handleStartConsultation = (patient: PatientData) => {
    setCurrentPatient(patient);
    setViewMode('patient_consultation');
  };

  const handleFinishConsultation = () => {
    setViewMode('doctor_portal');
  };

  const handleRefreshServices = () => {
    setServices((prev) =>
      prev.map((s) => ({
        ...s,
        latencyMs: Math.floor(Math.random() * 15) + 10,
        status: 'online',
      }))
    );
    setSystemStatus('online');
  };

  const handleSimulateCycle = () => {
    setIsSimulating(true);

    setTimeout(() => {
      const newEkoId = `EKO-${Math.random().toString(36).slice(2, 8)}`;
      const newEko: EKOItem = {
        id: newEkoId,
        domain: 'Medicina',
        status: 'validado',
        confidence: Number((0.85 + Math.random() * 0.12).toFixed(2)),
        created_at: new Date().toISOString().replace('T', ' ').slice(0, 16),
        hypotheses: [
          { id: `H-${Date.now().toString().slice(-3)}`, description: 'Hipótese gerada pelo simulador PCK', domain: 'Medicina' },
        ],
      };

      const newInsight: InsightItem = {
        id: `INS-${Math.random().toString(36).slice(2, 7)}`,
        ekoId: newEkoId,
        category: 'Medicina',
        theme: 'Análise sintomática e validação MVED',
        noveltyScore: Number(Math.random().toFixed(2)),
        confidence: newEko.confidence,
        impact: Number(Math.random().toFixed(2)),
        created_at: new Date().toISOString().replace('T', ' ').slice(0, 16),
      };

      setEkos((prev) => [newEko, ...prev]);
      setInsights((prev) => [newInsight, ...prev]);
      setIsSimulating(false);
    }, 800);
  };

  const handleProcessUCL = (ucl: UCLObject) => {
    const newEkoId = `EKO-${Math.random().toString(36).slice(2, 8)}`;
    const newEko: EKOItem = {
      id: newEkoId,
      domain: ucl.Category || 'Geral',
      status: 'validado',
      confidence: ucl.Confidence || 0.9,
      created_at: new Date().toISOString().replace('T', ' ').slice(0, 16),
      hypotheses: [
        { id: `H-01`, description: `Hipótese para ${ucl.Theme}`, domain: ucl.Category || 'Geral' },
      ],
    };

    const newInsight: InsightItem = {
      id: `INS-${Math.random().toString(36).slice(2, 7)}`,
      ekoId: newEkoId,
      category: ucl.Category || 'Geral',
      theme: ucl.Theme || 'Tema UCL Processado',
      noveltyScore: Number(Math.random().toFixed(2)),
      confidence: newEko.confidence,
      impact: Number(Math.random().toFixed(2)),
      created_at: new Date().toISOString().replace('T', ' ').slice(0, 16),
    };

    setEkos((prev) => [newEko, ...prev]);
    setInsights((prev) => [newInsight, ...prev]);
  };

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'pql', label: 'PQL Console', icon: Terminal },
    { id: 'assistant', label: 'Assistente', icon: Stethoscope },
    { id: 'catalog', label: 'Catálogo', icon: Database },
    { id: 'ucl', label: 'Validador UCL', icon: FileJson },
    { id: 'installer', label: 'Instalador install-geral.sh', icon: FileCode },
  ];

  return (
    <div className="min-h-screen bg-[#0A0C10] text-slate-200 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Navigation Header */}
      <Navbar
        viewMode={viewMode}
        setViewMode={handleSelectViewMode}
        isAdminAuthenticated={isAdminAuthenticated}
        onLogoutAdmin={handleLogoutAdmin}
        onOpenAdminLogin={() => setIsAdminLoginOpen(true)}
        systemStatus={systemStatus}
        ekosCount={ekos.length}
        insightsCount={insights.length}
      />

      {/* Super Admin Login Modal */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        onSuccess={handleAdminLoginSuccess}
      />

      {/* Main Content Router */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-8 py-6 space-y-6">
        {/* LANDING PAGE VIEW */}
        {viewMode === 'landing' && (
          <LandingView
            onSelectRole={handleSelectViewMode}
            onOpenAdminLogin={() => setIsAdminLoginOpen(true)}
          />
        )}

        {/* PATIENT AUTHENTICATION & PORTAL VIEW (PA) */}
        {viewMode === 'patient_form' && (
          <PatientAuthPortal
            onStartConsultation={handleStartConsultation}
            onBackToLanding={() => setViewMode('landing')}
          />
        )}

        {/* PATIENT INTERACTIVE AI CONSULTATION VIEW */}
        {viewMode === 'patient_consultation' && currentPatient && (
          <PatientConsultationView
            patient={currentPatient}
            onFinishConsultation={handleFinishConsultation}
            onBackToForm={() => setViewMode('patient_form')}
          />
        )}

        {/* DOCTOR AUTHENTICATION & REVIEW PORTAL VIEW (DR) */}
        {viewMode === 'doctor_portal' && (
          <DoctorAuthPortal onBackToLanding={() => setViewMode('landing')} />
        )}

        {/* RESTRICTED SUPER ADMIN DASHBOARD */}
        {viewMode === 'admin_dashboard' && isAdminAuthenticated && (
          <div className="space-y-6">
            {/* Global Super Admin Settings Card with All Configurations Saved Persistently */}
            <SuperAdminSettingsCard />

            {/* Medical Knowledge Bases Across Americas (South, Central, North) Card */}
            <MedicalKnowledgeBasesCard />

            {/* Microsoft Foundry Key Settings Bento Card */}
            <MsFoundrySettingsCard />

            {/* Dashboard Module Tabs */}
            <div className="flex gap-2 p-1.5 bg-[#161B22] border border-slate-800 rounded-2xl overflow-x-auto scrollbar-none">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all whitespace-nowrap cursor-pointer ${
                      isActive
                        ? 'bg-amber-600 text-white shadow-md border border-amber-500/50'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Dynamic Tab Views */}
            {activeTab === 'dashboard' && (
              <DashboardTab
                services={services}
                onRefreshServices={handleRefreshServices}
                onSimulateCycle={handleSimulateCycle}
                isSimulating={isSimulating}
              />
            )}

            {activeTab === 'pql' && <PqlConsoleTab />}

            {activeTab === 'assistant' && <AssistantTab />}

            {activeTab === 'catalog' && <CatalogTab ekos={ekos} insights={insights} />}

            {activeTab === 'ucl' && <UclGeneratorTab onProcessUCL={handleProcessUCL} />}

            {activeTab === 'installer' && <InstallerScriptTab />}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-[#0A0C10] py-6 text-center text-xs font-mono text-slate-500">
        © PASQUARED OS · Plataforma de Inteligência Médica · Debian 12 · PostgreSQL 16
      </footer>
    </div>
  );
}

