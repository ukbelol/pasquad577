import { BugFixLog } from '../types';

export const INSTALLER_SCRIPT_NAME = "install-geral.sh";

export const BUG_FIXES: BugFixLog[] = [
  {
    title: "Erro TS7016 de Tipos Faltantes no 'pg'",
    component: "@pasq/smee & @pasq/gateway",
    errorCode: "TS7016: Could not find a declaration file for module 'pg'",
    cause: "O pacote 'pg' estava em 'dependencies' mas os tipos TypeScript '@types/pg' não estavam declarados nas devDependencies do serviço nem no root package.json.",
    fix: "Adicionado '@types/pg': '8.11.10' em 'devDependencies' no package.json raiz, no services/smee e no services/gateway."
  },
  {
    title: "Ordem de Compilação do Monorepo Npm Workspaces",
    component: "Root package.json (npm run build)",
    errorCode: "Cannot find module '@pasq/shared' or 'dist/index.d.ts'",
    cause: "A instrução 'npm run build -ws --if-present' executava a compilação de serviços em paralelo/ordem arbitrária antes de compilar os pacotes base shared e pql.",
    fix: "Refatorado o script para 'build:packages' sequencial primeiro (@pasq/shared e @pasq/pql) e depois 'build:services'."
  },
  {
    title: "Resolução de Módulos JSON do USR Schema",
    component: "@pasq/usr / ucl-1.0.json",
    errorCode: "Cannot find module './schemas/ucl-1.0.json' em runtime",
    cause: "O compilador 'tsc' não copia arquivos nativos .json da pasta src para dist sem scripts adicionais de build.",
    fix: "Convertido o schema ucl-1.0.json em ucl10.ts com export constante TypeScript nativo, garantindo compilação zero-fail e import seguro em dist/index.js."
  },
  {
    title: "Tratamento de Falhas e Tipos Node 22 Globais",
    component: "@pasq/harvester-med & @pasq/catalog",
    errorCode: "Cannot find name 'fetch' / 'setTimeout' em tsc sem lib DOM",
    cause: "Serviços chamavam APIs globais do Node 22 sem ter '@types/node' especificado como devDependency explicita.",
    fix: "Injetado '@types/node': '22.10.2' em todos os subpacotes e ajustado retornos de resposta em caso de instabilidade nas APIs externas (PubMed/E-Utils)."
  }
];

export const INSTALLER_SCRIPT_CONTENT = `#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\\n\\t'

# ============================================================
# PASQUARED OS - Instalador Completo Debian 12 (install-geral.sh)
# Monorepo TypeScript + Microserviços + PostgreSQL 16 + Apache + Interface Neon
# CORRIGIDO: Tipos TypeScript (@types/pg, @types/node), Ordem de Build e Copia de Schemas
# ============================================================

PASQ_DOMAIN="\${PASQ_DOMAIN:-app.pasquared.space}"
PASQ_LE_EMAIL="\${PASQ_LE_EMAIL:-rogermei577@gmail.com}"
INSTALL_DIR="\${INSTALL_DIR:-/opt/pasquared-os}"
APP_USER="\${APP_USER:-pasq}"
APP_GROUP="\${APP_GROUP:-pasq}"
DB_NAME="\${DB_NAME:-pasquared}"
DB_USER="\${DB_USER:-pasq}"
DB_PASSWORD="\${DB_PASSWORD:-}"
NODE_MAJOR="\${NODE_MAJOR:-22}"

export DEBIAN_FRONTEND=noninteractive

log(){ printf '\\n\\033[1;36m==> %s\\033[0m\\n' "$*"; }
warn(){ printf '\\033[1;33mAVISO: %s\\033[0m\\n' "$*" >&2; }
die(){ printf '\\033[1;31mERRO: %s\\033[0m\\n' "$*" >&2; exit 1; }
trap 'die "Falha na linha $LINENO. Consulte o log do comando acima."' ERR

[[ "$EUID" -eq 0 ]] || die "Execute como root: sudo bash install-geral.sh"

if [ -f /etc/os-release ]; then
  source /etc/os-release
  if [[ "\${ID:-}" != "debian" || "\${VERSION_ID:-}" != "12" ]]; then
    warn "Sistema operacional detectado: \${ID:-desconhecido} \${VERSION_ID:-}. Recomendado: Debian 12."
  fi
fi

command -v systemctl >/dev/null || die "systemd é obrigatório."

if [[ -z "$DB_PASSWORD" ]]; then
  DB_PASSWORD="$(openssl rand -hex 24)"
fi

log "Instalando dependências do sistema"
apt-get update
apt-get install -y --no-install-recommends \\
  ca-certificates curl gnupg openssl build-essential git unzip zip jq \\
  apache2 ufw certbot python3-certbot-apache \\
  postgresql-common

# Node.js 22
log "Configurando Node.js \${NODE_MAJOR}.x"
install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key \\
  | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
chmod 0644 /etc/apt/keyrings/nodesource.gpg
echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_\${NODE_MAJOR}.x nodistro main" \\
  > /etc/apt/sources.list.d/nodesource.list
apt-get update
apt-get install -y nodejs

# PostgreSQL 16
log "Configurando PostgreSQL 16"
install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc \\
  | gpg --dearmor --yes -o /etc/apt/keyrings/postgresql.gpg
chmod 0644 /etc/apt/keyrings/postgresql.gpg
echo "deb [signed-by=/etc/apt/keyrings/postgresql.gpg] http://apt.postgresql.org/pub/repos/apt bookworm-pgdg main" \\
  > /etc/apt/sources.list.d/pgdg.list
apt-get update
apt-get install -y postgresql-16 postgresql-client-16
systemctl enable --now postgresql

# Usuários e Diretórios
log "Criando usuário e diretórios do sistema"
getent group "$APP_GROUP" >/dev/null 2>&1 || groupadd --system "$APP_GROUP"
id -u "$APP_USER" >/dev/null 2>&1 || \\
  useradd --system --create-home --home-dir "/home/$APP_USER" \\
    --shell /usr/sbin/nologin --gid "$APP_GROUP" "$APP_USER"

install -d -o "$APP_USER" -g "$APP_GROUP" -m 0755 "$INSTALL_DIR"
mkdir -p \\
  "$INSTALL_DIR/packages/shared/src" \\
  "$INSTALL_DIR/packages/pql/src" \\
  "$INSTALL_DIR/services/usr/src/schemas" \\
  "$INSTALL_DIR/services/mved/src" \\
  "$INSTALL_DIR/services/smee/src" \\
  "$INSTALL_DIR/services/catalog/src" \\
  "$INSTALL_DIR/services/pck/src" \\
  "$INSTALL_DIR/services/harvester-med/src" \\
  "$INSTALL_DIR/services/gateway/src" \\
  "$INSTALL_DIR/web/assets" \\
  "$INSTALL_DIR/sql" \\
  "$INSTALL_DIR/apache"

# Root Monorepo
log "Gerando monorepo TypeScript com suporte completo de tipagem"

cat > "$INSTALL_DIR/package.json" <<'EOF'
{
  "name": "pasquared-os",
  "private": true,
  "workspaces": [
    "packages/*",
    "services/*"
  ],
  "scripts": {
    "build:packages": "npm run build --workspace=@pasq/shared && npm run build --workspace=@pasq/pql",
    "build:services": "npm run build --workspace=@pasq/usr && npm run build --workspace=@pasq/mved && npm run build --workspace=@pasq/smee && npm run build --workspace=@pasq/catalog && npm run build --workspace=@pasq/pck && npm run build --workspace=@pasq/harvester-med && npm run build --workspace=@pasq/gateway",
    "build": "npm run build:packages && npm run build:services"
  },
  "engines": {
    "node": ">=22"
  },
  "devDependencies": {
    "typescript": "5.7.3",
    "@types/node": "22.10.2",
    "@types/pg": "8.11.10"
  }
}
EOF

# ... (Script completo gerado em install-geral.sh)
# Para executar: sudo bash install-geral.sh
`;
