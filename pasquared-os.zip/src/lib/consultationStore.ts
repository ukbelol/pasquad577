import { ConsultationRecord, MsFoundryConfig, PatientData, SuperAdminGlobalConfig } from '../types';

const CONSULTATIONS_STORAGE_KEY = 'pasquared_consultations_v1';
const MS_CONFIG_STORAGE_KEY = 'pasquared_ms_foundry_config_v1';
const GLOBAL_ADMIN_STORAGE_KEY = 'pasquared_admin_global_config_v1';

// Initial sample consultation for demo doctor search
const SAMPLE_CONSULTATIONS: ConsultationRecord[] = [
  {
    id: 'CONS-92810',
    patient: {
      nome: 'Carlos',
      sobrenome: 'Eduardo Silva',
      dataNascimento: '1985-06-14',
      cpf: '123.456.789-00',
    },
    messages: [
      {
        id: 'm1',
        sender: 'ai',
        text: 'Olá, Carlos! Sou o Auxiliar de Consulta do Pasquared OS. Vou fazer algumas perguntas investigativas, uma por vez, para entender melhor a sua queixa de saúde. Para começar: Qual é a sua queixa principal ou sintoma hoje?',
        timestamp: '18:10',
        isQuestion: true,
      },
      {
        id: 'm2',
        sender: 'patient',
        text: 'Estou sentindo uma dor de cabeça forte há 3 dias e visão um pouco embaçada quando leio.',
        timestamp: '18:11',
      },
      {
        id: 'm3',
        sender: 'ai',
        text: 'Entendido. Pergunta 2: Em uma escala de 1 a 10, qual é a intensidade dessa cefaleia? A dor é pulsátil, em aperto ou pontada?',
        timestamp: '18:12',
        isQuestion: true,
      },
      {
        id: 'm4',
        sender: 'patient',
        text: 'Nota 7 de 10. Parece uma pressão na testa e nas têmporas.',
        timestamp: '18:13',
      },
      {
        id: 'm5',
        sender: 'ai',
        text: 'Certo. Pergunta 3: Você apresentou febre, rigidez no pescoço, náuseas ou alteração recente da pressão arterial?',
        timestamp: '18:14',
        isQuestion: true,
      },
      {
        id: 'm6',
        sender: 'patient',
        text: 'Tive leve náusea ontem à noite. Sem febre. Minha pressão costuma ser 13 por 8.',
        timestamp: '18:15',
      },
      {
        id: 'm7',
        sender: 'ai',
        text: 'Pergunta 4: Você faz uso contínuo de alguma medicação ou possui diagnóstico prévio de hipertensão/enxaqueca?',
        timestamp: '18:16',
        isQuestion: true,
      },
      {
        id: 'm8',
        sender: 'patient',
        text: 'Tomo Losartana 50mg todos os dias pela manhã.',
        timestamp: '18:17',
      },
    ],
    attachments: [
      {
        id: 'att-1',
        type: 'document',
        name: 'Exame_Pressao_Recente.pdf',
        dataUrl: 'data:application/pdf;base64,JVBERi0xLjQK...',
        uploadedAt: '2026-08-11 18:18',
        size: '1.2 MB',
      },
      {
        id: 'att-2',
        type: 'audio',
        name: 'Relato_Vocal_Sintomas.mp3',
        dataUrl: 'https://actions.google.com/sounds/v1/ambiences/rain_heavy.ogg',
        uploadedAt: '2026-08-11 18:19',
        size: '450 KB',
      },
    ],
    preAssessment: {
      complaintSummary: 'Cefaleia holocraniana/frontal há 3 dias com intensidade 7/10, episódios de náusea e embaçamento visual leve em paciente hipertenso sob Losartana 50mg.',
      investigatedSymptoms: [
        'Cefaleia contínua (3 dias)',
        'Intensidade 7/10 em aperto/pressão',
        'Visão embaçada eventual',
        'Náusea esporádica sem vômitos',
        'Sem rigidez de nuca ou febre',
      ],
      riskLevel: 'AMARELO - Risco Médio / Atenção',
      diagnosticHypotheses: [
        'Cefaleia tensional exacerbada por estresse/fadiga visual',
        'Descontrole pressórico episódico em paciente hipertenso',
        'Enxaqueca sem aura',
      ],
      recommendations: 'Recomendada aferição imediata da pressão arterial, avaliação oftálmica e parecer médico. Evitar automedicação com vasoconstritores.',
      suggestedExamTypes: ['Aferição da Pressão Arterial (MAPA)', 'Fundo de Olho / Tonometria', 'Hemograma Completo'],
      cognitiveConfidence: 0.91,
    },
    status: 'concluida',
    doctorNotes: 'Paciente orientado a manter diário de pressão arterial e retorno em 7 dias.',
    createdAt: '2026-08-11 18:20',
    updatedAt: '2026-08-11 18:25',
  },
];

export function getStoredConsultations(): ConsultationRecord[] {
  try {
    const raw = localStorage.getItem(CONSULTATIONS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(CONSULTATIONS_STORAGE_KEY, JSON.stringify(SAMPLE_CONSULTATIONS));
      return SAMPLE_CONSULTATIONS;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading consultations from storage:', err);
    return SAMPLE_CONSULTATIONS;
  }
}

export function saveConsultation(consultation: ConsultationRecord): void {
  try {
    const current = getStoredConsultations();
    const index = current.findIndex((c) => c.id === consultation.id);
    if (index >= 0) {
      current[index] = consultation;
    } else {
      current.unshift(consultation);
    }
    localStorage.setItem(CONSULTATIONS_STORAGE_KEY, JSON.stringify(current));
  } catch (err) {
    console.error('Error saving consultation to storage:', err);
  }
}

export function findConsultationByCpfAndDob(
  rawCpf: string,
  rawDob: string
): ConsultationRecord | null {
  const consultations = getStoredConsultations();
  const cleanCpf = rawCpf.replace(/\D/g, '');
  const cleanDob = rawDob.trim();

  return (
    consultations.find((c) => {
      const patientCleanCpf = c.patient.cpf.replace(/\D/g, '');
      const patientDob = c.patient.dataNascimento.trim();
      return patientCleanCpf === cleanCpf && patientDob === cleanDob;
    }) || null
  );
}

// MS Foundry Config Helpers
export function getMsFoundryConfig(): MsFoundryConfig {
  try {
    const raw = localStorage.getItem(MS_CONFIG_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Error reading MS Foundry config:', err);
  }
  return {
    apiKey: '',
    endpoint: 'https://pasquared-foundry.openai.azure.com/',
    deploymentName: 'gpt-4o-health-v1',
    apiVersion: '2024-02-15-preview',
    isEnabled: false,
  };
}

export function saveMsFoundryConfig(config: MsFoundryConfig): void {
  try {
    localStorage.setItem(MS_CONFIG_STORAGE_KEY, JSON.stringify(config));
  } catch (err) {
    console.error('Error saving MS Foundry config:', err);
  }
}

// Super Admin Global System Config Helpers
export function getSuperAdminGlobalConfig(): SuperAdminGlobalConfig {
  try {
    const raw = localStorage.getItem(GLOBAL_ADMIN_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Error reading Super Admin global config:', err);
  }
  return {
    cognitiveThreshold: 80,
    walkieTalkieEnabled: true,
    autoSyncIntervalHours: 12,
    allowAnyFileType: true,
    aiAutoPruningEnabled: true,
    systemStatus: 'operacional',
    lastSavedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
  };
}

export function saveSuperAdminGlobalConfig(config: SuperAdminGlobalConfig): void {
  try {
    const updated = {
      ...config,
      lastSavedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
    };
    localStorage.setItem(GLOBAL_ADMIN_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error saving Super Admin global config:', err);
  }
}

// Utility to generate structured questions for AI Consultation
export const HEALTH_INVESTIGATIVE_QUESTIONS = [
  'Qual é o seu sintoma ou queixa principal hoje?',
  'Há quanto tempo você vem sentindo esse sintoma e ele piorou nas últimas horas?',
  'Em uma escala de 1 a 10, qual é a intensidade do desconforto ou dor?',
  'Você está com febre, tontura, falta de ar, náuseas ou dor no peito?',
  'Você possui alguma alergia, hipertensão, diabetes ou toma medicação diária?',
  'Gostaria de anexar exames, documentos ou gravar um relato para o médico antes de gerarmos sua pré-avaliação?',
];
