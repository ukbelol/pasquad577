import { UserProfile } from '../types';

const USERS_STORAGE_KEY = 'pasquared_users_v1';
const ACTIVE_SESSION_KEY = 'pasquared_active_session_v1';

// Initial sample seed users so demo login works immediately if desired
const SAMPLE_USERS: UserProfile[] = [
  {
    id: 'usr_pat_1',
    role: 'patient',
    nome: 'Carlos',
    sobrenome: 'Eduardo Silva',
    dataNascimento: '1985-06-14',
    cpf: '123.456.789-00',
    email: 'carlos.silva@email.com',
    telefone: '(11) 98765-4321',
    telefonesAdicionais: ['(11) 91234-5678'],
    cep: '01001-000',
    rua: 'Praça da Sé',
    numero: '100',
    bairro: 'Sé',
    cidade: 'São Paulo',
    uf: 'SP',
    senha: 'senha123',
    nomeMae: 'Maria Silva',
    nomePai: 'Jose Silva',
    createdAt: '2026-08-10 10:00',
    updatedAt: '2026-08-10 10:00',
  },
  {
    id: 'usr_doc_1',
    role: 'doctor',
    nome: 'Dra. Ana',
    sobrenome: 'Beatriz Ramos',
    dataNascimento: '1978-03-22',
    cpf: '987.654.321-11',
    email: 'dra.anabeatriz@hospital.com',
    telefone: '(11) 97777-8888',
    telefonesAdicionais: ['(11) 3333-4444'],
    cep: '04001-000',
    rua: 'Rua Vergueiro',
    numero: '500',
    bairro: 'Paraíso',
    cidade: 'São Paulo',
    uf: 'SP',
    senha: 'doc123',
    nomeMae: 'Helena Ramos',
    nomePai: 'Roberto Ramos',
    crm: 'CRM/SP 145890',
    createdAt: '2026-08-01 08:30',
    updatedAt: '2026-08-01 08:30',
  },
];

export function getStoredUsers(): UserProfile[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(SAMPLE_USERS));
      return SAMPLE_USERS;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading stored users:', err);
    return SAMPLE_USERS;
  }
}

export function saveUser(user: UserProfile): void {
  try {
    const users = getStoredUsers();
    const cleanInputCpf = user.cpf.replace(/\D/g, '');
    const index = users.findIndex(
      (u) => u.cpf.replace(/\D/g, '') === cleanInputCpf && u.role === user.role
    );

    if (index >= 0) {
      users[index] = { ...user, updatedAt: new Date().toISOString().slice(0, 16) };
    } else {
      users.unshift({ ...user, updatedAt: new Date().toISOString().slice(0, 16) });
    }
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Error saving user to storage:', err);
  }
}

export function findUserByCpf(cpf: string, role: 'patient' | 'doctor'): UserProfile | null {
  const users = getStoredUsers();
  const clean = cpf.replace(/\D/g, '');
  return users.find((u) => u.cpf.replace(/\D/g, '') === clean && u.role === role) || null;
}

export function authenticateUser(
  cpf: string,
  senhaInput: string,
  role: 'patient' | 'doctor'
): { success: boolean; user?: UserProfile; error?: string } {
  const cleanCpf = cpf.replace(/\D/g, '');
  if (!cleanCpf) {
    return { success: false, error: 'Por favor, informe seu CPF (Usuário).' };
  }
  if (!senhaInput) {
    return { success: false, error: 'Por favor, informe a senha cadastrada.' };
  }

  const user = findUserByCpf(cleanCpf, role);
  if (!user) {
    return { success: false, error: `Usuário com CPF ${cpf} não encontrado para o perfil ${role === 'patient' ? 'Paciente' : 'Doutor'}.` };
  }

  if (user.senha !== senhaInput) {
    return { success: false, error: 'Senha incorreta. Verifique suas credenciais.' };
  }

  // Save active session
  setActiveSession(user);
  return { success: true, user };
}

export function verifySecurityAnswers(
  cpf: string,
  role: 'patient' | 'doctor',
  nomeMaeInput: string,
  nomePaiInput: string,
  emailInput: string
): { success: boolean; user?: UserProfile; error?: string } {
  const cleanCpf = cpf.replace(/\D/g, '');
  if (!cleanCpf) {
    return { success: false, error: 'Por favor, informe seu CPF cadastrado.' };
  }

  const user = findUserByCpf(cleanCpf, role);
  if (!user) {
    return {
      success: false,
      error: `Usuário com este CPF não foi encontrado para o perfil ${role === 'patient' ? 'Paciente (PA)' : 'Doutor (DR)'}.`,
    };
  }

  // Question 3: Qual é o E-mail cadastrado?
  if (!emailInput.trim() || user.email.trim().toLowerCase() !== emailInput.trim().toLowerCase()) {
    return {
      success: false,
      error: 'Resposta incorreta para Pergunta 3: O E-mail informado não é igual ao cadastrado no sistema.',
    };
  }

  // Question 1: Qual o nome da mãe?
  const storedMae = (user.nomeMae || '').trim().toLowerCase();
  if (!nomeMaeInput.trim() || (storedMae && storedMae !== nomeMaeInput.trim().toLowerCase())) {
    return {
      success: false,
      error: 'Resposta incorreta para Pergunta 1: Nome da mãe não confere com o cadastrado.',
    };
  }

  // Question 2: Qual o nome do pai?
  const storedPai = (user.nomePai || '').trim().toLowerCase();
  if (!nomePaiInput.trim() || (storedPai && storedPai !== nomePaiInput.trim().toLowerCase())) {
    return {
      success: false,
      error: 'Resposta incorreta para Pergunta 2: Nome do pai não confere com o cadastrado.',
    };
  }

  return { success: true, user };
}

export function getActiveSession(): UserProfile | null {
  try {
    const raw = localStorage.getItem(ACTIVE_SESSION_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Error loading active session:', err);
  }
  return null;
}

export function setActiveSession(user: UserProfile | null): void {
  try {
    if (user) {
      localStorage.setItem(ACTIVE_SESSION_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(ACTIVE_SESSION_KEY);
    }
  } catch (err) {
    console.error('Error setting active session:', err);
  }
}

export interface AddressResult {
  rua: string;
  bairro: string;
  cidade: string;
  uf: string;
  success: boolean;
  error?: string;
}

export async function fetchAddressByCep(cep: string): Promise<AddressResult> {
  const cleanCep = cep.replace(/\D/g, '');
  if (cleanCep.length !== 8) {
    return { rua: '', bairro: '', cidade: '', uf: '', success: false, error: 'CEP deve conter 8 dígitos.' };
  }

  try {
    const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
    if (!response.ok) {
      throw new Error(`HTTP Error ${response.status}`);
    }
    const data = await response.json();
    if (data.erro) {
      return { rua: '', bairro: '', cidade: '', uf: '', success: false, error: 'CEP não encontrado.' };
    }
    return {
      rua: data.logradouro || '',
      bairro: data.bairro || '',
      cidade: data.localidade || '',
      uf: data.uf || '',
      success: true,
    };
  } catch (err) {
    console.warn('ViaCEP API error:', err);
    return {
      rua: '',
      bairro: '',
      cidade: '',
      uf: '',
      success: false,
      error: 'Falha ao consultar API de CEP. Preencha o endereço manualmente.',
    };
  }
}
