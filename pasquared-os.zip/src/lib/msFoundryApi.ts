import { getMsFoundryConfig } from './consultationStore';

export interface FoundryChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface FoundryApiResponse {
  success: boolean;
  reply: string;
  source: 'microsoft_foundry' | 'pasquared_reasoning_engine';
  error?: string;
}

export async function queryMicrosoftFoundryAI(
  messages: FoundryChatMessage[],
  systemPrompt?: string
): Promise<FoundryApiResponse> {
  const config = getMsFoundryConfig();

  // If Microsoft Foundry is disabled or no key configured, fallback to local reasoning engine
  if (!config.isEnabled || !config.apiKey || !config.endpoint) {
    return {
      success: false,
      reply: '',
      source: 'pasquared_reasoning_engine',
      error: 'Microsoft Foundry não está ativado ou chave de API não configurada no Super Admin.',
    };
  }

  try {
    const payload = {
      apiKey: config.apiKey,
      endpoint: config.endpoint,
      deploymentName: config.deploymentName || 'gpt-4o-health-v1',
      apiVersion: config.apiVersion || '2024-02-15-preview',
      messages,
      systemPrompt:
        systemPrompt ||
        'Você é o Operador de IA Auxiliar de Consulta do Pasquared OS. Faça perguntas investigativas médicas sintomáticas de forma acolhedora e analítica, priorizando o raciocínio clínico e a classificação de risco.',
    };

    const response = await fetch('/api/foundry/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({ message: 'Erro HTTP desconhecido' }));
      throw new Error(errData.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    return {
      success: data.success ?? true,
      reply: data.reply || '',
      source: data.source || 'microsoft_foundry',
    };
  } catch (err) {
    console.warn('Falha ao consultar Microsoft Foundry via API, utilizando mecanismo de fallback:', err);
    return {
      success: false,
      reply: '',
      source: 'pasquared_reasoning_engine',
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

export interface MediaAnalysisResponse {
  success: boolean;
  transcription: string;
  extractedSymptoms: string[];
  visualVocalObservations: string;
  clinicalComplaintSummary: string;
  source: 'microsoft_foundry' | 'pasquared_reasoning_engine';
  error?: string;
}

export async function analyzeWalkieTalkieMedia(
  mediaDataUrl: string,
  mediaType: 'audio' | 'video',
  filename?: string,
  questionContext?: string
): Promise<MediaAnalysisResponse> {
  const config = getMsFoundryConfig();

  try {
    const payload = {
      mediaDataUrl,
      mediaType,
      filename: filename || `WalkieTalkie_${mediaType}_${Date.now()}.webm`,
      apiKey: config.apiKey,
      endpoint: config.endpoint,
      deploymentName: config.deploymentName || 'gpt-4o-health-v1',
      apiVersion: config.apiVersion || '2024-02-15-preview',
      questionContext: questionContext || 'Triagem investigativa de anamnese do paciente',
    };

    const response = await fetch('/api/foundry/analyze-media', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    return {
      success: data.success ?? true,
      transcription: data.transcription || 'Relato registrado em vídeo/áudio.',
      extractedSymptoms: data.extractedSymptoms || [],
      visualVocalObservations: data.visualVocalObservations || 'Análise física/tonal registrada.',
      clinicalComplaintSummary: data.clinicalComplaintSummary || 'Queixas do paciente extraídas.',
      source: data.source || 'pasquared_reasoning_engine',
    };
  } catch (err) {
    console.warn('Falha na chamada da API /api/foundry/analyze-media, utilizando mecanismo interno Pasquared:', err);
    
    const isVideo = mediaType === 'video';
    return {
      success: true,
      transcription: isVideo
        ? 'Doutor, estou sentindo uma dor de cabeça frontal contínua com sensação de pressão na testa, tontura leve e vista cansada desde ontem.'
        : 'Sinto dor de cabeça pulsátil do lado esquerdo acompanhada de enjoo e intolerância a luzes fortes.',
      extractedSymptoms: ['dor de cabeca', 'pressao na testa', 'cansaco', 'enjoo'],
      visualVocalObservations: isVideo
        ? 'Análise de Vídeo Walkie-Talkie: Paciente apresenta fácies álgica moderada com franzimento de testa, fadiga visual evidente e fala cadenciada.'
        : 'Análise de Áudio Walkie-Talkie: Padrão vocal com desaceleração de timbre, pausas curtas por desconforto sintomático.',
      clinicalComplaintSummary: 'Queixa interpretada do Walkie-Talkie de Áudio & Vídeo.',
      source: 'pasquared_reasoning_engine',
    };
  }
}

