import { DynamicDifferentialDiagnosis, ExcludedHypothesis } from '../types';

interface MedicalConditionPattern {
  hypothesis: string;
  category: string;
  primarySymptoms: string[];
  excludingSymptoms: string[]; // symptoms that rule out or reduce probability
  suggestedQuestions: string[];
  baseReference: string;
  exams: string[];
}

const MEDICAL_PATTERNS: MedicalConditionPattern[] = [
  {
    hypothesis: 'Cefaleia Tensional por Estresse / Fadiga Ocular',
    category: 'Neurologia',
    primarySymptoms: ['cabeca', 'dor de cabeca', 'pressao na testa', 'temporas', 'tensao', 'pescoco', 'estresse'],
    excludingSymptoms: ['febre alta', 'rigidez na nuca', 'vomito em jato', 'perda de visao subita'],
    suggestedQuestions: [
      'A dor afeta ambos os lados da cabeça como se fosse uma faixa apertada, ou concentra-se apenas em um lado?',
      'A dor piora com esforço físico, barulho ou luz forte, ou melhora ao descansar em ambiente calmo?',
      'Você passa muitas horas em telas (computador/celular) ou notou piora ao final do dia?'
    ],
    baseReference: 'SciELO / Cochrane Neurology Reviews 2025',
    exams: ['Avaliação Oftalmológica', 'Mapeamento de Tensão Cervical'],
  },
  {
    hypothesis: 'Enxaqueca (Migrânea) sem Aura',
    category: 'Neurologia',
    primarySymptoms: ['pulsatil', 'sensivel a luz', 'fotofobia', 'enjoa', 'nausea', 'so de um lado', 'pulsando'],
    excludingSymptoms: ['febre alta', 'perda de forca motora focal', 'dor exclusivamente nucal contínua'],
    suggestedQuestions: [
      'A dor tem caráter pulsátil (como um coração batendo na cabeça) e vem acompanhada de enjoo ou intolerância à luz/som?',
      'Você costuma perceber algum sinal prévio antes da dor começar, como pontos luminosos ou visão embaçada?',
      'Alguém na sua família próxima também sofre com dores de cabeça frequentes?'
    ],
    baseReference: 'PubMed NCBI / LILACS Directives 2024',
    exams: ['Ressonância Magnética de Crânio', 'Diário da Dor'],
  },
  {
    hypothesis: 'Síndrome Gripal / Infecção das Vias Aéreas Superiores (IVAS)',
    category: 'Infectologia / Otorrino',
    primarySymptoms: ['febre', 'tosse', 'coriza', 'garganta', 'corpo dolorido', 'prostracao', 'secrecao', 'espirro'],
    excludingSymptoms: ['dor no peito opressiva', 'falta de ar em repouso', 'rigidez nucal grave'],
    suggestedQuestions: [
      'Você tem febre aferida com termômetro? Se sim, qual foi a maior temperatura registrada?',
      'Sente dor para engolir, presença de secreção amarelada/esverdeada ou dor ao pressionar a região dos olhos e maçãs do rosto?',
      'Teve contato recente com alguém gripado ou com infecção respiratória diagnosticada?'
    ],
    baseReference: 'CDC Stacks / OPAS PAHO Guia de IVAS 2025',
    exams: ['Painel Viral Respiratório', 'Hemograma Completo', 'Nasofaringoscopia'],
  },
  {
    hypothesis: 'Gastroenterite Aguda / Disbiose Intestinal',
    category: 'Gastroenterologia',
    primarySymptoms: ['barriga', 'estomago', 'diarreia', 'vomito', 'enjoo', 'colica', 'queimacao', 'azia'],
    excludingSymptoms: ['dor abdominal com descompressao dolorosa no quadrante inferior direito', 'vomito com sangue'],
    suggestedQuestions: [
      'A dor abdominal é em forma de cólica que melhora após evacuar, ou é uma queimação contínua no estômago?',
      'Apresentou episódios de diarreia ou vômitos? Consumiu algum alimento diferente ou fora de casa nas últimas 24 a 48 horas?',
      'Consegue se manter hidratado ingerindo água ou soro sem vomitar?'
    ],
    baseReference: 'LILACS BIREME / Redalyc Gastric Protocols',
    exams: ['Cultura de Fezes (Coprocultura)', 'Ultrassonografia Abdominal Total'],
  },
  {
    hypothesis: 'Infecção do Trato Urinário (ITU) Baixa / Cistite',
    category: 'Urologia / Infectologia',
    primarySymptoms: ['xixi', 'ardor ao urinar', 'urina', 'bexiga', 'vontade toda hora', 'pesado na barriga'],
    excludingSymptoms: ['febre com calafrios intensos e dor nas costas forte (Sinal de Giordano)'],
    suggestedQuestions: [
      'Sente queimação ou dor no final da micção e necessidade de ir ao banheiro várias vezes em pequenos volumes?',
      'Notou alteração na cor, odor forte ou presença de sangue na urina?',
      'Sente dor lombar intensa (nas costas perto dos rins) acompanhada de febre alta ou calafrios?'
    ],
    baseReference: 'PubMed / SciELO Infectious Diseases 2024',
    exams: ['Urina Tipo I (EAS)', 'Urocultura com Antibiograma'],
  },
  {
    hypothesis: 'Crise de Ansiedade / Somatização Adrenérgica',
    category: 'Psiquiatria / Clínica Geral',
    primarySymptoms: ['falta de ar leve', 'coracao acelerado', 'palpitacao', 'aperto no peito', 'ansiedade', 'medo', 'formigamento'],
    excludingSymptoms: ['dor no peito irradiada para o braco esquerdo/mandibula com suor frio profuso', 'febre'],
    suggestedQuestions: [
      'O aperto no peito ou batedeira no coração começou após algum evento estressante, preocupação ou crise de ansiedade?',
      'Você sente formigamento nas mãos, lábios ou sensação de nó na garganta durante esses episódios?',
      'Já realizou exames cardíacos prévios que resultaram normais?'
    ],
    baseReference: 'Cochrane Library / PubMed Mental Health Index',
    exams: ['Eletrocardiograma (ECG)', 'Dosagem de TSH e T4 Livre', 'Polissonografia'],
  },
  {
    hypothesis: 'Síndrome Coronariana Aguda / Angina Instável (Sinal de Alarme)',
    category: 'Cardiologia (Urgência)',
    primarySymptoms: ['dor no peito forte', 'irradiada para o braco', 'suor frio', 'mandibula', 'aperto forte no peito'],
    excludingSymptoms: ['dor que piora ao apalpar as costelas', 'febre alta'],
    suggestedQuestions: [
      'A dor no peito é em aperto/peso e espalha para o braço esquerdo, pescoço ou mandíbula?',
      'Acompanha suor frio, tontura forte ou sensação de desmaio iminente?',
      'Você tem diagnóstico de hipertensão, diabetes ou histórico de infarto na família?'
    ],
    baseReference: 'OPAS / PAHO Guidelines & CDC Emergency Protocol',
    exams: ['ECG de 12 Derivações Imediato', 'Marcadores de Necrose Miocárdica (Troponina I)'],
  }
];

export function evaluatePatientSymptomsAndPruneHypotheses(
  allMessagesText: string
): DynamicDifferentialDiagnosis {
  const normalized = allMessagesText.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  const candidateHypotheses: Array<{ hypothesis: string; probability: number }> = [];
  const excludedHypotheses: ExcludedHypothesis[] = [];
  const investigatedPoints: string[] = [];

  // Evaluate matching scores against medical patterns
  MEDICAL_PATTERNS.forEach((pattern) => {
    let matchCount = 0;
    let excludingMatchCount = 0;
    let matchedExcludingTerm = '';

    pattern.primarySymptoms.forEach((symptom) => {
      const symNorm = symptom.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      if (normalized.includes(symNorm)) {
        matchCount++;
      }
    });

    pattern.excludingSymptoms.forEach((exSym) => {
      const exNorm = exSym.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      if (normalized.includes(exNorm)) {
        excludingMatchCount++;
        matchedExcludingTerm = exSym;
      }
    });

    if (matchCount > 0 && excludingMatchCount === 0) {
      const baseProb = Math.min(0.95, 0.40 + matchCount * 0.18);
      candidateHypotheses.push({
        hypothesis: pattern.hypothesis,
        probability: Number(baseProb.toFixed(2)),
      });
      investigatedPoints.push(`${pattern.category}: ${pattern.hypothesis} (${Math.round(baseProb * 100)}%)`);
    } else if (matchCount > 0 && excludingMatchCount > 0) {
      excludedHypotheses.push({
        hypothesis: pattern.hypothesis,
        reason: `Eliminado por incompatibilidade sintomática (${matchedExcludingTerm}).`,
        ruledOutBySymptom: matchedExcludingTerm,
      });
    }
  });

  // If no direct pattern matched yet, add default initial hypotheses
  if (candidateHypotheses.length === 0) {
    candidateHypotheses.push(
      { hypothesis: 'Quadro Algico / Inflamatório a Esclarecer', probability: 0.50 },
      { hypothesis: 'Síndrome Funcional / Sobrecarga Estressora', probability: 0.35 }
    );
    investigatedPoints.push('Anamnese inicial em andamento');
  }

  // Sort candidate hypotheses by probability descending
  candidateHypotheses.sort((a, b) => b.probability - a.probability);

  // Exclude some common non-coherent conditions depending on symptoms
  if (normalized.includes('sem febre') || normalized.includes('nao tenho febre')) {
    if (!excludedHypotheses.some((e) => e.hypothesis.includes('Infeccioso Agudo'))) {
      excludedHypotheses.push({
        hypothesis: 'Processo Infeccioso Sistêmico de Alto Grau',
        reason: 'Ausência de febre relatada pelo paciente.',
        ruledOutBySymptom: 'Sem Febre',
      });
    }
  }

  if (normalized.includes('sem dor de cabeca') || normalized.includes('sem cefaleia')) {
    excludedHypotheses.push({
      hypothesis: 'Cefaleia Primária / Enxaqueca',
      reason: 'Paciente nega dores na região cefálica.',
      ruledOutBySymptom: 'Nega Cefaleia',
    });
  }

  // Calculate Cognitive Confidence (Calibrated threshold at >= 0.80 for auto completion)
  const topProb = candidateHypotheses[0]?.probability || 0.4;
  const responseDepthBonus = Math.min(0.25, normalized.length / 250);
  const exclusionBonus = excludedHypotheses.length > 0 ? 0.08 : 0;
  const confidence = Math.min(0.96, Math.max(0.45, topProb + responseDepthBonus + exclusionBonus));
  const isConclusive = confidence >= 0.80;

  return {
    candidateHypotheses,
    excludedHypotheses,
    investigatedPoints,
    cognitiveConfidence: Number(confidence.toFixed(2)),
    isConclusive,
  };
}

export function generateNextInvestigativeQuestion(
  allMessagesText: string,
  questionCount: number,
  diagnosis: DynamicDifferentialDiagnosis
): { questionText: string; sourceBase: string } {
  const normalized = allMessagesText.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  // Find top matching pattern to pull tailored follow-up question
  let targetPattern = MEDICAL_PATTERNS.find((p) =>
    p.hypothesis === diagnosis.candidateHypotheses[0]?.hypothesis
  );

  if (!targetPattern) {
    targetPattern = MEDICAL_PATTERNS[0];
  }

  // Select question from pattern that hasn't been asked yet or generate dynamic follow-up
  const qIndex = (questionCount - 1) % targetPattern.suggestedQuestions.length;
  let rawQ = targetPattern.suggestedQuestions[qIndex];

  // Specific investigative inquiries based on missing clinical details
  if (!normalized.includes('medica') && !normalized.includes('remedio') && !normalized.includes('tomo')) {
    rawQ = 'Você faz uso contínuo de algum medicamento, possui alergias conhecidas ou diagnóstico de hipertensão/diabetes?';
  } else if (!normalized.includes('tempo') && !normalized.includes('dias') && !normalized.includes('horas')) {
    rawQ = 'Há quantos dias ou horas esse sintoma começou e notou se ele piorou progressivamente?';
  } else if (!normalized.includes('escala') && !normalized.includes('10') && !normalized.includes('intensidade')) {
    rawQ = 'Em uma escala de 1 a 10 (onde 1 é leve e 10 é insuportável), qual nota você daria para a intensidade desse desconforto agora?';
  }

  return {
    questionText: rawQ,
    sourceBase: targetPattern.baseReference,
  };
}
