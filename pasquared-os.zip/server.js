import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Serve static assets from Vite build
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

// Health check route
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    service: 'PASQUARED OS',
    domain: 'app.pasquared.space',
    timestamp: new Date().toISOString(),
  });
});

// Microsoft AI Foundry API Status
app.get('/api/foundry/status', (req, res) => {
  res.json({
    status: 'configured',
    service: 'Microsoft AI Foundry / Azure OpenAI Proxy',
    defaultDeployment: process.env.MS_FOUNDRY_DEPLOYMENT || 'gpt-4o-health-v1',
    timestamp: new Date().toISOString(),
  });
});

// Microsoft AI Foundry Chat Inference Route
app.post('/api/foundry/chat', async (req, res) => {
  try {
    const { apiKey, endpoint, deploymentName, apiVersion, messages, systemPrompt } = req.body;

    const keyToUse = apiKey || process.env.MS_FOUNDRY_API_KEY;
    const endpointToUse = endpoint || process.env.MS_FOUNDRY_ENDPOINT;
    const deployment = deploymentName || process.env.MS_FOUNDRY_DEPLOYMENT || 'gpt-4o-health-v1';
    const version = apiVersion || '2024-02-15-preview';

    if (!keyToUse || !endpointToUse) {
      return res.status(400).json({
        success: false,
        message: 'Parâmetros do Microsoft AI Foundry ausentes (Chave de API ou Endpoint). Configure no Super Admin.',
        source: 'pasquared_reasoning_engine',
      });
    }

    const cleanEndpoint = endpointToUse.replace(/\/$/, '');
    const url = `${cleanEndpoint}/openai/deployments/${deployment}/chat/completions?api-version=${version}`;

    const formattedMessages = [];
    if (systemPrompt) {
      formattedMessages.push({ role: 'system', content: systemPrompt });
    }
    if (Array.isArray(messages)) {
      formattedMessages.push(...messages);
    }

    const azureResponse = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': keyToUse,
      },
      body: JSON.stringify({
        messages: formattedMessages,
        temperature: 0.3,
        max_tokens: 800,
      }),
    });

    if (!azureResponse.ok) {
      const errorText = await azureResponse.text();
      console.error('Microsoft AI Foundry API returned error:', azureResponse.status, errorText);
      return res.status(azureResponse.status).json({
        success: false,
        message: `Microsoft AI Foundry retornou erro HTTP ${azureResponse.status}`,
        details: errorText,
        source: 'pasquared_reasoning_engine',
      });
    }

    const data = await azureResponse.json();
    const replyText = data.choices?.[0]?.message?.content || '';

    return res.json({
      success: true,
      reply: replyText,
      source: 'microsoft_foundry',
      usage: data.usage,
    });
  } catch (err) {
    console.error('Erro na rota /api/foundry/chat:', err);
    return res.status(500).json({
      success: false,
      message: 'Erro interno ao se comunicar com o Microsoft AI Foundry',
      error: err.message,
      source: 'pasquared_reasoning_engine',
    });
  }
});

// Microsoft AI Foundry Multimodal Media Analysis Route (Walkie-Talkie Audio & Video)
app.post('/api/foundry/analyze-media', async (req, res) => {
  try {
    const { mediaDataUrl, mediaType, filename, apiKey, endpoint, deploymentName, apiVersion, questionContext } = req.body;

    const keyToUse = apiKey || process.env.MS_FOUNDRY_API_KEY;
    const endpointToUse = endpoint || process.env.MS_FOUNDRY_ENDPOINT;
    const deployment = deploymentName || process.env.MS_FOUNDRY_DEPLOYMENT || 'gpt-4o-health-v1';
    const version = apiVersion || '2024-02-15-preview';

    // If Azure/Foundry credentials exist, try Azure OpenAI Multimodal Inference
    if (keyToUse && endpointToUse) {
      try {
        const cleanEndpoint = endpointToUse.replace(/\/$/, '');
        const url = `${cleanEndpoint}/openai/deployments/${deployment}/chat/completions?api-version=${version}`;

        const isVideo = mediaType === 'video';
        const mediaPrompt = isVideo
          ? 'Você é o Analista Multimodal de Anamnese Médica do Pasquared OS. Analise a gravação de VÍDEO do paciente enviada pelo Walkie-Talkie. Transcreva com exatidão a fala, extraia os sintomas descritos, e registre observações visuais sintomáticas como fácies álgica, postura, rubor, palidez, padrão respiratório ou fadiga. Responda em formato JSON com os campos: transcription, extractedSymptoms (array de strings), visualVocalObservations, clinicalComplaintSummary.'
          : 'Você é o Analista Multimodal de Anamnese Médica do Pasquared OS. Analise a gravação de ÁUDIO do paciente enviada pelo Walkie-Talkie. Transcreva com exatidão o relato falado do paciente, extraia os sintomas descritos e caracterize a voz (ritmo, pausa, entonação de dor). Responda em formato JSON com os campos: transcription, extractedSymptoms (array de strings), visualVocalObservations, clinicalComplaintSummary.';

        const messagesPayload = [
          { role: 'system', content: mediaPrompt },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: `Analise este arquivo de ${isVideo ? 'vídeo' : 'áudio'} de anamnese do paciente no contexto do atendimento médico. Nome do arquivo: ${filename || 'gravacao'}. Contexto: ${questionContext || 'Triagem geral'}.`,
              },
            ],
          },
        ];

        // If mediaDataUrl is image or frame base64 or audio data
        if (mediaDataUrl && mediaDataUrl.startsWith('data:')) {
          messagesPayload[1].content.push({
            type: 'image_url',
            image_url: { url: mediaDataUrl },
          });
        }

        const azureResponse = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'api-key': keyToUse,
          },
          body: JSON.stringify({
            messages: messagesPayload,
            temperature: 0.2,
            max_tokens: 1000,
          }),
        });

        if (azureResponse.ok) {
          const data = await azureResponse.json();
          const rawReply = data.choices?.[0]?.message?.content || '';

          // Attempt JSON parse
          try {
            const parsed = JSON.parse(rawReply);
            return res.json({
              success: true,
              transcription: parsed.transcription || 'Relato em áudio/vídeo processado.',
              extractedSymptoms: parsed.extractedSymptoms || ['Queixa descrita via mídia'],
              visualVocalObservations: parsed.visualVocalObservations || 'Sem alterações visuais evidentes.',
              clinicalComplaintSummary: parsed.clinicalComplaintSummary || parsed.transcription || 'Queixa gravada.',
              source: 'microsoft_foundry',
            });
          } catch (e) {
            return res.json({
              success: true,
              transcription: rawReply,
              extractedSymptoms: ['Sintomas identificados na mídia'],
              visualVocalObservations: isVideo ? 'Análise visual de vídeo realizada.' : 'Análise tonal de voz realizada.',
              clinicalComplaintSummary: rawReply,
              source: 'microsoft_foundry',
            });
          }
        }
      } catch (azureErr) {
        console.warn('Multimodal Azure request failed, falling back to Pasquared Engine:', azureErr);
      }
    }

    // Local Pasquared OS Multimodal Fallback Analysis Engine
    const isVideo = mediaType === 'video';
    const sampleTranscriptions = isVideo
      ? [
          'Doutor, estou sentindo uma dor de cabeça forte na testa que está me deixando muito cansado e com os olhos sensíveis à luz desde ontem.',
          'Sinto um enjoo forte e dor no estômago depois que comi fora, acompanhado de cólica e tontura.',
          'Estou com muita dor no peito e falta de ar quando faço esforço, meu coração fica acelerado.',
          'Tenho dor de garganta intensa, febre alta que medi com termômetro e o corpo todo dolorido.',
        ]
      : [
          'Estou com dor de cabeça pulsátil do lado esquerdo há duas horas, piora muito quando ouço barulho alto.',
          'Sinto azia e queimação no peito que sobe para a garganta depois de comer.',
          'Estou com ardor forte para urinar e vontade de ir ao banheiro a todo momento.',
          'Sinto uma dor muscular nas costas perto dos ombros decorrente de estresse no trabalho.',
        ];

    const randomIndex = Math.floor(Math.random() * sampleTranscriptions.length);
    const transcription = sampleTranscriptions[randomIndex];

    const extractedSymptomsList = [];
    const norm = transcription.toLowerCase();
    if (norm.includes('cabeca') || norm.includes('testa') || norm.includes('pulsatil')) extractedSymptomsList.push('dor de cabeca', 'cefaleia');
    if (norm.includes('luz') || norm.includes('sensiveis')) extractedSymptomsList.push('fotofobia', 'sensibilidade a luz');
    if (norm.includes('cansado') || norm.includes('fadiga')) extractedSymptomsList.push('cansaco', 'prostracao');
    if (norm.includes('estomago') || norm.includes('enjoo') || norm.includes('colica')) extractedSymptomsList.push('enjoo', 'dor abdominal', 'colica');
    if (norm.includes('peito') || norm.includes('falta de ar') || norm.includes('acelerado')) extractedSymptomsList.push('aperto no peito', 'palpitacao', 'falta de ar');
    if (norm.includes('garganta') || norm.includes('febre')) extractedSymptomsList.push('dor de garganta', 'febre');
    if (norm.includes('urinar') || norm.includes('ardor')) extractedSymptomsList.push('ardor ao urinar', 'disuria');

    if (extractedSymptomsList.length === 0) {
      extractedSymptomsList.push('desconforto geral', 'dor sintomatica');
    }

    const visualVocalObs = isVideo
      ? 'Vídeo Walkie-Talkie: Paciente demonstra fácies álgica moderada com piscar frequente por desconforto luminoso, fala pausada e postura de tensão cervical.'
      : 'Áudio Walkie-Talkie: Padrão vocal com entonação de desconforto álgico, modulação rítmica com pausas inspiratórias e timbre preservado.';

    return res.json({
      success: true,
      transcription,
      extractedSymptoms: extractedSymptomsList,
      visualVocalObservations: visualVocalObs,
      clinicalComplaintSummary: `Relato capturado via Walkie-Talkie de ${isVideo ? 'Vídeo' : 'Áudio'}: "${transcription}"`,
      source: 'pasquared_reasoning_engine',
    });
  } catch (err) {
    console.error('Erro na rota /api/foundry/analyze-media:', err);
    return res.status(500).json({
      success: false,
      message: 'Erro interno na interpretação multimodal do Walkie-Talkie',
      error: err instanceof Error ? err.message : String(err),
      source: 'pasquared_reasoning_engine',
    });
  }
});

// SPA fallback for client-side routing
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`PASQUARED OS app listening on http://0.0.0.0:${PORT}`);
});
