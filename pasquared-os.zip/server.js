import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Serve static assets from Vite build
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

// Health check route
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    service: 'PASQUARED OS',
    domain: 'app.pasquared.space',
    timestamp: new Date().toISOString(),
  });
});

// SPA fallback for client-side routing
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`PASQUARED OS app listening on http://0.0.0.0:${PORT}`);
});
