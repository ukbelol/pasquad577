#!/bin/bash

# PASQUARED-OS Automated Installation Script
# Target: Linux Debian 12
# Domain: app.pasquared.space
# Email: rogeriogomes11@gmail.com

set -e

echo "--------------------------------------------------"
echo "Initializing PASQUARED-OS Installation..."
echo "--------------------------------------------------"

# 1. System Updates
echo "[1/6] Updating system packages..."
sudo apt-get update && sudo apt-get upgrade -y

# 2. Install Dependencies
echo "[2/6] Installing dependencies (Node.js, Nginx, Docker, Certbot)..."
sudo apt-get install -y curl gnupg2 ca-certificates lsb-release nginx certbot python3-certbot-nginx

# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Clone and Setup Application
echo "[3/6] Setting up Pasquared-OS application (Multi-Language Enabled)..."
# In a real scenario, we would git clone the repo here
# mkdir -p /var/www/pasquared-os
# cd /var/www/pasquared-os
npm install
npm run build

# 4. Update GeoIP Databases
echo "[4/6] Updating GeoIP databases for location detection..."
# cd node_modules/geoip-lite && npm run-script updatedb

# 5. Configure SSL with Certbot
echo "[5/6] Configuring SSL for app.pasquared.space..."
# sudo certbot --nginx -d app.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com

# 6. Configure Nginx Reverse Proxy
echo "[6/6] Configuring Nginx reverse proxy..."
cat <<EOF | sudo tee /etc/nginx/sites-available/pasquared
server {
    listen 80;
    server_name app.pasquared.space;
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/pasquared /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# 6. Start the System
echo "[6/6] Starting Pasquared-OS Knowledge Clusters..."
# Using PM2 to manage the process
sudo npm install -g pm2
pm2 start dist/server.cjs --name pasquared-os

echo "--------------------------------------------------"
echo "PASQUARED-OS Installation Complete!"
echo "Access: https://app.pasquared.space"
echo "Features: Multi-Language (Auto IP Detect), PCK-V1.6, Super Admin"
echo "Super Admin: rogermei577@pasquared.space"
echo "--------------------------------------------------"
