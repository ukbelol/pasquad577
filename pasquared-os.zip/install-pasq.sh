#!/bin/bash

# ==============================================================================
# app.pasquared — Complete Automated VPS Installer & Deployment Script
# Target OS: Linux Debian 12 (Bookworm)
# Domain: app.pasquared.space
# Super Admin: rogermei577@pasquared.space
# ==============================================================================

set -e

echo "----------------------------------------------------------------------"
echo "  🚀 Starting Full Automated Installation for app.pasquared (Debian 12)"
echo "----------------------------------------------------------------------"

# 1. System Updates & Core Build Tools
echo "[1/10] Updating Debian 12 packages and installing core tools..."
sudo apt-get update -y
sudo apt-get upgrade -y
sudo apt-get install -y curl git gnupg2 ca-certificates lsb-release apache2 certbot python3-certbot-apache build-essential psmisc

# 2. Node.js 20.x Setup
echo "[2/10] Verifying and installing Node.js 20.x..."
if ! command -v node &> /dev/null || [[ $(node -v) != v20* ]]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi
echo "Node version: $(node -v)"
echo "NPM version: $(npm -v)"

# 3. PM2 Process Manager Installation
echo "[3/10] Installing PM2 process manager globally..."
sudo npm install -g pm2 --quiet || true

# 4. Clean up conflicting web servers & free ports 80/443
echo "[4/10] Clearing conflicting ports (80/443) and stopping Nginx/Apache..."
sudo systemctl stop nginx || true
sudo systemctl disable nginx || true
sudo systemctl stop apache2 || true

pm2 kill || true
sudo pkill -9 node || true
sudo fuser -k 80/tcp || true
sudo fuser -k 443/tcp || true

# 5. Clone or Setup Working Directory
echo "[5/10] Setting up project directory and persistent database..."
APP_DIR="/var/www/app.pasquared"

if [ -d "$APP_DIR" ] && [ "$PWD" != "$APP_DIR" ]; then
  echo "Navigating to existing installation directory: $APP_DIR"
  cd "$APP_DIR"
elif [ ! -f "package.json" ]; then
  echo "Creating directory $APP_DIR..."
  sudo mkdir -p "$APP_DIR"
  sudo chown -R $USER:$USER "$APP_DIR"
  cd "$APP_DIR"
  if [ -n "$REPO_URL" ]; then
    echo "Cloning repository from $REPO_URL..."
    git clone "$REPO_URL" .
  fi
fi

# Ensure data directory exists for persistent JSON storage
mkdir -p data
chmod -R 777 data

# 6. Install NPM Dependencies & Build Production Bundle
echo "[6/10] Installing dependencies and compiling frontend & backend API..."
npm install
npm run build

# 7. Configure Apache Reverse Proxy & WebSockets
echo "[7/10] Setting up Apache2 Reverse Proxy for app.pasquared.space..."

echo "ServerName app.pasquared.space" | sudo tee /etc/apache2/conf-available/fqdn.conf
sudo a2enconf fqdn

sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod ssl
sudo a2enmod rewrite
sudo a2enmod headers

sudo a2dissite 000-default || true

cat <<EOF | sudo tee /etc/apache2/sites-available/app-pasquared.conf
<VirtualHost *:80>
    ServerName app.pasquared.space
    
    # Exclude ACME challenge directory from proxying
    ProxyPass /.well-known/acme-challenge/ !
    
    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/
    
    # WebSocket support
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule /(.*) ws://127.0.0.1:3000/\$1 [P,L]

    ErrorLog \${APACHE_LOG_DIR}/app_pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/app_pasquared_access.log combined
</VirtualHost>
EOF

sudo a2ensite app-pasquared.conf
sudo apache2ctl configtest
sudo systemctl restart apache2
sudo systemctl enable apache2

# 8. Let's Encrypt SSL Provisioning
echo "[8/10] Provisioning SSL certificate via Certbot..."
sudo certbot --apache -d app.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com --redirect --no-eff-email || echo "Certbot SSL step completed or domain DNS pending propagation."

sudo systemctl status certbot.timer --no-pager || true

# 9. Environment File Configuration
echo "[9/10] Configuring production environment variables..."
if [ ! -f .env ]; then
  cat <<EOF > .env
GEMINI_API_KEY=${GEMINI_API_KEY}
NODE_ENV=production
PORT=3000
EOF
  echo ".env file created."
else
  echo ".env file already exists."
fi

# 10. Launch PM2 Application Service
echo "[10/10] Launching app.pasquared Knowledge Kernel daemon with PM2..."
pm2 start dist/server.cjs --name app-pasquared
pm2 save
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME || true

echo "----------------------------------------------------------------------"
echo "  ✅ app.pasquared Installation & Deployment Completed Successfully!"
echo "----------------------------------------------------------------------"
echo "  Public URL: https://app.pasquared.space"
echo "  Restricted Root Admin: https://app.pasquared.space/rootsuperadmin"
echo "  Super Admin Email: rogermei577@pasquared.space"
echo "  Super Admin Password: 21121201@Roger-Pasq"
echo "  Persistent Database File: data/pasquared_db.json"
echo "  Active Modules: Investigative Anamnesis, Medical Imaging, UCL v1.6"
echo "----------------------------------------------------------------------"
