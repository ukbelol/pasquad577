#!/bin/bash

# app.pasquared Automated Installation Script
# Target Architecture: Linux Debian 12 (Bookworm)
# Domain: app.pasquared.space
# Super Admin: rogermei577@pasquared.space

set -e

echo "--------------------------------------------------"
echo "Initializing app.pasquared Installation on Debian 12..."
echo "--------------------------------------------------"

# 1. Pre-installation Cleanup (Conflict Resolution)
echo "[1/10] Cleaning up conflicting services and freeing ports..."
sudo systemctl stop nginx || true
sudo systemctl disable nginx || true
sudo systemctl stop apache2 || true

# Kill any node/pm2 processes
sudo npm install -g pm2 || true
pm2 kill || true
sudo pkill -9 node || true

# Free port 80/443 explicitly if still held
sudo fuser -k 80/tcp || true
sudo fuser -k 443/tcp || true

# 2. System Updates
echo "[2/10] Updating Debian 12 system packages..."
sudo apt-get update && sudo apt-get upgrade -y

# 3. Install Dependencies
echo "[3/10] Installing dependencies (Node.js 20, Apache2, Certbot)..."
sudo apt-get install -y curl gnupg2 ca-certificates lsb-release apache2 certbot python3-certbot-apache build-essential

# Fix Apache FQDN warning
echo "ServerName app.pasquared.space" | sudo tee /etc/apache2/conf-available/fqdn.conf
sudo a2enconf fqdn

# Enable Apache Proxy Modules
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod ssl
sudo a2enmod rewrite
sudo a2enmod headers

# Install Node.js 20.x if not installed or outdated
if ! command -v node &> /dev/null || [[ $(node -v) != v20* ]]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

# 4. Clone & Setup Application Structure
echo "[4/10] Preparing application directory and persistent DB..."
mkdir -p data
npm install
npm run build

# 5. Set Permissions
echo "[5/10] Applying file permissions..."
chmod -R 755 .
chmod -R 777 data

# 6. Configure Apache Reverse Proxy
echo "[6/10] Configuring Apache reverse proxy for app.pasquared.space..."
sudo a2dissite 000-default || true

cat <<EOF | sudo tee /etc/apache2/sites-available/app-pasquared.conf
<VirtualHost *:80>
    ServerName app.pasquared.space
    
    # Do not proxy Let's Encrypt / Certbot validation challenges
    ProxyPass /.well-known/acme-challenge/ !
    
    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/
    
    # WebSockets / SSE Support
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule /(.*) ws://127.0.0.1:3000/\$1 [P,L]

    ErrorLog \${APACHE_LOG_DIR}/app_pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/app_pasquared_access.log combined
</VirtualHost>
EOF

sudo a2ensite app-pasquared.conf
sudo apache2ctl configtest
sudo systemctl restart apache2
sudo systemctl enable apache2

# 7. SSL Certificate Generation (Let's Encrypt)
echo "[7/10] Generating and Installing SSL Certificate via Certbot..."
sudo certbot --apache -d app.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com --redirect --no-eff-email || echo "Certbot SSL installation skipped or domain DNS pending."

# 8. Verify Auto-Renewal
echo "[8/10] Ensuring SSL auto-renewal is active..."
sudo systemctl status certbot.timer --no-pager || true

# 9. Configure Environment Variables
echo "[9/10] Verifying environment setup..."
if [ ! -f .env ]; then
  echo "GEMINI_API_KEY=${GEMINI_API_KEY}" > .env
  echo "NODE_ENV=production" >> .env
  echo "PORT=3000" >> .env
fi

# 10. Start the System with PM2
echo "[10/10] Launching app.pasquared Knowledge Kernel with PM2..."
pm2 start dist/server.cjs --name app-pasquared
pm2 save
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME || true

echo "--------------------------------------------------"
echo "app.pasquared Installation Complete!"
echo "Access: https://app.pasquared.space"
echo "Restricted Super Admin: https://app.pasquared.space/rootsuperadmin"
echo "Super Admin Email: rogermei577@pasquared.space"
echo "Super Admin Password: 21121201@Roger-Pasq"
echo "Persistent Database: data/pasquared_db.json"
echo "Features: Health & Symptom Diagnostics, Image Analysis, UCL Protocol v1.6"
echo "--------------------------------------------------"
