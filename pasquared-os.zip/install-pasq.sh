#!/bin/bash

# PASQUARED-OS Automated Installation Script
# Target: Linux Debian 12
# Domain: app.pasquared.space
# Email: rogeriogomes11@gmail.com

set -e

echo "--------------------------------------------------"
echo "Initializing PASQUARED-OS Installation..."
echo "--------------------------------------------------"

# 1. Pre-installation Cleanup (Conflict Resolution)
echo "[1/8] Cleaning up existing services and freeing ports..."
sudo systemctl stop nginx || true
sudo systemctl disable nginx || true
sudo systemctl stop apache2 || true
sudo systemctl disable apache2 || true

# Kill any node/pm2 processes
sudo npm install -g pm2 || true
pm2 kill || true
sudo pkill -9 node || true

# Free port 80/443 explicitly if still held
sudo fuser -k 80/tcp || true
sudo fuser -k 443/tcp || true

# 2. System Updates
echo "[2/8] Updating system packages..."
sudo apt-get update && sudo apt-get upgrade -y

# 3. Install Dependencies
echo "[3/8] Installing dependencies (Node.js, Apache, Certbot)..."
sudo apt-get install -y curl gnupg2 ca-certificates lsb-release apache2 certbot python3-certbot-apache

# Fix Apache FQDN warning
echo "ServerName app.pasquared.space" | sudo tee /etc/apache2/conf-available/fqdn.conf
sudo a2enconf fqdn

# Enable Apache Proxy Modules
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod ssl
sudo a2enmod rewrite

# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 4. Clone and Setup Application
echo "[4/8] Setting up Pasquared-OS application (Multi-Language Enabled)..."
# sudo mkdir -p /var/www/pasquared-os
# sudo chown -R $USER:www-data /var/www/pasquared-os
npm install
npm run build

# 5. Set Permissions
echo "[5/8] Applying secure file permissions..."
# sudo chown -R www-data:www-data /var/www/pasquared-os
# sudo find /var/www/pasquared-os -type d -exec chmod 755 {} \;
# sudo find /var/www/pasquared-os -type f -exec chmod 644 {} \;

# 6. Update GeoIP Databases
echo "[6/8] Updating GeoIP databases for location detection..."

# 7. Configure SSL with Certbot
echo "[7/8] Configuring SSL for app.pasquared.space..."
# sudo certbot --apache -d app.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com

# 8. Configure Apache Reverse Proxy
echo "[8/8] Configuring Apache reverse proxy..."
cat <<EOF | sudo tee /etc/apache2/sites-available/pasquared.conf
<VirtualHost *:80>
    ServerName app.pasquared.space
    ProxyPreserveHost On
    ProxyPass / http://localhost:3000/
    ProxyPassReverse / http://localhost:3000/
    
    ErrorLog \${APACHE_LOG_DIR}/pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_access.log combined
</VirtualHost>
EOF

sudo a2ensite pasquared.conf
sudo systemctl restart apache2

# 9. Start the System
echo "[9/9] Starting Pasquared-OS Knowledge Clusters with PM2..."
pm2 start dist/server.cjs --name pasquared-os

echo "--------------------------------------------------"
echo "PASQUARED-OS Installation Complete!"
echo "Access: https://app.pasquared.space"
echo "Features: Multi-Language (Auto IP Detect), PCK-V1.6, Super Admin"
echo "Super Admin: rogermei577@pasquared.space"
echo "--------------------------------------------------"
