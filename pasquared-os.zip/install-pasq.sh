#!/bin/bash

# PASQUARED-OS Automated Installation Script
# Target: Linux Debian 12
# Domain: app.pasquared.space
# Email: rogeriogomes11@gmail.com

set -e

echo "--------------------------------------------------"
echo "Initializing PASQUARED-OS Installation..."
echo "--------------------------------------------------"

# 1. Pre-installation Cleanup (Conflict Resolution)
echo "[1/8] Cleaning up existing services and freeing ports..."
sudo systemctl stop nginx || true
sudo systemctl disable nginx || true
sudo systemctl stop apache2 || true
sudo systemctl disable apache2 || true

# Kill any node/pm2 processes
sudo npm install -g pm2 || true
pm2 kill || true
sudo pkill -9 node || true

# Free port 80/443 explicitly if still held
sudo fuser -k 80/tcp || true
sudo fuser -k 443/tcp || true

# 2. System Updates
echo "[2/8] Updating system packages..."
sudo apt-get update && sudo apt-get upgrade -y

# 3. Install Dependencies
echo "[3/8] Installing dependencies (Node.js, Apache, Certbot)..."
sudo apt-get install -y curl gnupg2 ca-certificates lsb-release apache2 certbot python3-certbot-apache

# Fix Apache FQDN warning
echo "ServerName app.pasquared.space" | sudo tee /etc/apache2/conf-available/fqdn.conf
sudo a2enconf fqdn

# Enable Apache Proxy Modules
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod ssl
sudo a2enmod rewrite

# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 4. Clone and Setup Application
echo "[4/8] Setting up Pasquared-OS application (Multi-Language Enabled)..."
# sudo mkdir -p /var/www/pasquared-os
# sudo chown -R $USER:www-data /var/www/pasquared-os
npm install
npm run build

# 5. Set Permissions
echo "[5/8] Applying secure file permissions..."
# sudo chown -R www-data:www-data /var/www/pasquared-os
# sudo find /var/www/pasquared-os -type d -exec chmod 755 {} \;
# sudo find /var/www/pasquared-os -type f -exec chmod 644 {} \;

# 6. Update GeoIP Databases
echo "[6/8] Updating GeoIP databases for location detection..."

# 7. Configure Apache Reverse Proxy
echo "[7/10] Configuring Apache reverse proxy..."
# Disable default site to prevent it from overriding our config
sudo a2dissite 000-default || true

cat <<EOF | sudo tee /etc/apache2/sites-available/pasquared.conf
<VirtualHost *:80>
    ServerName app.pasquared.space
    
    # Do not proxy Let's Encrypt / Certbot validation challenges
    ProxyPass /.well-known/acme-challenge/ !
    
    ProxyPreserveHost On
    ProxyPass / http://localhost:3000/
    ProxyPassReverse / http://localhost:3000/
    
    ErrorLog \${APACHE_LOG_DIR}/pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_access.log combined
</VirtualHost>
EOF

sudo a2ensite pasquared.conf
sudo apache2ctl configtest
sudo systemctl restart apache2

# 8. SSL Certificate Generation (Let's Encrypt)
echo "[8/10] Generating and Installing SSL Certificate via Certbot..."
# Execute certbot with Apache plugin, automatic HTTP->HTTPS redirect, and non-interactive TOS agreement
sudo certbot --apache -d app.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com --redirect --no-eff-email

# 9. Verify Auto-Renewal
echo "[9/10] Ensuring SSL auto-renewal is active..."
sudo systemctl status certbot.timer --no-pager || true
sudo certbot renew --dry-run

# 10. Start the System
echo "[10/10] Starting Pasquared-OS Knowledge Clusters with PM2..."
pm2 start dist/server.cjs --name pasquared-os

echo "--------------------------------------------------"
echo "PASQUARED-OS Installation Complete!"
echo "Access: https://app.pasquared.space"
echo "Restricted Super Admin: https://app.pasquared.space/rootsuperadmin"
echo "Super Admin Email: rogermei577@pasquared.space"
echo "Super Admin Password: 21121201@Roger-Pasq"
echo "Persistent Database: data/pasquared_db.json"
echo "Features: Multi-Language (Auto IP Detect), PCK-V1.6, Knowledge Loader (SA & NA)"
echo "--------------------------------------------------"
