#!/bin/bash

# PASQUARED-OS Automated Installation Script
# Target: Linux Debian 12
# Domain: app.pasquared.space
# Email: rogeriogomes11@gmail.com

set -e

echo "--------------------------------------------------"
echo "Initializing PASQUARED-OS Installation..."
echo "--------------------------------------------------"

# 1. System Updates
echo "[1/6] Updating system packages..."
sudo apt-get update && sudo apt-get upgrade -y

# 2. Install Dependencies
echo "[2/7] Installing dependencies (Node.js, Apache, Docker, Certbot)..."
sudo apt-get install -y curl gnupg2 ca-certificates lsb-release apache2 certbot python3-certbot-apache

# Enable Apache Proxy Modules
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod ssl
sudo a2enmod rewrite

# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Clone and Setup Application
echo "[3/7] Setting up Pasquared-OS application (Multi-Language Enabled)..."
# sudo mkdir -p /var/www/pasquared-os
# sudo chown -R $USER:www-data /var/www/pasquared-os
npm install
npm run build

# 4. Set Permissions
echo "[4/7] Applying secure file permissions..."
# sudo chown -R www-data:www-data /var/www/pasquared-os
# sudo find /var/www/pasquared-os -type d -exec chmod 755 {} \;
# sudo find /var/www/pasquared-os -type f -exec chmod 644 {} \;

# 5. Update GeoIP Databases
echo "[5/7] Updating GeoIP databases for location detection..."

# 6. Configure SSL with Certbot
echo "[6/7] Configuring SSL for app.pasquared.space..."
# sudo certbot --apache -d app.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com

# 7. Configure Apache Reverse Proxy
echo "[7/7] Configuring Apache reverse proxy..."
cat <<EOF | sudo tee /etc/apache2/sites-available/pasquared.conf
<VirtualHost *:80>
    ServerName app.pasquared.space
    ProxyPreserveHost On
    ProxyPass / http://localhost:3000/
    ProxyPassReverse / http://localhost:3000/
    
    ErrorLog \${APACHE_LOG_DIR}/pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_access.log combined
</VirtualHost>
EOF

sudo a2ensite pasquared.conf
sudo systemctl restart apache2

# 6. Start the System
echo "[6/6] Starting Pasquared-OS Knowledge Clusters..."
# Using PM2 to manage the process
sudo npm install -g pm2
pm2 start dist/server.cjs --name pasquared-os

echo "--------------------------------------------------"
echo "PASQUARED-OS Installation Complete!"
echo "Access: https://app.pasquared.space"
echo "Features: Multi-Language (Auto IP Detect), PCK-V1.6, Super Admin"
echo "Super Admin: rogermei577@pasquared.space"
echo "--------------------------------------------------"
