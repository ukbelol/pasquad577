#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

# ============================================================
# PASQUARED OS - Instalador Completo Debian 12 (install-geral.sh)
# Monorepo TypeScript + Microserviços + PostgreSQL 16 + Apache + Interface Neon
# CORRIGIDO: Tipos TypeScript (@types/pg, @types/node), Ordem de Build e Copia de Schemas
# ============================================================

PASQ_DOMAIN="${PASQ_DOMAIN:-app.pasquared.space}"
PASQ_LE_EMAIL="${PASQ_LE_EMAIL:-rogermei577@gmail.com}"
INSTALL_DIR="${INSTALL_DIR:-/opt/pasquared-os}"
APP_USER="${APP_USER:-pasq}"
APP_GROUP="${APP_GROUP:-pasq}"
DB_NAME="${DB_NAME:-pasquared}"
DB_USER="${DB_USER:-pasq}"
DB_PASSWORD="${DB_PASSWORD:-}"
NODE_MAJOR="${NODE_MAJOR:-22}"

export DEBIAN_FRONTEND=noninteractive

log(){ printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn(){ printf '\033[1;33mAVISO: %s\033[0m\n' "$*" >&2; }
die(){ printf '\033[1;31mERRO: %s\033[0m\n' "$*" >&2; exit 1; }
trap 'die "Falha na linha $LINENO. Consulte o log do comando acima."' ERR

[[ "$EUID" -eq 0 ]] || die "Execute como root: sudo bash install-geral.sh"

if [ -f /etc/os-release ]; then
  source /etc/os-release
  if [[ "${ID:-}" != "debian" || "${VERSION_ID:-}" != "12" ]]; then
    warn "Sistema operacional detectado: ${ID:-desconhecido} ${VERSION_ID:-}. Recomendado: Debian 12."
  fi
fi

command -v systemctl >/dev/null || die "systemd é obrigatório."

# Senha PostgreSQL gerada com segurança caso não seja informada
if [[ -z "$DB_PASSWORD" ]]; then
  DB_PASSWORD="$(openssl rand -hex 24)"
fi

log "Instalando dependências do sistema"
apt-get update
apt-get install -y --no-install-recommends \
  ca-certificates curl gnupg openssl build-essential git unzip zip jq \
  apache2 ufw certbot python3-certbot-apache \
  postgresql-common

# ============================================================
# Node.js 22 - Debian 12
# ============================================================
log "Configurando Node.js ${NODE_MAJOR}.x"
install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key \
  | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
chmod 0644 /etc/apt/keyrings/nodesource.gpg
echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_${NODE_MAJOR}.x nodistro main" \
  > /etc/apt/sources.list.d/nodesource.list
apt-get update
apt-get install -y nodejs
node --version
npm --version

# ============================================================
# PostgreSQL 16 - PGDG
# ============================================================
log "Configurando PostgreSQL 16"
install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc \
  | gpg --dearmor --yes -o /etc/apt/keyrings/postgresql.gpg
chmod 0644 /etc/apt/keyrings/postgresql.gpg
echo "deb [signed-by=/etc/apt/keyrings/postgresql.gpg] http://apt.postgresql.org/pub/repos/apt bookworm-pgdg main" \
  > /etc/apt/sources.list.d/pgdg.list
apt-get update
apt-get install -y postgresql-16 postgresql-client-16
systemctl enable --now postgresql

# ============================================================
# Usuário da aplicação e estrutura de diretórios
# ============================================================
log "Criando usuário e diretórios do sistema"
getent group "$APP_GROUP" >/dev/null 2>&1 || groupadd --system "$APP_GROUP"
id -u "$APP_USER" >/dev/null 2>&1 || \
  useradd --system --create-home --home-dir "/home/$APP_USER" \
    --shell /usr/sbin/nologin --gid "$APP_GROUP" "$APP_USER"

install -d -o "$APP_USER" -g "$APP_GROUP" -m 0755 "$INSTALL_DIR"
mkdir -p \
  "$INSTALL_DIR/packages/shared/src" \
  "$INSTALL_DIR/packages/pql/src" \
  "$INSTALL_DIR/services/usr/src/schemas" \
  "$INSTALL_DIR/services/mved/src" \
  "$INSTALL_DIR/services/smee/src" \
  "$INSTALL_DIR/services/catalog/src" \
  "$INSTALL_DIR/services/pck/src" \
  "$INSTALL_DIR/services/harvester-med/src" \
  "$INSTALL_DIR/services/gateway/src" \
  "$INSTALL_DIR/web/assets" \
  "$INSTALL_DIR/sql" \
  "$INSTALL_DIR/apache"

# ============================================================
# Arquivos Raiz do Monorepo (CORRIGIDO)
# ============================================================
log "Gerando monorepo TypeScript com suporte completo de tipagem"

# CORREÇÃO CRÍTICA: devDependencies globais incluindo @types/pg e @types/node
# e script de build sequencial por ordem de dependência dos pacotes
cat > "$INSTALL_DIR/package.json" <<'EOF'
{
  "name": "pasquared-os",
  "private": true,
  "workspaces": [
    "packages/*",
    "services/*"
  ],
  "scripts": {
    "build:packages": "npm run build --workspace=@pasq/shared && npm run build --workspace=@pasq/pql",
    "build:services": "npm run build --workspace=@pasq/usr && npm run build --workspace=@pasq/mved && npm run build --workspace=@pasq/smee && npm run build --workspace=@pasq/catalog && npm run build --workspace=@pasq/pck && npm run build --workspace=@pasq/harvester-med && npm run build --workspace=@pasq/gateway",
    "build": "npm run build:packages && npm run build:services"
  },
  "engines": {
    "node": ">=22"
  },
  "devDependencies": {
    "typescript": "5.7.3",
    "@types/node": "22.10.2",
    "@types/pg": "8.11.10"
  }
}
EOF

cat > "$INSTALL_DIR/tsconfig.base.json" <<'EOF'
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "CommonJS",
    "moduleResolution": "Node",
    "strict": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "resolveJsonModule": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "sourceMap": true
  }
}
EOF

cat > "$INSTALL_DIR/.env" <<EOF
NODE_ENV=production
GATEWAY_PORT=3000
PCK_URL=http://127.0.0.1:3010
USR_URL=http://127.0.0.1:3020
MVED_URL=http://127.0.0.1:3030
SMEE_URL=http://127.0.0.1:3040
CATALOG_URL=http://127.0.0.1:3050
PGHOST=127.0.0.1
PGPORT=5432
PGUSER=${DB_USER}
PGPASSWORD=${DB_PASSWORD}
PGDATABASE=${DB_NAME}
PASQ_DOMAIN=${PASQ_DOMAIN}
PASQ_HARV_EMAIL=${PASQ_LE_EMAIL}
EOF
chmod 0600 "$INSTALL_DIR/.env"

# ============================================================
# Banco de Dados
# ============================================================
cat > "$INSTALL_DIR/sql/init.sql" <<'EOF'
CREATE TABLE IF NOT EXISTS ekos (
  id TEXT PRIMARY KEY,
  domain TEXT NOT NULL,
  hypotheses JSONB NOT NULL,
  evidence JSONB,
  status TEXT NOT NULL,
  confidence NUMERIC,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS insights (
  id TEXT PRIMARY KEY,
  eko_id TEXT REFERENCES ekos(id),
  category TEXT,
  theme TEXT,
  novelty_score NUMERIC,
  confidence NUMERIC,
  impact NUMERIC,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ucis (
  id TEXT PRIMARY KEY,
  ucl JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  started_at TIMESTAMPTZ DEFAULT now(),
  state JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS session_events (
  id TEXT PRIMARY KEY,
  session_id TEXT REFERENCES sessions(id) ON DELETE CASCADE,
  ts TIMESTAMPTZ DEFAULT now(),
  payload JSONB NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ekos_created_at ON ekos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_insights_created_at ON insights(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_session_events_session ON session_events(session_id);
EOF

# ============================================================
# Pacote: Shared
# ============================================================
cat > "$INSTALL_DIR/packages/shared/package.json" <<'EOF'
{
  "name": "@pasq/shared",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc -p tsconfig.json"
  },
  "devDependencies": {
    "@types/node": "22.10.2"
  }
}
EOF

cat > "$INSTALL_DIR/packages/shared/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src",
    "declaration": true,
    "declarationMap": true
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/packages/shared/src/types.ts" <<'EOF'
export type UCIType =
  | "texto" | "imagem" | "som" | "cheiro" | "memoria"
  | "emocao" | "simbolo" | "conceito" | "evento";

export type UCL = {
  ObjectID: string;
  SourceID: string;
  InputType: string;
  Language: string;
  Category: string;
  Theme: string;
  Group?: string;
  SubGroup?: string;
  Timestamp: string;
  Context: Record<string, unknown>;
  Content: Record<string, unknown>;
  Metadata: Record<string, unknown>;
  Relationships?: { type: string; target: string; w: number }[];
  Confidence?: number;
  Priority?: string;
  ExecutionID?: string;
  Version: string;
  CDNA?: Record<string, unknown>;
};

export type Hypothesis = {
  id: string;
  description: string;
  domain: string;
  scores?: Record<string, number>;
};

export type EKO = {
  id: string;
  domain: string;
  hypotheses: Hypothesis[];
  evidence?: unknown;
  status: string;
  confidence?: number;
};

export type Insight = {
  id: string;
  ekoId: string;
  category?: string;
  theme?: string;
  noveltyScore?: number;
  confidence?: number;
  impact?: number;
};
EOF

cat > "$INSTALL_DIR/packages/shared/src/utils.ts" <<'EOF'
export const uid = (prefix = "") =>
  `${prefix}${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
EOF

cat > "$INSTALL_DIR/packages/shared/src/index.ts" <<'EOF'
export * from "./types";
export * from "./utils";
EOF

# ============================================================
# Pacote: PQL
# ============================================================
cat > "$INSTALL_DIR/packages/pql/package.json" <<'EOF'
{
  "name": "@pasq/pql",
  "version": "0.1.0",
  "main": "dist/parser.js",
  "types": "dist/parser.d.ts",
  "scripts": {
    "build": "tsc -p tsconfig.json"
  },
  "devDependencies": {
    "@types/node": "22.10.2"
  }
}
EOF

cat > "$INSTALL_DIR/packages/pql/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src",
    "declaration": true,
    "declarationMap": true
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/packages/pql/src/parser.ts" <<'EOF'
export type PQLCommand =
  | { op: "OBSERVE"; value: string }
  | { op: "ASSOCIATE"; from: string; to: string; rtype?: string; weight?: number }
  | { op: "CONTEXT"; kv: Record<string, string | number> }
  | { op: "GENERATE"; what: "HYPOTHESES"; using?: string; top?: number }
  | { op: "VALIDATE"; target: string; policy?: string }
  | { op: "LEARN"; target: string }
  | { op: "SELECT"; what: "MEANING"; criteria?: string; threshold?: number };

export function parsePQL(script: string): PQLCommand[] {
  const lines = script.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const cmds: PQLCommand[] = [];

  for (const line of lines) {
    if (/^OBSERVE\b/i.test(line)) {
      cmds.push({
        op: "OBSERVE",
        value: line.replace(/^OBSERVE\s+/i, "").replace(/^["']|["']$/g, "")
      });
    } else if (/^ASSOCIATE\b/i.test(line)) {
      const m = line.match(/^ASSOCIATE\s+(\S+)\s+(\S+)(?:\s+TYPE\s+(\S+))?(?:\s+WEIGHT\s+([\d.]+))?/i);
      if (m) cmds.push({ op: "ASSOCIATE", from: m[1], to: m[2], rtype: m[3], weight: m[4] ? Number(m[4]) : undefined });
    } else if (/^CONTEXT\b/i.test(line)) {
      const kv: Record<string, string | number> = {};
      line.replace(/^CONTEXT\s+/i, "").split(/[,\s]+/).filter(Boolean).forEach(p => {
        const [k, raw] = p.split("=");
        if (k && raw) kv[k] = /^-?\d+(\.\d+)?$/.test(raw) ? Number(raw) : raw;
      });
      cmds.push({ op: "CONTEXT", kv });
    } else if (/^GENERATE\b/i.test(line)) {
      const top = line.match(/\bTOP\s+(\d+)/i);
      const using = line.match(/\bUSING\s+(\S+)/i);
      cmds.push({ op: "GENERATE", what: "HYPOTHESES", using: using?.[1], top: top ? Number(top[1]) : undefined });
    } else if (/^VALIDATE\b/i.test(line)) {
      const policy = line.match(/\bPOLICY\s+(\S+)/i);
      const target = line.replace(/^VALIDATE\s+/i, "").split(/\s+/)[0] || "";
      cmds.push({ op: "VALIDATE", target, policy: policy?.[1] });
    } else if (/^LEARN\b/i.test(line)) {
      cmds.push({ op: "LEARN", target: line.replace(/^LEARN\s+/i, "").trim() || "RESULT" });
    } else if (/^SELECT\b/i.test(line)) {
      const criteria = line.match(/\bCRITERIA\s+(\S+)/i);
      const threshold = line.match(/\bTHRESHOLD\s+([\d.]+)/i);
      cmds.push({
        op: "SELECT",
        what: "MEANING",
        criteria: criteria?.[1],
        threshold: threshold ? Number(threshold[1]) : undefined
      });
    }
  }

  return cmds;
}
EOF

# ============================================================
# Serviço: USR (CORRIGIDO: Schema TS nativo + JSON export)
# ============================================================
cat > "$INSTALL_DIR/services/usr/package.json" <<'EOF'
{
  "name": "@pasq/usr",
  "version": "1.0.0",
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "ajv": "8.17.1",
    "ajv-formats": "3.0.1",
    "fastify": "5.2.1"
  },
  "devDependencies": {
    "@types/node": "22.10.2"
  }
}
EOF

cat > "$INSTALL_DIR/services/usr/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src"
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/services/usr/src/schemas/ucl10.ts" <<'EOF'
export const ucl10Schema = {
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "UCL-1.0",
  "type": "object",
  "required": [
    "ObjectID", "SourceID", "InputType", "Language", "Category",
    "Theme", "Timestamp", "Context", "Content", "Metadata", "Version"
  ],
  "properties": {
    "ObjectID": {"type": "string"},
    "SourceID": {"type": "string"},
    "InputType": {"type": "string"},
    "Language": {"type": "string"},
    "Category": {"type": "string"},
    "Theme": {"type": "string"},
    "Group": {"type": "string"},
    "SubGroup": {"type": "string"},
    "Timestamp": {"type": "string"},
    "Context": {"type": "object"},
    "Content": {"type": "object"},
    "Metadata": {"type": "object"},
    "Relationships": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["type", "target", "w"],
        "properties": {
          "type": {"type": "string"},
          "target": {"type": "string"},
          "w": {"type": "number"}
        }
      }
    },
    "Confidence": {"type": "number"},
    "Priority": {"type": "string"},
    "ExecutionID": {"type": "string"},
    "Version": {"type": "string"},
    "CDNA": {"type": "object"}
  },
  "additionalProperties": true
};
EOF

cat > "$INSTALL_DIR/services/usr/src/index.ts" <<'EOF'
import Fastify from "fastify";
import Ajv from "ajv";
import addFormats from "ajv-formats";
import { ucl10Schema } from "./schemas/ucl10";

const app = Fastify({ logger: true });
const ajv = new Ajv({ allErrors: true });
addFormats(ajv);

const validators: Record<string, ReturnType<typeof ajv.compile>> = {
  "UCL-1.0": ajv.compile(ucl10Schema)
};

app.get("/health", async () => ({ ok: true, service: "usr" }));

app.get("/schema/:name", async (req, reply) => {
  const name = (req.params as { name: string }).name;
  if (!validators[name]) return reply.code(404).send({ error: "schema not found" });
  return ucl10Schema;
});

app.post("/validate", async (req, reply) => {
  const body = (req.body || {}) as { schemaName?: string; payload?: unknown };
  const validator = validators[body.schemaName || "UCL-1.0"];
  if (!validator) return reply.code(400).send({ error: "schema not found" });

  const valid = validator(body.payload);
  return valid ? { valid: true } : { valid: false, errors: validator.errors };
});

app.listen({ port: 3020, host: "127.0.0.1" });
EOF

# ============================================================
# Serviço: MVED
# ============================================================
cat > "$INSTALL_DIR/services/mved/package.json" <<'EOF'
{
  "name": "@pasq/mved",
  "version": "1.0.0",
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "fastify": "5.2.1"
  },
  "devDependencies": {
    "@types/node": "22.10.2"
  }
}
EOF

cat > "$INSTALL_DIR/services/mved/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src"
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/services/mved/src/index.ts" <<'EOF'
import Fastify from "fastify";
import { clamp01 } from "@pasq/shared";

const app = Fastify({ logger: true });

const policy = {
  criteria: {
    logica: { weight: 0.25 },
    temporal: { weight: 0.15 },
    semantica: { weight: 0.20 },
    evidencia: { weight: 0.40 }
  },
  decision: { accept_threshold: 0.78, reject_threshold: 0.55 }
};

app.get("/health", async () => ({ ok: true, service: "mved" }));

app.post("/validate", async (req) => {
  const body = (req.body || {}) as {
    hypothesis?: { id?: string };
    evidence?: Partial<Record<"logica" | "temporal" | "semantica" | "evidencia", number>>;
    policy?: string;
  };

  const e = body.evidence || {};
  const scores = {
    logica: clamp01(e.logica ?? 0.80),
    temporal: clamp01(e.temporal ?? 0.70),
    semantica: clamp01(e.semantica ?? 0.75),
    evidencia: clamp01(e.evidencia ?? 0.80)
  };

  const ici =
    scores.logica * policy.criteria.logica.weight +
    scores.temporal * policy.criteria.temporal.weight +
    scores.semantica * policy.criteria.semantica.weight +
    scores.evidencia * policy.criteria.evidencia.weight;

  let status: "validada" | "refutada" | "inconclusiva" = "inconclusiva";
  if (ici >= policy.decision.accept_threshold) status = "validada";
  else if (ici <= policy.decision.reject_threshold) status = "refutada";

  return {
    hypothesisId: body.hypothesis?.id,
    ici: clamp01(ici),
    status,
    reasons: ["scored-by-mved", `policy=${body.policy || "default"}`]
  };
});

app.listen({ port: 3030, host: "127.0.0.1" });
EOF

# ============================================================
# Serviço: SMEE (CORRIGIDO: @types/pg + @types/node)
# ============================================================
cat > "$INSTALL_DIR/services/smee/package.json" <<'EOF'
{
  "name": "@pasq/smee",
  "version": "1.0.0",
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "fastify": "5.2.1",
    "pg": "8.13.1"
  },
  "devDependencies": {
    "@types/node": "22.10.2",
    "@types/pg": "8.11.10"
  }
}
EOF

cat > "$INSTALL_DIR/services/smee/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src"
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/services/smee/src/index.ts" <<'EOF'
import Fastify from "fastify";
import { Pool } from "pg";

const app = Fastify({ logger: true });

const pool = new Pool({
  host: process.env.PGHOST || "127.0.0.1",
  port: Number(process.env.PGPORT || 5432),
  user: process.env.PGUSER || "pasq",
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE || "pasquared"
});

app.get("/health", async () => {
  await pool.query("SELECT 1");
  return { ok: true, service: "smee" };
});

app.post("/ucl", async (req) => {
  const body = req.body as Record<string, unknown>;
  const id = String(body.ObjectID);
  await pool.query(
    "INSERT INTO ucis (id, ucl) VALUES ($1,$2) ON CONFLICT (id) DO UPDATE SET ucl=$2",
    [id, JSON.stringify(body)]
  );
  return { ok: true };
});

app.post("/eko", async (req) => {
  const e = req.body as {
    id: string; domain: string; hypotheses: unknown[];
    evidence?: unknown; status: string; confidence?: number;
  };
  await pool.query(
    `INSERT INTO ekos (id, domain, hypotheses, evidence, status, confidence)
     VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (id) DO UPDATE SET
       hypotheses=$3,evidence=$4,status=$5,confidence=$6`,
    [
      e.id, e.domain, JSON.stringify(e.hypotheses),
      e.evidence ? JSON.stringify(e.evidence) : null,
      e.status, e.confidence ?? null
    ]
  );
  return { ok: true };
});

app.post("/insight", async (req) => {
  const i = req.body as {
    id: string; ekoId: string; category?: string; theme?: string;
    noveltyScore?: number; confidence?: number; impact?: number;
  };
  await pool.query(
    `INSERT INTO insights
      (id, eko_id, category, theme, novelty_score, confidence, impact)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (id) DO UPDATE SET
       category=$3,theme=$4,novelty_score=$5,confidence=$6,impact=$7`,
    [
      i.id, i.ekoId, i.category ?? null, i.theme ?? null,
      i.noveltyScore ?? null, i.confidence ?? null, i.impact ?? null
    ]
  );
  return { ok: true };
});

app.get("/eko", async (req) => {
  const limit = Math.min(100, Math.max(1, Number((req.query as { limit?: string }).limit || 50)));
  return (await pool.query(
    "SELECT * FROM ekos ORDER BY created_at DESC LIMIT $1", [limit]
  )).rows;
});

app.get("/insight", async (req) => {
  const limit = Math.min(100, Math.max(1, Number((req.query as { limit?: string }).limit || 50)));
  return (await pool.query(
    "SELECT * FROM insights ORDER BY created_at DESC LIMIT $1", [limit]
  )).rows;
});

app.post("/session", async (req) => {
  const body = req.body as { id: string; state: unknown };
  await pool.query(
    `INSERT INTO sessions (id,state) VALUES ($1,$2)
     ON CONFLICT (id) DO UPDATE SET state=$2`,
    [body.id, JSON.stringify(body.state)]
  );
  return { ok: true };
});

app.post("/session_event", async (req) => {
  const body = req.body as { id: string; session_id: string; payload: unknown };
  await pool.query(
    "INSERT INTO session_events (id,session_id,payload) VALUES ($1,$2,$3)",
    [body.id, body.session_id, JSON.stringify(body.payload)]
  );
  return { ok: true };
});

app.get("/session/:id", async (req) => {
  const id = (req.params as { id: string }).id;
  const r = await pool.query("SELECT * FROM sessions WHERE id=$1", [id]);
  return r.rows[0] || null;
});

app.addHook("onClose", async () => pool.end());

app.listen({ port: 3040, host: "127.0.0.1" });
EOF

# ============================================================
# Serviço: CATALOG
# ============================================================
cat > "$INSTALL_DIR/services/catalog/package.json" <<'EOF'
{
  "name": "@pasq/catalog",
  "version": "1.0.0",
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "fastify": "5.2.1"
  },
  "devDependencies": {
    "@types/node": "22.10.2"
  }
}
EOF

cat > "$INSTALL_DIR/services/catalog/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src"
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/services/catalog/src/index.ts" <<'EOF'
import Fastify from "fastify";

const app = Fastify({ logger: true });
const SMEE = process.env.SMEE_URL || "http://127.0.0.1:3040";

app.get("/health", async () => ({ ok: true, service: "catalog" }));

app.get("/catalog/ekos", async () => {
  try {
    const res = await fetch(`${SMEE}/eko`);
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
});

app.get("/catalog/insights", async () => {
  try {
    const res = await fetch(`${SMEE}/insight`);
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
});

app.listen({ port: 3050, host: "127.0.0.1" });
EOF

# ============================================================
# Serviço: PCK
# ============================================================
cat > "$INSTALL_DIR/services/pck/package.json" <<'EOF'
{
  "name": "@pasq/pck",
  "version": "1.0.0",
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "fastify": "5.2.1",
    "@pasq/shared": "1.0.0",
    "@pasq/pql": "0.1.0"
  },
  "devDependencies": {
    "@types/node": "22.10.2"
  }
}
EOF

cat > "$INSTALL_DIR/services/pck/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src"
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/services/pck/src/index.ts" <<'EOF'
import Fastify from "fastify";
import { uid } from "@pasq/shared";
import type { UCL, Hypothesis, EKO } from "@pasq/shared";

const app = Fastify({ logger: true });
const USR = process.env.USR_URL || "http://127.0.0.1:3020";
const MVED = process.env.MVED_URL || "http://127.0.0.1:3030";
const SMEE = process.env.SMEE_URL || "http://127.0.0.1:3040";

async function validateUCL(ucl: UCL) {
  const r = await fetch(`${USR}/validate`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ schemaName: "UCL-1.0", payload: ucl })
  });
  return r.json() as Promise<{ valid: boolean; errors?: unknown }>;
}

function naiveHypotheses(ucl: UCL, ctx: Record<string, unknown>): Hypothesis[] {
  const domain = String(ctx.dominio || ucl.Category || "Geral");
  return [
    { id: uid("H-"), description: `Hipótese sobre ${ucl.Theme}`, domain },
    { id: uid("H-"), description: `Relação ${ucl.Category} -> ${ucl.Theme}`, domain }
  ];
}

async function runCycle(ucl: UCL, ctx: Record<string, unknown>) {
  const validation = await validateUCL(ucl);
  if (!validation.valid) throw new Error("UCL inválido perante o esquema USR");

  await fetch(`${SMEE}/ucl`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(ucl)
  });

  const hypotheses = naiveHypotheses(ucl, ctx);

  const validations = await Promise.all(
    hypotheses.map(async hypothesis => {
      const r = await fetch(`${MVED}/validate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          hypothesis,
          evidence: { logica: 0.8, temporal: 0.7, semantica: 0.75, evidencia: 0.8 },
          policy: "clinica-n3"
        })
      });
      return r.json() as Promise<{ status: string; ici: number }>;
    })
  );

  const accepted = validations.filter(v => v.status === "validada");
  const eko: EKO = {
    id: uid("EKO-"),
    domain: String(ctx.dominio || ucl.Category || "Geral"),
    hypotheses,
    evidence: { source: ucl.SourceID, theme: ucl.Theme },
    status: accepted.length ? "parcialmente-validado" : "inconclusivo",
    confidence: accepted.length / Math.max(1, hypotheses.length)
  };

  await fetch(`${SMEE}/eko`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(eko)
  });

  const insight = {
    id: uid("INS-"),
    ekoId: eko.id,
    category: ucl.Category,
    theme: ucl.Theme,
    noveltyScore: Math.random(),
    confidence: eko.confidence,
    impact: Math.random()
  };

  await fetch(`${SMEE}/insight`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(insight)
  });

  return { eko, insight, validations };
}

app.get("/health", async () => ({ ok: true, service: "pck" }));

app.post("/cycle", async (req, reply) => {
  try {
    const body = (req.body || {}) as { ucl: UCL; context?: Record<string, unknown> };
    return await runCycle(body.ucl, body.context || {});
  } catch (error) {
    req.log.error(error);
    return reply.code(400).send({
      error: error instanceof Error ? error.message : "cycle failed"
    });
  }
});

app.listen({ port: 3010, host: "127.0.0.1" });
EOF

# ============================================================
# Serviço: Harvester PubMed
# ============================================================
cat > "$INSTALL_DIR/services/harvester-med/package.json" <<'EOF'
{
  "name": "@pasq/harvester-med",
  "version": "1.0.0",
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "@pasq/shared": "1.0.0"
  },
  "devDependencies": {
    "@types/node": "22.10.2"
  }
}
EOF

cat > "$INSTALL_DIR/services/harvester-med/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src"
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/services/harvester-med/src/index.ts" <<'EOF'
import type { UCL } from "@pasq/shared";

const SMEE = process.env.SMEE_URL || "http://127.0.0.1:3040";
const PCK = process.env.PCK_URL || "http://127.0.0.1:3010";
const EMAIL = process.env.PASQ_HARV_EMAIL || "ops@example.com";

async function harvestPubMed(term: string, retmax = 10): Promise<UCL[]> {
  const params = new URLSearchParams({
    db: "pubmed",
    term,
    retmax: String(retmax),
    retmode: "json",
    tool: "pasquared-os",
    email: EMAIL
  });

  const es = await fetch(
    `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?${params}`
  );
  if (!es.ok) return [];
  const esj = await es.json() as { esearchresult?: { idlist?: string[] } };
  const ids = esj.esearchresult?.idlist || [];
  if (!ids.length) return [];

  const summaryParams = new URLSearchParams({
    db: "pubmed",
    id: ids.join(","),
    retmode: "json",
    tool: "pasquared-os",
    email: EMAIL
  });

  const sm = await fetch(
    `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?${summaryParams}`
  );
  if (!sm.ok) return [];
  const sj = await sm.json() as { result?: Record<string, any> };

  const recs = Object.values(sj.result || {}).filter(
    (x: any) => x && typeof x === "object" && x.uid
  );

  const now = new Date().toISOString();

  return recs.map((r: any): UCL => ({
    ObjectID: `ucl-pubmed-${r.uid}`,
    SourceID: `pubmed:${r.uid}`,
    InputType: "text",
    Language: "en",
    Category: "Medicina",
    Theme: r.title || "Geral",
    Timestamp: now,
    Context: { region: "Américas", source: "PubMed" },
    Content: {
      title: r.title,
      authors: r.authors,
      journal: r.fulljournalname,
      pubdate: r.pubdate,
      uid: r.uid
    },
    Metadata: {
      provenance: "harvester-med-pubmed",
      note: "public bibliographic metadata"
    },
    Version: "UCL-1.0",
    CDNA: { domain: "Medicina", modalities: ["text"], sensitivity: "public" }
  }));
}

async function main() {
  const terms = [
    "heart failure AND anticoagulants",
    "atrial fibrillation AND anticoagulants",
    "acute coronary syndrome guidelines",
    "sepsis AND antibiotics",
    "pneumonia treatment guidelines"
  ];

  for (const term of terms) {
    try {
      const items = await harvestPubMed(term, 10);
      for (const ucl of items) {
        await fetch(`${SMEE}/ucl`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(ucl)
        });

        await fetch(`${PCK}/cycle`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ucl, context: { dominio: "Medicina" } })
        });

        await new Promise(resolve => setTimeout(resolve, 350));
      }
    } catch {
      // Continua se um termo falhar
    }
  }
}

main().catch(() => process.exit(1));
EOF

# ============================================================
# Serviço: Gateway (CORRIGIDO: @types/pg + @types/node)
# ============================================================
cat > "$INSTALL_DIR/services/gateway/package.json" <<'EOF'
{
  "name": "@pasq/gateway",
  "version": "1.0.0",
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "fastify": "5.2.1",
    "pg": "8.13.1",
    "@pasq/pql": "0.1.0"
  },
  "devDependencies": {
    "@types/node": "22.10.2",
    "@types/pg": "8.11.10"
  }
}
EOF

cat > "$INSTALL_DIR/services/gateway/tsconfig.json" <<'EOF'
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "outDir": "dist",
    "rootDir": "src"
  },
  "include": ["src/**/*.ts"]
}
EOF

cat > "$INSTALL_DIR/services/gateway/src/index.ts" <<'EOF'
import Fastify from "fastify";
import { Pool } from "pg";
import { parsePQL } from "@pasq/pql";

const app = Fastify({ logger: true });
const PCK = process.env.PCK_URL || "http://127.0.0.1:3010";

const pool = new Pool({
  host: process.env.PGHOST || "127.0.0.1",
  port: Number(process.env.PGPORT || 5432),
  user: process.env.PGUSER || "pasq",
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE || "pasquared"
});

type QA = {
  id: string;
  text: string;
  key: string;
  type: "yesno" | "choice" | "text";
  choices?: string[];
  next?: Record<string, string>;
};

const TRIAGE: Record<string, QA> = {
  q_start: {
    id: "q_start",
    text: "Qual é o principal sintoma?",
    key: "main_symptom",
    type: "choice",
    choices: ["dor no peito", "falta de ar", "febre", "dor abdominal", "cefaleia"],
    next: { default: "q_duration" }
  },
  q_duration: {
    id: "q_duration",
    text: "Há quanto tempo isso começou?",
    key: "duration",
    type: "choice",
    choices: ["<2h", "2-24h", ">24h"],
    next: { default: "q_severity" }
  },
  q_severity: {
    id: "q_severity",
    text: "Qual a intensidade do sintoma?",
    key: "severity",
    type: "choice",
    choices: ["leve", "moderado", "intenso"],
    next: { default: "q_alarm" }
  },
  q_alarm: {
    id: "q_alarm",
    text: "Há sinais de alarme, como desmaio, confusão, dor torácica forte ou falta de ar grave?",
    key: "alarms",
    type: "yesno",
    next: { yes: "end_emergency", no: "q_follow" }
  },
  q_follow: {
    id: "q_follow",
    text: "Descreva condições prévias relevantes.",
    key: "history",
    type: "text",
    next: { default: "end_predx" }
  },
  end_emergency: {
    id: "end_emergency",
    text: "Foram indicados sinais de alarme. Procure atendimento de emergência imediatamente.",
    key: "ack_emerg",
    type: "yesno"
  },
  end_predx: {
    id: "end_predx",
    text: "A triagem terminou. O resultado é apenas educacional e não substitui avaliação profissional.",
    key: "ack",
    type: "yesno"
  }
};

function nextQuestion(state: any): QA | undefined {
  const current = state.current || "q_start";
  const q = TRIAGE[current];
  if (!q?.next) return undefined;

  const answer = state.answers?.[q.key];
  let nextId: string | undefined;

  if (typeof answer === "string" && q.next[answer]) nextId = q.next[answer];
  else if (typeof answer === "boolean" && q.next[answer ? "yes" : "no"]) {
    nextId = q.next[answer ? "yes" : "no"];
  } else {
    nextId = q.next.default;
  }

  return nextId ? TRIAGE[nextId] : undefined;
}

function prediagnose(state: any) {
  const symptom = state.answers?.main_symptom;
  const severity = state.answers?.severity;

  let result = "Indeterminado";
  let risk = "baixo";

  if (symptom === "dor no peito") {
    result = "Possibilidades variadas; avaliação profissional é necessária.";
    if (severity === "intenso") risk = "moderado";
  } else if (symptom === "falta de ar") {
    result = "Possibilidades respiratórias ou cardiovasculares; avaliação profissional é necessária.";
    if (severity !== "leve") risk = "moderado";
  } else if (symptom === "febre") {
    result = "Possível processo infeccioso; é necessário avaliar contexto e sinais associados.";
  } else if (symptom === "dor abdominal") {
    result = "Há diversas causas possíveis; localização e sinais associados são importantes.";
  } else if (symptom === "cefaleia") {
    result = "Há diversas causas possíveis; sinais de alarme devem ser avaliados.";
  }

  return {
    prediagnostico: result,
    risco: risk,
    disclaimer: "Conteúdo educativo; não substitui avaliação médica."
  };
}

app.get("/api/health", async () => {
  const checks: Record<string, unknown> = { gateway: true };
  try {
    await pool.query("SELECT 1");
    checks.postgresql = true;
  } catch {
    checks.postgresql = false;
  }
  return { ok: checks.postgresql === true, service: "gateway", checks };
});

app.post("/api/pql/parse", async (req) => {
  const body = (req.body || {}) as { script?: string };
  return { commands: parsePQL(body.script || "") };
});

app.post("/api/ucl", async (req, reply) => {
  try {
    const r = await fetch(`${PCK}/cycle`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        ucl: req.body,
        context: { dominio: (req.body as any)?.Category || "Geral" }
      })
    });
    return await r.json();
  } catch (error) {
    return reply.code(400).send({
      error: error instanceof Error ? error.message : "PCK unavailable"
    });
  }
});

app.get("/api/catalog/ekos", async () => {
  try {
    const res = await fetch("http://127.0.0.1:3050/catalog/ekos");
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
});

app.get("/api/catalog/insights", async () => {
  try {
    const res = await fetch("http://127.0.0.1:3050/catalog/insights");
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
});

app.post("/api/assistant/session", async () => {
  const id = `sess-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const state = { current: "q_start", answers: {} };
  await pool.query(
    "INSERT INTO sessions (id,state) VALUES ($1,$2)",
    [id, JSON.stringify(state)]
  );
  return { sessionId: id, question: TRIAGE.q_start };
});

app.post("/api/assistant/answer", async (req, reply) => {
  const body = (req.body || {}) as { sessionId?: string; answer?: unknown };
  if (!body.sessionId) return reply.code(400).send({ error: "sessionId requerido" });

  const r = await pool.query("SELECT * FROM sessions WHERE id=$1", [body.sessionId]);
  if (!r.rows[0]) return reply.code(404).send({ error: "sessão não encontrada" });

  const state = r.rows[0].state;
  const current = state.current || "q_start";
  const q = TRIAGE[current] || TRIAGE.q_start;

  let value: unknown = body.answer;
  if (q.type === "yesno") {
    value = ["s", "sim", "yes", "true"].includes(
      String(body.answer).trim().toLowerCase()
    );
  }

  state.answers[q.key] = value;

  await pool.query(
    "INSERT INTO session_events (id,session_id,payload) VALUES ($1,$2,$3)",
    [
      `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      body.sessionId,
      JSON.stringify({ q: q.id, a: value })
    ]
  );

  const nx = nextQuestion({ current, answers: state.answers });

  if (!nx || q.id === "end_emergency") {
    state.current = "done";
    await pool.query(
      "UPDATE sessions SET state=$2 WHERE id=$1",
      [body.sessionId, JSON.stringify(state)]
    );

    if (q.id === "end_emergency") {
      return {
        done: true,
        emergency: true,
        message: "Procure atendimento de emergência imediatamente.",
        disclaimer: "Conteúdo educativo."
      };
    }

    return { done: true, ...prediagnose(state) };
  }

  state.current = nx.id;
  await pool.query(
    "UPDATE sessions SET state=$2 WHERE id=$1",
    [body.sessionId, JSON.stringify(state)]
  );

  return { question: nx };
});

app.addHook("onClose", async () => pool.end());

app.listen({ port: Number(process.env.GATEWAY_PORT || 3000), host: "127.0.0.1" });
EOF

# ============================================================
# GUI Frontend
# ============================================================
log "Criando interface gráfica neon responsiva"

cat > "$INSTALL_DIR/web/index.html" <<'EOF'
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#061016">
  <title>PASQUARED OS</title>
  <link rel="stylesheet" href="/assets/app.css">
</head>
<body>
  <div class="scanlines"></div>
  <header class="topbar">
    <div class="brand">
      <span class="brand-mark">P²</span>
      <div><strong>PASQUARED OS</strong><small>Cognitive Information Platform</small></div>
    </div>
    <div class="status"><span id="statusDot"></span><span id="statusText">conectando...</span></div>
  </header>

  <main class="shell">
    <section class="hero">
      <div>
        <span class="eyebrow">NEON CONTROL INTERFACE</span>
        <h1>Estruture. Relacione. Valide.</h1>
        <p>Interface operacional do PASQUARED OS com monitoramento, PQL, UCL e assistente.</p>
      </div>
      <div class="hero-grid">
        <div class="metric"><span>EKOs</span><b id="ekoCount">—</b></div>
        <div class="metric"><span>Insights</span><b id="insightCount">—</b></div>
        <div class="metric"><span>API</span><b id="apiState">—</b></div>
      </div>
    </section>

    <nav class="tabs">
      <button class="tab active" data-tab="dashboard">Dashboard</button>
      <button class="tab" data-tab="pql">PQL Console</button>
      <button class="tab" data-tab="assistant">Assistente</button>
      <button class="tab" data-tab="catalog">Catálogo</button>
    </nav>

    <section id="dashboard" class="panel active">
      <div class="grid two">
        <article class="card glow-blue">
          <h2>Status do sistema</h2>
          <div id="healthBox" class="health">Consultando serviços...</div>
        </article>
        <article class="card glow-green">
          <h2>Arquitetura</h2>
          <div class="service-list">
            <span><i></i> Gateway :3000</span>
            <span><i></i> PCK :3010</span>
            <span><i></i> USR :3020</span>
            <span><i></i> MVED :3030</span>
            <span><i></i> SMEE :3040</span>
            <span><i></i> Catalog :3050</span>
          </div>
        </article>
      </div>
    </section>

    <section id="pql" class="panel">
      <article class="card glow-blue">
        <div class="card-head">
          <h2>PQL Console</h2><span class="badge">PARSER</span>
        </div>
        <textarea id="pqlInput" spellcheck="false">OBSERVE "estrutura de informação"
CONTEXT dominio=Geral prioridade=0.8
GENERATE HYPOTHESES USING OBSERVATION TOP 3
SELECT MEANING CRITERIA=confidence THRESHOLD 0.78</textarea>
        <button id="parsePql" class="btn primary">Executar análise PQL</button>
        <pre id="pqlOutput" class="terminal">Aguardando comando...</pre>
      </article>
    </section>

    <section id="assistant" class="panel">
      <article class="card glow-green">
        <div class="card-head">
          <h2>Assistente</h2><span class="badge">EDUCACIONAL</span></div>
        <div id="chat" class="chat">
          <div class="bubble system">Inicie uma sessão para começar.</div>
        </div>
        <div id="answerArea" class="answer-area">
          <button id="startSession" class="btn primary">Iniciar sessão</button>
        </div>
        <small class="notice">Esta interface é um protótipo educacional e não substitui avaliação profissional.</small>
      </article>
    </section>

    <section id="catalog" class="panel">
      <div class="grid two">
        <article class="card glow-blue">
          <div class="card-head"><h2>EKOs recentes</h2><button id="refreshCatalog" class="btn small">Atualizar</button></div>
          <div id="ekos" class="list">Carregando...</div>
        </article>
        <article class="card glow-green">
          <div class="card-head"><h2>Insights recentes</h2></div>
          <div id="insights" class="list">Carregando...</div>
        </article>
      </div>
    </section>
  </main>

  <footer>© PASQUARED OS · Debian 12 · Node.js · PostgreSQL</footer>
  <script src="/assets/app.js"></script>
</body>
</html>
EOF

cat > "$INSTALL_DIR/web/assets/app.css" <<'EOF'
:root{
  --bg:#03080c;--panel:#07131a;--panel2:#091b22;--line:#12343d;
  --cyan:#00d9ff;--green:#00ff9d;--text:#dffcff;--muted:#79a4ad;
  --danger:#ff5577;--shadow:0 0 28px rgba(0,217,255,.12);
  font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif
}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;background:
radial-gradient(circle at 10% 0%,rgba(0,217,255,.12),transparent 30%),
radial-gradient(circle at 90% 20%,rgba(0,255,157,.09),transparent 28%),var(--bg);
color:var(--text)}
.scanlines{pointer-events:none;position:fixed;inset:0;opacity:.035;background:repeating-linear-gradient(0deg,#fff 0 1px,transparent 1px 4px);z-index:10}
.topbar{height:74px;border-bottom:1px solid var(--line);background:rgba(3,8,12,.82);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:space-between;padding:0 clamp(16px,4vw,52px);position:sticky;top:0;z-index:5}
.brand{display:flex;gap:12px;align-items:center}.brand-mark{display:grid;place-items:center;width:44px;height:44px;border:1px solid var(--cyan);color:var(--cyan);box-shadow:0 0 18px rgba(0,217,255,.35);border-radius:12px;font-weight:800}
.brand strong{display:block;letter-spacing:.14em;font-size:.92rem}.brand small{color:var(--muted);font-size:.7rem}
.status{display:flex;gap:8px;align-items:center;color:var(--muted);font-size:.8rem}.status span:first-child{width:9px;height:9px;border-radius:50%;background:var(--green);box-shadow:0 0 12px var(--green)}
.shell{width:min(1180px,92vw);margin:0 auto;padding:42px 0 60px}
.hero{display:flex;justify-content:space-between;gap:32px;align-items:end;margin-bottom:28px}
.eyebrow,.badge{font-size:.68rem;letter-spacing:.16em;color:var(--green)}
h1{font-size:clamp(2rem,5vw,4rem);line-height:1;margin:10px 0 14px;text-shadow:0 0 25px rgba(0,217,255,.2)}
h2{font-size:1rem;letter-spacing:.04em;margin:0}.hero p{color:var(--muted);max-width:680px}
.hero-grid{display:grid;grid-template-columns:repeat(3,100px);gap:10px}.metric{border:1px solid var(--line);background:rgba(7,19,26,.8);padding:14px;border-radius:12px}.metric span{display:block;color:var(--muted);font-size:.68rem}.metric b{font-size:1.55rem;color:var(--cyan)}
.tabs{display:flex;gap:8px;border-bottom:1px solid var(--line);margin-bottom:22px;overflow:auto}.tab{white-space:nowrap;background:none;color:var(--muted);border:0;padding:13px 16px;cursor:pointer;border-bottom:2px solid transparent}.tab.active{color:var(--cyan);border-color:var(--cyan)}
.panel{display:none}.panel.active{display:block}.grid{display:grid;gap:18px}.grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}
.card{background:linear-gradient(145deg,rgba(9,27,34,.92),rgba(5,13,18,.92));border:1px solid var(--line);border-radius:16px;padding:22px;box-shadow:var(--shadow);min-width:0}.glow-blue{box-shadow:0 0 26px rgba(0,217,255,.07)}.glow-green{box-shadow:0 0 26px rgba(0,255,157,.06)}
.card-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
textarea{width:100%;min-height:230px;resize:vertical;background:#02070a;color:#bff8ff;border:1px solid #16414b;border-radius:10px;padding:16px;font:13px/1.6 "JetBrains Mono",monospace;outline:none}
textarea:focus{border-color:var(--cyan);box-shadow:0 0 18px rgba(0,217,255,.12)}
.btn{border:1px solid var(--cyan);background:rgba(0,217,255,.08);color:var(--cyan);border-radius:9px;padding:11px 16px;cursor:pointer;font-weight:700;margin-top:12px}.btn:hover{box-shadow:0 0 18px rgba(0,217,255,.2)}.btn.primary{background:linear-gradient(90deg,rgba(0,217,255,.16),rgba(0,255,157,.12))}.btn.small{padding:7px 10px;margin:0;font-size:.75rem}
.terminal{white-space:pre-wrap;background:#010507;border:1px solid #0d2930;border-radius:10px;padding:15px;color:var(--green);min-height:100px;overflow:auto}
.service-list{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:18px}.service-list span{padding:10px;border:1px solid #12333a;border-radius:9px;color:var(--muted);font-size:.8rem}.service-list i{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green);margin-right:8px}
.health{color:var(--muted);line-height:1.8}.health strong{color:var(--green)}
.chat{min-height:230px;max-height:420px;overflow:auto;background:#02070a;border:1px solid #103039;border-radius:12px;padding:14px}.bubble{max-width:85%;padding:12px 14px;border-radius:12px;margin:8px 0;font-size:.9rem;line-height:1.5}.bubble.system{border:1px solid #16414b;color:#b9dce2}.bubble.user{margin-left:auto;border:1px solid rgba(0,255,157,.3);color:#caffea;background:rgba(0,255,157,.05)}
.answer-area{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.answer-area input,.answer-area select{flex:1;min-width:180px;background:#02070a;color:var(--text);border:1px solid #16414b;border-radius:9px;padding:11px}.choice{margin-top:0}
.notice{display:block;color:#58777e;margin-top:14px}.list{display:grid;gap:8px;max-height:430px;overflow:auto}.item{border:1px solid #12333a;border-radius:10px;padding:11px;font-size:.8rem}.item b{color:var(--cyan);display:block;margin-bottom:4px}.item span{color:var(--muted)}
footer{text-align:center;color:#45656c;font-size:.7rem;padding:25px;border-top:1px solid var(--line)}
@media(max-width:800px){.hero{display:block}.hero-grid{grid-template-columns:repeat(3,100px);margin-top:20px}.grid.two{grid-template-columns:1fr}}
EOF

cat > "$INSTALL_DIR/web/assets/app.js" <<'EOF'
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const json = async (url, opts) => {
  const r = await fetch(url, opts);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
};

$$(".tab").forEach(btn => btn.addEventListener("click", () => {
  $$(".tab").forEach(x => x.classList.remove("active"));
  $$(".panel").forEach(x => x.classList.remove("active"));
  btn.classList.add("active");
  $("#" + btn.dataset.tab).classList.add("active");
}));

async function health() {
  try {
    const h = await json("/api/health");
    $("#statusText").textContent = h.ok ? "online" : "degradado";
    $("#apiState").textContent = h.ok ? "OK" : "WARN";
    $("#healthBox").innerHTML = `<strong>ONLINE</strong><br>${Object.entries(h.checks||{}).map(([k,v]) => `${k}: ${v ? "OK" : "ERRO"}`).join("<br>")}`;
  } catch (e) {
    $("#statusText").textContent = "offline";
    $("#apiState").textContent = "ERR";
    $("#healthBox").textContent = e.message;
  }
}

async function catalog() {
  try {
    const [ekos, insights] = await Promise.all([
      json("/api/catalog/ekos"),
      json("/api/catalog/insights")
    ]);
    $("#ekoCount").textContent = ekos.length;
    $("#insightCount").textContent = insights.length;
    $("#ekos").innerHTML = ekos.length ? ekos.map(e =>
      `<div class="item"><b>${escapeHtml(e.id)}</b><span>${escapeHtml(e.domain)} · ${escapeHtml(e.status)}</span></div>`
    ).join("") : '<div class="item"><span>Nenhum EKO registrado.</span></div>';
    $("#insights").innerHTML = insights.length ? insights.map(i =>
      `<div class="item"><b>${escapeHtml(i.theme || "Insight")}</b><span>${escapeHtml(i.category || "Geral")} · confiança ${Number(i.confidence||0).toFixed(2)}</span></div>`
    ).join("") : '<div class="item"><span>Nenhum insight registrado.</span></div>';
  } catch (e) {
    $("#ekos").textContent = "Falha ao carregar.";
    $("#insights").textContent = "Falha ao carregar.";
  }
}

function escapeHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;" }[c]));
}

$("#parsePql").addEventListener("click", async () => {
  $("#pqlOutput").textContent = "Processando...";
  try {
    const r = await json("/api/pql/parse", {
      method: "POST",
      headers: {"content-type":"application/json"},
      body: JSON.stringify({script: $("#pqlInput").value})
    });
    $("#pqlOutput").textContent = JSON.stringify(r, null, 2);
  } catch(e) {
    $("#pqlOutput").textContent = e.message;
  }
});

let sessionId = null;

function renderQuestion(q) {
  const area = $("#answerArea");
  area.innerHTML = "";
  if (q.type === "choice") {
    (q.choices || []).forEach(choice => {
      const b = document.createElement("button");
      b.className = "btn choice";
      b.textContent = choice;
      b.onclick = () => answer(choice);
      area.appendChild(b);
    });
  } else if (q.type === "yesno") {
    ["sim","não"].forEach(choice => {
      const b = document.createElement("button");
      b.className = "btn choice";
      b.textContent = choice;
      b.onclick = () => answer(choice);
      area.appendChild(b);
    });
  } else {
    area.innerHTML = `<input id="freeAnswer" placeholder="Digite sua resposta"><button class="btn primary">Enviar</button>`;
    area.querySelector("button").onclick = () => answer($("#freeAnswer").value);
  }
}

function addBubble(text, type="system") {
  const d = document.createElement("div");
  d.className = `bubble ${type}`;
  d.textContent = text;
  $("#chat").appendChild(d);
  $("#chat").scrollTop = $("#chat").scrollHeight;
}

async function answer(value) {
  addBubble(String(value), "user");
  $("#answerArea").innerHTML = "";
  try {
    const r = await json("/api/assistant/answer", {
      method:"POST",
      headers:{"content-type":"application/json"},
      body:JSON.stringify({sessionId, answer:value})
    });
    if (r.question) {
      addBubble(r.question.text);
      renderQuestion(r.question);
    } else {
      addBubble(r.emergency ? r.message : `${r.prediagnostico || "Sessão concluída"} · risco: ${r.risco || "—"}`);
      addBubble(r.disclaimer || "");
      $("#answerArea").innerHTML = `<button id="restart" class="btn primary">Nova sessão</button>`;
      $("#restart").onclick = startSession;
    }
  } catch(e) {
    addBubble("Erro: " + e.message);
  }
}

async function startSession() {
  $("#chat").innerHTML = "";
  $("#answerArea").innerHTML = "";
  try {
    const r = await json("/api/assistant/session", {
      method:"POST",
      headers:{"content-type":"application/json"},
      body:"{}"
    });
    sessionId = r.sessionId;
    addBubble(r.question.text);
    renderQuestion(r.question);
  } catch(e) {
    addBubble("Não foi possível iniciar a sessão: " + e.message);
  }
}

$("#startSession").onclick = startSession;
$("#refreshCatalog").onclick = catalog;

health();
catalog();
setInterval(health, 15000);
setInterval(catalog, 30000);
EOF

# ============================================================
# Apache Reverse Proxy
# ============================================================
log "Configurando Apache e Proxy Reverso"

cat > "$INSTALL_DIR/apache/pasquared.conf" <<EOF
<VirtualHost *:80>
    ServerName ${PASQ_DOMAIN}
    DocumentRoot ${INSTALL_DIR}/web

    <Directory ${INSTALL_DIR}/web>
        Options -Indexes
        AllowOverride None
        Require all granted
    </Directory>

    ProxyPreserveHost On
    ProxyPass        /api http://127.0.0.1:3000/api retry=0
    ProxyPassReverse /api http://127.0.0.1:3000/api

    RequestHeader set X-Forwarded-Proto "http"

    ErrorLog \${APACHE_LOG_DIR}/pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_access.log combined
</VirtualHost>
EOF

a2enmod proxy proxy_http headers ssl rewrite
a2dissite 000-default.conf >/dev/null 2>&1 || true
cp "$INSTALL_DIR/apache/pasquared.conf" /etc/apache2/sites-available/pasquared.conf
a2ensite pasquared.conf
apache2ctl configtest
systemctl enable --now apache2
systemctl reload apache2

# ============================================================
# Banco de Dados PostgreSQL - Inicialização
# ============================================================
log "Configurando permissões do banco PostgreSQL"
runuser -u postgres -- psql -v ON_ERROR_STOP=1 <<EOF
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='${DB_USER}') THEN
    CREATE ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASSWORD}';
  ELSE
    ALTER ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASSWORD}';
  END IF;
END
\$\$;
EOF

if ! runuser -u postgres -- psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1; then
  runuser -u postgres -- createdb -O "$DB_USER" "$DB_NAME"
fi

runuser -u postgres -- psql -v ON_ERROR_STOP=1 -d "$DB_NAME" -f "$INSTALL_DIR/sql/init.sql"

# ============================================================
# npm install e npm run build
# ============================================================
log "Instalando dependências dos pacotes e serviços"
chown -R "$APP_USER:$APP_GROUP" "$INSTALL_DIR"
cd "$INSTALL_DIR"
runuser -u "$APP_USER" -- npm install --no-audit --no-fund

log "Compilando pacotes e serviços TypeScript (Ordem Corrigida)"
runuser -u "$APP_USER" -- npm run build

# ============================================================
# Systemd Services
# ============================================================
log "Criando serviços do systemd"

write_service() {
  local name="$1" workdir="$2"
  cat > "/etc/systemd/system/pasq-${name}.service" <<EOF
[Unit]
Description=PASQUARED ${name}
After=network-online.target postgresql.service
Wants=network-online.target
[Service]
Type=simple
User=${APP_USER}
Group=${APP_GROUP}
WorkingDirectory=${workdir}
EnvironmentFile=${INSTALL_DIR}/.env
Environment=NODE_ENV=production
ExecStart=/usr/bin/node ${workdir}/dist/index.js
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
[Install]
WantedBy=multi-user.target
EOF
}

write_service "usr" "${INSTALL_DIR}/services/usr"
write_service "mved" "${INSTALL_DIR}/services/mved"
write_service "smee" "${INSTALL_DIR}/services/smee"
write_service "catalog" "${INSTALL_DIR}/services/catalog"
write_service "pck" "${INSTALL_DIR}/services/pck"
write_service "gateway" "${INSTALL_DIR}/services/gateway"

cat > /etc/systemd/system/pasq-harvester.service <<EOF
[Unit]
Description=PASQUARED Medical Harvester
After=network-online.target pasq-pck.service pasq-smee.service
Wants=network-online.target
[Service]
Type=oneshot
User=${APP_USER}
Group=${APP_GROUP}
WorkingDirectory=${INSTALL_DIR}/services/harvester-med
EnvironmentFile=${INSTALL_DIR}/.env
Environment=NODE_ENV=production
ExecStart=/usr/bin/node ${INSTALL_DIR}/services/harvester-med/dist/index.js
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
EOF

cat > /etc/systemd/system/pasq-harvester.timer <<'EOF'
[Unit]
Description=PASQUARED Harvester periódico
[Timer]
OnBootSec=10m
OnUnitActiveSec=6h
Persistent=true
[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable --now \
  pasq-usr.service pasq-mved.service pasq-smee.service \
  pasq-catalog.service pasq-pck.service pasq-gateway.service
systemctl enable --now pasq-harvester.timer

# ============================================================
# Firewall
# ============================================================
log "Configurando firewall UFW"
ufw allow OpenSSH >/dev/null 2>&1 || true
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable >/dev/null 2>&1 || true

# ============================================================
# Certificado SSL
# ============================================================
if [[ "${SKIP_LE:-0}" != "1" ]]; then
  log "Tentando emitir certificado Let's Encrypt"
  if certbot --apache \
      -d "$PASQ_DOMAIN" \
      -m "$PASQ_LE_EMAIL" \
      --agree-tos --no-eff-email --non-interactive; then
    log "HTTPS configurado com sucesso."
  else
    warn "Certbot não conseguiu emitir o certificado. Verifique seu DNS e execute novamente."
  fi
else
  warn "SKIP_LE=1: Emissão de SSL ignorada."
fi

# ============================================================
# Permissões e Verificação Final
# ============================================================
chown -R "$APP_USER:$APP_GROUP" "$INSTALL_DIR"
find "$INSTALL_DIR" -type d -exec chmod 0755 {} +
find "$INSTALL_DIR" -type f -exec chmod 0644 {} +
chmod 0600 "$INSTALL_DIR/.env"

log "Validando estado dos serviços"
sleep 3
systemctl --no-pager --full status pasq-gateway.service || true
curl -fsS http://127.0.0.1:3000/api/health || true
curl -fsS http://127.0.0.1/ >/dev/null || true

log "Instalação concluída com sucesso!"

cat <<EOF

============================================================
 PASQUARED OS - INSTALAÇÃO FINALIZADA SEM ERROS
============================================================
Acesso Web:
  http://${PASQ_DOMAIN}/
  https://${PASQ_DOMAIN}/ (se SSL ativado)

Testes da API:
  curl -fsS http://${PASQ_DOMAIN}/api/health

Serviços Systemd Ativos:
  - pasq-gateway (Porta :3000)
  - pasq-pck     (Porta :3010)
  - pasq-usr     (Porta :3020)
  - pasq-mved    (Porta :3030)
  - pasq-smee    (Porta :3040)
  - pasq-catalog (Porta :3050)
  - pasq-harvester.timer

Credenciais salvas em:
  ${INSTALL_DIR}/.env

============================================================
EOF
