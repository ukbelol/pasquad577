#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# Teste end-to-end automatizado para Pasquared OS
# Uso: ./test_end2end.sh

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: node não encontrado. Instale Node.js (>=22) e npm e tente novamente." >&2
  exit 2
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: npm não encontrado. Instale npm e tente novamente." >&2
  exit 2
fi

export MS_FOUNDRY_ENDPOINT="${MS_FOUNDRY_ENDPOINT:-https://rgs577-7620-pasquared-resource.services.ai.azure.com/openai/v1/responses}"
export MS_FOUNDRY_API_KEY="${MS_FOUNDRY_API_KEY:-5pCt9BAhaW9gf46m3E5yj1fA1UEdF400JmorFH94m9uFzB4JP53lJQQJ99CHACZoyfiXJ3w3AAAAACOGlAeL}"

echo "Instalando dependências (pode demorar)..."
npm install --legacy-peer-deps

echo "Buildando a aplicação..."
npm run build

# iniciar servidor em background
LOGFILE="test_server.log"
PIDFILE=".test_server.pid"

echo "Iniciando servidor (node server.js) em background..."
nohup node server.js > "$LOGFILE" 2>&1 &
SERVER_PID=$!
echo $SERVER_PID > "$PIDFILE"

# esperar servidor subir
echo "Aguardando 3s para o servidor inicializar..."
sleep 3

# Testes
echo "Teste: /api/health"
curl -sS http://127.0.0.1:3000/api/health | jq . || true

echo "Teste: /api/knowledge/pubmed (query: headache nausea)"
curl -sS -X POST http://127.0.0.1:3000/api/knowledge/pubmed -H "Content-Type: application/json" -d '{"query":"headache AND nausea","maxResults":2}' | jq . || true

# Chat test (não garantido sem credenciais reais)
echo "Teste: /api/foundry/chat (mock messages)"
read -r -d '' PAYLOAD <<'JSON'
{
  "messages": [
    {"role":"system","content":"Teste automática de integração"},
    {"role":"user","content":"Paciente relata dor de cabeça e náusea há 2 dias."}
  ],
  "systemPrompt": "Responda em formato de pergunta investigativa curta.",
  "deploymentName": "gpt-5.6-sol"
}
JSON

curl -sS -X POST http://127.0.0.1:3000/api/foundry/chat -H "Content-Type: application/json" -d "$PAYLOAD" | jq . || true

# cleanup
echo "Encerrando servidor (PID $SERVER_PID)"
kill $SERVER_PID || true
rm -f "$PIDFILE"

echo "Logs de servidor em: $LOGFILE"

echo "Teste finalizado."
