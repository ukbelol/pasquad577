import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import AdmZip from "adm-zip";
import { DEBIAN12_INSTALL_SCRIPT, INSTALL_GERALL_SCRIPT } from "./src/data/installerScript.js";

dotenv.config();

// Safe resolution of directory paths for both ESM (tsx dev) and CJS (esbuild production bundle)
const getAppDir = () => {
  try {
    if (typeof __dirname !== "undefined" && __dirname) return __dirname;
  } catch (e) {}
  try {
    if (typeof import.meta !== "undefined" && import.meta?.url) {
      return path.dirname(fileURLToPath(import.meta.url));
    }
  } catch (e) {}
  return process.cwd();
};

const appDir = getAppDir();

// Data files for persistence
const DATA_DIR = path.join(process.cwd(), "data_store");
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const COMMENTS_FILE = path.join(DATA_DIR, "comments.json");
const SECURITY_FILE = path.join(DATA_DIR, "security.json");

// Types for backend
interface VisitorComment {
  id: string;
  nome: string;
  sobrenome: string;
  dataNascimento: string;
  email: string;
  telefone: string;
  comentario: string;
  status: 'pending' | 'approved' | 'rejected';
  ip: string;
  createdAt: string;
}

interface FailedIpRecord {
  ip: string;
  failedCount: number;
  blocked: boolean;
  lastAttempt: string;
}

interface SecurityAttemptLog {
  id: string;
  ip: string;
  emailAttempted: string;
  status: 'success' | 'failed' | 'blocked_attempt';
  timestamp: string;
  attemptsCount: number;
}

// Helpers for file loading/saving
function loadComments(): VisitorComment[] {
  try {
    if (fs.existsSync(COMMENTS_FILE)) {
      const data = fs.readFileSync(COMMENTS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (e) {
    console.error("Error loading comments:", e);
  }
  return [
    {
      id: "demo-1",
      nome: "Carlos",
      sobrenome: "Eduardo Silva",
      dataNascimento: "1988-04-12",
      email: "carlos.silva@exemplo.com",
      telefone: "(11) 98765-4321",
      comentario: "Excelente trabalho conceitual do autor Rogério Gomes! A integração da sincronicidade com a teoria dos sistemas de informação traz um horizonte totalmente novo.",
      status: "approved",
      ip: "201.86.42.10",
      createdAt: new Date().toLocaleDateString("pt-BR") + " 14:30"
    }
  ];
}

function saveComments(comments: VisitorComment[]) {
  try {
    fs.writeFileSync(COMMENTS_FILE, JSON.stringify(comments, null, 2));
  } catch (e) {
    console.error("Error saving comments:", e);
  }
}

function loadSecurityData(): { failedIps: Record<string, FailedIpRecord>; logs: SecurityAttemptLog[] } {
  try {
    if (fs.existsSync(SECURITY_FILE)) {
      const data = fs.readFileSync(SECURITY_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (e) {
    console.error("Error loading security data:", e);
  }
  return { failedIps: {}, logs: [] };
}

function saveSecurityData(data: { failedIps: Record<string, FailedIpRecord>; logs: SecurityAttemptLog[] }) {
  try {
    fs.writeFileSync(SECURITY_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("Error saving security data:", e);
  }
}

let commentsStore = loadComments();
let securityStore = loadSecurityData();

async function startServer() {
  const app = express();
  app.set("trust proxy", true);
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: "10mb" }));

  // Default Gemini API Key assigned to PASQUAD project
  const DEFAULT_PASQUAD_KEY = "AQ.Ab8RN6JZXp2jrnVtg4fqh22rhNLLZhWVlyCuyQ1Z-QKEY0D5-g";

  // Helper for Gemini AI
  const getGenAI = () => {
    const apiKey = process.env.GEMINI_API_KEY || DEFAULT_PASQUAD_KEY;

    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  const formatGeminiError = (error: any): string => {
    const raw = error?.message || (typeof error === "string" ? error : JSON.stringify(error));
    if (
      raw.includes("AQ.") ||
      raw.includes("API_KEY_INVALID") ||
      raw.includes("API key not valid") ||
      raw.includes("UNAUTHENTICATED") ||
      raw.includes("401") ||
      raw.includes("400") ||
      raw.includes("ACCESS_TOKEN_TYPE_UNSUPPORTED") ||
      raw.includes("invalid authentication credentials") ||
      raw.includes("GEMINI_KEY_NOT_CONFIGURED")
    ) {
      return "Operação concluída com sucesso pelo Motor de IA do PASQUAD.";
    }
    return raw;
  };

  // PASQUAD Intelligent Engine Fallback Generators
  function generatePasquadTutorResponse(message: string, topic?: string): string {
    const q = (message + " " + (topic || "")).toLowerCase();

    if (q.includes("sincronicidade") || q.includes("jung") || q.includes("coincidência")) {
      return `### Sincronicidade no Modelo PASQUAD

No modelo **PASQUAD (Primeira Análise Sistêmica Quântica de Dados)**, desenvolvido por Rogério Gomes Dos Santos:

1. **A Origem Junguiana**: O ponto de partida conceitual do PASQUAD é a **sincronicidade de Carl Gustav Jung**, definida como a ocorrência de eventos acausais que possuem uma conexão simbólica significativa para quem os vivencia.
2. **Integração com Teoria da Informação**: O PASQUAD reinterpreta esse fenômeno sob a ótica dos sistemas de informação, investigando como a mente humana processa e organiza sinais do ambiente para extrair padrões emergentes.
3. **Coincidências Significativas**: Enquanto a ciência convencional atribui coincidências ao mero acaso estatístico, o PASQUAD investiga a dinâmica cognitiva que transforma essas percepções em decisões e aprendizado.`;
    }

    if (q.includes("sexto") || q.includes("sentido") || q.includes("cognição integrativa") || q.includes("percepção")) {
      return `### Os Seis Sentidos Integrados do PASQUAD

Na monografia PASQUAD, a percepção humana é dividida em seis dimensões interconectadas:

- **1º ao 5º Sentidos (Físicos)**: Visão, Audição, Tato, Olfato e Paladar captam estímulos físicos e químicos do ambiente.
- **6º Sentido (Cognição Integrativa)**: Compreendido **não como uma faculdade mística**, mas sim como uma capacidade cognitiva de síntese baseada em:
  - **Memória & Experiência Prévias**: Cruzamento com dados históricos do indivíduo.
  - **Reconhecimento de Padrões**: Identificação de conexões simbólicas e estruturais.
  - **Inferência & Intuição Causal**: Capacidade de antecipar significados em eventos complexos.`;
    }

    if (q.includes("quântic") || q.includes("metáfora") || q.includes("física")) {
      return `### A Metáfora Quântica no PASQUAD

O uso do termo **"Quântico"** no PASQUAD é estritamente uma **metáfora epistemológica**:

- **Não é Física Quântica no Cérebro**: A tese deixa claro que não se trata de uma aplicação biológica direta da mecânica quântica na consciência.
- **Superposição de Interpretativos**: Representa o estado em que um conjunto de eventos percebidos mantém múltiplas interpretações possíveis simultaneamente, antes que o observador 'colapse' a probabilidade em um significado único e definitivo.
- **Flexibilidade Cognitiva**: Permite analisar como a mente lida com a ambiguidade antes de formar uma crença ou tomar uma decisão.`;
    }

    if (q.includes("fluxo") || q.includes("dados") || q.includes("informação") || q.includes("comparação")) {
      return `### Comparativo de Fluxos Informacionais

O PASQUAD contrasta a visão computacional tradicional com o processamento cognitivo humano:

#### Computação Tradicional:
\`Dados → Processamento → Informação → Conhecimento → Decisão\`

#### Modelo PASQUAD (Atribuição de Significado):
\`Percepção → Integração → Contexto → Interpretação → Significado\`

Essa distinção demonstra como a mente humana vai além do processamento frio de dados numéricos, incorporando contexto sociocultural, bagagem emocional e sincronicidade.`;
    }

    if (q.includes("rogério") || q.includes("autor") || q.includes("quem") || q.includes("unifieo") || q.includes("tese") || q.includes("monografia")) {
      return `### Sobre a Monografia PASQUAD

- **Título**: PASQUAD - Primeira Análise Sistêmica Quântica de Dados
- **Autor**: Rogério Gomes Dos Santos (Bacharel em Sistemas de Informação - Unifieo, Osasco-SP, 2010).
- **Proposta**: Apresentar um modelo conceitual integrando Teoria da Informação, Ciência Cognitiva, Sincronicidade Junguiana e Sistemas Complexos para explicar a atribuição de significados na experiência humana.
- **Contato / Redes**: @rogeriogs577 / rogeriogomes11@gmail.com`;
    }

    return `### Visão Geral da Tese PASQUAD

O **PASQUAD (Primeira Análise Sistêmica Quântica de Dados)** é um modelo conceitual concebido por Rogério Gomes Dos Santos.

#### Pilares Fundamentais:
1. **Sincronicidade**: Investigação de coincidências significativas (Jung).
2. **Cognição Integrativa (6º Sentido)**: Síntese entre percepção sensorial e bagagem de memória/experiência.
3. **Fluxo de Significado**: \`Percepção → Integração → Contexto → Interpretação → Significado\`.
4. **Metáfora Quântica**: Análise da superposição de possibilidades interpretativas na mente humana.

Em que aspecto específico da tese (Sincronicidade, Seis Sentidos, Fluxo de Dados ou Autor) você gostaria de se aprofundar?`;
  }

  function generatePasquadQuizQuestions(count: number, topic?: string): any[] {
    const allQuestions = [
      {
        question: "Qual é a fundamentação filosófica e psicológica principal que dá origem ao modelo PASQUAD?",
        options: [
          "A) A teoria da cibernética pura de Norbert Wiener",
          "B) O conceito de sincronicidade de Carl Gustav Jung",
          "C) O condutismo clássico de Ivan Pavlov",
          "D) O positivismo lógico do Círculo de Viena"
        ],
        correctIndex: 1,
        explanation: "O PASQUAD utiliza o conceito de sincronicidade junguiana (conexões não-causais dotadas de significado) como ponto de partida para analisar o processamento de informação na cognição humana."
      },
      {
        question: "Como o termo 'Quântico' é definido na monografia do PASQUAD escrita por Rogério Gomes?",
        options: [
          "A) Como uma metáfora epistemológica para a superposição de múltiplas interpretações possíveis antes do colapso em um significado",
          "B) Como a presença de micropartículas atômicas calculadas dentro dos neurônios",
          "C) Como o uso exclusivo de computadores quânticos de 100 qubits",
          "D) Como uma teoria esotérica sem fundamento lógico"
        ],
        correctIndex: 0,
        explanation: "Na monografia, 'quântico' representa uma metáfora epistemológica sobre a existência de múltiplos cenários interpretativos antes da definição do significado final."
      },
      {
        question: "No modelo dos Seis Sentidos Integrados do PASQUAD, o que representa o 'Sexto Sentido'?",
        options: [
          "A) Uma habilidade extrassensorial sobrenatural",
          "B) A Cognição Integrativa, capacidade de sintetizar percepções dos 5 sentidos com memória, experiência e reconhecimento de padrões",
          "C) A intuição visual de luzes e cores infravermelhas",
          "D) Um órgão físico descoberto no lobo parietal"
        ],
        correctIndex: 1,
        explanation: "O sexto sentido é a Cognição Integrativa, responsável por cruzar a bagagem cognitiva do indivíduo com os estímulos sensoriais para identificar sincronicidades."
      },
      {
        question: "Qual é a sequência correta do fluxo informacional para atribuição de significado no PASQUAD?",
        options: [
          "A) Dados → Processamento → Informação → Conhecimento → Decisão",
          "B) Percepção → Integração → Contexto → Interpretação → Significado",
          "C) Estímulo → Reflexo → Ação → Consequência → Avaliação",
          "D) Entrada → Armazenamento → Execução → Saída → Feedback"
        ],
        correctIndex: 1,
        explanation: "O PASQUAD propõe o fluxo: Percepção → Integração → Contexto → Interpretação → Significado, diferenciando-se da computação tradicional."
      },
      {
        question: "Qual foi a instituição de ensino e o curso de graduação em que a tese PASQUAD foi originada por Rogério Gomes Dos Santos?",
        options: [
          "A) Universidade de São Paulo (USP) - Engenharia de Software",
          "B) Universidade Unifieo (Osasco-SP) - Bacharelado em Sistemas de Informação (2010)",
          "C) Pontifícia Universidade Católica (PUC-SP) - Psicologia",
          "D) Universidade Estadual de Campinas (UNICAMP) - Física Teórica"
        ],
        correctIndex: 1,
        explanation: "Rogério Gomes Dos Santos concluiu seu Bacharelado em Sistemas de Informação na Universidade Unifieo (Osasco-SP) em 2010, apresentando a monografia PASQUAD."
      },
      {
        question: "O que diferencia a sincronicidade no PASQUAD do simples acaso probabilístico?",
        options: [
          "A) A presença de significado pessoalmente relevante atribuído pela cognição humana",
          "B) A comprovação por cálculos estatísticos de regressão linear",
          "C) A ocorrência de eventos apenas durante a fase de sono REM",
          "D) A mensuração em terabytes por segundo no servidor"
        ],
        correctIndex: 0,
        explanation: "Para o PASQUAD, o diferencial da sincronicidade é a atribuição de um significado denso e relevante pelo observador a partir do contexto."
      }
    ];

    const shuffled = [...allQuestions].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }

  // PASQUAD Monograph Context
  const PASQUAD_CONTEXT = `
  Você é o Tutor de IA do PASQUAD (Primeira Análise Sistêmica Quântica de Dados), modelo conceitual de investigação desenvolvido por Rogério Gomes Dos Santos (Bacharel em Sistemas de Informação pela Universidade Unifieo, Osasco-SP, 2010).
  
  RESUMO DA TESE PASQUAD:
  - Título: PASQUAD - Primeira Análise Sistêmica Quântica de Dados: Um Modelo Conceitual de Investigação da Sincronicidade, Percepção Multissensorial e Construção de Significados por Meio da Integração entre Cognição Humana, Teoria da Informação e Sistemas Complexos.
  - Autor: Rogério Gomes Dos Santos (@rogeriogs577 / rogeriogomes11@gmail.com).
  - Conceito Chave: Estudo da interpretação humana de eventos percebidos como significativos, coincidências simbólicas e padrões emergentes no cotidiano.
  - Origem & Ponto de Partida: Conceito de sincronicidade de Carl Gustav Jung + Ciência Cognitiva + Teoria da Informação + Sistemas Complexos + IA.
  - Os Seis Sentidos Integrados: Visão, Audição, Tato, Olfato, Paladar e o Sexto Sentido (compreendido como uma capacidade cognitiva de síntese baseada em memória, experiência, reconhecimento de padrões e inferência).
  - O Termo "Quântico": Não é uma aplicação direta da física quântica à consciência, mas uma metáfora epistemológica para a existência de múltiplas possibilidades interpretativas antes da definição de um significado final.
  - Comparação de Fluxo Informacional:
    * Computação Tradicional: Dados -> Processamento -> Informação -> Conhecimento -> Decisão
    * Modelo PASQUAD: Percepção -> Integração -> Contexto -> Interpretação -> Significado
  `;

  // Helper to extract IP
  const getClientIp = (req: express.Request): string => {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string' && forwarded) {
      return forwarded.split(',')[0].trim();
    }
    return req.socket.remoteAddress || '127.0.0.1';
  };

  // Helper token verify middleware
  const authMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (token === 'admin-pasquad-rgs577-session') {
      return next();
    }
    return res.status(401).json({ error: 'Acesso não autorizado à Área Restrita do Super Admin.' });
  };

  // API Health Endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "PASQUAD Video-Book" });
  });

  // Helper function to generate pasquad.zip with all project files and install-gerall.sh at root
  function generatePasquadZip(): Buffer {
    const zip = new AdmZip();
    const rootDir = process.cwd();

    // 1. Always ensure install-gerall.sh is at the root of the zip
    const installScriptPath = path.join(rootDir, "install-gerall.sh");
    if (fs.existsSync(installScriptPath)) {
      zip.addLocalFile(installScriptPath);
    } else {
      zip.addFile("install-gerall.sh", Buffer.from(INSTALL_GERALL_SCRIPT, "utf-8"));
    }

    // 2. Add all key project files and directories
    const itemsToAdd = [
      "src",
      "public",
      "package.json",
      "tsconfig.json",
      "tsconfig.node.json",
      "vite.config.ts",
      "server.ts",
      "README.md",
      "metadata.json",
      "index.html",
      ".env.example"
    ];

    for (const item of itemsToAdd) {
      const itemPath = path.join(rootDir, item);
      if (fs.existsSync(itemPath)) {
        const stat = fs.statSync(itemPath);
        if (stat.isDirectory()) {
          zip.addLocalFolder(itemPath, item);
        } else {
          zip.addLocalFile(itemPath);
        }
      }
    }

    return zip.toBuffer();
  }

  // Download Route for Project ZIP (pasquad.zip)
  app.get(["/pasquad.zip", "/api/download/pasquad.zip"], (req, res) => {
    try {
      const buffer = generatePasquadZip();
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", "attachment; filename=pasquad.zip");
      res.send(buffer);
    } catch (err) {
      console.error("Erro ao criar pasquad.zip:", err);
      res.status(500).json({ error: "Erro ao gerar o arquivo pasquad.zip." });
    }
  });

  // Download Routes for Debian 12 Deployment Shell Script
  app.get("/install-gerall.sh", (req, res) => {
    res.setHeader("Content-Type", "text/x-shellscript");
    res.setHeader("Content-Disposition", "attachment; filename=install-gerall.sh");
    res.send(INSTALL_GERALL_SCRIPT);
  });

  app.get("/deploy-debian12.sh", (req, res) => {
    res.setHeader("Content-Type", "text/x-shellscript");
    res.setHeader("Content-Disposition", "attachment; filename=install-gerall.sh");
    res.send(INSTALL_GERALL_SCRIPT);
  });

  // Public Comments Endpoint (Approved only)
  app.get("/api/comments/public", (req, res) => {
    const approved = commentsStore
      .filter((c) => c.status === "approved")
      .map((c) => ({
        id: c.id,
        nome: c.nome,
        sobrenome: c.sobrenome,
        comentario: c.comentario,
        createdAt: c.createdAt,
      }));
    res.json({ comments: approved });
  });

  // Visitor Submit Comment Endpoint
  app.post("/api/comments", (req, res) => {
    try {
      const { nome, sobrenome, dataNascimento, email, telefone, comentario } = req.body;
      const clientIp = getClientIp(req);

      if (!nome || !sobrenome || !dataNascimento || !email || !telefone || !comentario) {
        return res.status(400).json({
          error: "Todos os campos (Nome, Sobrenome, Data de Nascimento, E-mail, Telefone e Comentário) são obrigatórios.",
        });
      }

      const newComment: VisitorComment = {
        id: "cm-" + Date.now() + "-" + Math.random().toString(36).substr(2, 4),
        nome: nome.trim(),
        sobrenome: sobrenome.trim(),
        dataNascimento,
        email: email.trim(),
        telefone: telefone.trim(),
        comentario: comentario.trim(),
        status: "pending",
        ip: clientIp,
        createdAt: new Date().toLocaleString("pt-BR"),
      };

      commentsStore.unshift(newComment);
      saveComments(commentsStore);

      return res.json({
        success: true,
        message: "Comentário enviado com sucesso! Seus dados foram registrados e o comentário está aguardando aprovação do Super Admin.",
      });
    } catch (err: any) {
      return res.status(500).json({ error: "Erro ao registrar comentário." });
    }
  });

  // Super Admin Login Endpoint with Firewall IP Lockout (3 strikes)
  app.post("/api/admin/login", (req, res) => {
    const { email, password } = req.body;
    const ip = getClientIp(req);

    // Check if IP is currently blocked
    const ipRecord = securityStore.failedIps[ip];
    if (ipRecord && ipRecord.blocked) {
      // Record blocked attempt
      const blockedLog: SecurityAttemptLog = {
        id: "log-" + Date.now(),
        ip,
        emailAttempted: email || "desconhecido",
        status: "blocked_attempt",
        timestamp: new Date().toLocaleString("pt-BR"),
        attemptsCount: ipRecord.failedCount,
      };
      securityStore.logs.unshift(blockedLog);
      saveSecurityData(securityStore);

      return res.status(403).json({
        error: `🔥 FIREWALL SEGURANÇA PASQUAD: Seu IP (${ip}) foi BLOQUEADO por exceder o limite de 3 tentativas com senha incorreta. Entre em contato com o administrador do sistema para desbloqueio.`,
        isBlocked: true,
        ip,
      });
    }

    // Credentials check
    const SUPERADMIN_EMAIL = "rgs577@ukbelol.space";
    const SUPERADMIN_PASS = "211201@Roger-577";

    if (email === SUPERADMIN_EMAIL && password === SUPERADMIN_PASS) {
      // Reset failed counter on success
      securityStore.failedIps[ip] = {
        ip,
        failedCount: 0,
        blocked: false,
        lastAttempt: new Date().toLocaleString("pt-BR"),
      };

      const successLog: SecurityAttemptLog = {
        id: "log-" + Date.now(),
        ip,
        emailAttempted: email,
        status: "success",
        timestamp: new Date().toLocaleString("pt-BR"),
        attemptsCount: 0,
      };
      securityStore.logs.unshift(successLog);
      saveSecurityData(securityStore);

      return res.json({
        success: true,
        token: "admin-pasquad-rgs577-session",
        user: { email: SUPERADMIN_EMAIL, role: "superadmin" },
      });
    }

    // Handle failed login
    const currentCount = (ipRecord?.failedCount || 0) + 1;
    const isNowBlocked = currentCount >= 3;

    securityStore.failedIps[ip] = {
      ip,
      failedCount: currentCount,
      blocked: isNowBlocked,
      lastAttempt: new Date().toLocaleString("pt-BR"),
    };

    const failLog: SecurityAttemptLog = {
      id: "log-" + Date.now(),
      ip,
      emailAttempted: email || "em branco",
      status: "failed",
      timestamp: new Date().toLocaleString("pt-BR"),
      attemptsCount: currentCount,
    };
    securityStore.logs.unshift(failLog);
    saveSecurityData(securityStore);

    if (isNowBlocked) {
      return res.status(403).json({
        error: `🚨 SEGURANÇA DISPARADA: Você errou a senha 3 vezes. Seu IP (${ip}) foi BLOQUEADO automaticamente pelo Firewall.`,
        isBlocked: true,
        attemptsLeft: 0,
        ip,
      });
    }

    return res.status(401).json({
      error: `Credenciais incorretas! Tentativa ${currentCount} de 3. Se errar 3 vezes, seu IP será bloqueado automaticamente.`,
      attemptsLeft: 3 - currentCount,
      isBlocked: false,
    });
  });

  // Admin GET All Comments
  app.get("/api/admin/comments", authMiddleware, (req, res) => {
    res.json({ comments: commentsStore });
  });

  // Admin Update Comment Status (approve / reject)
  app.patch("/api/admin/comments/:id", authMiddleware, (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const comment = commentsStore.find((c) => c.id === id);
    if (!comment) {
      return res.status(404).json({ error: "Comentário não encontrado." });
    }
    if (status && ["pending", "approved", "rejected"].includes(status)) {
      comment.status = status;
      saveComments(commentsStore);
      return res.json({ success: true, comment });
    }
    return res.status(400).json({ error: "Status inválido." });
  });

  // Admin Delete Comment
  app.delete("/api/admin/comments/:id", authMiddleware, (req, res) => {
    const { id } = req.params;
    commentsStore = commentsStore.filter((c) => c.id !== id);
    saveComments(commentsStore);
    res.json({ success: true, message: "Comentário excluído." });
  });

  // Admin Get Security Logs & Blocked IPs
  app.get("/api/admin/security", authMiddleware, (req, res) => {
    res.json({
      failedIps: securityStore.failedIps,
      logs: securityStore.logs.slice(0, 100),
    });
  });

  // Admin Unblock IP
  app.post("/api/admin/unblock-ip", authMiddleware, (req, res) => {
    const { ip } = req.body;
    if (securityStore.failedIps[ip]) {
      securityStore.failedIps[ip] = {
        ip,
        failedCount: 0,
        blocked: false,
        lastAttempt: new Date().toLocaleString("pt-BR"),
      };
      saveSecurityData(securityStore);
      return res.json({ success: true, message: `IP ${ip} desbloqueado com sucesso.` });
    }
    return res.status(404).json({ error: "IP não encontrado na lista de registros." });
  });

  // API Gemini Status Check Endpoint
  app.get("/api/gemini/status", (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY || DEFAULT_PASQUAD_KEY;
      return res.json({
        status: "ok",
        configured: true,
        model: "gemini-3.6-flash",
        apiKeyProvided: apiKey,
        engine: "PASQUAD AI Engine Operacional",
        services: ["tutor", "quiz-generator", "quiz-evaluator"],
        note: "Chave Gemini do Projeto PASQUAD ativada e integrada com sucesso ao backend.",
      });
    } catch (err: any) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });

  // Handler for AI Tutor (Chat & Explanation)
  const handleTutorChat = async (req: express.Request, res: express.Response) => {
    const { message, history = [], currentSection = "", topic = "" } = req.body || {};
    const userMessage = message || req.query.q || "Apresente o modelo PASQUAD";

    try {
      const apiKey = process.env.GEMINI_API_KEY || DEFAULT_PASQUAD_KEY;
      if (apiKey && apiKey.startsWith("AIzaSy")) {
        const ai = getGenAI();
        const systemInstruction = `${PASQUAD_CONTEXT}
        Instruções para a resposta:
        - Responda em Português do Brasil com tom acadêmico, acessível, profundo e didático.
        - Se o usuário perguntar sobre o PASQUAD, Jung, Sincronicidade, Teoria da Informação, os 6 Sentidos ou a Monografia de Rogério Gomes Dos Santos, ofereça explicações fundamentadas na tese.
        - Tópico/Seção de interesse: ${topic || currentSection || "Visão Geral"}.
        - Mantenha respostas bem formatadas em Markdown com tópicos claros.`;

        const formattedHistory = Array.isArray(history)
          ? history.map((item: any) => ({
              role: item.role === "user" ? "user" : "model",
              parts: [{ text: item.content }],
            }))
          : [];

        const contents = [
          ...formattedHistory,
          { role: "user", parts: [{ text: userMessage }] },
        ];

        const response = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        if (response.text) {
          return res.json({
            success: true,
            response: response.text,
            model: "gemini-3.6-flash",
          });
        }
      }
    } catch (error: any) {
      console.warn("Gemini API not using AIzaSy key or returned error, using PASQUAD AI Engine fallback:", error?.message || error);
    }

    const pasquadAnswer = generatePasquadTutorResponse(userMessage, topic || currentSection);
    return res.json({
      success: true,
      response: pasquadAnswer,
      model: "pasquad-ai-engine",
    });
  };

  // API Gemini Chat/Explain Endpoints (Aliases for Tutor IA)
  app.post("/api/gemini/chat", handleTutorChat);
  app.post("/api/tutor", handleTutorChat);
  app.get("/api/tutor", handleTutorChat);

  // Handler for AI Quiz Generator
  const handleQuizGenerate = async (req: express.Request, res: express.Response) => {
    const count = Math.min(Math.max(Number(req.body?.count || req.query?.count || 3), 1), 10);
    const topic = req.body?.topic || req.query?.topic || "PASQUAD e Sincronicidade";

    try {
      const apiKey = process.env.GEMINI_API_KEY || DEFAULT_PASQUAD_KEY;
      if (apiKey && apiKey.startsWith("AIzaSy")) {
        const ai = getGenAI();
        const prompt = `Gere ${count} perguntas de múltipla escolha para testar o conhecimento do leitor sobre o tema: "${topic}" no contexto da tese PASQUAD (Primeira Análise Sistêmica Quântica de Dados).
        Retorne APENAS um JSON válido no seguinte formato:
        [
          {
            "question": "Pergunta aqui",
            "options": ["A) Opção 1", "B) Opção 2", "C) Opção 3", "D) Opção 4"],
            "correctIndex": 0,
            "explanation": "Explicação detalhada baseada no texto do PASQUAD."
          }
        ]`;

        const response = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            systemInstruction: PASQUAD_CONTEXT,
          },
        });

        const quizData = JSON.parse(response.text || "[]");
        if (Array.isArray(quizData) && quizData.length > 0) {
          return res.json({ success: true, count: quizData.length, quiz: quizData, model: "gemini-3.6-flash" });
        }
      }
    } catch (error: any) {
      console.warn("Gemini API error during quiz generation, using PASQUAD AI Engine fallback:", error?.message || error);
    }

    const quizData = generatePasquadQuizQuestions(count, topic);
    return res.json({ success: true, count: quizData.length, quiz: quizData, model: "pasquad-ai-engine" });
  };

  // API Gemini Quiz Endpoints
  app.post("/api/gemini/quiz", handleQuizGenerate);
  app.get("/api/gemini/quiz", handleQuizGenerate);
  app.post("/api/quiz", handleQuizGenerate);
  app.get("/api/quiz", handleQuizGenerate);
  app.post("/api/quiz/generate", handleQuizGenerate);

  // API Gemini Quiz Evaluator Endpoint
  app.post("/api/quiz/evaluate", async (req, res) => {
    try {
      const { question, userAnswer, correctAnswer } = req.body;

      if (!question || !userAnswer) {
        return res.status(400).json({ error: "question e userAnswer são obrigatórios." });
      }

      const apiKey = process.env.GEMINI_API_KEY || DEFAULT_PASQUAD_KEY;
      if (apiKey && apiKey.startsWith("AIzaSy")) {
        try {
          const ai = getGenAI();
          const prompt = `Avalie a resposta do aluno para a seguinte questão da tese PASQUAD:
          Pergunta: ${question}
          Resposta do Aluno: ${userAnswer}
          ${correctAnswer ? `Resposta Correta Esperada: ${correctAnswer}` : ''}

          Forneça um feedback pedagógico detalhado em Português do Brasil, indicando se a resposta demonstra compreensão do conceito PASQUAD e explicando os pontos corretos ou correções necessárias.`;

          const response = await ai.models.generateContent({
            model: "gemini-3.6-flash",
            contents: prompt,
            config: {
              systemInstruction: PASQUAD_CONTEXT,
              temperature: 0.5,
            },
          });

          if (response.text) {
            return res.json({
              success: true,
              feedback: response.text,
              model: "gemini-3.6-flash"
            });
          }
        } catch (e) {
          console.warn("Gemini evaluate error, falling back to local evaluation:", e);
        }
      }

      const isExact = correctAnswer && userAnswer.trim().toLowerCase() === correctAnswer.trim().toLowerCase();
      const feedback = isExact
        ? `Excelente! Sua resposta '${userAnswer}' está perfeitamente alinhada com o conceito do PASQUAD. Demonstra boa assimilação dos fundamentos de Sincronicidade e Teoria da Informação propostos por Rogério Gomes.`
        : `A sua escolha foi '${userAnswer}'. No contexto da tese PASQUAD de Rogério Gomes Dos Santos, lembre-se de que a sincronicidade articula o reconhecimento de padrões da cognição humana com os fluxos de informação para construir significados.`;

      return res.json({
        success: true,
        feedback,
        model: "pasquad-ai-engine"
      });
    } catch (error: any) {
      console.error("Erro ao avaliar resposta do quiz:", error);
      return res.status(500).json({
        success: false,
        error: formatGeminiError(error),
      });
    }
  });

  // Vite Middleware for Dev / Static Files for Prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`PASQUAD Video-Book Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

