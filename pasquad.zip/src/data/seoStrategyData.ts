export interface SEOKeywordGroup {
  category: string;
  description: string;
  keywords: Array<{
    term: string;
    searchVolume: string;
    intent: string;
    difficulty: string;
  }>;
}

export const PASQUAD_SEO_STRATEGY = {
  title: 'Metodologia de SEO e Posicionamento para o PASQUAD',
  subtitle: 'Estratégia de Palavras-Chave e Arquitetura de Conteúdo para Liderança de Busca',
  author: 'Rogério Gomes Dos Santos',
  targetDomain: 'pqd.ukbelol.space',
  
  methodologyOverview: [
    {
      title: '1. Arquitetura em Clusters Teóricos (Silo Structure)',
      description: 'Organização do conteúdo em quatro núcleos interligados: (1) Análise Sistêmica Quântica de Dados, (2) Sincronicidade Junguiana Computacional, (3) Percepção dos Seis Sentidos Integrados, e (4) Teoria da Informação em Sistemas Complexos.'
    },
    {
      title: '2. Maximização de Autoridade E-E-A-T (Google Quality Rater Guidelines)',
      description: 'Construção da marca do autor Rogério Gomes Dos Santos (Unifieo 2010) com Schema.org ScholarlyArticle, referenciamento acadêmico direto e declaração de autoria auditável.'
    },
    {
      title: '3. Marcação de Dados Estruturados Rich Snippets (JSON-LD)',
      description: 'Injeção automática de metadados estruturados para o Google indexar o Video-Book como Objeto de Vídeo Educacional e Tese Acadêmica com citações diretas.'
    },
    {
      title: '4. Captura de Buscas Acadêmicas e de Cauda Longa (Long-Tail Keywords)',
      description: 'Foco em termos de busca de alta intenção investigativa onde internautas e pesquisadores procuram por conexões entre física/sistemas quânticos, psicologia analítica e ciência de dados.'
    }
  ],

  keywordGroups: [
    {
      category: 'Núcleo Primário - PASQUAD & Tese',
      description: 'Termos diretos da marca conceitual para garantir ranking #1 absoluto',
      keywords: [
        { term: 'PASQUAD', searchVolume: 'Alta (Marca)', intent: 'Navegacional', difficulty: 'Baixa' },
        { term: 'Primeira Análise Sistêmica Quântica de Dados', searchVolume: 'Exata', intent: 'Informativa', difficulty: 'Baixa' },
        { term: 'Rogério Gomes Dos Santos PASQUAD', searchVolume: 'Específica', intent: 'Navegacional', difficulty: 'Baixa' },
        { term: 'Análise Sistêmica Quântica de Dados tese', searchVolume: 'Média', intent: 'Investigativa', difficulty: 'Média' },
        { term: 'Modelo conceitual PASQUAD', searchVolume: 'Média', intent: 'Informativa', difficulty: 'Baixa' }
      ]
    },
    {
      category: 'Cluster Sincronicidade & Carl Jung',
      description: 'Atração de público interessado em psicologia analítica e conexões com informação',
      keywords: [
        { term: 'Sincronicidade de Jung e Teoria da Informação', searchVolume: 'Média/Alta', intent: 'Informativa', difficulty: 'Média' },
        { term: 'Coincidências significativas análise de dados', searchVolume: 'Alta', intent: 'Investigativa', difficulty: 'Média' },
        { term: 'Sincronicidade em sistemas complexos', searchVolume: 'Média', intent: 'Informativa', difficulty: 'Média' },
        { term: 'Interpretação quântica da sincronicidade', searchVolume: 'Média', intent: 'Informativa', difficulty: 'Média' },
        { term: 'Conexões não causais e percepção humana', searchVolume: 'Alta', intent: 'Informativa', difficulty: 'Média' }
      ]
    },
    {
      category: 'Cluster Percepção & Seis Sentidos Integrados',
      description: 'Pesquisas sobre cognição, inteligência artificial e sexto sentido',
      keywords: [
        { term: 'Sexto sentido cognição integrativa', searchVolume: 'Média', intent: 'Informativa', difficulty: 'Baixa' },
        { term: 'Modelo dos Seis Sentidos Integrados', searchVolume: 'Exata', intent: 'Informativa', difficulty: 'Baixa' },
        { term: 'Percepção multissensorial e tomada de decisão', searchVolume: 'Alta', intent: 'Informativa', difficulty: 'Média' },
        { term: 'Processamento de informação e significado humano', searchVolume: 'Média', intent: 'Informativa', difficulty: 'Média' },
        { term: 'Reconhecimento de padrões no cotidiano', searchVolume: 'Alta', intent: 'Informativa', difficulty: 'Média' }
      ]
    },
    {
      category: 'Cluster Tecnologia & Sistemas de Informação',
      description: 'Intersecção com profissionais de TI, Data Science e Inteligência Artificial',
      keywords: [
        { term: 'Fluxo Percepção Integração Contexto Interpretação Significado', searchVolume: 'Exata', intent: 'Informativa', difficulty: 'Baixa' },
        { term: 'Quântico como metáfora na ciência de dados', searchVolume: 'Média', intent: 'Informativa', difficulty: 'Baixa' },
        { term: 'Sistemas de Informação e Sincronicidade Unifieo', searchVolume: 'Exata', intent: 'Navegacional', difficulty: 'Baixa' },
        { term: 'Análise sistêmica de coincidências simbólicas', searchVolume: 'Média', intent: 'Investigativa', difficulty: 'Média' }
      ]
    }
  ] as SEOKeywordGroup[],

  jsonLdSchema: {
    "@context": "https://schema.org",
    "@type": "ScholarlyArticle",
    "headline": "PASQUAD - Primeira Análise Sistêmica Quântica de Dados",
    "description": "Modelo conceitual de investigação da sincronicidade, percepção multissensorial e construção de significados por Rogério Gomes Dos Santos.",
    "author": {
      "@type": "Person",
      "name": "Rogério Gomes Dos Santos",
      "alumniOf": "Universidade Unifieo",
      "email": "rogeriogomes11@gmail.com",
      "sameAs": "https://instagram.com/rogeriogs577"
    },
    "publisher": {
      "@type": "Organization",
      "name": "PASQUAD Research"
    },
    "url": "https://pqd.ukbelol.space",
    "inLanguage": "pt-BR",
    "about": ["Sincronicidade", "Carl Gustav Jung", "Teoria da Informação", "Sistemas Complexos", "Cognição Integrativa"]
  }
};
