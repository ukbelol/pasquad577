// Web Audio API ambient generator and UI feedback sound effects for PASQUAD Video-Book

class QuantumAudioEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private currentAmbient: string = 'off';

  // Ambient sound nodes
  private ambientOsc1: OscillatorNode | null = null;
  private ambientOsc2: OscillatorNode | null = null;
  private ambientGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private lfoNode: OscillatorNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.ambientGain && this.ctx) {
      this.ambientGain.gain.setTargetAtTime(muted ? 0 : 0.08, this.ctx.currentTime, 0.1);
    }
  }

  public playChime(type: 'slide' | 'chapter' | 'ai' | 'correct') {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      if (type === 'slide') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(432, now);
        osc.frequency.exponentialRampToValueAtTime(864, now + 0.15);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
      } else if (type === 'chapter') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(216, now);
        osc.frequency.exponentialRampToValueAtTime(432, now + 0.4);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
      } else if (type === 'ai') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(528, now);
        osc.frequency.exponentialRampToValueAtTime(1056, now + 0.25);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'correct') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(528, now);
        osc.frequency.setValueAtTime(660, now + 0.1);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      }
    } catch (e) {
      console.warn("Audio Synth Error:", e);
    }
  }

  public setAmbient(type: 'off' | 'quantum-432' | 'solfeggio-528' | 'alpha-waves' | 'cosmic-synth') {
    this.currentAmbient = type;
    this.stopAmbient();

    if (type === 'off' || this.isMuted) return;

    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      this.ambientGain = this.ctx.createGain();
      this.filterNode = this.ctx.createBiquadFilter();

      this.filterNode.type = 'lowpass';
      this.filterNode.frequency.setValueAtTime(600, now);

      this.ambientOsc1 = this.ctx.createOscillator();
      this.ambientOsc2 = this.ctx.createOscillator();

      if (type === 'quantum-432') {
        // Deep 432Hz harmonic pad with binaural 8Hz alpha beat
        this.ambientOsc1.frequency.setValueAtTime(108, now); // A2 harmonic
        this.ambientOsc2.frequency.setValueAtTime(116, now); // 8Hz offset
        this.ambientOsc1.type = 'sine';
        this.ambientOsc2.type = 'triangle';
      } else if (type === 'solfeggio-528') {
        // 528 Hz Solfeggio frequency ambient tone
        this.ambientOsc1.frequency.setValueAtTime(264, now); // C4 harmonic
        this.ambientOsc2.frequency.setValueAtTime(268, now); // 4Hz beat
        this.ambientOsc1.type = 'sine';
        this.ambientOsc2.type = 'sine';
      } else if (type === 'alpha-waves') {
        // Alpha state 10Hz binaural drone
        this.ambientOsc1.frequency.setValueAtTime(136.1, now); // Om frequency
        this.ambientOsc2.frequency.setValueAtTime(146.1, now); // 10Hz offset
        this.ambientOsc1.type = 'sine';
        this.ambientOsc2.type = 'sine';
      } else if (type === 'cosmic-synth') {
        // Ethereal cosmic synth
        this.ambientOsc1.frequency.setValueAtTime(162, now);
        this.ambientOsc2.frequency.setValueAtTime(243, now);
        this.ambientOsc1.type = 'sawtooth';
        this.ambientOsc2.type = 'triangle';
        this.filterNode.frequency.setValueAtTime(350, now);
      }

      // LFO for subtle swelling effect
      this.lfoNode = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      this.lfoNode.frequency.setValueAtTime(0.15, now); // 0.15 Hz slow swell
      lfoGain.gain.setValueAtTime(150, now);

      this.lfoNode.connect(lfoGain);
      lfoGain.connect(this.filterNode.frequency);

      this.ambientOsc1.connect(this.filterNode);
      this.ambientOsc2.connect(this.filterNode);
      this.filterNode.connect(this.ambientGain);
      this.ambientGain.connect(this.ctx.destination);

      this.ambientGain.gain.setValueAtTime(0.001, now);
      this.ambientGain.gain.exponentialRampToValueAtTime(0.04, now + 2); // Soft 2s fade in

      this.ambientOsc1.start(now);
      this.ambientOsc2.start(now);
      this.lfoNode.start(now);
    } catch (e) {
      console.warn("Ambient Audio Error:", e);
    }
  }

  private stopAmbient() {
    if (this.ctx && this.ambientGain) {
      try {
        const now = this.ctx.currentTime;
        this.ambientGain.gain.linearRampToValueAtTime(0.0001, now + 0.5);
        setTimeout(() => {
          this.ambientOsc1?.stop();
          this.ambientOsc2?.stop();
          this.lfoNode?.stop();
          this.ambientOsc1?.disconnect();
          this.ambientOsc2?.disconnect();
          this.lfoNode?.disconnect();
          this.ambientGain?.disconnect();
          this.filterNode?.disconnect();
          this.ambientOsc1 = null;
          this.ambientOsc2 = null;
          this.lfoNode = null;
          this.ambientGain = null;
          this.filterNode = null;
        }, 500);
      } catch (e) {
        // Ignore
      }
    }
  }
}

export const audioSynth = new QuantumAudioEngine();
