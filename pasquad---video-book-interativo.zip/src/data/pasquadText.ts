import { Section } from '../types';

export const PASQUAD_METADATA = {
  title: "PASQUAD",
  fullTitle: "PASQUAD - Primeira Análise Sistêmica Quântica de Dados",
  subtitle: "Um Modelo Conceitual de Investigação da Sincronicidade, Percepção Multissensorial e Construção de Significados por Meio da Integração entre Cognição Humana, Teoria da Informação e Sistemas Complexos",
  type: "MONOGRAFIA CONCEITUAL",
  typeDescription: "Proposta de um Novo Modelo Interdisciplinar de Análise de Padrões Informacionais na Experiência Humana",
  author: "Rogério Gomes Dos Santos",
  location: "Osasco – São Paulo – Brasil",
  birthDate: "05 de Maio de 1977",
  degree: "Bacharelado em Sistemas de Informação",
  university: "Universidade Unifieo – Osasco – SP",
  graduationYear: "2010",
  social: "@rogeriogs577",
  email: "rogeriogomes11@gmail.com",
  keywordsPt: ["PASQUAD", "sincronicidade", "cognição", "percepção", "sistemas complexos", "informação", "consciência"],
  keywordsEn: ["synchronicity", "cognition", "information theory", "perception", "complex systems"]
};

export const PASQUAD_SECTIONS: Section[] = [
  {
    id: "capa",
    chapter: "Apresentação",
    number: "0.0",
    title: "PASQUAD — Monografia Conceitual",
    subtitle: "Primeira Análise Sistêmica Quântica de Dados",
    keywords: ["PASQUAD", "Apresentação", "Rogério Gomes Dos Santos", "Sistemas de Informação"],
    visualPrompt: "Matriz quântica de dados fluindo em rede neural reluzente e ondas de informação",
    paragraphs: [
      "Bem-vindo ao Video-Book da tese PASQUAD: Primeira Análise Sistêmica Quântica de Dados.",
      "Esta monografia conceitual apresenta uma proposta de modelo interdisciplinar destinada ao estudo da interpretação humana de eventos percebidos como significativos, coincidências simbólicas e padrões emergentes no cotidiano.",
      "Trabalho elaborado por Rogério Gomes Dos Santos, Bacharel em Sistemas de Informação pela Universidade Unifieo (Osasco – SP, 2010)."
    ]
  },
  {
    id: "resumo",
    chapter: "Resumo & Abstract",
    number: "0.1",
    title: "Resumo Executivo",
    subtitle: "Visão Geral e Palavras-Chave",
    keywords: ["Resumo", "Sincronicidade", "Teoria da Informação", "Seis Sentidos"],
    visualPrompt: "Conexões neurais integradas com símbolos de dados, psique e informação sistêmica",
    paragraphs: [
      "A presente monografia conceitual apresenta o desenvolvimento do modelo denominado PASQUAD – Primeira Análise Sistêmica Quântica de Dados, uma proposta interdisciplinar destinada ao estudo da interpretação humana de eventos percebidos como significativos, coincidências simbólicas e padrões emergentes no cotidiano.",
      "O modelo tem como ponto de partida o conceito de sincronicidade, desenvolvido pelo psiquiatra suíço Carl Gustav Jung, associado a estudos contemporâneos sobre cognição, percepção, teoria da informação, sistemas complexos e inteligência artificial.",
      "O PASQUAD propõe que a realidade percebida pelo ser humano pode ser analisada como um fluxo contínuo de informações, no qual eventos materiais e imateriais são interpretados através da integração de múltiplos sistemas perceptivos.",
      "A proposta introduz o conceito dos 'seis sentidos integrados', sendo o sexto sentido compreendido como uma capacidade cognitiva de síntese baseada em memória, experiência, reconhecimento de padrões e inferência.",
      "O termo 'quântico', presente na denominação do modelo, não representa uma aplicação direta da física quântica à consciência, mas uma metáfora epistemológica relacionada à existência de múltiplas possibilidades interpretativas antes da definição de um significado final.",
      "A pesquisa propõe uma arquitetura metodológica para analisar como indivíduos treinados podem interpretar informações ambientais utilizando critérios de coerência, conhecimento interdisciplinar e validação crítica."
    ]
  },
  {
    id: "abstract",
    chapter: "Resumo & Abstract",
    number: "0.2",
    title: "Abstract",
    subtitle: "English Conceptual Summary",
    keywords: ["Abstract", "Synchronicity", "Integrated Perception", "Pattern Recognition"],
    visualPrompt: "Globe of interconnected data lines, quantum superposition nodes and cognitive mapping",
    paragraphs: [
      "This conceptual thesis presents PASQUAD – First Systemic Quantum Data Analysis, an interdisciplinary model proposed for investigating human interpretation of meaningful coincidences, symbolic patterns and information processing.",
      "Inspired by Carl Gustav Jung’s concept of synchronicity and connected with contemporary studies in cognition, information theory and complex systems, PASQUAD proposes a framework for understanding how humans construct meaning through integrated perception.",
      "The model introduces six integrated senses, considering the sixth sense as a cognitive synthesis mechanism based on experience, memory and pattern recognition.",
      "The research proposes a conceptual methodology for future empirical investigations."
    ]
  },
  {
    id: "sumario",
    chapter: "Estrutura do Trabalho",
    number: "0.3",
    title: "Sumário Proposto",
    subtitle: "Organização dos Capítulos",
    keywords: ["Sumário", "Capítulo 1", "Capítulo 2", "Introdução", "Fundamentação Teórica"],
    visualPrompt: "Árvore de tópicos interativa com nós iluminados representando cada capítulo do modelo PASQUAD",
    paragraphs: [
      "A monografia é estruturada em Capítulos e Subseções encadeadas logicamente:",
      "Capítulo 1 – Introdução: 1.1 Contextualização da pesquisa; 1.2 Origem da proposta PASQUAD; 1.3 Problema de pesquisa; 1.4 Hipótese central; 1.5 Objetivos; 1.6 Justificativa.",
      "Capítulo 2 – Fundamentação Teórica: 2.1 Carl Gustav Jung e o conceito de sincronicidade; 2.2 O inconsciente coletivo e os arquétipos; 2.3 Percepção humana e construção de realidade; 2.4 Teoria da informação; 2.5 Sistemas complexos adaptativos; 2.6 Inteligência artificial e reconhecimento de padrões; 2.7 Relação entre observador e interpretação."
    ]
  },
  {
    id: "cap1-intro",
    chapter: "Capítulo 1",
    number: "1.0",
    title: "Introdução",
    subtitle: "A Busca Humana por Padrões e Significado",
    keywords: ["Introdução", "Padrões", "Causalidade", "Carl Gustav Jung"],
    visualPrompt: "Pessoa contemplando o cosmos com constelações fluindo em forma de dados e significados",
    paragraphs: [
      "A humanidade sempre buscou compreender sua relação com o universo, a natureza e os acontecimentos que compõem sua existência. Desde as primeiras sociedades humanas, padrões presentes no ambiente foram interpretados como formas de comunicação simbólica entre o indivíduo e o mundo ao seu redor.",
      "O desenvolvimento científico ampliou essa capacidade de observação, permitindo compreender fenômenos naturais por meio de métodos experimentais.",
      "Entretanto, permanece uma questão fundamental: Como o ser humano atribui significado aos acontecimentos aparentemente conectados por coincidências significativas?",
      "Essa pergunta encontra uma importante referência no conceito de sincronicidade elaborado por Carl Gustav Jung. Para Jung, determinados acontecimentos podem apresentar uma relação baseada não na causalidade tradicional, mas no significado psicológico atribuído pelo observador.",
      "O PASQUAD surge como uma tentativa de organizar esse fenômeno dentro de uma estrutura conceitual interdisciplinar, utilizando conhecimentos provenientes da tecnologia da informação, área de formação do autor, associados a conceitos de psicologia, filosofia e ciência cognitiva."
    ]
  },
  {
    id: "cap1-1",
    chapter: "Capítulo 1",
    number: "1.1",
    title: "Origem da Proposta PASQUAD",
    subtitle: "A Visão dos Sistemas de Informação Aplicada à Experiência",
    keywords: ["Sistemas de Informação", "Processamento de Dados", "Realidade", "Modelos Internos"],
    visualPrompt: "Linha de montagem de dados transformando estímulos sensoriais em mapas de inteligência",
    paragraphs: [
      "A formação em Sistemas de Informação proporciona uma visão baseada em: coleta de dados; processamento; organização; análise; interpretação; tomada de decisão.",
      "A partir dessa perspectiva, surge a hipótese de que experiências humanas também podem ser analisadas como processos informacionais complexos.",
      "O indivíduo recebe continuamente informações: visuais, sonoras, ambientais, emocionais, culturais e cognitivas.",
      "A interpretação desses dados produz modelos internos de realidade. O PASQUAD propõe estudar esse processo de forma sistêmica."
    ]
  },
  {
    id: "cap1-2",
    chapter: "Capítulo 1",
    number: "1.2",
    title: "Problema de Pesquisa",
    subtitle: "A Questão Central do PASQUAD",
    keywords: ["Problema de Pesquisa", "Protocolo", "Análise Sistêmica", "Integração Sensorial"],
    visualPrompt: "Um prisma quântico refratando feixes dispersos de dados em um padrão coerente e focalizado",
    paragraphs: [
      "A pesquisa formula sua questão delimitadora fundamental:",
      "Como desenvolver um modelo conceitual capaz de organizar a interpretação de eventos percebidos como sincrônicos utilizando integração sensorial, conhecimento interdisciplinar e análise sistêmica?"
    ]
  },
  {
    id: "cap1-3",
    chapter: "Capítulo 1",
    number: "1.3",
    title: "Hipótese Central",
    subtitle: "Protocolo Estruturado e Validação Lógica",
    keywords: ["Hipótese", "Protocolo", "Coerência", "Validação Lógica"],
    visualPrompt: "Matriz holográfica demonstrando um fluxo lógico validando eventos e percepções",
    paragraphs: [
      "A hipótese principal desta pesquisa estabelece que:",
      "\"Se informações percebidas pelo indivíduo forem organizadas através de um protocolo estruturado envolvendo percepção, contexto, conhecimento e validação lógica, será possível produzir interpretações mais consistentes sobre padrões significativos presentes na experiência humana.\""
    ]
  },
  {
    id: "cap1-4-5",
    chapter: "Capítulo 1",
    number: "1.4 & 1.5",
    title: "Objetivo Geral e Objetivos Específicos",
    subtitle: "Metas do Modelo PASQUAD",
    keywords: ["Objetivos", "Modelo Conceitual", "Percepção Multissensorial", "IA"],
    visualPrompt: "Rede de metas interdisciplinares interligando Ciência Cognitiva, IA e Teoria da Informação",
    paragraphs: [
      "Objetivo Geral: Desenvolver um modelo conceitual denominado PASQUAD capaz de representar processos humanos de interpretação de informações complexas provenientes da interação entre indivíduo e ambiente.",
      "Objetivos Específicos:",
      "1. Criar uma arquitetura de análise baseada em informações multissensoriais.",
      "2. Desenvolver critérios para interpretação de padrões.",
      "3. Relacionar percepção humana e teoria da informação.",
      "4. Propor metodologia futura de validação experimental.",
      "5. Explorar aplicações em ciência cognitiva e inteligência artificial."
    ]
  },
  {
    id: "cap1-6",
    chapter: "Capítulo 1",
    number: "1.6",
    title: "Justificativa",
    subtitle: "Transformando Dados em Significado na Era da Informação",
    keywords: ["Justificativa", "Expansão de Informações", "Tecnologia", "Psicologia"],
    visualPrompt: "Ponte luminosa ligando os domínios da Tecnologia da Informação, Psicologia e Filosofia",
    paragraphs: [
      "A sociedade contemporânea vive uma expansão contínua da quantidade de informações disponíveis. Apesar do avanço tecnológico, permanece o desafio de compreender como seres humanos transformam dados em significado.",
      "O PASQUAD busca contribuir para esse debate propondo uma ponte conceitual entre: tecnologia da informação; psicologia; filosofia; cognição; análise de sistemas."
    ]
  },
  {
    id: "cap2-1",
    chapter: "Capítulo 2",
    number: "2.1",
    title: "Sincronicidade em Carl Gustav Jung",
    subtitle: "Conexões Não-Causais Significativas",
    keywords: ["Carl Gustav Jung", "Sincronicidade", "Significado Psicológico", "Acontecimentos"],
    visualPrompt: "Dois eventos distantes convergindo no tempo unidos por uma espiral de significado psicológico",
    paragraphs: [
      "O conceito de sincronicidade representa um dos elementos centrais desta pesquisa.",
      "Jung descreveu experiências nas quais acontecimentos internos (como pensamentos, sonhos ou intuições) e externos (eventos ambientais simultâneos) parecem apresentar uma conexão significativa para o indivíduo, mesmo sem uma relação causal evidente.",
      "O PASQUAD utiliza esse conceito como ponto inicial para investigar mecanismos humanos de interpretação."
    ]
  },
  {
    id: "cap2-2",
    chapter: "Capítulo 2",
    number: "2.2",
    title: "A Informação como Elemento Fundamental",
    subtitle: "Comparação de Modelos Informacionais",
    keywords: ["Teoria da Informação", "Fluxo Informacional", "Computação", "PASQUAD"],
    visualPrompt: "Diagrama comparativo com fluxo tradicional de dados versus fluxo quântico-perceptivo PASQUAD",
    paragraphs: [
      "A proposta considera a informação como elemento organizador da experiência humana.",
      "Em sistemas computacionais tradicionais, a cadeia de valor informacional ocorre da seguinte forma:",
      "Dados → Processamento → Informação → Conhecimento → Decisão.",
      "No modelo PASQUAD, a cadeia de atribuição de significado na consciência opera do seguinte modo:",
      "Percepção → Integração → Contexto → Interpretação → Significado."
    ]
  },
  {
    id: "cap2-3",
    chapter: "Capítulo 2",
    number: "2.3",
    title: "O Modelo dos Seis Sentidos Integrados",
    subtitle: "A Cognição Integrativa como Sexto Sentido",
    keywords: ["Seis Sentidos", "Cognição Integrativa", "Visão", "Audição", "Sintese"],
    visualPrompt: "Hexágono holográfico unindo os 5 sentidos clássicos ao polo central do Sexto Sentido Cognitivo",
    paragraphs: [
      "O PASQUAD considera a percepção como um ecossistema multissensorial abrangendo os cinco sentidos biológicos clássicos: Visão, Audição, Tato, Olfato e Paladar.",
      "Adicionalmente, introduz o conceito do sexto elemento: a 'Cognição Integrativa'.",
      "O sexto elemento não é encarado como misticismo, mas como a capacidade cognitiva humana de sintetizar e unir informações aparentemente separadas, baseada em memória, experiência acumulada, reconhecimento de padrões profundos e inferência contextual rápida."
    ]
  },
  {
    id: "declaracao",
    chapter: "Autoria & Encerramento",
    number: "3.0",
    title: "Declaração de Autoria e Compromisso Científico",
    subtitle: "Rogério Gomes Dos Santos",
    keywords: ["Autoria", "Rogério Gomes Dos Santos", "Investigação Interdisciplinar", "Compromisso Científico"],
    visualPrompt: "Assinatura do autor com selo conceitual PASQUAD e coordenadas de Osasco-SP",
    paragraphs: [
      "Eu, Rogério Gomes Dos Santos, declaro que o presente trabalho apresenta uma proposta conceitual original denominada PASQUAD – Primeira Análise Sistêmica Quântica de Dados, desenvolvida como uma investigação interdisciplinar sobre percepção, informação e construção de significado.",
      "A proposta apresentada possui caráter exploratório e busca estimular pesquisas futuras, mantendo compromisso com princípios científicos de análise crítica, validação metodológica e distinção entre hipóteses conceituais e conhecimentos comprovados.",
      "Rogério Gomes Dos Santos | Osasco – São Paulo – Brasil | Bacharel em Sistemas de Informação (Unifieo 2010) | Redes: @rogeriogs577 | Contato: rogeriogomes11@gmail.com"
    ]
  }
];
