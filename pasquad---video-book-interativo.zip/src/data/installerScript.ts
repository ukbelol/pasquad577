export const INSTALL_GERALL_SCRIPT = `#!/bin/bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO GERAL AUTOMATIZADA - PASQUAD VIDEO-BOOK (DEBIAN 12)
# Arquivo: install-gerall.sh
# Web Server: Apache2 Reverse Proxy (Portas 80, 443) + PM2 Process Manager
# Prevenção Definitiva contra Erros 503 (Service Unavailable), 404 e 302
# Domínio Alvo: pqd.ukbelol.space
# E-mail SSL (Certbot): rogeriogomes11@gmail.com
# Super Admin: roger577@ukbelol.space
# Autor: Rogério Gomes Dos Santos
# ==============================================================================

set -e

# Configurações de ambiente headless para prevenir erros de GUI/Qt/XCB
export QT_QPA_PLATFORM=offscreen
export DISPLAY=:99
export XDG_RUNTIME_DIR=/tmp/runtime-root
mkdir -p /tmp/runtime-root
chmod 700 /tmp/runtime-root

# Cores para terminal
RED='\\x1b[0;31m'
GREEN='\\x1b[0;32m'
CYAN='\\x1b[0;36m'
YELLOW='\\x1b[1;33m'
BOLD='\\x1b[1m'
NC='\\x1b[0m' # No Color

echo -e "\${CYAN}"
echo "================================================================="
echo "   INSTALADOR GERAL AUTOMÁTICO PASQUAD - DEBIAN 12 LINUX         "
echo "   Web Server: Apache2 Reverse Proxy + PM2 Process Manager        "
echo "   Instalação Automática: NVM, Node.js 20, NPM, Vite, Apache2 SSL "
echo "   Proteção Anti-Erro: 503 (Service Unavailable), 404 e 302      "
echo "   Domínio: pqd.ukbelol.space                                   "
echo "================================================================="
echo -e "\${NC}"

# 1. Verificar privilégios de Root
if [ "$EUID" -ne 0 ]; then
  echo -e "\${RED}Erro: Por favor, execute este script como root ou com sudo! Exemplo:\${NC}"
  echo -e "\${YELLOW}curl -sSL https://pqd.ukbelol.space/install-gerall.sh | sudo bash\${NC}"
  exit 1
fi

# 2. Atualizar repositórios do Debian 12 e dependências de sistema
echo -e "\${YELLOW}[1/10] Atualizando pacotes do Debian 12 e instalando dependências do sistema...\${NC}"
apt update && apt upgrade -y
apt install -y curl wget git build-essential ufw software-properties-common ca-certificates gnupg lsb-release unzip \\
  xvfb libgl1-mesa-glx libgl1-mesa-dri libglib2.0-0 libxcb-xinerama0 libxcb-cursor0 libx11-xcb1 libxcb-icccm4 \\
  libxcb-image0 libxcb-keysyms1 libxcb-randr0 libxcb-render-util0 libxcb-shape0 libxcb-xfixes0 libfontconfig1 \\
  libdbus-1-3 libxi6 libxrender1 libsm6 libice6 libxtst6 libxkbcommon-x11-0 libxkbcommon0 apache2 certbot python3-certbot-apache || true

# 3. Instalar e Configurar NVM (Node Version Manager) e Node.js 20 LTS
echo -e "\${YELLOW}[2/10] Instalando NVM (Node Version Manager) e Node.js 20 LTS...\${NC}"
export NVM_DIR="/root/.nvm"
if [ ! -d "$NVM_DIR" ]; then
  PROFILE=/dev/null curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
fi
[ -s "$NVM_DIR/nvm.sh" ] && \\. "$NVM_DIR/nvm.sh"
[ -s "$NVM_DIR/bash_completion" ] && \\. "$NVM_DIR/bash_completion"

nvm install 20 || true
nvm use 20 || true
nvm alias default 20 || true

# Instalar também Node.js 20 LTS via Nodesource APT para disponibilidade global no sistema
if ! command -v node &> /dev/null || [[ $(node -v) != v20* ]]; then
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg 2>/dev/null || true
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
  apt update
  apt install -y nodejs
fi

echo -e "\${GREEN}✓ Node.js $(node -v) e NPM v$(npm -v) verificados e ativos com NVM!\${NC}"

# 4. Instalar PM2, Vite, esbuild, typescript e tsx globalmente
echo -e "\${YELLOW}[3/10] Instalando PM2 (Process Manager), Vite, esbuild e utilitários globais...\${NC}"
npm install -g pm2 esbuild tsx vite typescript

# 5. Configurar Módulos do Apache2 Web Server
echo -e "\${YELLOW}[4/10] Ativando módulos de Reverse Proxy, SSL, WebSocket e Headers no Apache2...\${NC}"
if [ -f "/etc/apache2/ports.conf" ]; then
  grep -q "Listen 80" /etc/apache2/ports.conf || echo "Listen 80" >> /etc/apache2/ports.conf
  grep -q "Listen 443" /etc/apache2/ports.conf || echo "Listen 443" >> /etc/apache2/ports.conf
fi
a2enmod proxy proxy_http proxy_wstunnel rewrite ssl headers

# 6. Criar Diretório da Aplicação e Ajustar Permissões (Evita 503 e 403)
APP_DIR="/var/www/pasquad-app"
CURRENT_DIR="$(pwd)"
echo -e "\${YELLOW}[5/10] Configurando estrutura do projeto em $APP_DIR...\${NC}"

chmod 755 /var/www
mkdir -p "$APP_DIR"

if [ -f "$CURRENT_DIR/package.json" ]; then
  echo -e "\${CYAN}Copiando arquivos do diretório atual $CURRENT_DIR...\${NC}"
  cp -rf "$CURRENT_DIR"/* "$APP_DIR"/ 2>/dev/null || true
  if ls "$CURRENT_DIR"/.* 1> /dev/null 2>&1; then
    cp -rf "$CURRENT_DIR"/.* "$APP_DIR"/ 2>/dev/null || true
  fi
elif [ -f "$CURRENT_DIR/pasquad.zip" ]; then
  echo -e "\${CYAN}Extraindo pasquad.zip para $APP_DIR...\${NC}"
  unzip -o "$CURRENT_DIR/pasquad.zip" -d "$APP_DIR"
else
  echo -e "\${CYAN}Baixando pacote pasquad.zip de https://pqd.ukbelol.space/pasquad.zip...\${NC}"
  curl -sSL -o /tmp/pasquad.zip https://pqd.ukbelol.space/pasquad.zip || true
  if [ -f "/tmp/pasquad.zip" ]; then
    unzip -o /tmp/pasquad.zip -d "$APP_DIR"
    rm -f /tmp/pasquad.zip
  fi
fi

mkdir -p "$APP_DIR/src"
mkdir -p "$APP_DIR/public"
mkdir -p "$APP_DIR/data_store"
mkdir -p "$APP_DIR/dist"

cd "$APP_DIR"

# 7. Instalar dependências NPM e Compilar o Projeto (Vite + esbuild)
echo -e "\${YELLOW}[6/10] Instalando dependências NPM e compilando a aplicação...\${NC}"
npm install --production=false
QT_QPA_PLATFORM=offscreen DISPLAY=:99 npm run build

# Permissões rigorosas de pasta/arquivo (755 para pastas, 644 para arquivos, www-data)
echo -e "\${YELLOW}Aplicando permissões 755/644 com proprietário www-data em $APP_DIR...\${NC}"
chown -R www-data:www-data "$APP_DIR" 2>/dev/null || true
chmod -R 755 "$APP_DIR"
chmod -R 777 "$APP_DIR/data_store" 2>/dev/null || true
find "$APP_DIR" -type d -exec chmod 755 {} + 2>/dev/null || true
find "$APP_DIR" -type f -exec chmod 644 {} + 2>/dev/null || true
chmod +x "$APP_DIR/install-gerall.sh" 2>/dev/null || true

# 8. Configurar Ecossistema PM2 e Iniciar Serviço no Backend (Porta 3000)
echo -e "\${YELLOW}[7/10] Configurando ecossistema PM2 e iniciando serviço pasquad na porta 3000...\${NC}"

cat << 'EOF' > "$APP_DIR/ecosystem.config.cjs"
module.exports = {
  apps: [{
    name: "pasquad",
    cwd: "/var/www/pasquad-app",
    script: "./dist/server.cjs",
    env: {
      NODE_ENV: "production",
      PORT: 3000,
      QT_QPA_PLATFORM: "offscreen",
      DISPLAY: ":99"
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G'
  }]
};
EOF

chown www-data:www-data "$APP_DIR/ecosystem.config.cjs" 2>/dev/null || true
chmod 644 "$APP_DIR/ecosystem.config.cjs"

pm2 delete pasquad 2>/dev/null || true
QT_QPA_PLATFORM=offscreen DISPLAY=:99 pm2 start "$APP_DIR/ecosystem.config.cjs"

PM2_BIN=$(which pm2 || echo "/usr/bin/pm2")
$PM2_BIN startup systemd -u root --hp /root --force 2>/dev/null || true
$PM2_BIN save

# Verificação de Saúde na porta 3000 (Garantia contra erro 503)
echo -e "\${YELLOW}Aguardando inicialização do servidor backend na porta 3000...\${NC}"
MAX_RETRIES=25
RETRY_COUNT=0
BACKEND_OK=false

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
  if curl -s http://127.0.0.1:3000/api/health | grep -q "ok"; then
    BACKEND_OK=true
    break
  fi
  sleep 2
  RETRY_COUNT=$((RETRY_COUNT+1))
  echo -n "."
done
echo ""

if [ "$BACKEND_OK" = true ]; then
  echo -e "\${GREEN}✓ Servidor Node.js operando perfeitamente na porta 3000!\${NC}"
else
  echo -e "\${RED}⚠ O serviço no PM2 está subindo. Diagnóstico dos logs:\${NC}"
  pm2 logs pasquad --lines 15 --raw || true
fi

# 9. Configurar VirtualHosts no Apache2 (HTTP :80 e HTTPS :443) com SSLEngine ON
echo -e "\${YELLOW}[8/10] Criando VirtualHosts no Apache2 com SSLEngine ON (Prevenção SSL_ERROR_RX_RECORD_TOO_LONG)...\${NC}"

# Garantir geração de certificado SSL emergencial se o Let's Encrypt ainda não existir.
# Isso impede que a porta 443 responda em HTTP não criptografado (causa de SSL_ERROR_RX_RECORD_TOO_LONG).
SSL_DIR="/etc/ssl/pqd"
mkdir -p "$SSL_DIR"
if [ ! -f "$SSL_DIR/pqd.crt" ]; then
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \\
    -keyout "$SSL_DIR/pqd.key" \\
    -out "$SSL_DIR/pqd.crt" \\
    -subj "/CN=pqd.ukbelol.space/O=PASQUAD/C=BR" 2>/dev/null || true
fi

CERT_FILE="$SSL_DIR/pqd.crt"
KEY_FILE="$SSL_DIR/pqd.key"

if [ -f "/etc/letsencrypt/live/pqd.ukbelol.space/fullchain.pem" ]; then
  CERT_FILE="/etc/letsencrypt/live/pqd.ukbelol.space/fullchain.pem"
  KEY_FILE="/etc/letsencrypt/live/pqd.ukbelol.space/privkey.pem"
fi

cat << EOF > /etc/apache2/sites-available/pqd.ukbelol.space.conf
<VirtualHost *:80>
    ServerName pqd.ukbelol.space
    ServerAlias www.pqd.ukbelol.space

    ServerAdmin rogeriogomes11@gmail.com
    DocumentRoot /var/www/pasquad-app/dist

    <Directory /var/www/pasquad-app/dist>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Redirecionamento automático HTTP -> HTTPS
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

    ErrorLog \\\${APACHE_LOG_DIR}/pasquad_http_error.log
    CustomLog \\\${APACHE_LOG_DIR}/pasquad_http_access.log combined
</VirtualHost>

<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerName pqd.ukbelol.space
    ServerAlias www.pqd.ukbelol.space

    ServerAdmin rogeriogomes11@gmail.com
    DocumentRoot /var/www/pasquad-app/dist

    SSLEngine on
    SSLCertificateFile $CERT_FILE
    SSLCertificateKeyFile $KEY_FILE

    SSLProtocol all -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite HIGH:!aNULL:!MD5

    <Directory /var/www/pasquad-app>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    <Directory /var/www/pasquad-app/dist>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ProxyRequests Off
    ProxyPreserveHost On
    ProxyVia On
    ProxyTimeout 120

    <Proxy *>
        Require all granted
    </Proxy>

    # Configuração de Proxy para WebSockets
    ProxyPass /ws ws://127.0.0.1:3000/ws disablereuse=On retry=0 timeout=120
    ProxyPassReverse /ws ws://127.0.0.1:3000/ws

    # Proxy Reverse HTTP com disablereuse=On e retry=0
    ProxyPass / http://127.0.0.1:3000/ disablereuse=On retry=0 timeout=120
    ProxyPassReverse / http://127.0.0.1:3000/

    # Cabeçalhos proxy informando HTTPS para a aplicação Node.js
    RequestHeader set X-Forwarded-Proto "https"
    RequestHeader set X-Forwarded-Port "443"

    ErrorLog \\\${APACHE_LOG_DIR}/pasquad_ssl_error.log
    CustomLog \\\${APACHE_LOG_DIR}/pasquad_ssl_access.log combined
</VirtualHost>
</IfModule>
EOF

a2dissite 000-default.conf default-ssl.conf pasquad.ukbelol.space.conf 2>/dev/null || true
a2ensite pqd.ukbelol.space.conf

apache2ctl configtest
systemctl restart apache2

# 10. Configurar Firewall UFW e Emitir Certificado SSL Let's Encrypt Oficial
echo -e "\${YELLOW}[9/10] Habilitando Firewall UFW nas portas 80, 443 e 22...\${NC}"
ufw allow in on lo 2>/dev/null || true
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

echo -e "\${YELLOW}[10/10] Emitindo/Atualizando Certificado SSL Oficial Let's Encrypt com Certbot...\${NC}"
certbot --apache -d pqd.ukbelol.space -d www.pqd.ukbelol.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com --reinstall || \\
certbot --apache -d pqd.ukbelol.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com --reinstall || {
  echo -e "\${YELLOW}Tentando emissão via certbot certonly webroot como fallback...\${NC}"
  certbot certonly --webroot -w /var/www/pasquad-app/dist -d pqd.ukbelol.space -d www.pqd.ukbelol.space --non-interactive --agree-tos -m rogeriogomes11@gmail.com || true
  
  if [ -f "/etc/letsencrypt/live/pqd.ukbelol.space/fullchain.pem" ]; then
    sed -i "s|\$SSL_DIR/pqd.crt|/etc/letsencrypt/live/pqd.ukbelol.space/fullchain.pem|g" /etc/apache2/sites-available/pqd.ukbelol.space.conf
    sed -i "s|\$SSL_DIR/pqd.key|/etc/letsencrypt/live/pqd.ukbelol.space/privkey.pem|g" /etc/apache2/sites-available/pqd.ukbelol.space.conf
  fi
}

systemctl restart apache2

echo -e "\${GREEN}"
echo "================================================================="
echo "   SISTEMA PASQUAD INSTALADO E NO AR COM SUCESSO NO DEBIAN 12!  "
echo "================================================================="
echo "   URL Principal: https://pqd.ukbelol.space                       "
echo "   Painel Admin:  https://pqd.ukbelol.space (Menu Admin)         "
echo "   Super Admin:   roger577@ukbelol.space                          "
echo "   Web Server:    Apache2 (Reverse Proxy - Porta 3000)            "
echo "   Gerenciador:   PM2 Process Manager                             "
echo "   Node / NVM:    Node.js 20 LTS ativo via NVM                    "
echo "   Portas Abertas: 80 (HTTP) e 443 (HTTPS - SSL Válido Ativo)     "
echo "   Permissões:    755 (www-data:www-data)                         "
echo "   Proteção Erros: Anti-503 (disablereuse=On), Anti-404, Anti-302  "
echo "================================================================="
echo -e "\${NC}"
`;

export const DEBIAN12_INSTALL_SCRIPT = INSTALL_GERALL_SCRIPT;
