export const DEBIAN12_INSTALL_SCRIPT = `#!/bin/bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO AUTOMATIZADA - PASQUAD VIDEO-BOOK (DEBIAN 12)
# Domínio Target: pasquad.ukbelol.space
# E-mail SSL Certbot: rogermei577@gmail.com
# Super Admin Configurado: roger577@ukbelol.space
# Autor: Rogério Gomes Dos Santos
# ==============================================================================

set -e

# Cores para saída no terminal
RED='\\033[0;31m'
GREEN='\\033[0;32m'
CYAN='\\033[0;36m'
YELLOW='\\033[1;33m'
NC='\\033[0m'

echo -e "\${CYAN}"
echo "================================================================="
echo "   INICIANDO INSTALAÇÃO AUTOMÁTICA PASQUAD - DEBIAN 12 LINUX    "
echo "   Domínio: pasquad.ukbelol.space                               "
echo "   Certificado SSL: Let's Encrypt (rogermei577@gmail.com)       "
echo "================================================================="
echo -e "\${NC}"

# 1. Verificar privilégios de Superusuário (Root)
if [ "$EUID" -ne 0 ]; then
  echo -e "\${RED}Erro: Por favor, execute este script como root ou com sudo!\${NC}"
  exit 1
fi

# 2. Atualizar Sistema Operacional Debian 12
echo -e "\${YELLOW}[1/8] Atualizando repositórios do Debian 12...\${NC}"
apt update && apt upgrade -y
apt install -y curl wget git build-essential ufw software-properties-common ca-certificates gnupg lsb-release

# 3. Instalar Node.js 20 LTS e NPM
echo -e "\${YELLOW}[2/8] Instalando Node.js 20 LTS e ferramentas de compilação...\${NC}"
if ! command -v node &> /dev/null; then
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
  NODE_MAJOR=20
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
  apt update
  apt install -y nodejs
fi

echo -e "\${GREEN}Node.js $(node -v) e NPM $(npm -v) instalados com sucesso!\${NC}"

# 4. Instalar Nginx e Certbot
echo -e "\${YELLOW}[3/8] Instalando Nginx Web Server e Certbot SSL...\${NC}"
apt install -y nginx certbot python3-certbot-nginx

# 5. Criar Diretório e Clonar/Configurar Aplicação
APP_DIR="/var/www/pasquad-app"
echo -e "\${YELLOW}[4/8] Configurando diretório da aplicação em $APP_DIR...\${NC}"

mkdir -p $APP_DIR
cd $APP_DIR

# Caso exista código local, copia os arquivos do projeto atual ou cria o setup
if [ -f "package.json" ]; then
  echo "Diretório já contém o código da aplicação. Atualizando dependências..."
else
  echo "Copiando arquivos da aplicação..."
  # Se o repositório Git estiver disponível, substitua a linha abaixo pelo git clone
  # git clone https://github.com/seu-usuario/pasquad-videobook.git .
fi

# Instalar dependências npm e compilar a aplicação
echo -e "\${YELLOW}[5/8] Instalando dependências NPM e compilando projeto...\${NC}"
npm install
npm run build

# 6. Configurar Serviço Systemd para a aplicação
echo -e "\${YELLOW}[6/8] Criando e ativando serviço Systemd (pasquad.service)...\${NC}"

cat << 'EOF' > /etc/systemd/system/pasquad.service
[Unit]
Description=PASQUAD Video-Book Node.js Application
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/var/www/pasquad-app
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable pasquad
systemctl restart pasquad

# 7. Configurar Nginx Reverse Proxy
echo -e "\${YELLOW}[7/8] Configurando Nginx para o domínio pasquad.ukbelol.space...\${NC}"

cat << 'EOF' > /etc/nginx/sites-available/pasquad.ukbelol.space
server {
    listen 80;
    listen [::]:80;
    server_name pasquad.ukbelol.space www.pasquad.ukbelol.space;

    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

ln -sf /etc/nginx/sites-available/pasquad.ukbelol.space /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

# 8. Obter e Instalar Certificado SSL Válido com Let's Encrypt Certbot
echo -e "\${YELLOW}[8/8] Obtendo Certificado SSL Válido para pasquad.ukbelol.space...\${NC}"

# Configurar Firewall UFW
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# Executar Certbot
certbot --nginx -d pasquad.ukbelol.space --non-interactive --agree-tos -m rogermei577@gmail.com --redirect || {
  echo -e "\${RED}Aviso: Certbot não conseguiu validar o domínio imediatamente. Certifique-se de que o Apontamento DNS do tipo A do domínio pasquad.ukbelol.space está direcionado para o IP público deste servidor.\${NC}"
}

# Habilitar renovação automática do SSL
systemctl enable certbot.timer

echo -e "\${GREEN}"
echo "================================================================="
echo "   INSTALAÇÃO E CONFIGURAÇÃO CONCLUÍDAS COM SUCESSO!            "
echo "================================================================="
echo "   Site Ativo em: https://pasquad.ukbelol.space                  "
echo "   Painel Super Admin: https://pasquad.ukbelol.space (aba Admin) "
echo "   Super Admin Email: roger577@ukbelol.space                     "
echo "   Segurança Firewall IP: Bloqueio ativado após 3 erros de senha"
echo "================================================================="
echo -e "\${NC}"
`;
