export const INSTALL_GERALL_SCRIPT = `#!/bin/bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO GERAL AUTOMATIZADA - PASQUAD VIDEO-BOOK (DEBIAN 12)
# Arquivo: install-gerall.sh
# Web Server: Apache2 com Reverse Proxy + PM2 Process Manager
# Solução de Permissões & Prevenção de Erro 503: disablereuse=On, 755 permissions
# Domínio Alvo: pasquad.ukbelol.space
# E-mail para Certificado SSL (Certbot): rogermei577@gmail.com
# Credenciais Super Admin: roger577@ukbelol.space
# Autor: Rogério Gomes Dos Santos
# ==============================================================================

set -e

# Configurações de ambiente para prevenir erros de GUI/Qt/XCB e headless build
export QT_QPA_PLATFORM=offscreen
export DISPLAY=:99
export XDG_RUNTIME_DIR=/tmp/runtime-root
mkdir -p /tmp/runtime-root
chmod 700 /tmp/runtime-root

# Cores para mensagens de status no terminal
RED='\\x1b[0;31m'
GREEN='\\x1b[0;32m'
CYAN='\\x1b[0;36m'
YELLOW='\\x1b[1;33m'
BOLD='\\x1b[1m'
NC='\\x1b[0m' # No Color

echo -e "\${CYAN}"
echo "================================================================="
echo "   INSTALADOR GERAL AUTOMÁTICO PASQUAD - DEBIAN 12 LINUX         "
echo "   Web Server: Apache2 + PM2 Process Manager                     "
echo "   Abertura de Portas (80, 443) e Correção de Permissões/503     "
echo "   Domínio: pasquad.ukbelol.space                               "
echo "   Certificado SSL: Let's Encrypt (rogermei577@gmail.com)       "
echo "================================================================="
echo -e "\${NC}"

# 1. Verificar privilégios de Superusuário (Root)
if [ "$EUID" -ne 0 ]; then
  echo -e "\${RED}Erro: Por favor, execute este script como root ou com sudo! Exemplo:\${NC}"
  echo -e "\${YELLOW}curl -sSL https://pasquad.ukbelol.space/install-gerall.sh | sudo bash\${NC}"
  exit 1
fi

# 2. Atualizar repositórios e pacotes do Debian 12 (Incluindo suporte Headless/Qt/XCB)
echo -e "\${YELLOW}[1/10] Atualizando repositórios do Debian 12 e instalando dependências do sistema...\${NC}"
apt update && apt upgrade -y
apt install -y curl wget git build-essential ufw software-properties-common ca-certificates gnupg lsb-release unzip \\
  xvfb libgl1-mesa-glx libgl1-mesa-dri libglib2.0-0 libxcb-xinerama0 libxcb-cursor0 libx11-xcb1 libxcb-icccm4 \\
  libxcb-image0 libxcb-keysyms1 libxcb-randr0 libxcb-render-util0 libxcb-shape0 libxcb-xfixes0 libfontconfig1 \\
  libdbus-1-3 libxi6 libxrender1 libsm6 libice6 libxtst6 libxkbcommon-x11-0 libxkbcommon0 || true

# 3. Instalar Node.js 20.x LTS e NPM com repositório oficial Nodesource
echo -e "\${YELLOW}[2/10] Instalando Node.js 20 LTS e ferramentas C/C++...\${NC}"
if ! command -v node &> /dev/null || [[ $(node -v) != v20* ]]; then
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
  NODE_MAJOR=20
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
  apt update
  apt install -y nodejs
fi

echo -e "\${GREEN}✓ Node.js $(node -v) e NPM v$(npm -v) verificados e prontos!\${NC}"

# 4. Instalar PM2 Globalmente para Gestão de Processos Node.js
echo -e "\${YELLOW}[3/10] Instalando PM2 (Process Manager) e ferramentas de compilação globalmente...\${NC}"
npm install -g pm2 esbuild tsx vite typescript

# 5. Instalar Web Server Apache2 e Certbot SSL para Apache
echo -e "\${YELLOW}[4/10] Instalando Apache2 Web Server e Certbot SSL para Apache...\${NC}"
apt install -y apache2 certbot python3-certbot-apache

# Habilitar escuta explícita nas portas 80 e 443 no Apache2
if [ -f "/etc/apache2/ports.conf" ]; then
  grep -q "Listen 80" /etc/apache2/ports.conf || echo "Listen 80" >> /etc/apache2/ports.conf
  grep -q "Listen 443" /etc/apache2/ports.conf || echo "Listen 443" >> /etc/apache2/ports.conf
fi

# Ativar módulos necessários do Apache2 (Proxy, Proxy HTTP, WebSocket, SSL, Rewrite, Headers)
echo -e "\${YELLOW}Habilitando módulos de Proxy, SSL e Headers no Apache2...\${NC}"
a2enmod proxy proxy_http proxy_wstunnel rewrite ssl headers

# 6. Criar Diretórios e Copiar/Extrair Arquivos do Projeto com Permissões Adequadas
APP_DIR="/var/www/pasquad-app"
CURRENT_DIR="$(pwd)"
echo -e "\${YELLOW}[5/10] Criando e configurando diretório do projeto em $APP_DIR...\${NC}"

# Garantir permissão de travessia na pasta pai /var/www
chmod 755 /var/www
mkdir -p "$APP_DIR"

# Copiar ou extrair arquivos a partir do diretório local
if [ -f "$CURRENT_DIR/package.json" ]; then
  echo -e "\${CYAN}Copiando arquivos e pastas do projeto a partir de $CURRENT_DIR...\${NC}"
  cp -rf "$CURRENT_DIR"/* "$APP_DIR"/ 2>/dev/null || true
  if ls "$CURRENT_DIR"/.* 1> /dev/null 2>&1; then
    cp -rf "$CURRENT_DIR"/.* "$APP_DIR"/ 2>/dev/null || true
  fi
elif [ -f "$CURRENT_DIR/pasquad.zip" ]; then
  echo -e "\${CYAN}Extraindo pasquad.zip do diretório local para $APP_DIR...\${NC}"
  unzip -o "$CURRENT_DIR/pasquad.zip" -d "$APP_DIR"
else
  echo -e "\${CYAN}Baixando pacote pasquad.zip diretamente de https://pasquad.ukbelol.space/pasquad.zip...\${NC}"
  curl -sSL -o /tmp/pasquad.zip https://pasquad.ukbelol.space/pasquad.zip || true
  if [ -f "/tmp/pasquad.zip" ]; then
    unzip -o /tmp/pasquad.zip -d "$APP_DIR"
    rm -f /tmp/pasquad.zip
  fi
fi

# Garantir existência das pastas obrigatórias
mkdir -p "$APP_DIR/src"
mkdir -p "$APP_DIR/public"

cd "$APP_DIR"

# 7. Instalar dependências NPM e compilar o projeto
echo -e "\${YELLOW}[6/10] Instalando dependências NPM e executando compilação do projeto...\${NC}"
npm install --production=false
QT_QPA_PLATFORM=offscreen DISPLAY=:99 npm run build

# CORREÇÃO RIGOROSA DE PERMISSÕES DE PASTAS E ARQUIVOS (Evita Erro 503 e Permission Denied)
echo -e "\${YELLOW}Ajustando permissões de acesso em $APP_DIR para o Apache2 (www-data)...\${NC}"
chown -R www-data:www-data "$APP_DIR" 2>/dev/null || true
chmod -R 755 "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 755 {} + 2>/dev/null || true
find "$APP_DIR" -type f -exec chmod 644 {} + 2>/dev/null || true
chmod +x "$APP_DIR/install-gerall.sh" 2>/dev/null || true

# 8. Criar arquivo de Ecossistema e Iniciar Aplicação Node.js via PM2
echo -e "\${YELLOW}[7/10] Configurando ecossistema PM2 e iniciando backend na porta 3000...\${NC}"

cat << 'EOF' > "$APP_DIR/ecosystem.config.cjs"
module.exports = {
  apps: [{
    name: "pasquad",
    script: "./dist/server.cjs",
    env: {
      NODE_ENV: "production",
      PORT: 3000,
      QT_QPA_PLATFORM: "offscreen",
      DISPLAY: ":99"
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G'
  }]
};
EOF

# Garantir permissão no arquivo de configuração do PM2
chown www-data:www-data "$APP_DIR/ecosystem.config.cjs" 2>/dev/null || true
chmod 644 "$APP_DIR/ecosystem.config.cjs"

# Reiniciar serviço no PM2
pm2 delete pasquad 2>/dev/null || true
QT_QPA_PLATFORM=offscreen DISPLAY=:99 pm2 start "$APP_DIR/ecosystem.config.cjs"

# Persistir processo PM2 para reinicialização do servidor
pm2 startup systemd -u root --hp /root || pm2 startup || true
pm2 save

# Aguardar e verificar se o backend subiu com sucesso na porta 3000
echo -e "\${YELLOW}Aguardando resposta do servidor Node.js na porta 3000...\${NC}"
MAX_RETRIES=20
RETRY_COUNT=0
BACKEND_OK=false

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
  if curl -s http://127.0.0.1:3000/api/health | grep -q "ok"; then
    BACKEND_OK=true
    break
  fi
  sleep 2
  RETRY_COUNT=$((RETRY_COUNT+1))
  echo -n "."
done
echo ""

if [ "$BACKEND_OK" = true ]; then
  echo -e "\${GREEN}✓ Servidor Node.js operando com sucesso na porta 3000!\${NC}"
else
  echo -e "\${RED}⚠ O processo PM2 está inicializando. Verifique com 'pm2 status pasquad'.\${NC}"
fi

# 9. Configurar VirtualHost do Apache2 com Proteção contra Erro 503
echo -e "\${YELLOW}[8/10] Criando configuração VirtualHost no Apache2 com Reverse Proxy otimizado...\${NC}"

cat << 'EOF' > /etc/apache2/sites-available/pasquad.ukbelol.space.conf
<VirtualHost *:80>
    ServerName pasquad.ukbelol.space
    ServerAlias www.pasquad.ukbelol.space

    ServerAdmin rogermei577@gmail.com
    DocumentRoot /var/www/pasquad-app

    <Directory /var/www/pasquad-app>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ProxyRequests Off
    ProxyPreserveHost On
    ProxyVia On

    <Proxy *>
        Require all granted
    </Proxy>

    # Suporte a WebSockets
    ProxyPass /ws ws://127.0.0.1:3000/ws disablereuse=On
    ProxyPassReverse /ws ws://127.0.0.1:3000/ws

    # ProxyPass HTTP com disablereuse=On e retry=0 para PREVENÇÃO TOTAL DO ERRO 503
    ProxyPass / http://127.0.0.1:3000/ disablereuse=On retry=0 timeout=120
    ProxyPassReverse / http://127.0.0.1:3000/

    ErrorLog \${APACHE_LOG_DIR}/pasquad_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquad_access.log combined
</VirtualHost>
EOF

# Desativar VirtualHost padrão e ativar o PASQUAD
a2dissite 000-default.conf 2>/dev/null || true
a2ensite pasquad.ukbelol.space.conf

apache2ctl configtest
systemctl restart apache2

# 10. Configurar Firewall UFW (Portas 22, 80, 443 e loopback) e Certificado SSL
echo -e "\${YELLOW}[9/10] Configurando Firewall UFW para abrir Portas 80, 443 e 22...\${NC}"
ufw allow in on lo 2>/dev/null || true
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

echo -e "\${YELLOW}[10/10] Emitindo e Instalando Certificado SSL Válido com Let's Encrypt Certbot...\${NC}"
certbot --apache -d pasquad.ukbelol.space --non-interactive --agree-tos -m rogermei577@gmail.com --redirect || {
  echo -e "\${RED}Atenção: O Certbot não pôde validar o SSL imediatamente. Certifique-se de que o Apontamento DNS A de pasquad.ukbelol.space aponta para o IP público deste servidor.\${NC}"
}

systemctl restart apache2

echo -e "\${GREEN}"
echo "================================================================="
echo "   SISTEMA PASQUAD INSTALADO E COLOCADO NO AR COM SUCESSO!     "
echo "================================================================="
echo "   URL Principal: https://pasquad.ukbelol.space                   "
echo "   Painel Admin:  https://pasquad.ukbelol.space (Menu Admin)     "
echo "   Super Admin:   roger577@ukbelol.space                          "
echo "   Web Server:    Apache2 (Reverse Proxy - Porta 3000)            "
echo "   Gerenciador:   PM2 Process Manager                             "
echo "   Portas Abertas: 80 (HTTP) e 443 (HTTPS SSL)                    "
echo "   Permissões:    755 (www-data:www-data)                         "
echo "   Prevenção 503: disablereuse=On e retry=0 Ativados              "
echo "================================================================="
echo -e "\${NC}"
`;

export const DEBIAN12_INSTALL_SCRIPT = INSTALL_GERALL_SCRIPT;
