export const INSTALL_GERALL_SCRIPT = `#!/bin/bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO GERAL AUTOMATIZADA - PASQUAD VIDEO-BOOK (DEBIAN 12)
# Arquivo: install-gerall.sh
# Web Server: Apache2 com Proxy Pass + PM2 Process Manager
# Solução QT/XCB: QT_QPA_PLATFORM=offscreen + Pacotes Headless X11
# Domínio Alvo: pasquad.ukbelol.space
# E-mail para Certificado SSL (Certbot): rogermei577@gmail.com
# Credenciais Super Admin: roger577@ukbelol.space
# Autor: Rogério Gomes Dos Santos
# ==============================================================================

set -e

# Configurações para prevenir erros de GUI/Qt/XCB em servidores headless Linux
export QT_QPA_PLATFORM=offscreen
export DISPLAY=:99
export XDG_RUNTIME_DIR=/tmp/runtime-root
mkdir -p /tmp/runtime-root
chmod 700 /tmp/runtime-root

# Cores para mensagens de status no terminal
RED='\\x1b[0;31m'
GREEN='\\x1b[0;32m'
CYAN='\\x1b[0;36m'
YELLOW='\\x1b[1;33m'
BOLD='\\x1b[1m'
NC='\\x1b[0m' # No Color

echo -e "\${CYAN}"
echo "================================================================="
echo "   INSTALADOR GERAL AUTOMÁTICO PASQUAD - DEBIAN 12 LINUX         "
echo "   Web Server: Apache2 + PM2 Process Manager                     "
echo "   Suporte Headless Qt/XCB (Prevenção de erro qt.qpa.xcb)       "
echo "   Domínio: pasquad.ukbelol.space                               "
echo "   Certificado SSL: Let's Encrypt (rogermei577@gmail.com)       "
echo "================================================================="
echo -e "\${NC}"

# 1. Verificar privilégios de Superusuário (Root)
if [ "$EUID" -ne 0 ]; then
  echo -e "\${RED}Erro: Por favor, execute este script como root ou com sudo! Exemplo:\${NC}"
  echo -e "\${YELLOW}curl -sSL https://pasquad.ukbelol.space/install-gerall.sh | sudo bash\${NC}"
  exit 1
fi

# 2. Atualizar repositórios e pacotes do Debian 12 (Incluindo bibliotecas XCB/Qt/Mesa Headless)
echo -e "\${YELLOW}[1/10] Atualizando repositórios do Debian 12 e instalando dependências headless/XCB...\${NC}"
apt update && apt upgrade -y
apt install -y curl wget git build-essential ufw software-properties-common ca-certificates gnupg lsb-release unzip \\
  xvfb libgl1-mesa-glx libgl1-mesa-dri libglib2.0-0 libxcb-xinerama0 libxcb-cursor0 libx11-xcb1 libxcb-icccm4 \\
  libxcb-image0 libxcb-keysyms1 libxcb-randr0 libxcb-render-util0 libxcb-shape0 libxcb-xfixes0 libfontconfig1 \\
  libdbus-1-3 libxi6 libxrender1 libsm6 libice6 libxtst6 libxkbcommon-x11-0 libxkbcommon0 || true

# 3. Instalar Node.js 20.x LTS e NPM com repositório oficial Nodesource
echo -e "\${YELLOW}[2/10] Instalando Node.js 20 LTS e ferramentas de compilação C/C++...\${NC}"
if ! command -v node &> /dev/null || [[ $(node -v) != v20* ]]; then
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
  NODE_MAJOR=20
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
  apt update
  apt install -y nodejs
fi

echo -e "\${GREEN}✓ Node.js $(node -v) e NPM v$(npm -v) verificados e prontos!\${NC}"

# 4. Instalar PM2 Globalmente para Gestão de Processos Node.js
echo -e "\${YELLOW}[3/10] Instalando PM2 (Process Manager) e ferramentas de build globalmente...\${NC}"
npm install -g pm2 esbuild tsx vite typescript

# 5. Instalar Web Server Apache2 e Certbot para Apache
echo -e "\${YELLOW}[4/10] Instalando Apache2 Web Server e Certbot SSL para Apache...\${NC}"
apt install -y apache2 certbot python3-certbot-apache

# Ativar módulos necessários do Apache2 (Proxy, Proxy HTTP, WebSocket, SSL, Rewrite)
echo -e "\${YELLOW}Habilitando módulos de Proxy e SSL no Apache2...\${NC}"
a2enmod proxy proxy_http proxy_wstunnel rewrite ssl headers

# 6. Criar Diretório de Destino e Copiar/Extrair Arquivos do Projeto
APP_DIR="/var/www/pasquad-app"
CURRENT_DIR="$(pwd)"
echo -e "\${YELLOW}[5/10] Criando estrutura de pastas e copiando arquivos do projeto em $APP_DIR...\${NC}"

mkdir -p "$APP_DIR"

# Copiar ou extrair arquivos a partir do diretório local
if [ -f "$CURRENT_DIR/package.json" ]; then
  echo -e "\${CYAN}Copiando arquivos e pastas do projeto a partir de $CURRENT_DIR...\${NC}"
  cp -rf "$CURRENT_DIR"/* "$APP_DIR"/ 2>/dev/null || true
  if ls "$CURRENT_DIR"/.* 1> /dev/null 2>&1; then
    cp -rf "$CURRENT_DIR"/.* "$APP_DIR"/ 2>/dev/null || true
  fi
elif [ -f "$CURRENT_DIR/pasquad.zip" ]; then
  echo -e "\${CYAN}Extraindo pasquad.zip do diretório local para $APP_DIR...\${NC}"
  unzip -o "$CURRENT_DIR/pasquad.zip" -d "$APP_DIR"
else
  echo -e "\${CYAN}Baixando pacote pasquad.zip diretamente de https://pasquad.ukbelol.space/pasquad.zip...\${NC}"
  curl -sSL -o /tmp/pasquad.zip https://pasquad.ukbelol.space/pasquad.zip || true
  if [ -f "/tmp/pasquad.zip" ]; then
    unzip -o /tmp/pasquad.zip -d "$APP_DIR"
    rm -f /tmp/pasquad.zip
  fi
fi

# Garantir existência das pastas obrigatórias do projeto
mkdir -p "$APP_DIR/src"
mkdir -p "$APP_DIR/public"

cd "$APP_DIR"

# 7. Instalar todas as dependências NPM do Node.js/Vite/esbuild e compilar o projeto
echo -e "\${YELLOW}[6/10] Instalando dependências NPM e executando compilação (Vite + esbuild)...\${NC}"
npm install --production=false
QT_QPA_PLATFORM=offscreen DISPLAY=:99 npm run build

# REVISÃO RIGOROSA DE PERMISSÕES DE PASTAS E ARQUIVOS (Prevenção Total de Acesso e Erro 502)
echo -e "\${YELLOW}Ajustando e aplicando permissões de acesso em $APP_DIR...\${NC}"
chown -R www-data:www-data "$APP_DIR" 2>/dev/null || true
chmod -R 755 "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 755 {} + 2>/dev/null || true
find "$APP_DIR" -type f -exec chmod 644 {} + 2>/dev/null || true
chmod +x "$APP_DIR/install-gerall.sh" 2>/dev/null || true

# 8. Iniciar e Gerenciar Aplicação Node.js via PM2
echo -e "\${YELLOW}[7/10] Configurando e iniciando o servidor Node.js com PM2 (Porta 3000)...\${NC}"

# Parar processo anterior no PM2 se existir
pm2 delete pasquad 2>/dev/null || true

# Iniciar servidor compilado no PM2 com QT_QPA_PLATFORM=offscreen
QT_QPA_PLATFORM=offscreen DISPLAY=:99 PORT=3000 NODE_ENV=production pm2 start dist/server.cjs --name "pasquad"

# Configurar PM2 para iniciar automaticamente junto com o sistema operacional
pm2 startup systemd -u root --hp /root || pm2 startup || true
pm2 save

# Aguardar e verificar se o backend subiu na porta 3000 antes de integrar o Apache
echo -e "\${YELLOW}Verificando se o backend no PM2 está respondendo na porta 3000...\${NC}"
MAX_RETRIES=20
RETRY_COUNT=0
BACKEND_OK=false

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
  if curl -s http://127.0.0.1:3000/api/health | grep -q "ok"; then
    BACKEND_OK=true
    break
  fi
  sleep 2
  RETRY_COUNT=$((RETRY_COUNT+1))
  echo -n "."
done
echo ""

if [ "$BACKEND_OK" = true ]; then
  echo -e "\${GREEN}✓ Backend PM2 operando com sucesso na porta 3000 (Sem erro 502 ou Qt XCB)!\${NC}"
else
  echo -e "\${RED}⚠ Atenção: O PM2 ainda está inicializando a aplicação.\${NC}"
fi

# 9. Configurar VirtualHost do Apache2 como Reverse Proxy Otimizado
echo -e "\${YELLOW}[8/10] Configurando VirtualHost do Apache2 para pasquad.ukbelol.space...\${NC}"

cat << 'EOF' > /etc/apache2/sites-available/pasquad.ukbelol.space.conf
<VirtualHost *:80>
    ServerName pasquad.ukbelol.space
    ServerAlias www.pasquad.ukbelol.space

    ServerAdmin rogermei577@gmail.com
    DocumentRoot /var/www/pasquad-app

    ProxyRequests Off
    ProxyPreserveHost On
    ProxyVia Full

    <Proxy *>
        Require all granted
    </Proxy>

    # Suporte a WebSockets e Requisições HTTP
    ProxyPass /ws ws://127.0.0.1:3000/ws
    ProxyPassReverse /ws ws://127.0.0.1:3000/ws

    ProxyPass / http://127.0.0.1:3000/ retry=0 timeout=60
    ProxyPassReverse / http://127.0.0.1:3000/

    ErrorLog \${APACHE_LOG_DIR}/pasquad_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquad_access.log combined
</VirtualHost>
EOF

# Desativar site padrão do Apache2 e ativar pasquad
a2dissite 000-default.conf 2>/dev/null || true
a2ensite pasquad.ukbelol.space.conf

apache2ctl configtest
systemctl restart apache2

# 10. Liberar Firewall e Emitir Certificado SSL com Certbot Apache
echo -e "\${YELLOW}[9/10] Liberando portas no Firewall UFW (22, 80, 443)...\${NC}"
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

echo -e "\${YELLOW}[10/10] Emitindo Certificado SSL Válido com Let's Encrypt Certbot para Apache...\${NC}"
certbot --apache -d pasquad.ukbelol.space --non-interactive --agree-tos -m rogermei577@gmail.com --redirect || {
  echo -e "\${RED}Atenção: O Certbot não pôde validar o domínio imediatamente. Verifique se o Apontamento DNS A de pasquad.ukbelol.space aponta para o IP público deste servidor.\${NC}"
}

systemctl restart apache2

echo -e "\${GREEN}"
echo "================================================================="
echo "   SISTEMA PASQUAD INSTALADO E COLOCADO NO AR COM SUCESSO!     "
echo "================================================================="
echo "   URL Principal: https://pasquad.ukbelol.space                   "
echo "   Painel Admin:  https://pasquad.ukbelol.space (Menu Admin)     "
echo "   Super Admin:   roger577@ukbelol.space                          "
echo "   Web Server:    Apache2 (Reverse Proxy - Porta 3000)            "
echo "   Gerenciador:   PM2 Process Manager                             "
echo "   Modo Headless: QT_QPA_PLATFORM=offscreen ativado               "
echo "   Certificado:   SSL Válido (Let's Encrypt - rogermei577@gmail.com)"
echo "   Permissões:    755 (www-data:www-data) Sem Erro 502/XCB        "
echo "================================================================="
echo -e "\${NC}"
`;

export const DEBIAN12_INSTALL_SCRIPT = INSTALL_GERALL_SCRIPT;
