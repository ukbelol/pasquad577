import React, { createContext, useContext, useState, useEffect } from 'react';
import { SupportedLanguage } from '../i18n/types';
import { UI_TRANSLATIONS } from '../i18n/uiTranslations';
import { THESIS_TRANSLATIONS } from '../i18n/textTranslations';
import { PASQUAD_SECTIONS } from '../data/pasquadText';
import { Section } from '../types';

interface LanguageContextType {
  uiLang: SupportedLanguage;
  audioLang: SupportedLanguage;
  textLang: SupportedLanguage;
  setUiLang: (lang: SupportedLanguage) => void;
  setAudioLang: (lang: SupportedLanguage) => void;
  setTextLang: (lang: SupportedLanguage) => void;
  setAllLanguages: (lang: SupportedLanguage) => void;
  t: (key: string) => string;
  getSection: (sectionId: string) => Section;
  getAudioDescriptionText: (sectionId: string, paragraphIndex: number) => string;
  isModalOpen: boolean;
  setIsModalOpen: (open: boolean) => void;
  openLanguageModal: () => void;
  closeLanguageModal: () => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'pasquad_language_settings';

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [uiLang, setUiLangState] = useState<SupportedLanguage>('pt');
  const [audioLang, setAudioLangState] = useState<SupportedLanguage>('pt');
  const [textLang, setTextLangState] = useState<SupportedLanguage>('pt');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  // Load saved preferences on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.uiLang) setUiLangState(parsed.uiLang);
        if (parsed.audioLang) setAudioLangState(parsed.audioLang);
        if (parsed.textLang) setTextLangState(parsed.textLang);
      }
    } catch (e) {
      console.warn('Error reading language preferences:', e);
    }
  }, []);

  // Save changes to localStorage
  const savePreferences = (ui: SupportedLanguage, audio: SupportedLanguage, text: SupportedLanguage) => {
    try {
      localStorage.setItem(
        LOCAL_STORAGE_KEY,
        JSON.stringify({ uiLang: ui, audioLang: audio, textLang: text })
      );
    } catch (e) {
      console.warn('Error saving language preferences:', e);
    }
  };

  const setUiLang = (lang: SupportedLanguage) => {
    setUiLangState(lang);
    savePreferences(lang, audioLang, textLang);
  };

  const setAudioLang = (lang: SupportedLanguage) => {
    setAudioLangState(lang);
    savePreferences(uiLang, lang, textLang);
  };

  const setTextLang = (lang: SupportedLanguage) => {
    setTextLangState(lang);
    savePreferences(uiLang, audioLang, lang);
  };

  const setAllLanguages = (lang: SupportedLanguage) => {
    setUiLangState(lang);
    setAudioLangState(lang);
    setTextLangState(lang);
    savePreferences(lang, lang, lang);
  };

  const t = (key: string): string => {
    const langDict = UI_TRANSLATIONS[uiLang] || UI_TRANSLATIONS['pt'];
    if (langDict && langDict[key]) {
      return langDict[key];
    }
    // Fallback to Portuguese or English
    const ptDict = UI_TRANSLATIONS['pt'];
    if (ptDict && ptDict[key]) return ptDict[key];
    return key;
  };

  const getSection = (sectionId: string): Section => {
    const sectionsForLang = THESIS_TRANSLATIONS[textLang] || THESIS_TRANSLATIONS['pt'];
    const found = sectionsForLang.find((s) => s.id === sectionId);
    if (found) return found;

    // Fallback to Portuguese
    const ptFound = PASQUAD_SECTIONS.find((s) => s.id === sectionId);
    return ptFound || PASQUAD_SECTIONS[0];
  };

  const getAudioDescriptionText = (sectionId: string, paragraphIndex: number): string => {
    const sectionsForAudio = THESIS_TRANSLATIONS[audioLang] || THESIS_TRANSLATIONS['pt'];
    const found = sectionsForAudio.find((s) => s.id === sectionId) || PASQUAD_SECTIONS.find((s) => s.id === sectionId);

    if (found && found.paragraphs[paragraphIndex]) {
      return found.paragraphs[paragraphIndex];
    }
    const ptFound = PASQUAD_SECTIONS.find((s) => s.id === sectionId);
    return ptFound?.paragraphs[paragraphIndex] || ptFound?.paragraphs[0] || '';
  };

  const openLanguageModal = () => setIsModalOpen(true);
  const closeLanguageModal = () => setIsModalOpen(false);

  return (
    <LanguageContext.Provider
      value={{
        uiLang,
        audioLang,
        textLang,
        setUiLang,
        setAudioLang,
        setTextLang,
        setAllLanguages,
        t,
        getSection,
        getAudioDescriptionText,
        isModalOpen,
        setIsModalOpen,
        openLanguageModal,
        closeLanguageModal,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
