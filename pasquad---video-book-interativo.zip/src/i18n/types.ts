export type SupportedLanguage =
  | 'pt'
  | 'en'
  | 'es'
  | 'fr'
  | 'de'
  | 'it'
  | 'ja'
  | 'zh'
  | 'ru'
  | 'ar';

export interface LanguageInfo {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
  bcp47: string;
}

export interface LanguageSettings {
  uiLang: SupportedLanguage;
  audioLang: SupportedLanguage;
  textLang: SupportedLanguage;
}
