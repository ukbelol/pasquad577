import { Section } from '../types';
import { SupportedLanguage } from './types';
import { PASQUAD_SECTIONS } from '../data/pasquadText';

export const THESIS_TRANSLATIONS: Record<SupportedLanguage, Section[]> = {
  pt: PASQUAD_SECTIONS,

  en: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'Presentation',
        title: 'PASQUAD — Conceptual Monograph',
        subtitle: 'First Systemic Quantum Data Analysis',
        paragraphs: [
          'Welcome to the PASQUAD Video-Book thesis: First Systemic Quantum Data Analysis.',
          'This conceptual monograph presents a proposal for an interdisciplinary model aimed at studying human interpretation of meaningful events, symbolic coincidences, and emerging patterns in everyday life.',
          'Work developed by Rogério Gomes Dos Santos, Bachelor of Information Systems from Unifieo University (Osasco – SP, Brazil, 2010).'
        ]
      };
    }
    if (sec.id === 'resumo') {
      return {
        ...sec,
        chapter: 'Executive Summary',
        title: 'Executive Summary',
        subtitle: 'Overview & Keywords',
        paragraphs: [
          'This conceptual monograph presents the development of the PASQUAD model – First Systemic Quantum Data Analysis, an interdisciplinary proposal for studying human interpretation of meaningful coincidences and symbolic patterns.',
          'The model takes Carl Gustav Jung’s concept of synchronicity as a starting point, connecting it with contemporary studies in cognition, perception, information theory, complex systems, and artificial intelligence.',
          'PASQUAD proposes that perceived reality can be analyzed as a continuous flow of information, in which material and immaterial events are interpreted through the integration of multiple sensory systems.',
          'The proposal introduces the concept of six integrated senses, with the sixth sense defined as an integrative cognitive capacity based on memory, experience, pattern recognition, and rapid contextual inference.',
          'The term "quantum" in the model represents an epistemological metaphor regarding multiple interpretative possibilities before defining a final meaning.',
          'The research proposes a methodological architecture to analyze how trained individuals can interpret environmental information using coherence criteria and critical validation.'
        ]
      };
    }
    if (sec.id === 'abstract') {
      return {
        ...sec,
        chapter: 'Abstract',
        title: 'Conceptual Abstract',
        subtitle: 'English Conceptual Summary',
        paragraphs: [
          'This conceptual thesis presents PASQUAD – First Systemic Quantum Data Analysis, an interdisciplinary model proposed for investigating human interpretation of meaningful coincidences, symbolic patterns, and information processing.',
          'Inspired by Carl Gustav Jung’s concept of synchronicity and connected with contemporary studies in cognition, information theory, and complex systems, PASQUAD proposes a framework for understanding how humans construct meaning through integrated perception.',
          'The model introduces six integrated senses, considering the sixth sense as a cognitive synthesis mechanism based on experience, memory, and pattern recognition.',
          'The research proposes a conceptual methodology for future empirical investigations.'
        ]
      };
    }
    if (sec.id === 'sumario') {
      return {
        ...sec,
        chapter: 'Structure of Work',
        title: 'Proposed Table of Contents',
        subtitle: 'Chapter Organization',
        paragraphs: [
          'The monograph is structured into logically connected Chapters and Subsections:',
          'Chapter 1 – Introduction: 1.1 Research Context; 1.2 Origin of PASQUAD; 1.3 Research Problem; 1.4 Central Hypothesis; 1.5 Objectives; 1.6 Justification.',
          'Chapter 2 – Theoretical Foundation: 2.1 Carl Gustav Jung and Synchronicity; 2.2 Collective Unconscious & Archetypes; 2.3 Human Perception & Reality Construction; 2.4 Information Theory; 2.5 Adaptive Complex Systems; 2.6 Artificial Intelligence & Pattern Recognition; 2.7 Observer and Interpretation Relationship.'
        ]
      };
    }
    if (sec.id === 'cap1-intro') {
      return {
        ...sec,
        chapter: 'Chapter 1',
        title: 'Introduction',
        subtitle: 'The Human Search for Patterns and Meaning',
        paragraphs: [
          'Humanity has always sought to understand its connection with the cosmos, nature, and the events shaping existence. From early societies, environmental patterns were interpreted as symbolic communication between the individual and the surrounding world.',
          'Scientific development expanded this observation capacity, allowing natural phenomena to be understood through experimental methods.',
          'However, a fundamental question remains: How do human beings attribute deep meaning to events seemingly linked by meaningful coincidences?',
          'This question finds an essential reference point in Carl Gustav Jung’s concept of synchronicity, where events share a connection based not on traditional causality, but on psychological meaning attributed by the observer.',
          'PASQUAD emerges as an initiative to structure this phenomenon within an interdisciplinary framework using Information Systems, Psychology, and Cognitive Science.'
        ]
      };
    }
    if (sec.id === 'cap1-1') {
      return {
        ...sec,
        chapter: 'Chapter 1',
        title: 'Origin of the PASQUAD Proposal',
        subtitle: 'An Information Systems Perspective on Human Experience',
        paragraphs: [
          'Background training in Information Systems provides a perspective grounded in: data collection; processing; organization; analysis; interpretation; and decision-making.',
          'From this vantage point, the hypothesis arises that human experiences can also be studied as complex information processes.',
          'An individual continuously receives streams of information: visual, auditory, environmental, emotional, cultural, and cognitive.',
          'Interpreting these data flows creates internal models of reality. PASQUAD proposes investigating this process systemically.'
        ]
      };
    }
    if (sec.id === 'cap1-2') {
      return {
        ...sec,
        chapter: 'Chapter 1',
        title: 'Research Problem',
        subtitle: 'The Core Question of PASQUAD',
        paragraphs: [
          'The research formulates its fundamental bounding question:',
          'How can a conceptual model be developed to organize the interpretation of events perceived as synchronic using sensory integration, interdisciplinary knowledge, and systemic analysis?'
        ]
      };
    }
    if (sec.id === 'cap1-3') {
      return {
        ...sec,
        chapter: 'Chapter 1',
        title: 'Central Hypothesis',
        subtitle: 'Structured Protocol & Logical Validation',
        paragraphs: [
          'The primary hypothesis of this research states:',
          '"If information perceived by an individual is organized through a structured protocol involving perception, context, knowledge, and logical validation, it will be possible to produce more consistent interpretations of meaningful patterns in human experience."'
        ]
      };
    }
    if (sec.id === 'cap1-4-5') {
      return {
        ...sec,
        chapter: 'Chapter 1',
        title: 'General & Specific Objectives',
        subtitle: 'Goals of the PASQUAD Model',
        paragraphs: [
          'General Objective: Develop a conceptual model named PASQUAD capable of representing human processes of interpreting complex information arising from interaction between individual and environment.',
          'Specific Objectives:',
          '1. Build an analytical architecture based on multisensory information.',
          '2. Establish criteria for pattern interpretation.',
          '3. Connect human perception with information theory.',
          '4. Propose future experimental validation methodologies.',
          '5. Explore applications in cognitive science and artificial intelligence.'
        ]
      };
    }
    if (sec.id === 'cap1-6') {
      return {
        ...sec,
        chapter: 'Chapter 1',
        title: 'Justification',
        subtitle: 'Transforming Data into Meaning in the Information Age',
        paragraphs: [
          'Contemporary society experiences an exponential increase in available data. Despite technological advancements, the challenge of understanding how humans convert raw data into genuine meaning remains.',
          'PASQUAD contributes to this discussion by building a conceptual bridge between information technology, psychology, philosophy, cognition, and systems analysis.'
        ]
      };
    }
    if (sec.id === 'cap2-1') {
      return {
        ...sec,
        chapter: 'Chapter 2',
        title: 'Synchronicity in Carl Gustav Jung',
        subtitle: 'Meaningful Acausal Connections',
        paragraphs: [
          'The concept of synchronicity represents a core pillar of this research.',
          'Jung described experiences where internal states (thoughts, dreams, intuitions) and external physical events coincide meaningfully without a causal relationship.',
          'PASQUAD uses this concept as a starting point to investigate human interpretation mechanisms.'
        ]
      };
    }
    if (sec.id === 'cap2-2') {
      return {
        ...sec,
        chapter: 'Chapter 2',
        title: 'Information as a Fundamental Element',
        subtitle: 'Comparing Informational Models',
        paragraphs: [
          'The proposal treats information as the organizing foundation of human experience.',
          'In traditional computing, information processing follows: Data → Processing → Information → Knowledge → Decision.',
          'In the PASQUAD model, meaning attribution in consciousness operates as: Perception → Integration → Context → Interpretation → Meaning.'
        ]
      };
    }
    if (sec.id === 'cap2-3') {
      return {
        ...sec,
        chapter: 'Chapter 2',
        title: 'The Six Integrated Senses Model',
        subtitle: 'Integrative Cognition as the Sixth Sense',
        paragraphs: [
          'PASQUAD views perception as a multisensory ecosystem encompassing the 5 classical biological senses: Sight, Hearing, Touch, Smell, and Taste.',
          'It introduces a sixth element: "Integrative Cognition".',
          'The sixth element is not mysticism, but the human cognitive capacity to synthesize separate streams of data based on memory, experience, deep pattern recognition, and rapid context inference.'
        ]
      };
    }
    if (sec.id === 'declaracao') {
      return {
        ...sec,
        chapter: 'Authorship & Closing',
        title: 'Authorship Declaration & Scientific Commitment',
        subtitle: 'Rogério Gomes Dos Santos',
        paragraphs: [
          'I, Rogério Gomes Dos Santos, declare that this work presents an original conceptual proposal named PASQUAD – First Systemic Quantum Data Analysis, developed as an interdisciplinary study on perception, information, and meaning construction.',
          'This exploratory proposal aims to stimulate future research while upholding scientific rigor, critical analysis, and methodological validation.',
          'Rogério Gomes Dos Santos | Osasco – São Paulo – Brazil | Bachelor of Information Systems (Unifieo 2010) | Social: @rogeriogs577 | Contact: rogeriogomes11@gmail.com'
        ]
      };
    }
    return sec;
  }),

  es: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'Presentación',
        title: 'PASQUAD — Monografía Conceptual',
        subtitle: 'Primer Análisis Sistémico Cuántico de Datos',
        paragraphs: [
          'Bienvenido al Video-Libro de la tesis PASQUAD: Primer Análisis Sistémico Cuántico de Datos.',
          'Esta monografía conceptual presenta un modelo interdisciplinario destinado al estudio de la interpretación humana de eventos significativos, coincidencias simbólicas y patrones emergentes.',
          'Trabajo realizado por Rogério Gomes Dos Santos, Licenciado en Sistemas de Información por la Universidad Unifieo (Osasco – SP, Brasil, 2010).'
        ]
      };
    }
    if (sec.id === 'resumo') {
      return {
        ...sec,
        chapter: 'Resumen Ejecutivo',
        title: 'Resumen Ejecutivo',
        subtitle: 'Visión General y Palabras Clave',
        paragraphs: [
          'Esta monografía conceptual presenta el desarrollo del modelo PASQUAD – Primer Análisis Sistémico Cuántico de Datos, una propuesta interdisciplinaria para estudiar la interpretación humana de patrones significativos.',
          'El modelo toma como punto de partida la sincronicidad de Carl Gustav Jung, conectándola con estudios sobre cognición, percepción, teoría de la información y sistemas complejos.',
          'PASQUAD propone que la realidad percibida puede analizarse como un flujo continuo de información en el que eventos materiales e inmateriales se interpretan mediante la integración de múltiples sistemas sensoriales.',
          'La propuesta introduce el concepto de los seis sentidos integrados, definiendo el sexto sentido como una capacidad cognitiva integradora basada en memoria, experiencia y reconocimiento de patrones.',
          'El término "cuántico" representa una metáfora epistemológica referente a múltiples posibilidades interpretativas antes de definir un significado final.',
          'Se propone una arquitectura metodológica para analizar cómo individuos entrenados pueden interpretar información ambiental con criterios de coherencia.'
        ]
      };
    }
    if (sec.id === 'cap2-3') {
      return {
        ...sec,
        chapter: 'Capítulo 2',
        title: 'El Modelo de los Seis Sentidos Integrados',
        subtitle: 'La Cognición Integradora como Sexto Sentido',
        paragraphs: [
          'PASQUAD considera la percepción como un ecosistema multisensorial que abarca los 5 sentidos biológicos: Vista, Oído, Tacto, Olfato y Gusto.',
          'Introduce un sexto elemento: la "Cognición Integradora".',
          'Este sexto elemento no es misticismo, sino la capacidad cognitiva humana de sintetizar datos dispersos basándose en memoria, experiencia, reconocimiento profundo de patrones e inferencia contextual.'
        ]
      };
    }
    return {
      ...sec,
      title: sec.title.replace('Capítulo', 'Capítulo').replace('Introdução', 'Introducción'),
    };
  }),

  fr: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'Présentation',
        title: 'PASQUAD — Monographie Conceptuelle',
        subtitle: 'Première Analyse Systémique Quantique de Données',
        paragraphs: [
          'Bienvenue dans le Vidéo-Livre de la thèse PASQUAD : Première Analyse Systémique Quantique de Données.',
          'Cette monographie conceptuelle présente un modèle interdisciplinaire pour l’étude de l’interprétation humaine des coïncidences symboliques et des motifs émergents.',
          'Travail élaboré par Rogério Gomes Dos Santos, diplômé en Systèmes d’Information de l’Université Unifieo (Osasco – SP, Brésil, 2010).'
        ]
      };
    }
    if (sec.id === 'cap2-3') {
      return {
        ...sec,
        chapter: 'Chapitre 2',
        title: 'Le Modèle des Six Sens Intégrés',
        subtitle: 'La Cognition Intégrative comme Sixième Sens',
        paragraphs: [
          'PASQUAD considère la perception comme un écosystème multisensoriel comprenant la Vue, l’Ouïe, le Toucher, l’Odorat et le Goût.',
          'Il introduit un sixième élément : la "Cognition Intégrative".',
          'Ce sixième élément représente la capacité cognitive de synthétiser des flux d’informations complexes basée sur la mémoire, l’expérience et la reconnaissance de motifs.'
        ]
      };
    }
    return sec;
  }),

  de: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'Präsentation',
        title: 'PASQUAD — Konzeptionelle Monographie',
        subtitle: 'Erste Systemische Quanten-Datenanalyse',
        paragraphs: [
          'Willkommen beim Video-Buch der PASQUAD-Thesis: Erste Systemische Quanten-Datenanalyse.',
          'Diese konzeptionelle Monographie präsentiert ein interdisziplinäres Modell zur Untersuchung menschlicher Interpretation von bedeutungsvollen Ereignissen und symbolischen Mustern.',
          'Arbeit von Rogério Gomes Dos Santos, Bachelor der Wirtschaftsinformatik an der Unifieo Universität (Osasco – SP, Brasilien, 2010).'
        ]
      };
    }
    if (sec.id === 'cap2-3') {
      return {
        ...sec,
        chapter: 'Kapitel 2',
        title: 'Das Modell der Sechs Integrierten Sinne',
        subtitle: 'Integrative Kognition als Sechster Sinn',
        paragraphs: [
          'PASQUAD betrachtet Wahrnehmung als multisensorisches Ökosystem mit den 5 klassischen Sinnen: Sehen, Hören, Fühlen, Riechen und Schmecken.',
          'Es führt ein sechstes Element ein: die "Integrative Kognition".',
          'Dieses sechste Element ist die kognitive Fähigkeit zur Synthese von Informationsströmen basierend auf Erfahrung, Gedächtnis und Mustererkennung.'
        ]
      };
    }
    return sec;
  }),

  it: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'Presentazione',
        title: 'PASQUAD — Monografia Concettuale',
        subtitle: 'Prima Analisi Sistemica Quantistica dei Dati',
        paragraphs: [
          'Benvenuti nel Video-Libro della tesi PASQUAD: Prima Analisi Sistemica Quantistica dei Dati.',
          'Questa monografia concettuale presenta una proposta di modello interdisciplinare per lo studio dell’interpretazione umana di coincidenze significative e modelli emergenti.',
          'Lavoro ideato da Rogério Gomes Dos Santos, Laureato in Sistemi Informativi (Unifieo 2010).'
        ]
      };
    }
    return sec;
  }),

  ja: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'イントロダクション',
        title: 'PASQUAD — 概念論文ビデオブック',
        subtitle: '第1回量子データシステム分析',
        paragraphs: [
          'PASQUAD論文ビデオブック「第1回量子データシステム分析」へようこそ。',
          '本論文は、意味のある偶然の一致（シンクロニシティ）やシンボル的パターンの人間的解釈を研究するための学際的モデルを提案します。',
          '著者：ロジェリオ・ゴメス・ドス・サントス（ブラジル・ウニフィエオ大学情報システム学士、2010年）。'
        ]
      };
    }
    if (sec.id === 'cap2-3') {
      return {
        ...sec,
        chapter: '第2章',
        title: '6つの統合感覚モデル',
        subtitle: '第6感としての統合的認知',
        paragraphs: [
          'PASQUADは知覚を五感（視覚、聴覚、触覚、嗅覚、味覚）を包括する多感覚エコシステムとして捉えます。',
          'さらに第6の要素として「統合的認知（Integrative Cognition）」を導入します。',
          'これは神秘主義ではなく、記憶、経験、深層パターン認識に基づく高度な認知合成能力を指します。'
        ]
      };
    }
    return sec;
  }),

  zh: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: '作品导读',
        title: 'PASQUAD — 概念论文',
        subtitle: '首次系统化量子数据分析',
        paragraphs: [
          '欢迎体验 PASQUAD 论文视频有声书：首次系统化量子数据分析。',
          '本概念论文提出了一个跨学科模型，旨在探索人类对日常生活中意味深长巧合与模式的解释机制。',
          '由罗热里奥·戈梅斯·多斯·桑托斯撰写（巴西 Unifieo 大学信息系统学士，2010）。'
        ]
      };
    }
    if (sec.id === 'cap2-3') {
      return {
        ...sec,
        chapter: '第二章',
        title: '六维融合感知模型',
        subtitle: '作为第六感的整合认知',
        paragraphs: [
          'PASQUAD 将人类感知视为包含视觉、听觉、触觉、嗅觉和味觉五大生物感觉的综合生态系统。',
          '引入第六个核心元素：“整合认知（Integrative Cognition）”。',
          '第六感并非玄学，而是基于记忆、经验、模式识别及快速语境推理的综合认知能力。'
        ]
      };
    }
    return sec;
  }),

  ru: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'Презентация',
        title: 'PASQUAD — Концептуальная Монография',
        subtitle: 'Первичный Системный Квантовый Анализ Данных',
        paragraphs: [
          'Добро пожаловать в Видео-Книгу монографии PASQUAD: Первичный Системный Квантовый Анализ Данных.',
          'Эта монография предлагает междисциплинарную модель для изучения интерпретации человеком значимых совпадений и символических паттернов.',
          'Автор: Рожерио Гомес Дос Сантос, бакалавр информационных систем университета Unifieo (2010).'
        ]
      };
    }
    return sec;
  }),

  ar: PASQUAD_SECTIONS.map((sec) => {
    if (sec.id === 'capa') {
      return {
        ...sec,
        chapter: 'المقدمة',
        title: 'PASQUAD — أطروحة مفاهيمية',
        subtitle: 'أول تحليل سيستمي كمومي للبيانات',
        paragraphs: [
          'مرحبًا بكم في كتاب الفيديو لأطروحة PASQUAD: أول تحليل سيستمي كمومي للبيانات.',
          'تقدم هذه الأطروحة نموذجا متعدد التخصصات لدراسة تفسير الإنسان للتصادفات المعنوية والأنماط الناشئة.',
          'إعداد: روجيريو غوميز دوس سانتوس، بكالوريوس نظم المعلومات من جامعة Unifieo (2010).'
        ]
      };
    }
    return sec;
  })
};
