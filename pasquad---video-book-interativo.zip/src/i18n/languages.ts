import { LanguageInfo, SupportedLanguage } from './types';

export const SUPPORTED_LANGUAGES: Record<SupportedLanguage, LanguageInfo> = {
  pt: {
    code: 'pt',
    name: 'Português',
    nativeName: 'Português (Brasil)',
    flag: '🇧🇷',
    bcp47: 'pt-BR',
  },
  en: {
    code: 'en',
    name: 'Inglês',
    nativeName: 'English (US)',
    flag: '🇺🇸',
    bcp47: 'en-US',
  },
  es: {
    code: 'es',
    name: 'Espanhol',
    nativeName: 'Español',
    flag: '🇪🇸',
    bcp47: 'es-ES',
  },
  fr: {
    code: 'fr',
    name: 'Francês',
    nativeName: 'Français',
    flag: '🇫🇷',
    bcp47: 'fr-FR',
  },
  de: {
    code: 'de',
    name: 'Alemão',
    nativeName: 'Deutsch',
    flag: '🇩🇪',
    bcp47: 'de-DE',
  },
  it: {
    code: 'it',
    name: 'Italiano',
    nativeName: 'Italiano',
    flag: '🇮🇹',
    bcp47: 'it-IT',
  },
  ja: {
    code: 'ja',
    name: 'Japonês',
    nativeName: '日本語',
    flag: '🇯🇵',
    bcp47: 'ja-JP',
  },
  zh: {
    code: 'zh',
    name: 'Chinês',
    nativeName: '中文 (简体)',
    flag: '🇨🇳',
    bcp47: 'zh-CN',
  },
  ru: {
    code: 'ru',
    name: 'Russo',
    nativeName: 'Русский',
    flag: '🇷🇺',
    bcp47: 'ru-RU',
  },
  ar: {
    code: 'ar',
    name: 'Árabe',
    nativeName: 'العربية',
    flag: '🇸🇦',
    bcp47: 'ar-SA',
  },
};

export const LANGUAGE_LIST = Object.values(SUPPORTED_LANGUAGES);
