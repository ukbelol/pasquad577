export interface Section {
  id: string;
  chapter: string;
  number: string;
  title: string;
  subtitle?: string;
  paragraphs: string[];
  keywords?: string[];
  visualPrompt?: string; // Concept for the background visual slide
}

export interface SlideData {
  sectionId: string;
  chapterTitle: string;
  sectionTitle: string;
  text: string;
  paragraphIndex: number;
  totalParagraphs: number;
  visualPrompt?: string;
}

export interface Bookmark {
  id: string;
  sectionId: string;
  paragraphIndex: number;
  textSnippet: string;
  createdAt: string;
  note?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface QuizItem {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface VisitorComment {
  id: string;
  nome: string;
  sobrenome: string;
  dataNascimento: string;
  email: string;
  telefone: string;
  comentario: string;
  status: 'pending' | 'approved' | 'rejected';
  ip: string;
  createdAt: string;
}

export interface SecurityLog {
  id: string;
  ip: string;
  emailAttempted: string;
  status: 'success' | 'failed' | 'ip_blocked';
  timestamp: string;
  attemptsCount: number;
}

export type ViewMode =
  | 'video'
  | 'reader'
  | 'diagrams'
  | 'ai-tutor'
  | 'author'
  | 'comments'
  | 'admin'
  | 'seo-installer';

export type AmbientSound = 'off' | 'quantum-432' | 'solfeggio-528' | 'alpha-waves' | 'cosmic-synth';

