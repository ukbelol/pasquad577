import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, CheckCircle2, AlertCircle, ShieldAlert, User, Calendar, Phone, Mail, Clock } from 'lucide-react';
import { audioSynth } from '../utils/audioSynth';

interface PublicComment {
  id: string;
  nome: string;
  sobrenome: string;
  comentario: string;
  createdAt: string;
}

export const CommentsSection: React.FC = () => {
  const [comments, setComments] = useState<PublicComment[]>([]);
  const [formData, setFormData] = useState({
    nome: '',
    sobrenome: '',
    dataNascimento: '',
    email: '',
    telefone: '',
    comentario: '',
  });

  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    fetchApprovedComments();
  }, []);

  const fetchApprovedComments = async () => {
    try {
      const res = await fetch('/api/comments/public');
      const data = await res.json();
      if (data.comments) {
        setComments(data.comments);
      }
    } catch (err) {
      console.warn('Erro ao carregar comentários:', err);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    const { nome, sobrenome, dataNascimento, email, telefone, comentario } = formData;
    if (!nome || !sobrenome || !dataNascimento || !email || !telefone || !comentario) {
      setStatusMessage({
        type: 'error',
        text: 'Por favor, preencha todos os campos obrigatórios (Nome, Sobrenome, Data de Nascimento, E-mail, Telefone e Comentário).',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Erro ao enviar comentário.');
      }

      audioSynth.playChime('correct');
      setStatusMessage({
        type: 'success',
        text: data.message || 'Comentário enviado com sucesso! Seus dados foram registrados e o comentário passará pela moderação do Super Admin.',
      });

      setFormData({
        nome: '',
        sobrenome: '',
        dataNascimento: '',
        email: '',
        telefone: '',
        comentario: '',
      });
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Falha ao enviar comentário.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Área de Comentários e Debate Teórico</h2>
            <p className="text-xs text-slate-400">
              Deixe sua reflexão sobre a tese PASQUAD, Sincronicidade e os Seis Sentidos Integrados
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-amber-400 font-medium">
          <ShieldAlert className="w-4 h-4" />
          <span>Moderação Ativa pelo Super Admin</span>
        </div>
      </div>

      {/* Form Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="border-b border-slate-800 pb-4">
          <h3 className="text-lg font-bold text-white flex items-center space-x-2">
            <span>Enviar seu Comentário</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Por medida de segurança e auditoria acadêmica, informe seus dados completos antes de enviar.
          </p>
        </div>

        {statusMessage && (
          <div
            className={`p-4 rounded-xl text-xs flex items-center space-x-2 border ${
              statusMessage.type === 'success'
                ? 'bg-emerald-950 border-emerald-800 text-emerald-300'
                : 'bg-rose-950 border-rose-800 text-rose-300'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-400" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            {/* Nome */}
            <div className="space-y-1">
              <label className="text-xs text-slate-300 font-medium flex items-center space-x-1">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>Nome *</span>
              </label>
              <input
                type="text"
                name="nome"
                required
                placeholder="Ex: Rogério"
                value={formData.nome}
                onChange={handleChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Sobrenome */}
            <div className="space-y-1">
              <label className="text-xs text-slate-300 font-medium flex items-center space-x-1">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sobrenome *</span>
              </label>
              <input
                type="text"
                name="sobrenome"
                required
                placeholder="Ex: Gomes dos Santos"
                value={formData.sobrenome}
                onChange={handleChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Data de Nascimento */}
            <div className="space-y-1">
              <label className="text-xs text-slate-300 font-medium flex items-center space-x-1">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Data de Nascimento *</span>
              </label>
              <input
                type="date"
                name="dataNascimento"
                required
                value={formData.dataNascimento}
                onChange={handleChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* E-mail */}
            <div className="space-y-1">
              <label className="text-xs text-slate-300 font-medium flex items-center space-x-1">
                <Mail className="w-3.5 h-3.5 text-cyan-400" />
                <span>E-mail *</span>
              </label>
              <input
                type="email"
                name="email"
                required
                placeholder="seu.email@dominio.com"
                value={formData.email}
                onChange={handleChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Telefone */}
            <div className="space-y-1 sm:col-span-2">
              <label className="text-xs text-slate-300 font-medium flex items-center space-x-1">
                <Phone className="w-3.5 h-3.5 text-cyan-400" />
                <span>Telefone / WhatsApp *</span>
              </label>
              <input
                type="tel"
                name="telefone"
                required
                placeholder="(11) 99999-9999"
                value={formData.telefone}
                onChange={handleChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Comentario */}
          <div className="space-y-1">
            <label className="text-xs text-slate-300 font-medium flex items-center space-x-1">
              <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
              <span>Seu Comentário ou Pergunta Teórica *</span>
            </label>
            <textarea
              name="comentario"
              required
              rows={4}
              placeholder="Escreva sua opinião, análise ou dúvida sobre a tese PASQUAD..."
              value={formData.comentario}
              onChange={handleChange}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
          >
            <Send className="w-4 h-4 fill-current" />
            <span>{isSubmitting ? 'Enviando...' : 'Enviar Comentário para Aprovação'}</span>
          </button>
        </form>
      </div>

      {/* Approved Comments List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <h3 className="text-base font-bold text-white flex items-center space-x-2">
            <MessageSquare className="w-4 h-4 text-cyan-400" />
            <span>Comentários Aprovados ({comments.length})</span>
          </h3>
        </div>

        {comments.length === 0 ? (
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 text-center text-xs text-slate-400">
            Nenhum comentário aprovado publicamente ainda. Seja o primeiro a comentar!
          </div>
        ) : (
          <div className="space-y-3">
            {comments.map((cm) => (
              <div
                key={cm.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between text-xs border-b border-slate-800/60 pb-2">
                  <div className="font-bold text-cyan-300 flex items-center space-x-1.5">
                    <User className="w-3.5 h-3.5 text-cyan-400" />
                    <span>
                      {cm.nome} {cm.sobrenome}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 flex items-center space-x-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>{cm.createdAt}</span>
                  </div>
                </div>

                <p className="text-slate-200 text-xs sm:text-sm leading-relaxed pt-1">
                  "{cm.comentario}"
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
