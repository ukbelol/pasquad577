import React, { useState } from 'react';
import {
  Network,
  Cpu,
  Brain,
  Eye,
  Ear,
  Hand,
  Activity,
  Zap,
  Sparkles,
  Layers,
  ArrowRight,
  Info,
  CheckCircle2,
} from 'lucide-react';
import { audioSynth } from '../utils/audioSynth';

export const DiagramExplorer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'comparison' | 'senses' | 'pillars'>('comparison');
  const [selectedNode, setSelectedNode] = useState<string | null>('percepcao');

  // Node details for Classical vs PASQUAD
  const nodeDetails: Record<
    string,
    { title: string; type: 'computing' | 'pasquad'; description: string; detail: string }
  > = {
    dados: {
      title: 'Dados Brutos (Sistemas Computacionais)',
      type: 'computing',
      description: 'Sinais binários e brutos sem contexto ou significado intrínseco.',
      detail: 'Sinais de entrada capturados por sensores, teclados ou arquivos brutos.',
    },
    processamento: {
      title: 'Processamento (Sistemas Computacionais)',
      type: 'computing',
      description: 'Algoritmos executados pela CPU ou GPU para transformar dados.',
      detail: 'Operações lógicas, matemáticas e de ordenação aplicadas aos dados.',
    },
    informacao: {
      title: 'Informação Estruturada',
      type: 'computing',
      description: 'Dados organizados em relatórios, tabelas ou estruturas utilizáveis.',
      detail: 'Resultado do processamento que reduz a incerteza do sistema.',
    },
    conhecimento: {
      title: 'Conhecimento',
      type: 'computing',
      description: 'Padrões aprendidos e armazenados em bancos de dados ou modelos.',
      detail: 'Acúmulo de informações correlacionadas ao longo do tempo.',
    },
    decisao: {
      title: 'Tomada de Decisão',
      type: 'computing',
      description: 'Ação executada com base no processamento e conhecimento.',
      detail: 'Output final de controle de um sistema de informação tradicional.',
    },

    // PASQUAD Nodes
    percepcao: {
      title: '1. Percepção (Modelo PASQUAD)',
      type: 'pasquad',
      description: 'Captação contínua de estímulos do ambiente por múltiplos canais.',
      detail: 'O indivíduo recebe estímulos visuais, sonoros, táteis, olfativos, gustativos e intuitivos do ambiente em tempo real.',
    },
    integracao: {
      title: '2. Integração (Modelo PASQUAD)',
      type: 'pasquad',
      description: 'Unificação dos dados multissensoriais pelo ecossistema cognitivo.',
      detail: 'Fundição dos cinco sentidos com o sexto sentido (Cognição Integrativa), correlacionando memórias e experiências acumuladas.',
    },
    contexto: {
      title: '3. Contexto (Modelo PASQUAD)',
      type: 'pasquad',
      description: 'Enquadramento situacional, emocional, cultural e temporal do evento.',
      detail: 'Análise do momento em que a coincidência ocorre, considerando o estado emocional e os eventos simultâneos do indivíduo.',
    },
    interpretacao: {
      title: '4. Interpretação (Modelo PASQUAD)',
      type: 'pasquad',
      description: 'Exploração de múltiplas possibilidades quântico-epistemológicas.',
      detail: 'Analogia quântica: superposição de possíveis significados antes de colapsar na percepção de uma sincronicidade coerente.',
    },
    significado: {
      title: '5. Significado (Modelo PASQUAD)',
      type: 'pasquad',
      description: 'Atribuição de sentido profundo e propósito à experiência vivida.',
      detail: 'O colapso da interpretação em uma transformação interna ou constatação de sincronicidade significativa entre mente e mundo.',
    },
  };

  // 6 Integrated Senses Data
  const sensesList = [
    {
      id: 'visao',
      name: '1. Visão',
      icon: Eye,
      color: 'from-blue-500 to-cyan-500',
      description: 'Percepção de ondas luminosas, formas, cores, movimentos e sincronicidades visuais.',
    },
    {
      id: 'audicao',
      name: '2. Audição',
      icon: Ear,
      color: 'from-cyan-500 to-teal-500',
      description: 'Processamento de frequências sonoras, falas, sons da natureza e coincidências auditivas.',
    },
    {
      id: 'tato',
      name: '3. Tato',
      icon: Hand,
      color: 'from-teal-500 to-emerald-500',
      description: 'Estímulos hápicos, variações de temperatura e sensações corporais que acompanham intuições.',
    },
    {
      id: 'olfato',
      name: '4. Olfato',
      icon: Activity,
      color: 'from-emerald-500 to-amber-500',
      description: 'Percepção de odores que disparam memórias profundas e estados emocionais específicos.',
    },
    {
      id: 'paladar',
      name: '5. Paladar',
      icon: Zap,
      color: 'from-amber-500 to-orange-500',
      description: 'Respostas gustativas vinculadas ao sistema límbico e experiências viscerais.',
    },
    {
      id: 'sexto-sentido',
      name: '6. Cognição Integrativa (O Sexto Sentido)',
      icon: Brain,
      color: 'from-purple-500 via-indigo-500 to-cyan-500',
      isHighlight: true,
      description:
        'A capacidade de síntese cognitiva avançada. Não é misticismo, mas a habilidade da mente humana de unificar memórias, reconhecimento de padrões profundos, inferências rápidas e lógica para extrair sentido de coincidências significativas.',
    },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center space-x-2 bg-purple-950/60 border border-purple-800/50 text-purple-300 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider">
          <Network className="w-3.5 h-3.5 text-purple-400" />
          <span>Arquitetura Interdisciplinar PASQUAD</span>
        </div>
        <h2 className="text-3xl font-extrabold text-white tracking-tight">
          Diagramas e Modelos de Análise
        </h2>
        <p className="text-slate-400 max-w-2xl mx-auto text-sm">
          Explore a comparação entre os fluxos computacionais clássicos e o modelo
          PASQUAD de interpretação quântico-cognitiva da experiência humana.
        </p>
      </div>

      {/* Diagram Mode Tabs */}
      <div className="flex justify-center border-b border-slate-800">
        <div className="flex space-x-4">
          <button
            onClick={() => {
              audioSynth.playChime('slide');
              setActiveTab('comparison');
            }}
            className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === 'comparison'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>Computação vs. PASQUAD</span>
          </button>

          <button
            onClick={() => {
              audioSynth.playChime('slide');
              setActiveTab('senses');
            }}
            className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === 'senses'
                ? 'border-purple-500 text-purple-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Brain className="w-4 h-4" />
            <span>Os Seis Sentidos Integrados</span>
          </button>

          <button
            onClick={() => {
              audioSynth.playChime('slide');
              setActiveTab('pillars');
            }}
            className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === 'pillars'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Pilares Teóricos</span>
          </button>
        </div>
      </div>

      {/* TAB 1: COMPUTATION VS PASQUAD */}
      {activeTab === 'comparison' && (
        <div className="space-y-8 animate-fadeIn">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Traditional Computing Card */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <Cpu className="w-5 h-5 text-blue-400" />
                  <h3 className="font-bold text-slate-200 text-base">
                    Sistemas Computacionais Clássicos
                  </h3>
                </div>
                <span className="text-[10px] font-mono bg-blue-950 text-blue-300 px-2 py-0.5 rounded border border-blue-800/40">
                  Fluxo Linear
                </span>
              </div>

              <div className="space-y-2">
                {[
                  { id: 'dados', label: 'Dados' },
                  { id: 'processamento', label: 'Processamento' },
                  { id: 'informacao', label: 'Informação' },
                  { id: 'conhecimento', label: 'Conhecimento' },
                  { id: 'decisao', label: 'Decisão' },
                ].map((step, i) => (
                  <div key={step.id} className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedNode(step.id)}
                      className={`flex-1 p-3 rounded-xl border text-left text-xs font-mono font-medium transition-all ${
                        selectedNode === step.id
                          ? 'bg-blue-950/90 border-blue-500 text-blue-200 shadow-lg shadow-blue-500/20'
                          : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {i + 1}. {step.label}
                    </button>
                    {i < 4 && (
                      <ArrowRight className="w-4 h-4 text-slate-600 flex-shrink-0" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* PASQUAD Model Card */}
            <div className="bg-slate-900/80 border border-cyan-900/60 rounded-2xl p-6 space-y-4 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none"></div>

              <div className="flex items-center justify-between border-b border-cyan-900/50 pb-3">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  <h3 className="font-bold text-cyan-200 text-base">
                    Modelo PASQUAD (Rogério Gomes)
                  </h3>
                </div>
                <span className="text-[10px] font-mono bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800">
                  Fluxo Quântico-Sistêmico
                </span>
              </div>

              <div className="space-y-2">
                {[
                  { id: 'percepcao', label: 'Percepção Multissensorial' },
                  { id: 'integracao', label: 'Integração Cognitiva (6º Sentido)' },
                  { id: 'contexto', label: 'Análise de Contexto' },
                  { id: 'interpretacao', label: 'Interpretação (Superposição)' },
                  { id: 'significado', label: 'Atribuição de Significado' },
                ].map((step, i) => (
                  <div key={step.id} className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedNode(step.id)}
                      className={`flex-1 p-3 rounded-xl border text-left text-xs font-mono font-medium transition-all ${
                        selectedNode === step.id
                          ? 'bg-cyan-950/90 border-cyan-400 text-cyan-200 shadow-lg shadow-cyan-500/30 scale-[1.02]'
                          : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-cyan-800'
                      }`}
                    >
                      {i + 1}. {step.label}
                    </button>
                    {i < 4 && (
                      <ArrowRight className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Node Inspector Detail Panel */}
          {selectedNode && nodeDetails[selectedNode] && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3 animate-fadeIn">
              <div className="flex items-center space-x-2 text-cyan-400">
                <Info className="w-5 h-5" />
                <h4 className="font-bold text-lg text-white">
                  {nodeDetails[selectedNode].title}
                </h4>
              </div>
              <p className="text-slate-300 text-sm leading-relaxed">
                {nodeDetails[selectedNode].description}
              </p>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-xs text-slate-400 font-mono">
                💡 <span className="font-semibold text-slate-200">Detalhe Conceitual:</span>{' '}
                {nodeDetails[selectedNode].detail}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: THE 6 INTEGRATED SENSES */}
      {activeTab === 'senses' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-slate-900/60 border border-purple-900/50 rounded-2xl p-6 text-center space-y-2">
            <Brain className="w-8 h-8 text-purple-400 mx-auto" />
            <h3 className="text-xl font-bold text-white">
              O Ecossistema dos Seis Sentidos Integrados
            </h3>
            <p className="text-xs text-slate-400 max-w-xl mx-auto">
              No PASQUAD, a percepção humana unifica os 5 sentidos biológicos clássicos
              com o 6º elemento: a Cognição Integrativa, responsável por correlacionar
              padrões e inferências profundas.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {sensesList.map((sense) => {
              const Icon = sense.icon;
              return (
                <div
                  key={sense.id}
                  className={`bg-slate-900/80 border p-5 rounded-2xl space-y-3 relative overflow-hidden transition-all hover:scale-[1.02] ${
                    sense.isHighlight
                      ? 'border-purple-500/80 shadow-xl shadow-purple-500/10 sm:col-span-2 lg:col-span-3 bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`p-3 rounded-xl bg-gradient-to-br ${sense.color} text-slate-950 font-bold`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-base">
                        {sense.name}
                      </h4>
                      {sense.isHighlight && (
                        <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 bg-purple-950 px-2 py-0.5 rounded border border-purple-800">
                          Sexto Sentido PASQUAD
                        </span>
                      )}
                    </div>
                  </div>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    {sense.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: THEORETICAL PILLARS */}
      {activeTab === 'pillars' && (
        <div className="grid md:grid-cols-2 gap-6 animate-fadeIn">
          {[
            {
              title: '1. Sincronicidade de Carl Gustav Jung',
              tag: 'Psicologia Analítica',
              color: 'emerald',
              description:
                'Investigação das coincidências não-causais entre eventos psíquicos internos e fatos objetivos externos, conectados pelo significado subjetivo percebido pelo observador.',
            },
            {
              title: '2. Teoria da Informação & Redução de Incerteza',
              tag: 'Ciência da Computação',
              color: 'blue',
              description:
                'Análise da experiência humana como um fluxo estruturado de dados que reduz a entropia informacional e constrói modelos mentais de interpretação.',
            },
            {
              title: '3. Sistemas Complexos Adaptativos',
              tag: 'Sistemática & Emergência',
              color: 'purple',
              description:
                'Entendimento de que a mente humana interage com o ambiente como um sistema complexo onde o todo exibe propriedades emergentes que não podem ser reduzidas a componentes isolados.',
            },
            {
              title: '4. Reconhecimento de Padrões & IA',
              tag: 'Tecnologia Avançada',
              color: 'amber',
              description:
                'Paralelo entre o processamento humano e algoritmos de aprendizado de máquina para extrair padrões significativos em ambientes altamente ruidosos.',
            },
          ].map((pillar, idx) => (
            <div
              key={idx}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3 relative hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-base">{pillar.title}</h4>
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-slate-950 text-cyan-400 border border-slate-800">
                  {pillar.tag}
                </span>
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                {pillar.description}
              </p>
              <div className="flex items-center space-x-1 text-[11px] text-emerald-400 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Integrado no Modelo PASQUAD</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
