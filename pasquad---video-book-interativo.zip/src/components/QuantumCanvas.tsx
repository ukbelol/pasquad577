import React, { useEffect, useRef } from 'react';

interface QuantumCanvasProps {
  isPlaying: boolean;
  activeSectionId?: string;
  intensity?: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  pulsePhase: number;
}

export const QuantumCanvas: React.FC<QuantumCanvasProps> = ({
  isPlaying,
  activeSectionId = 'capa',
  intensity = 1,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || window.innerHeight);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };

    window.addEventListener('resize', handleResize);

    // Color theme based on current section
    const getThemeColors = (sectionId: string) => {
      if (sectionId.includes('cap2-1')) return ['#10b981', '#059669', '#34d399', '#6ee7b7']; // Emerald/Jungian
      if (sectionId.includes('cap2-2')) return ['#3b82f6', '#60a5fa', '#1d4ed8', '#93c5fd']; // Blue/Information
      if (sectionId.includes('cap2-3')) return ['#8b5cf6', '#a78bfa', '#ec4899', '#f472b6']; // Violet/6 Senses
      if (sectionId.includes('cap1')) return ['#06b6d4', '#22d3ee', '#0284c7', '#38bdf8']; // Cyan/Tech
      return ['#6366f1', '#818cf8', '#3b82f6', '#a855f7']; // Indigo Quantum
    };

    const colors = getThemeColors(activeSectionId);

    // Generate quantum particles
    const particleCount = Math.min(Math.floor((width * height) / 12000), 75);
    const particles: Particle[] = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * (isPlaying ? 0.8 : 0.3),
        vy: (Math.random() - 0.5) * (isPlaying ? 0.8 : 0.3),
        radius: Math.random() * 2.5 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        pulsePhase: Math.random() * Math.PI * 2,
      });
    }

    let wavePhase = 0;

    const render = () => {
      ctx.fillStyle = 'rgba(10, 15, 30, 0.25)'; // Deep quantum space fade
      ctx.fillRect(0, 0, width, height);

      wavePhase += isPlaying ? 0.03 : 0.01;

      // Draw quantum background wave interference
      ctx.lineWidth = 1;
      const waveCount = 3;
      for (let w = 0; w < waveCount; w++) {
        ctx.beginPath();
        const strokeColor = colors[w % colors.length];
        ctx.strokeStyle = strokeColor + '18'; // Low opacity wave

        for (let x = 0; x < width; x += 15) {
          const y =
            height / 2 +
            Math.sin(x * 0.005 + wavePhase + w * 1.5) * (30 * intensity) +
            Math.cos(x * 0.002 + wavePhase * 0.7) * (20 * intensity);
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

      // Draw particle mesh network
      for (let i = 0; i < particles.length; i++) {
        const p1 = particles[i];
        p1.pulsePhase += isPlaying ? 0.04 : 0.01;

        // Move particle
        p1.x += p1.vx * (isPlaying ? 1.5 : 1);
        p1.y += p1.vy * (isPlaying ? 1.5 : 1);

        // Wrap around screen
        if (p1.x < 0) p1.x = width;
        if (p1.x > width) p1.x = 0;
        if (p1.y < 0) p1.y = height;
        if (p1.y > height) p1.y = 0;

        // Draw particle
        const currentRadius = p1.radius + Math.sin(p1.pulsePhase) * 0.8;
        ctx.beginPath();
        ctx.arc(p1.x, p1.y, Math.max(0.5, currentRadius), 0, Math.PI * 2);
        ctx.fillStyle = p1.color;
        ctx.fill();

        // Connect nearby particles with quantum data entanglement lines
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const maxDist = 120;

          if (dist < maxDist) {
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            const alpha = ((1 - dist / maxDist) * 0.25).toFixed(2);
            ctx.strokeStyle = `rgba(165, 180, 252, ${alpha})`;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [isPlaying, activeSectionId, intensity]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none rounded-2xl"
    />
  );
};
