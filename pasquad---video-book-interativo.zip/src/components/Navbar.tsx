import React from 'react';
import {
  Play,
  BookOpen,
  Network,
  Bot,
  UserCheck,
  Volume2,
  VolumeX,
  HelpCircle,
  Sparkles,
  MessageSquare,
  ShieldCheck,
  Globe,
} from 'lucide-react';
import { ViewMode, AmbientSound } from '../types';
import { audioSynth } from '../utils/audioSynth';
import { useLanguage } from '../context/LanguageContext';
import { SUPPORTED_LANGUAGES } from '../i18n/languages';

interface NavbarProps {
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  ambientSound: AmbientSound;
  onChangeAmbient: (sound: AmbientSound) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenQuiz: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onSelectView,
  ambientSound,
  onChangeAmbient,
  isMuted,
  onToggleMute,
  onOpenQuiz,
}) => {
  const { uiLang, audioLang, textLang, t, openLanguageModal } = useLanguage();

  return (
    <header className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-cyan-900/40 px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Author badge */}
        <div
          onClick={() => onSelectView('video')}
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-600 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold tracking-wider text-white font-mono">
                {t('appTitle')}
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-widest bg-cyan-950/80 text-cyan-400 px-2 py-0.5 rounded border border-cyan-800/50">
                Video-Book
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-xs sm:max-w-md">
              {t('appSubtitle')}
            </p>
          </div>
        </div>

        {/* Navigation Modes */}
        <nav className="flex items-center space-x-1 sm:space-x-1.5 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800/80 overflow-x-auto max-w-full touch-pan-x scrollbar-none">
          <button
            id="nav-btn-video"
            onClick={() => {
              audioSynth.playChime('slide');
              onSelectView('video');
            }}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-medium min-h-[44px] transition-all flex-shrink-0 ${
              currentView === 'video'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Play className="w-4 h-4 text-cyan-300" />
            <span className="inline text-[11px] sm:text-xs">{t('navVideo')}</span>
          </button>

          <button
            id="nav-btn-diagrams"
            onClick={() => {
              audioSynth.playChime('slide');
              onSelectView('diagrams');
            }}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-medium min-h-[44px] transition-all flex-shrink-0 ${
              currentView === 'diagrams'
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md shadow-purple-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Network className="w-4 h-4 text-purple-300" />
            <span className="inline text-[11px] sm:text-xs">{t('navDiagrams')}</span>
          </button>

          <button
            id="nav-btn-reader"
            onClick={() => {
              audioSynth.playChime('slide');
              onSelectView('reader');
            }}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-medium min-h-[44px] transition-all flex-shrink-0 ${
              currentView === 'reader'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-300" />
            <span className="inline text-[11px] sm:text-xs">{t('navReader')}</span>
          </button>

          <button
            id="nav-btn-comments"
            onClick={() => {
              audioSynth.playChime('slide');
              onSelectView('comments');
            }}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-medium min-h-[44px] transition-all flex-shrink-0 ${
              currentView === 'comments'
                ? 'bg-gradient-to-r from-teal-600 to-cyan-600 text-white shadow-md shadow-teal-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-teal-300" />
            <span className="inline text-[11px] sm:text-xs">{t('navComments')}</span>
          </button>

          <button
            id="nav-btn-tutor"
            onClick={() => {
              audioSynth.playChime('ai');
              onSelectView('ai-tutor');
            }}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-medium min-h-[44px] transition-all flex-shrink-0 ${
              currentView === 'ai-tutor'
                ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-md shadow-indigo-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Bot className="w-4 h-4 text-cyan-300" />
            <span className="inline text-[11px] sm:text-xs">{t('navTutor')}</span>
          </button>

          <button
            id="nav-btn-author"
            onClick={() => {
              audioSynth.playChime('slide');
              onSelectView('author');
            }}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-medium min-h-[44px] transition-all flex-shrink-0 ${
              currentView === 'author'
                ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-md shadow-amber-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <UserCheck className="w-4 h-4 text-amber-300" />
            <span className="inline text-[11px] sm:text-xs">{t('navAuthor')}</span>
          </button>

          <button
            id="nav-btn-admin"
            onClick={() => {
              audioSynth.playChime('slide');
              onSelectView('admin');
            }}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs font-bold min-h-[44px] transition-all flex-shrink-0 ${
              currentView === 'admin'
                ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md shadow-rose-500/20 font-bold'
                : 'text-rose-400 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-rose-300" />
            <span className="inline text-[11px] sm:text-xs">{t('navAdmin')}</span>
          </button>
        </nav>

        {/* Quick Tools, Language Selector & Sound Control */}
        <div className="flex items-center space-x-2">
          {/* Language Selector Button */}
          <button
            id="btn-open-language-modal"
            onClick={() => {
              audioSynth.playChime('slide');
              openLanguageModal();
            }}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-cyan-950/80 text-cyan-300 border border-cyan-700/50 hover:bg-cyan-900/60 transition-all shadow-sm group"
            title="Escolher idioma do site, áudio descrição e texto explicativo"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400 group-hover:rotate-45 transition-transform" />
            <span className="hidden sm:inline">{t('navLanguage')}</span>
            <div className="flex items-center -space-x-1 text-[11px] bg-slate-900/90 px-1.5 py-0.5 rounded border border-slate-800">
              <span>{SUPPORTED_LANGUAGES[uiLang].flag}</span>
              {audioLang !== uiLang && <span>{SUPPORTED_LANGUAGES[audioLang].flag}</span>}
              {textLang !== uiLang && textLang !== audioLang && (
                <span>{SUPPORTED_LANGUAGES[textLang].flag}</span>
              )}
            </div>
          </button>

          {/* Quiz Button */}
          <button
            id="btn-open-quiz"
            onClick={() => {
              audioSynth.playChime('correct');
              onOpenQuiz();
            }}
            className="flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-colors"
            title="Testar Conhecimento (Quiz PASQUAD)"
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">{t('navQuiz')}</span>
          </button>

          {/* Ambient Sound Dropdown */}
          <div className="relative flex items-center bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-xs">
            <span className="text-slate-400 text-[10px] mr-1 hidden sm:inline">
              {t('soundLabel')}
            </span>
            <select
              id="ambient-sound-select"
              value={ambientSound}
              onChange={(e) => onChangeAmbient(e.target.value as AmbientSound)}
              className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer py-0.5"
            >
              <option value="off" className="bg-slate-900 text-slate-300">
                {t('soundOff')}
              </option>
              <option value="quantum-432" className="bg-slate-900 text-cyan-300">
                {t('sound432')}
              </option>
              <option value="solfeggio-528" className="bg-slate-900 text-emerald-300">
                {t('sound528')}
              </option>
              <option value="alpha-waves" className="bg-slate-900 text-indigo-300">
                {t('soundAlpha')}
              </option>
              <option value="cosmic-synth" className="bg-slate-900 text-purple-300">
                {t('soundSynth')}
              </option>
            </select>
          </div>

          {/* Mute toggle */}
          <button
            id="btn-toggle-mute"
            onClick={onToggleMute}
            className={`p-2 rounded-lg border text-xs transition-colors ${
              isMuted
                ? 'bg-rose-950/40 border-rose-800/50 text-rose-400'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
            }`}
            title={isMuted ? t('muteOn') : t('muteOff')}
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4" />
            ) : (
              <Volume2 className="w-4 h-4 text-cyan-400" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

