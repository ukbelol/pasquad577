import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  Volume2,
  Maximize2,
  Minimize2,
  Sparkles,
  Bot,
  Network,
  BookOpen,
  Bookmark,
  Share2,
  Check,
  Zap,
} from 'lucide-react';
import { PASQUAD_SECTIONS } from '../data/pasquadText';
import { QuantumCanvas } from './QuantumCanvas';
import { audioSynth } from '../utils/audioSynth';
import { Section, ViewMode } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { SUPPORTED_LANGUAGES } from '../i18n/languages';

interface VideoPlayerProps {
  onSelectView: (view: ViewMode) => void;
  onAskAIAboutSection: (section: Section) => void;
  onBookmarkSection: (section: Section, paragraphIdx: number) => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  onSelectView,
  onAskAIAboutSection,
  onBookmarkSection,
}) => {
  const { uiLang, audioLang, textLang, getSection, getAudioDescriptionText, t } = useLanguage();

  const [sectionIndex, setSectionIndex] = useState<number>(0);
  const [paragraphIndex, setParagraphIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string>('');
  const [autoAdvance, setAutoAdvance] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  const playerRef = useRef<HTMLDivElement | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Get current section translated according to textLang
  const currentSection = getSection(PASQUAD_SECTIONS[sectionIndex].id);
  const currentParagraph =
    currentSection.paragraphs[paragraphIndex] || currentSection.paragraphs[0];

  // Get audio narration text according to audioLang
  const audioText = getAudioDescriptionText(PASQUAD_SECTIONS[sectionIndex].id, paragraphIndex);

  // Load browser speech voices for audioLang
  useEffect(() => {
    const updateVoices = () => {
      if ('speechSynthesis' in window) {
        const availableVoices = window.speechSynthesis.getVoices();
        const langInfo = SUPPORTED_LANGUAGES[audioLang] || SUPPORTED_LANGUAGES['pt'];
        const matchedVoices = availableVoices.filter(
          (v) =>
            v.lang.toLowerCase().includes(audioLang) ||
            v.lang.toLowerCase().includes(langInfo.bcp47.toLowerCase())
        );
        const finalVoices = matchedVoices.length > 0 ? matchedVoices : availableVoices;
        setVoices(finalVoices);
        if (finalVoices.length > 0) {
          setSelectedVoice(finalVoices[0].name);
        }
      }
    };

    updateVoices();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, [audioLang]);

  // Handle TTS narration
  const speakParagraph = (text: string) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel(); // Stop current speech

    if (!isPlaying) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = speechRate;
    const langInfo = SUPPORTED_LANGUAGES[audioLang] || SUPPORTED_LANGUAGES['pt'];
    utterance.lang = langInfo.bcp47;

    if (selectedVoice) {
      const voiceObj = voices.find((v) => v.name === selectedVoice);
      if (voiceObj) utterance.voice = voiceObj;
    }

    utterance.onend = () => {
      if (autoAdvance && isPlaying) {
        handleNextParagraph();
      }
    };

    utterance.onerror = (e) => {
      console.warn('Speech error:', e);
      setIsPlaying(false);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // Re-trigger narration when paragraph or play state changes
  useEffect(() => {
    if (isPlaying) {
      speakParagraph(audioText);
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    }

    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [sectionIndex, paragraphIndex, isPlaying, speechRate, selectedVoice, audioLang, audioText]);

  const handleNextParagraph = () => {
    audioSynth.playChime('slide');
    if (paragraphIndex < currentSection.paragraphs.length - 1) {
      setParagraphIndex((prev) => prev + 1);
    } else if (sectionIndex < PASQUAD_SECTIONS.length - 1) {
      audioSynth.playChime('chapter');
      setSectionIndex((prev) => prev + 1);
      setParagraphIndex(0);
    } else {
      setIsPlaying(false); // End of video book
    }
  };

  const handlePrevParagraph = () => {
    audioSynth.playChime('slide');
    if (paragraphIndex > 0) {
      setParagraphIndex((prev) => prev - 1);
    } else if (sectionIndex > 0) {
      setSectionIndex((prev) => prev - 1);
      setParagraphIndex(PASQUAD_SECTIONS[sectionIndex - 1].paragraphs.length - 1);
    }
  };

  const togglePlay = () => {
    const nextState = !isPlaying;
    setIsPlaying(nextState);
    if (nextState) {
      audioSynth.playChime('slide');
    }
  };

  const toggleFullscreen = () => {
    if (!playerRef.current) return;
    if (!document.fullscreenElement) {
      playerRef.current.requestFullscreen().catch((err) => {
        console.warn('Fullscreen error:', err);
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch((err) => console.warn(err));
      setIsFullscreen(false);
    }
  };

  // Calculate overall video-book completion progress
  const totalSections = PASQUAD_SECTIONS.length;
  const currentOverallProgress = Math.round(
    ((sectionIndex + (paragraphIndex + 1) / currentSection.paragraphs.length) /
      totalSections) *
      100
  );

  const handleCopyText = () => {
    navigator.clipboard.writeText(
      `${currentSection.title} - ${currentParagraph}\n(PASQUAD por Rogério Gomes Dos Santos)`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Chapter Selection & Quick Jump Tabs */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
        {PASQUAD_SECTIONS.map((sec, idx) => {
          const isActive = idx === sectionIndex;
          return (
            <button
              key={sec.id}
              onClick={() => {
                audioSynth.playChime('slide');
                setSectionIndex(idx);
                setParagraphIndex(0);
              }}
              className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-lg shadow-cyan-500/20 scale-105'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span className="opacity-70 mr-1">{sec.number}</span>
              <span>{sec.title.split('—')[0]}</span>
            </button>
          );
        })}
      </div>

      {/* Main Video-Book Cinema Display */}
      <div
        ref={playerRef}
        className="relative bg-slate-950 border border-cyan-900/40 rounded-2xl shadow-2xl overflow-hidden aspect-video min-h-[420px] md:min-h-[520px] flex flex-col justify-between p-6 sm:p-10 select-none group"
      >
        {/* Animated Background Quantum Mesh */}
        <QuantumCanvas
          isPlaying={isPlaying}
          activeSectionId={currentSection.id}
          intensity={isPlaying ? 1.5 : 0.8}
        />

        {/* Top Video Header Bar */}
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <span className="inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold tracking-wider uppercase bg-cyan-950/80 text-cyan-300 border border-cyan-800/60 backdrop-blur-sm">
              <Zap className="w-3 h-3 mr-1 text-cyan-400" />
              {currentSection.chapter} ({currentSection.number})
            </span>

            {isPlaying && (
              <span className="flex items-center space-x-1.5 text-xs text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>NARRANDO</span>
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopyText}
              className="p-2 rounded-lg bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800 backdrop-blur-sm transition-colors text-xs flex items-center space-x-1"
              title="Copiar texto da cena"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 text-[10px]">Copiado</span>
                </>
              ) : (
                <Share2 className="w-3.5 h-3.5" />
              )}
            </button>

            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-lg bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800 backdrop-blur-sm transition-colors"
              title={isFullscreen ? 'Sair da Tela Cheia' : 'Modo Cinema Tela Cheia'}
            >
              {isFullscreen ? (
                <Minimize2 className="w-4 h-4" />
              ) : (
                <Maximize2 className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        {/* Center Kinetic Typography & Visual Card */}
        <div className="relative z-10 my-auto text-center max-w-3xl mx-auto space-y-4">
          {/* Section Title */}
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-200 font-sans">
              {currentSection.title}
            </h2>
            {currentSection.subtitle && (
              <p className="text-sm sm:text-base text-cyan-400 font-medium tracking-wide">
                {currentSection.subtitle}
              </p>
            )}
          </div>

          {/* Current Paragraph Subtitle / Narration Frame */}
          <div className="bg-slate-900/90 border border-cyan-800/50 rounded-2xl p-6 sm:p-8 backdrop-blur-md shadow-xl text-slate-100 text-lg sm:text-xl lg:text-2xl leading-relaxed font-serif relative overflow-hidden transition-all duration-300 hover:border-cyan-500/60">
            {/* Ambient accent bar */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-500"></div>

            <p className="tracking-wide">
              "{currentParagraph}"
            </p>

            {/* Paragraph Step Indicator */}
            <div className="mt-4 flex items-center justify-between text-xs text-slate-400 font-sans font-medium pt-3 border-t border-slate-800/80">
              <span className="text-cyan-400">
                Parágrafo {paragraphIndex + 1} de {currentSection.paragraphs.length}
              </span>
              <div className="flex items-center space-x-1">
                {currentSection.paragraphs.map((_, pIdx) => (
                  <span
                    key={pIdx}
                    className={`h-1.5 rounded-full transition-all ${
                      pIdx === paragraphIndex
                        ? 'w-6 bg-cyan-400'
                        : 'w-1.5 bg-slate-700'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Video Controls & Progress Bar */}
        <div className="relative z-10 space-y-3">
          {/* Progress Bar */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>
                Seção {sectionIndex + 1}/{totalSections} • {currentSection.id}
              </span>
              <span className="text-cyan-400 font-bold">
                {currentOverallProgress}% Concluído
              </span>
            </div>
            <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-500 transition-all duration-500"
                style={{ width: `${currentOverallProgress}%` }}
              />
            </div>
          </div>

          {/* Control Buttons Strip */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            {/* Playback Transport Buttons */}
            <div className="flex items-center space-x-3">
              <button
                onClick={handlePrevParagraph}
                className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
                title="Anterior"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              <button
                onClick={togglePlay}
                className="p-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold hover:scale-105 shadow-lg shadow-cyan-500/30 transition-all flex items-center justify-center"
                title={isPlaying ? 'Pausar' : 'Reproduzir Narração'}
              >
                {isPlaying ? (
                  <Pause className="w-6 h-6 fill-current" />
                ) : (
                  <Play className="w-6 h-6 fill-current ml-0.5" />
                )}
              </button>

              <button
                onClick={handleNextParagraph}
                className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
                title="Próximo"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setParagraphIndex(0);
                  setIsPlaying(true);
                }}
                className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Recomeçar Seção"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {/* Voice & Speed Controls */}
            <div className="flex items-center space-x-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
              <Volume2 className="w-4 h-4 text-cyan-400 ml-1 hidden sm:inline" />

              {/* Speech Speed */}
              <select
                value={speechRate}
                onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                className="bg-slate-950 text-slate-200 text-xs rounded-lg px-2 py-1 border border-slate-800 focus:outline-none cursor-pointer"
                title="Velocidade da Narração"
              >
                <option value={0.8}>0.8x Lento</option>
                <option value={1.0}>1.0x Normal</option>
                <option value={1.25}>1.25x Rápido</option>
                <option value={1.5}>1.5x Muito Rápido</option>
              </select>

              {/* Voice Choice if available */}
              {voices.length > 0 && (
                <select
                  value={selectedVoice}
                  onChange={(e) => setSelectedVoice(e.target.value)}
                  className="bg-slate-950 text-slate-200 text-xs rounded-lg px-2 py-1 border border-slate-800 focus:outline-none cursor-pointer max-w-[120px] sm:max-w-[160px] truncate"
                  title="Voz do Narrador"
                >
                  {voices.map((v) => (
                    <option key={v.name} value={v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              )}

              {/* Auto advance checkbox */}
              <button
                onClick={() => setAutoAdvance(!autoAdvance)}
                className={`px-2 py-1 rounded text-[11px] font-medium border transition-colors ${
                  autoAdvance
                    ? 'bg-cyan-950 border-cyan-800 text-cyan-300'
                    : 'bg-slate-950 border-slate-800 text-slate-500'
                }`}
                title="Avanço Automático de Cenas"
              >
                Auto-Avanço: {autoAdvance ? 'ON' : 'OFF'}
              </button>
            </div>

            {/* AI Assistant Quick Trigger */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => onAskAIAboutSection(currentSection)}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs font-semibold hover:from-indigo-500 hover:to-purple-500 shadow-md shadow-indigo-500/20 transition-all"
              >
                <Bot className="w-4 h-4 text-cyan-300 animate-pulse" />
                <span>Explicar com IA</span>
              </button>

              <button
                onClick={() =>
                  onBookmarkSection(currentSection, paragraphIndex)
                }
                className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400 hover:bg-slate-800 transition-colors"
                title="Salvar Marcador nesta cena"
              >
                <Bookmark className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Video Chapter Synopsis Card */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Análise Conceitual do Capítulo
            </h3>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onSelectView('diagrams')}
              className="text-xs text-purple-400 hover:text-purple-300 flex items-center space-x-1 bg-purple-950/40 px-2.5 py-1 rounded border border-purple-800/40"
            >
              <Network className="w-3.5 h-3.5" />
              <span>Ver Diagrama PASQUAD</span>
            </button>
            <button
              onClick={() => onSelectView('reader')}
              className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center space-x-1 bg-emerald-950/40 px-2.5 py-1 rounded border border-emerald-800/40"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Abrir Texto Integral</span>
            </button>
          </div>
        </div>

        {/* Key words badges */}
        <div className="flex flex-wrap gap-2">
          {currentSection.keywords?.map((kw, i) => (
            <span
              key={i}
              className="text-xs bg-slate-950 text-cyan-300 border border-cyan-900/60 px-2.5 py-0.5 rounded-full"
            >
              #{kw}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
