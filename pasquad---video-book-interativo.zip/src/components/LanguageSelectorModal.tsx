import React from 'react';
import { Globe, X, Check, Volume2, Monitor, BookOpen, Sparkles, Zap } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { LANGUAGE_LIST, SUPPORTED_LANGUAGES } from '../i18n/languages';
import { SupportedLanguage } from '../i18n/types';
import { audioSynth } from '../utils/audioSynth';

export const LanguageSelectorModal: React.FC = () => {
  const {
    uiLang,
    audioLang,
    textLang,
    setUiLang,
    setAudioLang,
    setTextLang,
    setAllLanguages,
    t,
    isModalOpen,
    closeLanguageModal,
  } = useLanguage();

  if (!isModalOpen) return null;

  const handleSelectPreset = (lang: SupportedLanguage) => {
    audioSynth.playChime('correct');
    setAllLanguages(lang);
  };

  const handleSelectUI = (lang: SupportedLanguage) => {
    audioSynth.playChime('slide');
    setUiLang(lang);
  };

  const handleSelectAudio = (lang: SupportedLanguage) => {
    audioSynth.playChime('slide');
    setAudioLang(lang);
  };

  const handleSelectText = (lang: SupportedLanguage) => {
    audioSynth.playChime('slide');
    setTextLang(lang);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-950/50 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <Globe className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                {t('langModalTitle')}
                <span className="text-[10px] font-mono uppercase bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-800">
                  i18n 10 Languages
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {t('langModalSubtitle')}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              audioSynth.playChime('slide');
              closeLanguageModal();
            }}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar flex-1">
          {/* Active Status Summary Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs">
            <div className="flex items-center space-x-2 text-slate-300">
              <Monitor className="w-4 h-4 text-cyan-400" />
              <span className="text-slate-400">{t('activeBadgeUI')}:</span>
              <span className="font-semibold text-white flex items-center gap-1">
                {SUPPORTED_LANGUAGES[uiLang].flag} {SUPPORTED_LANGUAGES[uiLang].nativeName}
              </span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <Volume2 className="w-4 h-4 text-indigo-400" />
              <span className="text-slate-400">{t('activeBadgeAudio')}:</span>
              <span className="font-semibold text-white flex items-center gap-1">
                {SUPPORTED_LANGUAGES[audioLang].flag} {SUPPORTED_LANGUAGES[audioLang].nativeName}
              </span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-400">{t('activeBadgeText')}:</span>
              <span className="font-semibold text-white flex items-center gap-1">
                {SUPPORTED_LANGUAGES[textLang].flag} {SUPPORTED_LANGUAGES[textLang].nativeName}
              </span>
            </div>
          </div>

          {/* Quick Presets Section */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              {t('presetLabel')}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {LANGUAGE_LIST.map((lang) => {
                const isAllSelected =
                  uiLang === lang.code && audioLang === lang.code && textLang === lang.code;
                return (
                  <button
                    key={`preset-${lang.code}`}
                    onClick={() => handleSelectPreset(lang.code)}
                    className={`flex items-center space-x-2 p-2 rounded-xl text-xs font-medium border transition-all ${
                      isAllSelected
                        ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-lg shadow-cyan-500/10'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/80'
                    }`}
                  >
                    <span className="text-base">{lang.flag}</span>
                    <span className="truncate">{lang.name}</span>
                    {isAllSelected && <Check className="w-3.5 h-3.5 text-cyan-400 ml-auto" />}
                  </button>
                );
              })}
            </div>
          </div>

          <hr className="border-slate-800" />

          {/* 1. UI Language Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Monitor className="w-4 h-4 text-cyan-400" />
              {t('uiLangLabel')}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {LANGUAGE_LIST.map((lang) => (
                <button
                  key={`ui-${lang.code}`}
                  onClick={() => handleSelectUI(lang.code)}
                  className={`flex items-center justify-between p-2 rounded-lg text-xs border transition-all ${
                    uiLang === lang.code
                      ? 'bg-cyan-600/30 border-cyan-400 text-white font-semibold'
                      : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <span className="flex items-center gap-1.5 truncate">
                    <span>{lang.flag}</span>
                    <span className="truncate">{lang.nativeName}</span>
                  </span>
                  {uiLang === lang.code && <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* 2. Audio Description Language Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-indigo-400" />
              {t('audioLangLabel')}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {LANGUAGE_LIST.map((lang) => (
                <button
                  key={`audio-${lang.code}`}
                  onClick={() => handleSelectAudio(lang.code)}
                  className={`flex items-center justify-between p-2 rounded-lg text-xs border transition-all ${
                    audioLang === lang.code
                      ? 'bg-indigo-600/30 border-indigo-400 text-white font-semibold'
                      : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <span className="flex items-center gap-1.5 truncate">
                    <span>{lang.flag}</span>
                    <span className="truncate">{lang.nativeName}</span>
                  </span>
                  {audioLang === lang.code && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Explanatory Text Language Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-emerald-400" />
              {t('textLangLabel')}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {LANGUAGE_LIST.map((lang) => (
                <button
                  key={`text-${lang.code}`}
                  onClick={() => handleSelectText(lang.code)}
                  className={`flex items-center justify-between p-2 rounded-lg text-xs border transition-all ${
                    textLang === lang.code
                      ? 'bg-emerald-600/30 border-emerald-400 text-white font-semibold'
                      : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <span className="flex items-center gap-1.5 truncate">
                    <span>{lang.flag}</span>
                    <span className="truncate">{lang.nativeName}</span>
                  </span>
                  {textLang === lang.code && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/90 flex items-center justify-between">
          <p className="text-[11px] text-slate-500 hidden sm:block">
            Idiomas suportados: Português, English, Español, Français, Deutsch, Italiano, 日本語, 中文, Русский, العربية
          </p>
          <button
            onClick={() => {
              audioSynth.playChime('correct');
              closeLanguageModal();
            }}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:brightness-110 shadow-lg shadow-cyan-500/20 transition-all ml-auto"
          >
            {t('langModalClose')}
          </button>
        </div>
      </div>
    </div>
  );
};
