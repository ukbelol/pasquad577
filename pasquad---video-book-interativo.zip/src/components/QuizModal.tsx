import React, { useState } from 'react';
import { HelpCircle, CheckCircle, XCircle, Award, RefreshCw, X, Sparkles } from 'lucide-react';
import { QuizItem } from '../types';
import { audioSynth } from '../utils/audioSynth';

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({ isOpen, onClose }) => {
  const defaultQuestions: QuizItem[] = [
    {
      question: "Qual é o conceito psicológico e filosófico que serve como ponto de partida para o PASQUAD?",
      options: [
        "A) Causalidade Determinística Newtoniana",
        "B) Sincronicidade de Carl Gustav Jung",
        "C) Comportamentismo Operante de Skinner",
        "D) Materialismo Dialético"
      ],
      correctIndex: 1,
      explanation: "O PASQUAD utiliza a sincronicidade junguiana (conexões não-causais significativas) como ponto inicial para investigar o processamento de informação na experiência humana."
    },
    {
      question: "No PASQUAD, como deve ser compreendido o termo 'Quântico'?",
      options: [
        "A) Uma aplicação biológica direta da mecânica quântica no cérebro",
        "B) Uma metáfora epistemológica sobre a existência de múltiplas possibilidades interpretativas antes da escolha de um significado",
        "C) Um computador quântico físico construído em laboratório",
        "D) Uma teoria sobrenatural sem fundamentação lógica"
      ],
      correctIndex: 1,
      explanation: "A monografia deixa claro que 'quântico' é uma metáfora epistemológica para representar a superposição de interpretações possíveis antes do 'colapso' no significado final."
    },
    {
      question: "O que caracteriza o 'Sexto Sentido' no modelo dos Seis Sentidos Integrados do PASQUAD?",
      options: [
        "A) Uma faculdade mística não comprovável",
        "B) A Cognição Integrativa, capacidade sintética baseada em memória, experiência, reconhecimento de padrões e inferência",
        "C) A visão infravermelha dos animais",
        "D) O sexto par de nervos cranianos"
      ],
      correctIndex: 1,
      explanation: "O sexto elemento do PASQUAD é a Cognição Integrativa, que unifica os 5 sentidos clássicos usando a bagagem cognitiva do indivíduo para reconhecer sincronicidades."
    },
    {
      question: "Qual é o fluxo informacional proposto pelo PASQUAD para a atribuição de significado?",
      options: [
        "A) Dados → Processamento → Informação → Conhecimento → Decisão",
        "B) Percepção → Integração → Contexto → Interpretação → Significado",
        "C) Intuição → Imaginação → Ação → Resultado",
        "D) Percepção → Esquecimento → Reação → Decisão"
      ],
      correctIndex: 1,
      explanation: "Enquanto a computação tradicional usa Dados->Processamento->Informação->Conhecimento->Decisão, o PASQUAD propõe: Percepção -> Integração -> Contexto -> Interpretação -> Significado."
    },
    {
      question: "Quem é o autor da monografia conceitual PASQUAD e qual é sua área de graduação?",
      options: [
        "A) Carl Gustav Jung, Bacharel em Medicina",
        "B) Rogério Gomes Dos Santos, Bacharel em Sistemas de Informação (Unifieo 2010)",
        "C) Claude Shannon, Engenharia Elétrica",
        "D) Rogério Silva, Bacharel em Psicologia"
      ],
      correctIndex: 1,
      explanation: "Rogério Gomes Dos Santos é Bacharel em Sistemas de Informação pela Universidade Unifieo (Osasco-SP, 2010), trazendo a visão de sistemas de dados para a experiência humana."
    }
  ];

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);
  const [showResult, setShowResult] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentQ = defaultQuestions[currentIndex];

  const handleSelectOption = (idx: number) => {
    if (isSubmitted) return;
    setSelectedOption(idx);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null || isSubmitted) return;
    setIsSubmitted(true);

    if (selectedOption === currentQ.correctIndex) {
      audioSynth.playChime('correct');
      setScore((prev) => prev + 1);
    } else {
      audioSynth.playChime('slide');
    }
  };

  const handleNextQuestion = () => {
    setSelectedOption(null);
    setIsSubmitted(false);

    if (currentIndex < defaultQuestions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setShowResult(true);
    }
  };

  const handleRestartQuiz = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setScore(0);
    setShowResult(false);
    setIsSubmitted(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-cyan-800 rounded-2xl max-w-xl w-full p-6 space-y-6 relative shadow-2xl">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-950 border border-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-amber-950 border border-amber-800 text-amber-400">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Quiz PASQUAD</h3>
            <p className="text-xs text-slate-400">
              Avalie seu entendimento da tese e dos conceitos quântico-sistêmicos
            </p>
          </div>
        </div>

        {!showResult ? (
          <div className="space-y-6">
            {/* Progress */}
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>
                Questão {currentIndex + 1} de {defaultQuestions.length}
              </span>
              <span className="text-amber-400 font-bold">Pontuação: {score}</span>
            </div>

            {/* Question Text */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-sm sm:text-base font-semibold text-slate-100">
              {currentQ.question}
            </div>

            {/* Options */}
            <div className="space-y-2">
              {currentQ.options.map((opt, idx) => {
                let btnStyle = 'bg-slate-950 border-slate-800 text-slate-300 hover:border-cyan-800';
                if (selectedOption === idx) {
                  btnStyle = 'bg-cyan-950 border-cyan-400 text-cyan-200 font-bold';
                }
                if (isSubmitted) {
                  if (idx === currentQ.correctIndex) {
                    btnStyle = 'bg-emerald-950 border-emerald-500 text-emerald-200 font-bold';
                  } else if (selectedOption === idx && idx !== currentQ.correctIndex) {
                    btnStyle = 'bg-rose-950 border-rose-500 text-rose-200';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={isSubmitted}
                    className={`w-full text-left p-3.5 rounded-xl border text-xs sm:text-sm transition-all ${btnStyle}`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>

            {/* Explanation box after submit */}
            {isSubmitted && (
              <div className="bg-slate-950 border border-cyan-900/60 p-4 rounded-xl text-xs space-y-1 animate-fadeIn">
                <span className="font-bold text-cyan-400">💡 Explicação Teórica:</span>
                <p className="text-slate-300">{currentQ.explanation}</p>
              </div>
            )}

            {/* Action button */}
            <div className="flex justify-end pt-2">
              {!isSubmitted ? (
                <button
                  onClick={handleSubmitAnswer}
                  disabled={selectedOption === null}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs disabled:opacity-50 transition-all"
                >
                  Confirmar Resposta
                </button>
              ) : (
                <button
                  onClick={handleNextQuestion}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold text-xs transition-all"
                >
                  {currentIndex < defaultQuestions.length - 1 ? 'Próxima Questão' : 'Ver Resultado Final'}
                </button>
              )}
            </div>
          </div>
        ) : (
          /* Final Result Screen */
          <div className="text-center space-y-6 py-4 animate-fadeIn">
            <div className="inline-flex p-4 rounded-full bg-amber-950 border border-amber-800 text-amber-400">
              <Award className="w-12 h-12 animate-bounce" />
            </div>

            <div className="space-y-2">
              <h4 className="text-2xl font-extrabold text-white">Quiz Concluído!</h4>
              <p className="text-sm text-slate-300">
                Sua pontuação final foi de{' '}
                <span className="font-bold text-cyan-400 text-lg">
                  {score} / {defaultQuestions.length}
                </span>{' '}
                respostas corretas ({Math.round((score / defaultQuestions.length) * 100)}%).
              </p>
            </div>

            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {score >= 4
                ? 'Excelente domínio conceitual sobre o modelo PASQUAD, a sincronicidade e o sexto sentido cognitivo!'
                : 'Bom trabalho! Recomendamos assistir novamente às seções do Video-Book para aprofundar os pilares teóricos.'}
            </p>

            <div className="flex items-center justify-center space-x-3 pt-4">
              <button
                onClick={handleRestartQuiz}
                className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-slate-800 text-white font-semibold text-xs hover:bg-slate-700 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Refazer Quiz</span>
              </button>

              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs transition-all"
              >
                Concluir
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
