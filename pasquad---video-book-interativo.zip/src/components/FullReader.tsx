import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Search,
  Bookmark,
  Play,
  Download,
  Printer,
  ChevronRight,
  Sun,
  Moon,
  Sparkles,
  Check,
} from 'lucide-react';
import { PASQUAD_SECTIONS, PASQUAD_METADATA } from '../data/pasquadText';
import { Section, Bookmark as BookmarkType, ViewMode } from '../types';
import { audioSynth } from '../utils/audioSynth';

interface FullReaderProps {
  onSelectView: (view: ViewMode) => void;
  onNarrateSection: (sectionId: string) => void;
}

export const FullReader: React.FC<FullReaderProps> = ({
  onSelectView,
  onNarrateSection,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg' | 'xl'>('md');
  const [readerTheme, setReaderTheme] = useState<'quantum' | 'sepia' | 'light'>('quantum');
  const [activeSectionId, setActiveSectionId] = useState<string>(PASQUAD_SECTIONS[0].id);
  const [bookmarks, setBookmarks] = useState<BookmarkType[]>([]);
  const [copiedNotification, setCopiedNotification] = useState<string | null>(null);

  // Load saved bookmarks from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('pasquad_bookmarks');
      if (saved) {
        setBookmarks(JSON.parse(saved));
      }
    } catch (e) {
      console.warn('Bookmark storage error:', e);
    }
  }, []);

  const saveBookmark = (sec: Section, pIdx: number) => {
    audioSynth.playChime('correct');
    const newBookmark: BookmarkType = {
      id: Date.now().toString(),
      sectionId: sec.id,
      paragraphIndex: pIdx,
      textSnippet: sec.paragraphs[pIdx].substring(0, 80) + '...',
      createdAt: new Date().toLocaleDateString('pt-BR'),
    };
    const updated = [newBookmark, ...bookmarks];
    setBookmarks(updated);
    localStorage.setItem('pasquad_bookmarks', JSON.stringify(updated));
    setCopiedNotification('Marcador salvo com sucesso!');
    setTimeout(() => setCopiedNotification(null), 2000);
  };

  const removeBookmark = (id: string) => {
    const updated = bookmarks.filter((b) => b.id !== id);
    setBookmarks(updated);
    localStorage.setItem('pasquad_bookmarks', JSON.stringify(updated));
  };

  // Filter sections by search term
  const filteredSections = PASQUAD_SECTIONS.filter((sec) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      sec.title.toLowerCase().includes(term) ||
      sec.chapter.toLowerCase().includes(term) ||
      sec.paragraphs.some((p) => p.toLowerCase().includes(term))
    );
  });

  // Font size classes
  const fontClasses = {
    sm: 'text-sm leading-normal',
    md: 'text-base leading-relaxed',
    lg: 'text-lg leading-loose',
    xl: 'text-xl leading-loose',
  };

  // Theme styling
  const themeClasses = {
    quantum: 'bg-slate-950 text-slate-200 border-slate-800',
    sepia: 'bg-[#fbf0d9] text-[#433422] border-[#e2d3b2]',
    light: 'bg-white text-slate-900 border-slate-200',
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Reader Controls Toolbar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 sticky top-16 z-40 backdrop-blur-md">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar na tese PASQUAD..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Font Size & Theme Toggles */}
        <div className="flex items-center space-x-3">
          {/* Font Size */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs font-mono">
            {(['sm', 'md', 'lg', 'xl'] as const).map((size) => (
              <button
                key={size}
                onClick={() => setFontSize(size)}
                className={`px-2 py-0.5 rounded transition-colors ${
                  fontSize === size
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {size.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Theme Selector */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setReaderTheme('quantum')}
              className={`p-1.5 rounded transition-colors ${
                readerTheme === 'quantum'
                  ? 'bg-slate-800 text-cyan-400'
                  : 'text-slate-400'
              }`}
              title="Tema Quântico Escuro"
            >
              <Moon className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setReaderTheme('sepia')}
              className={`p-1.5 rounded transition-colors ${
                readerTheme === 'sepia'
                  ? 'bg-[#e2d3b2] text-[#433422]'
                  : 'text-slate-400'
              }`}
              title="Tema Sépia Conforto"
            >
              <BookOpen className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setReaderTheme('light')}
              className={`p-1.5 rounded transition-colors ${
                readerTheme === 'light'
                  ? 'bg-slate-200 text-slate-900'
                  : 'text-slate-400'
              }`}
              title="Tema Claro"
            >
              <Sun className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Print/Export Button */}
          <button
            onClick={handlePrint}
            className="p-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 hover:text-white transition-colors"
            title="Imprimir / Exportar PDF"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {copiedNotification && (
        <div className="bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs px-4 py-2 rounded-xl flex items-center space-x-2 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{copiedNotification}</span>
        </div>
      )}

      {/* Main Grid: TOC + Monograph Body */}
      <div className="grid lg:grid-cols-4 gap-6">
        {/* TOC Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-2">
              <BookOpen className="w-4 h-4 text-cyan-400" />
              <span>Sumário do Texto</span>
            </h3>

            <div className="space-y-1 max-h-[480px] overflow-y-auto pr-1">
              {PASQUAD_SECTIONS.map((sec) => (
                <a
                  key={sec.id}
                  href={`#sec-${sec.id}`}
                  onClick={() => setActiveSectionId(sec.id)}
                  className={`block px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                    activeSectionId === sec.id
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="text-[10px] text-slate-500">{sec.number}</div>
                  <div className="truncate">{sec.title}</div>
                </a>
              ))}
            </div>
          </div>

          {/* Bookmarks Section */}
          {bookmarks.length > 0 && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center space-x-2">
                <Bookmark className="w-4 h-4" />
                <span>Marcadores ({bookmarks.length})</span>
              </h3>

              <div className="space-y-2 max-h-[220px] overflow-y-auto">
                {bookmarks.map((bm) => (
                  <div
                    key={bm.id}
                    className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1"
                  >
                    <p className="text-slate-300 italic line-clamp-2">
                      "{bm.textSnippet}"
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                      <span>{bm.createdAt}</span>
                      <button
                        onClick={() => removeBookmark(bm.id)}
                        className="text-rose-400 hover:underline"
                      >
                        Remover
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Monograph Document Container */}
        <div className="lg:col-span-3 space-y-8">
          {filteredSections.map((sec) => (
            <section
              id={`sec-${sec.id}`}
              key={sec.id}
              className={`p-6 sm:p-10 rounded-2xl border shadow-xl transition-all space-y-6 ${themeClasses[readerTheme]}`}
            >
              {/* Section Header */}
              <div className="border-b border-slate-800/50 pb-4 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-cyan-500 font-mono">
                    {sec.chapter} • {sec.number}
                  </span>
                  <h2 className="text-2xl font-extrabold tracking-tight mt-1">
                    {sec.title}
                  </h2>
                  {sec.subtitle && (
                    <p className="text-sm opacity-80 mt-0.5">{sec.subtitle}</p>
                  )}
                </div>

                {/* Direct Narration Button */}
                <button
                  onClick={() => onNarrateSection(sec.id)}
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 text-white font-semibold text-xs hover:bg-cyan-500 shadow-md transition-all"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Ouvir esta Seção</span>
                </button>
              </div>

              {/* Paragraphs */}
              <div className={`space-y-4 font-serif ${fontClasses[fontSize]}`}>
                {sec.paragraphs.map((p, pIdx) => (
                  <div key={pIdx} className="group relative">
                    <p className="indent-4 leading-relaxed">{p}</p>
                    <button
                      onClick={() => saveBookmark(sec, pIdx)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity absolute right-0 top-0 text-amber-500 hover:text-amber-400 p-1"
                      title="Salvar Marcador neste parágrafo"
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
};
