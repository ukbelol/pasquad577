import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Lock,
  UserCheck,
  CheckCircle,
  XCircle,
  Trash2,
  RefreshCw,
  Search,
  Key,
  ShieldCheck,
  Terminal,
  Download,
  Copy,
  Globe,
  Database,
  Calendar,
  Phone,
  Mail,
  User,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { VisitorComment, SecurityLog } from '../types';
import { PASQUAD_SEO_STRATEGY } from '../data/seoStrategyData';
import { INSTALL_GERALL_SCRIPT, DEBIAN12_INSTALL_SCRIPT } from '../data/installerScript';
import { audioSynth } from '../utils/audioSynth';

interface FailedIpRecord {
  ip: string;
  failedCount: number;
  blocked: boolean;
  lastAttempt: string;
}

export const AdminDashboard: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [token, setToken] = useState<string>('');
  
  // Login State
  const [loginEmail, setLoginEmail] = useState<string>('roger577@ukbelol.space');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [attemptsLeft, setAttemptsLeft] = useState<number | null>(null);
  const [isIpBlocked, setIsIpBlocked] = useState<boolean>(false);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  // Admin Data State
  const [activeTab, setActiveTab] = useState<'comments' | 'security' | 'seo' | 'installer'>('comments');
  const [commentsList, setCommentsList] = useState<VisitorComment[]>([]);
  const [commentsFilter, setCommentsFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [securityData, setSecurityData] = useState<{ failedIps: Record<string, FailedIpRecord>; logs: SecurityLog[] }>({
    failedIps: {},
    logs: [],
  });

  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Check saved session token
  useEffect(() => {
    const savedToken = localStorage.getItem('pasquad_admin_token');
    if (savedToken) {
      setToken(savedToken);
      setIsAuthenticated(true);
      fetchAdminComments(savedToken);
      fetchSecurityData(savedToken);
    }
  }, []);

  const showNotification = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(null), 3000);
  };

  // Login handler
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });

      const data = await res.json();

      if (!res.ok) {
        audioSynth.playChime('slide');
        if (data.isBlocked) {
          setIsIpBlocked(true);
        }
        if (data.attemptsLeft !== undefined) {
          setAttemptsLeft(data.attemptsLeft);
        }
        throw new Error(data.error || 'Credenciais inválidas.');
      }

      audioSynth.playChime('correct');
      setToken(data.token);
      localStorage.setItem('pasquad_admin_token', data.token);
      setIsAuthenticated(true);
      fetchAdminComments(data.token);
      fetchSecurityData(data.token);
      showNotification('Login como Super Admin realizado com sucesso!');
    } catch (err: any) {
      setLoginError(err.message || 'Falha no login.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('pasquad_admin_token');
    setIsAuthenticated(false);
    setToken('');
    setLoginPassword('');
  };

  // Comments Management
  const fetchAdminComments = async (authToken: string) => {
    try {
      const res = await fetch('/api/admin/comments', {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      const data = await res.json();
      if (data.comments) {
        setCommentsList(data.comments);
      }
    } catch (e) {
      console.error('Error fetching admin comments:', e);
    }
  };

  const handleUpdateCommentStatus = async (id: string, status: 'approved' | 'rejected') => {
    try {
      const res = await fetch(`/api/admin/comments/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        audioSynth.playChime('correct');
        fetchAdminComments(token);
        showNotification(`Status do comentário atualizado para: ${status.toUpperCase()}`);
      }
    } catch (e) {
      console.error('Error updating status:', e);
    }
  };

  const handleDeleteComment = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este comentário permanentemente?')) return;
    try {
      const res = await fetch(`/api/admin/comments/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchAdminComments(token);
        showNotification('Comentário removido com sucesso.');
      }
    } catch (e) {
      console.error('Error deleting comment:', e);
    }
  };

  // Security Management
  const fetchSecurityData = async (authToken: string) => {
    try {
      const res = await fetch('/api/admin/security', {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      const data = await res.json();
      if (data) {
        setSecurityData(data);
      }
    } catch (e) {
      console.error('Error fetching security:', e);
    }
  };

  const handleUnblockIp = async (ipToUnblock: string) => {
    try {
      const res = await fetch('/api/admin/unblock-ip', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ ip: ipToUnblock }),
      });
      if (res.ok) {
        audioSynth.playChime('correct');
        fetchSecurityData(token);
        showNotification(`IP ${ipToUnblock} desbloqueado pelo Firewall!`);
      }
    } catch (e) {
      console.error('Error unblocking IP:', e);
    }
  };

  const copyScriptToClipboard = () => {
    navigator.clipboard.writeText(INSTALL_GERALL_SCRIPT);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Filtered comments
  const filteredComments = commentsList.filter((c) => {
    if (commentsFilter === 'all') return true;
    return c.status === commentsFilter;
  });

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-12 space-y-6">
        {/* Super Admin Login Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none"></div>

          <div className="text-center space-y-2">
            <div className="inline-flex p-3 rounded-2xl bg-cyan-950 border border-cyan-800 text-cyan-400">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold text-white">Painel Super Admin PASQUAD</h2>
            <p className="text-xs text-slate-400">
              Acesso exclusivo de administração e moderação
            </p>
          </div>

          {/* Firewall Security Notice */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-900/50 text-[11px] text-amber-300 space-y-1">
            <div className="font-bold flex items-center space-x-1">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Firewall de Segurança Ativo:</span>
            </div>
            <p className="text-slate-400">
              Tentativas com senha incorreta são monitoradas. Se errar 3 vezes, seu IP será bloqueado pelo servidor.
            </p>
          </div>

          {loginError && (
            <div className="p-3.5 rounded-xl bg-rose-950/90 border border-rose-800 text-rose-200 text-xs flex items-start space-x-2 animate-fadeIn">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs text-slate-300 font-medium">E-mail Super Admin</label>
              <input
                type="email"
                required
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs text-slate-300 font-medium">Senha</label>
              <input
                type="password"
                required
                placeholder="••••••••••••"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn || isIpBlocked}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs hover:scale-[1.01] active:scale-[0.99] transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              <Key className="w-4 h-4" />
              <span>{isLoggingIn ? 'Autenticando...' : 'Acessar Dashboard Admin'}</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Action Success Toast */}
      {actionSuccessMsg && (
        <div className="bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs px-4 py-3 rounded-xl flex items-center space-x-2 animate-fadeIn sticky top-16 z-50 shadow-xl">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Admin Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold text-white">Painel Super Admin PASQUAD</h2>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-mono">
                Autenticado: roger577@ukbelol.space
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Moderação de visitantes, logs do firewall de segurança, SEO e script de deployment
            </p>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-rose-400 hover:text-rose-300 hover:border-rose-900 text-xs font-semibold transition-colors"
        >
          Sair do Painel
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('comments')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
            activeTab === 'comments'
              ? 'bg-cyan-500 text-slate-950'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>Comentários dos Visitantes ({commentsList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
            activeTab === 'security'
              ? 'bg-cyan-500 text-slate-950'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Firewall & Logs de Segurança</span>
        </button>

        <button
          onClick={() => setActiveTab('seo')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
            activeTab === 'seo'
              ? 'bg-cyan-500 text-slate-950'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>Estratégia SEO & Palavras-Chave</span>
        </button>

        <button
          onClick={() => setActiveTab('installer')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
            activeTab === 'installer'
              ? 'bg-cyan-500 text-slate-950'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>Instalador Geral install-gerall.sh</span>
        </button>
      </div>

      {/* TAB 1: MODERAÇÃO DE COMENTÁRIOS COM DADOS DOS VISITANTES */}
      {activeTab === 'comments' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center space-x-2">
              {(['all', 'pending', 'approved', 'rejected'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setCommentsFilter(filter)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium capitalize transition-colors ${
                    commentsFilter === filter
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {filter === 'all' && 'Todos'}
                  {filter === 'pending' && 'Pendentes'}
                  {filter === 'approved' && 'Aprovados'}
                  {filter === 'rejected' && 'Rejeitados'}
                </button>
              ))}
            </div>

            <button
              onClick={() => fetchAdminComments(token)}
              className="p-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 hover:text-white transition-colors text-xs flex items-center space-x-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Atualizar</span>
            </button>
          </div>

          {filteredComments.length === 0 ? (
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-12 text-center text-xs text-slate-400">
              Nenhum comentário encontrado para esta categoria.
            </div>
          ) : (
            <div className="space-y-4">
              {filteredComments.map((cm) => (
                <div
                  key={cm.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-md"
                >
                  {/* Status badge & Actions */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase ${
                          cm.status === 'approved'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : cm.status === 'rejected'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}
                      >
                        {cm.status === 'pending' && 'Aguardando Aprovação'}
                        {cm.status === 'approved' && 'Aprovado Publicamente'}
                        {cm.status === 'rejected' && 'Rejeitado / Oculto'}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">ID: {cm.id}</span>
                    </div>

                    <div className="flex items-center space-x-2">
                      {cm.status !== 'approved' && (
                        <button
                          onClick={() => handleUpdateCommentStatus(cm.id, 'approved')}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 text-slate-950 font-bold text-xs hover:bg-emerald-500 transition-all flex items-center space-x-1"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Aprovar Divulgação</span>
                        </button>
                      )}

                      {cm.status !== 'rejected' && (
                        <button
                          onClick={() => handleUpdateCommentStatus(cm.id, 'rejected')}
                          className="px-3 py-1.5 rounded-xl bg-amber-600 text-slate-950 font-bold text-xs hover:bg-amber-500 transition-all flex items-center space-x-1"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Rejeitar</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleDeleteComment(cm.id)}
                        className="p-1.5 rounded-xl bg-rose-950 border border-rose-800 text-rose-400 hover:text-white transition-colors"
                        title="Excluir Comentário"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Complete Visitor Details Required by User Prompt */}
                  <div className="grid sm:grid-cols-3 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-xs">
                    <div>
                      <span className="text-slate-500 text-[10px] block">Nome Completo:</span>
                      <span className="font-bold text-slate-200">
                        {cm.nome} {cm.sobrenome}
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">Data de Nascimento:</span>
                      <span className="font-mono text-cyan-400">{cm.dataNascimento}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">E-mail do Visitante:</span>
                      <span className="text-slate-300">{cm.email}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">Telefone / WhatsApp:</span>
                      <span className="text-slate-300 font-mono">{cm.telefone}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">Endereço IP de Origem:</span>
                      <span className="text-amber-400 font-mono">{cm.ip}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">Data/Hora do Envio:</span>
                      <span className="text-slate-400 font-mono">{cm.createdAt}</span>
                    </div>
                  </div>

                  {/* Comment Text */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Conteúdo do Comentário:
                    </span>
                    <p className="text-sm text-slate-100 bg-slate-950/60 p-4 rounded-xl border border-slate-800 leading-relaxed font-sans">
                      "{cm.comentario}"
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: FIREWALL DE SEGURANÇA & IP LOCKOUT */}
      {activeTab === 'security' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <ShieldAlert className="w-5 h-5 text-amber-400" />
                <span>Regras de Proteção de Firewall (IP Lockout)</span>
              </h3>

              <button
                onClick={() => fetchSecurityData(token)}
                className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 hover:text-white transition-colors flex items-center space-x-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Atualizar Logs</span>
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              O sistema de firewall da aplicação PASQUAD monitora todas as tentativas de autenticação no Painel Super Admin (`roger577@ukbelol.space`). Qualquer endereço IP que falhar 3 vezes consecutivas na digitação da senha é bloqueado automaticamente pelo servidor.
            </p>
          </div>

          {/* Blocked IPs Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center space-x-2">
              <Lock className="w-4 h-4 text-rose-400" />
              <span>Registros de Tentativas Incorretas e IPs Bloqueados</span>
            </h4>

            {Object.keys(securityData.failedIps).length === 0 ? (
              <div className="text-xs text-slate-500 py-4 text-center">
                Nenhum IP foi bloqueado ou registrou falhas recentemente.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-mono">
                      <th className="py-2.5 px-3">Endereço IP</th>
                      <th className="py-2.5 px-3">Erros de Senha</th>
                      <th className="py-2.5 px-3">Status do IP</th>
                      <th className="py-2.5 px-3">Última Tentativa</th>
                      <th className="py-2.5 px-3 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {(Object.entries(securityData.failedIps) as [string, FailedIpRecord][]).map(([ip, rec]) => (
                      <tr key={ip} className="hover:bg-slate-950/40">
                        <td className="py-3 px-3 font-mono font-bold text-amber-300">{ip}</td>
                        <td className="py-3 px-3 font-mono">{rec.failedCount} / 3</td>
                        <td className="py-3 px-3">
                          {rec.blocked ? (
                            <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold uppercase text-[10px]">
                              🚨 IP Bloqueado pelo Firewall
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-medium text-[10px]">
                              Liberado ({3 - rec.failedCount} tentativa restante)
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-slate-400">{rec.lastAttempt}</td>
                        <td className="py-3 px-3 text-right">
                          {rec.blocked && (
                            <button
                              onClick={() => handleUnblockIp(ip)}
                              className="px-3 py-1 rounded-lg bg-cyan-600 text-slate-950 font-bold text-xs hover:bg-cyan-500 transition-colors"
                            >
                              Desbloquear IP
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Security Log */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center space-x-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>Histórico Detalhado do Audit Log de Segurança</span>
            </h4>

            <div className="space-y-2 max-h-80 overflow-y-auto font-mono text-xs pr-1">
              {securityData.logs.length === 0 ? (
                <div className="text-slate-500 text-center py-4">Nenhum evento registrado ainda.</div>
              ) : (
                securityData.logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-[11px]"
                  >
                    <div className="space-x-2">
                      <span className="text-slate-500">{log.timestamp}</span>
                      <span className="text-amber-400 font-bold">{log.ip}</span>
                      <span className="text-slate-400">tentou e-mail: "{log.emailAttempted}"</span>
                    </div>

                    <div>
                      {log.status === 'success' && (
                        <span className="text-emerald-400 font-bold">SUCCESS (Login OK)</span>
                      )}
                      {log.status === 'failed' && (
                        <span className="text-rose-400 font-bold">FAILED (Senha incorreta)</span>
                      )}
                      {log.status === 'blocked_attempt' && (
                        <span className="text-purple-400 font-bold">BLOCKED_ATTEMPT (IP re-tentou após bloqueio)</span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ESTRATÉGIA SEO & PALAVRAS-CHAVE */}
      {activeTab === 'seo' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400">
                <Globe className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">
                  Metodologia de Palavras-Chave para Liderança de Busca (Google & Bing)
                </h3>
                <p className="text-xs text-slate-400">
                  Estratégia formulada para colocar o PASQUAD no topo dos resultados de pesquisa referente a Sincronicidade e Ciência de Dados
                </p>
              </div>
            </div>

            {/* Methodology Items */}
            <div className="grid sm:grid-cols-2 gap-4 pt-2">
              {PASQUAD_SEO_STRATEGY.methodologyOverview.map((item, idx) => (
                <div key={idx} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
                  <h4 className="text-xs font-bold text-cyan-300">{item.title}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Keywords Matrix */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider text-slate-300">
              Matriz de Palavras-Chave Segmentadas por Intenção
            </h4>

            {PASQUAD_SEO_STRATEGY.keywordGroups.map((group, gIdx) => (
              <div key={gIdx} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div>
                  <h5 className="text-xs font-bold text-cyan-400">{group.category}</h5>
                  <p className="text-[11px] text-slate-400">{group.description}</p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-500 font-mono text-[10px]">
                        <th className="py-2 px-3">Palavra-Chave / Termo de Busca</th>
                        <th className="py-2 px-3">Volume de Busca</th>
                        <th className="py-2 px-3">Intenção do Usuário</th>
                        <th className="py-2 px-3">Dificuldade SEO</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-sans">
                      {group.keywords.map((kw, kIdx) => (
                        <tr key={kIdx} className="hover:bg-slate-950/40">
                          <td className="py-2.5 px-3 font-semibold text-slate-200">{kw.term}</td>
                          <td className="py-2.5 px-3 text-slate-400 font-mono">{kw.searchVolume}</td>
                          <td className="py-2.5 px-3 text-cyan-400">{kw.intent}</td>
                          <td className="py-2.5 px-3 text-emerald-400 font-mono">{kw.difficulty}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>

          {/* Schema Markup Code block */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                Código Schema.org (JSON-LD) para Injeção no Header do Site
              </h4>
            </div>
            <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono text-cyan-300 overflow-x-auto">
              {JSON.stringify(PASQUAD_SEO_STRATEGY.jsonLdSchema, null, 2)}
            </pre>
          </div>
        </div>
      )}

      {/* TAB 4: SCRIPT INSTALADOR GERAL install-gerall.sh */}
      {activeTab === 'installer' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="space-y-1">
                <span className="text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded font-mono uppercase font-bold">
                  Script de Instalação Automática Total
                </span>
                <h3 className="text-xl font-bold text-white">
                  Instalador Geral: <code className="text-cyan-400">install-gerall.sh</code>
                </h3>
                <p className="text-xs text-slate-400">
                  Baixa todas as dependências (Node.js 20 LTS, Nginx, Certbot SSL), compila o projeto, configura o serviço Systemd e coloca o PASQUAD no ar em <code className="text-cyan-400">pasquad.ukbelol.space</code>
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={copyScriptToClipboard}
                  className="px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 hover:text-white transition-colors text-xs font-semibold flex items-center space-x-1.5"
                >
                  {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-cyan-400" />}
                  <span>{copiedCode ? 'Copiado!' : 'Copiar Script'}</span>
                </button>

                <a
                  href="/install-gerall.sh"
                  download="install-gerall.sh"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs hover:scale-105 transition-all flex items-center space-x-1.5 shadow-lg shadow-cyan-500/20"
                >
                  <Download className="w-4 h-4" />
                  <span>Baixar install-gerall.sh</span>
                </a>
              </div>
            </div>

            {/* Terminal Instructions */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
              <span className="text-slate-400 font-bold block">Como executar diretamente no seu servidor Debian 12:</span>
              <div className="text-cyan-300 bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 flex items-center justify-between">
                <code>curl -sSL https://pasquad.ukbelol.space/install-gerall.sh | sudo bash</code>
                <span className="text-[10px] text-amber-400 font-sans font-medium px-2 py-0.5 rounded bg-amber-950 border border-amber-800 ml-2">
                  Executar como Root / Sudo
                </span>
              </div>
            </div>

            {/* Code Box */}
            <div className="space-y-2">
              <span className="text-xs text-slate-400 font-mono">Código Fonte do Shell Script install-gerall.sh:</span>
              <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono text-emerald-400 overflow-x-auto max-h-96">
                {INSTALL_GERALL_SCRIPT}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
