import React from 'react';
import { User, Mail, Instagram, GraduationCap, MapPin, Calendar, FileText, CheckCircle2 } from 'lucide-react';
import { PASQUAD_METADATA } from '../data/pasquadText';

export const AuthorCard: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Author Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-4 sm:space-y-0 sm:space-x-6 relative z-10 text-center sm:text-left">
          {/* Avatar Icon / Initial badge */}
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 p-0.5 shadow-xl flex-shrink-0">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-cyan-400 font-extrabold text-2xl font-mono">
              RG
            </div>
          </div>

          <div className="space-y-2 flex-1">
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-[10px] font-bold uppercase tracking-wider">
              <span>Autor e Pesquisador</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {PASQUAD_METADATA.author}
            </h2>

            <p className="text-sm text-slate-300">
              {PASQUAD_METADATA.degree} — {PASQUAD_METADATA.university} ({PASQUAD_METADATA.graduationYear})
            </p>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-slate-400 pt-1">
              <span className="flex items-center space-x-1">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>{PASQUAD_METADATA.location}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Nascimento: {PASQUAD_METADATA.birthDate}</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Academic Credentials & Contact Details */}
      <div className="grid sm:grid-cols-2 gap-4">
        {/* Contact Links */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-2">
            <Mail className="w-4 h-4 text-cyan-400" />
            <span>Canais de Contato</span>
          </h3>

          <div className="space-y-2 text-xs">
            <a
              href={`mailto:${PASQUAD_METADATA.email}`}
              className="flex items-center space-x-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 hover:text-cyan-300 hover:border-cyan-800 transition-colors"
            >
              <Mail className="w-4 h-4 text-cyan-400" />
              <span>E-mail: {PASQUAD_METADATA.email}</span>
            </a>

            <a
              href="https://instagram.com/rogeriogs577"
              target="_blank"
              rel="noreferrer"
              className="flex items-center space-x-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 hover:text-cyan-300 hover:border-cyan-800 transition-colors"
            >
              <Instagram className="w-4 h-4 text-purple-400" />
              <span>Redes Sociais: {PASQUAD_METADATA.social}</span>
            </a>
          </div>
        </div>

        {/* Graduation Info */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-2">
            <GraduationCap className="w-4 h-4 text-purple-400" />
            <span>Formação Acadêmica</span>
          </h3>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1 text-xs text-slate-300">
            <p className="font-bold text-white">{PASQUAD_METADATA.degree}</p>
            <p className="text-slate-400">{PASQUAD_METADATA.university}</p>
            <p className="text-cyan-400 font-mono text-[11px]">Ano de Conclusão: {PASQUAD_METADATA.graduationYear}</p>
          </div>
        </div>
      </div>

      {/* Declaração de Autoria */}
      <div className="bg-slate-900/90 border border-cyan-900/60 rounded-2xl p-6 sm:p-8 space-y-4">
        <div className="flex items-center space-x-2 border-b border-cyan-900/40 pb-3">
          <FileText className="w-5 h-5 text-cyan-400" />
          <h3 className="text-lg font-bold text-white">Declaração de Autoria</h3>
        </div>

        <blockquote className="text-slate-300 text-xs sm:text-sm leading-relaxed font-serif italic border-l-2 border-cyan-500 pl-4 py-1">
          "Eu, Rogério Gomes Dos Santos, declaro que o presente trabalho apresenta uma proposta conceitual original denominada PASQUAD – Primeira Análise Sistêmica Quântica de Dados, desenvolvida como uma investigação interdisciplinar sobre percepção, informação e construção de significado. A proposta apresentada possui caráter exploratório e busca estimular pesquisas futuras, mantendo compromisso com princípios científicos de análise crítica, validação metodológica e distinção entre hipóteses conceituais e conhecimentos comprovados."
        </blockquote>

        <div className="flex items-center space-x-2 text-xs text-emerald-400 font-medium pt-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Obra e Proposta Registradas e Certificadas pelo Autor</span>
        </div>
      </div>
    </div>
  );
};
