import React, { useState } from 'react';
import { ViewMode, AmbientSound, Section } from './types';
import { Navbar } from './components/Navbar';
import { VideoPlayer } from './components/VideoPlayer';
import { DiagramExplorer } from './components/DiagramExplorer';
import { FullReader } from './components/FullReader';
import { AIAssistant } from './components/AIAssistant';
import { AuthorCard } from './components/AuthorCard';
import { CommentsSection } from './components/CommentsSection';
import { AdminDashboard } from './components/AdminDashboard';
import { QuizModal } from './components/QuizModal';
import { LanguageSelectorModal } from './components/LanguageSelectorModal';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { audioSynth } from './utils/audioSynth';

function AppContent() {
  const [currentView, setCurrentView] = useState<ViewMode>('video');
  const [ambientSound, setAmbientSound] = useState<AmbientSound>('quantum-432');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isQuizOpen, setIsQuizOpen] = useState<boolean>(false);
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [selectedSectionForAI, setSelectedSectionForAI] = useState<Section | undefined>(undefined);
  const { t } = useLanguage();

  const handleSelectView = (view: ViewMode) => {
    setCurrentView(view);
  };

  const handleChangeAmbient = (sound: AmbientSound) => {
    setAmbientSound(sound);
    audioSynth.setAmbient(sound);
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    audioSynth.setMuted(nextMuted);
  };

  const handleAskAIAboutSection = (section: Section) => {
    setSelectedSectionForAI(section);
    setAiPrompt(
      `Poderia explicar em detalhes o conceito da seção "${section.title}" (${section.subtitle || ''}) da tese PASQUAD e suas implicações para a teoria da informação e percepção humana?`
    );
    setCurrentView('ai-tutor');
  };

  const handleBookmarkSection = (section: Section, paragraphIdx: number) => {
    try {
      const saved = localStorage.getItem('pasquad_bookmarks');
      const bookmarks = saved ? JSON.parse(saved) : [];
      const newBm = {
        id: Date.now().toString(),
        sectionId: section.id,
        paragraphIndex: paragraphIdx,
        textSnippet: section.paragraphs[paragraphIdx].substring(0, 80) + '...',
        createdAt: new Date().toLocaleDateString('pt-BR'),
      };
      localStorage.setItem(
        'pasquad_bookmarks',
        JSON.stringify([newBm, ...bookmarks])
      );
      audioSynth.playChime('correct');
    } catch (e) {
      console.warn('Bookmark error:', e);
    }
  };

  const handleNarrateSectionFromReader = (sectionId: string) => {
    setCurrentView('video');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        onSelectView={handleSelectView}
        ambientSound={ambientSound}
        onChangeAmbient={handleChangeAmbient}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenQuiz={() => setIsQuizOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-7xl mx-auto w-full">
        {currentView === 'video' && (
          <VideoPlayer
            onSelectView={handleSelectView}
            onAskAIAboutSection={handleAskAIAboutSection}
            onBookmarkSection={handleBookmarkSection}
          />
        )}

        {currentView === 'diagrams' && <DiagramExplorer />}

        {currentView === 'reader' && (
          <FullReader
            onSelectView={handleSelectView}
            onNarrateSection={handleNarrateSectionFromReader}
          />
        )}

        {currentView === 'comments' && <CommentsSection />}

        {currentView === 'ai-tutor' && (
          <AIAssistant
            initialPrompt={aiPrompt}
            currentSection={selectedSectionForAI}
          />
        )}

        {currentView === 'author' && <AuthorCard />}

        {currentView === 'admin' && <AdminDashboard />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500 space-y-2">
        <p>{t('copyright')}</p>
        <p className="text-[11px] text-slate-600">{t('footerSub')}</p>
      </footer>

      {/* Interactive Quiz Modal */}
      <QuizModal isOpen={isQuizOpen} onClose={() => setIsQuizOpen(false)} />

      {/* Language Selector Modal */}
      <LanguageSelectorModal />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

