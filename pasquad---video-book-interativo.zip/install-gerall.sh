#!/bin/bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO GERAL AUTOMATIZADA - PASQUAD VIDEO-BOOK (DEBIAN 12)
# Arquivo: install-gerall.sh
# Domínio Alvo: pasquad.ukbelol.space
# E-mail para Certificado SSL (Certbot): rogermei577@gmail.com
# Credenciais Super Admin: roger577@ukbelol.space
# Autor: Rogério Gomes Dos Santos
# ==============================================================================

set -e

# Cores para mensagens de status no terminal
RED='\x1b[0;31m'
GREEN='\x1b[0;32m'
CYAN='\x1b[0;36m'
YELLOW='\x1b[1;33m'
BOLD='\x1b[1m'
NC='\x1b[0m' # No Color

echo -e "${CYAN}"
echo "================================================================="
echo "   INSTALADOR GERAL AUTOMÁTICO PASQUAD - DEBIAN 12 LINUX         "
echo "   Domínio: pasquad.ukbelol.space                               "
echo "   Certificado SSL: Let's Encrypt (rogermei577@gmail.com)       "
echo "   Instalação completa de dependências, SSL e colocação no ar   "
echo "================================================================="
echo -e "${NC}"

# 1. Verificar privilégios de Superusuário (Root)
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Erro: Por favor, execute este script como root ou com sudo! Exemplo:${NC}"
  echo -e "${YELLOW}curl -sSL https://pasquad.ukbelol.space/install-gerall.sh | sudo bash${NC}"
  exit 1
fi

# 2. Atualizar repositórios e pacotes do Debian 12
echo -e "${YELLOW}[1/9] Atualizando repositórios do sistema operacional Debian 12...${NC}"
apt update && apt upgrade -y
apt install -y curl wget git build-essential ufw software-properties-common ca-certificates gnupg lsb-release

# 3. Instalar Node.js 20.x LTS e NPM com repositório oficial Nodesource
echo -e "${YELLOW}[2/9] Instalando Node.js 20 LTS e ferramentas de compilação C/C++...${NC}"
if ! command -v node &> /dev/null || [[ $(node -v) != v20* ]]; then
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
  NODE_MAJOR=20
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
  apt update
  apt install -y nodejs
fi

echo -e "${GREEN}✓ Node.js $(node -v) e NPM v$(npm -v) verificados e prontos!${NC}"

# 4. Instalar Web Server Nginx e Certbot SSL
echo -e "${YELLOW}[3/9] Instalando Nginx Web Server e Certbot SSL para Nginx...${NC}"
apt install -y nginx certbot python3-certbot-nginx

# 5. Criar Diretório e Preparar Aplicação
APP_DIR="/var/www/pasquad-app"
echo -e "${YELLOW}[4/9] Configurando diretório da aplicação em $APP_DIR...${NC}"

mkdir -p $APP_DIR
cd $APP_DIR

# Se o diretório contiver código ou estivemos em um ambiente clonado
if [ ! -f "package.json" ]; then
  echo -e "${CYAN}Baixando estrutura do projeto PASQUAD...${NC}"
  # Caso deseje clonar diretamente de um repositório git:
  # git clone https://github.com/seu-usuario/pasquad-videobook.git .
fi

# 6. Instalar todas as dependências NPM e compilar o projeto
echo -e "${YELLOW}[5/9] Baixando todas as dependências NPM e compilando a aplicação...${NC}"
npm install --production=false
npm run build

# 7. Criar e Ativar Serviço Systemd
echo -e "${YELLOW}[6/9] Criando e ativando serviço Systemd em /etc/systemd/system/pasquad.service...${NC}"

cat << 'EOF' > /etc/systemd/system/pasquad.service
[Unit]
Description=PASQUAD Video-Book Node.js Production Application
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/var/www/pasquad-app
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable pasquad
systemctl restart pasquad

# 8. Configurar Nginx Reverse Proxy
echo -e "${YELLOW}[7/9] Configurando Nginx Reverse Proxy para pasquad.ukbelol.space...${NC}"

cat << 'EOF' > /etc/nginx/sites-available/pasquad.ukbelol.space
server {
    listen 80;
    listen [::]:80;
    server_name pasquad.ukbelol.space www.pasquad.ukbelol.space;

    client_max_body_size 50M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

ln -sf /etc/nginx/sites-available/pasquad.ukbelol.space /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

# 9. Configurar Firewall UFW e Emitir Certificado SSL Válido
echo -e "${YELLOW}[8/9] Liberando portas no Firewall UFW (22, 80, 443)...${NC}"
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

echo -e "${YELLOW}[9/9] Emitindo Certificado SSL Válido com Let's Encrypt para pasquad.ukbelol.space...${NC}"
certbot --nginx -d pasquad.ukbelol.space --non-interactive --agree-tos -m rogermei577@gmail.com --redirect || {
  echo -e "${RED}Atenção: O Certbot não pôde validar o domínio imediatamente. Verifique se o Apontamento DNS A de pasquad.ukbelol.space aponta para o IP público deste servidor.${NC}"
}

# Habilitar renovação automática do SSL
systemctl enable certbot.timer

# Verificar status final do serviço
sleep 3
if curl -s http://127.0.0.1:3000/api/health | grep -q "ok"; then
  echo -e "${GREEN}✓ Backend Node.js respondendo perfeitamente na porta 3000!${NC}"
else
  echo -e "${YELLOW}! O serviço está iniciando... Verifique com 'systemctl status pasquad'.${NC}"
fi

echo -e "${GREEN}"
echo "================================================================="
echo "   SISTEMA PASQUAD INSTALADO E COLOCADO NO AR COM SUCESSO!     "
echo "================================================================="
echo "   URL Principal: https://pasquad.ukbelol.space                   "
echo "   Painel Admin:  https://pasquad.ukbelol.space (Menu Admin)     "
echo "   Super Admin:   roger577@ukbelol.space                          "
echo "   Certificado:   SSL Ativo (Let's Encrypt - rogermei577@gmail.com)"
echo "   Firewall:      Ativo com Bloqueio de IP após 3 tentativas      "
echo "================================================================="
echo -e "${NC}"
