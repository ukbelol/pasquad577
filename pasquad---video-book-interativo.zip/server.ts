import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import AdmZip from "adm-zip";
import { DEBIAN12_INSTALL_SCRIPT, INSTALL_GERALL_SCRIPT } from "./src/data/installerScript.js";

dotenv.config();

// Safe resolution of directory paths for both ESM (tsx dev) and CJS (esbuild production bundle)
const getAppDir = () => {
  try {
    if (typeof __dirname !== "undefined" && __dirname) return __dirname;
  } catch (e) {}
  try {
    if (typeof import.meta !== "undefined" && import.meta?.url) {
      return path.dirname(fileURLToPath(import.meta.url));
    }
  } catch (e) {}
  return process.cwd();
};

const appDir = getAppDir();

// Data files for persistence
const DATA_DIR = path.join(process.cwd(), "data_store");
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const COMMENTS_FILE = path.join(DATA_DIR, "comments.json");
const SECURITY_FILE = path.join(DATA_DIR, "security.json");

// Types for backend
interface VisitorComment {
  id: string;
  nome: string;
  sobrenome: string;
  dataNascimento: string;
  email: string;
  telefone: string;
  comentario: string;
  status: 'pending' | 'approved' | 'rejected';
  ip: string;
  createdAt: string;
}

interface FailedIpRecord {
  ip: string;
  failedCount: number;
  blocked: boolean;
  lastAttempt: string;
}

interface SecurityAttemptLog {
  id: string;
  ip: string;
  emailAttempted: string;
  status: 'success' | 'failed' | 'blocked_attempt';
  timestamp: string;
  attemptsCount: number;
}

// Helpers for file loading/saving
function loadComments(): VisitorComment[] {
  try {
    if (fs.existsSync(COMMENTS_FILE)) {
      const data = fs.readFileSync(COMMENTS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (e) {
    console.error("Error loading comments:", e);
  }
  return [
    {
      id: "demo-1",
      nome: "Carlos",
      sobrenome: "Eduardo Silva",
      dataNascimento: "1988-04-12",
      email: "carlos.silva@exemplo.com",
      telefone: "(11) 98765-4321",
      comentario: "Excelente trabalho conceitual do autor Rogério Gomes! A integração da sincronicidade com a teoria dos sistemas de informação traz um horizonte totalmente novo.",
      status: "approved",
      ip: "201.86.42.10",
      createdAt: new Date().toLocaleDateString("pt-BR") + " 14:30"
    }
  ];
}

function saveComments(comments: VisitorComment[]) {
  try {
    fs.writeFileSync(COMMENTS_FILE, JSON.stringify(comments, null, 2));
  } catch (e) {
    console.error("Error saving comments:", e);
  }
}

function loadSecurityData(): { failedIps: Record<string, FailedIpRecord>; logs: SecurityAttemptLog[] } {
  try {
    if (fs.existsSync(SECURITY_FILE)) {
      const data = fs.readFileSync(SECURITY_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (e) {
    console.error("Error loading security data:", e);
  }
  return { failedIps: {}, logs: [] };
}

function saveSecurityData(data: { failedIps: Record<string, FailedIpRecord>; logs: SecurityAttemptLog[] }) {
  try {
    fs.writeFileSync(SECURITY_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("Error saving security data:", e);
  }
}

let commentsStore = loadComments();
let securityStore = loadSecurityData();

async function startServer() {
  const app = express();
  app.set("trust proxy", true);
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: "10mb" }));

  // Helper for Gemini AI
  const getGenAI = () => {
    const apiKey = process.env.GEMINI_API_KEY || "AQ.Ab8RN6Ldsee6jRCgSVtgZp2YoD5sjQNGtUwmOdtMyq9JoG9LwQ";
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not configured.");
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  // PASQUAD Monograph Context
  const PASQUAD_CONTEXT = `
  Você é o Tutor de IA do PASQUAD (Primeira Análise Sistêmica Quântica de Dados), modelo conceitual de investigação desenvolvido por Rogério Gomes Dos Santos (Bacharel em Sistemas de Informação pela Universidade Unifieo, Osasco-SP, 2010).
  
  RESUMO DA TESE PASQUAD:
  - Título: PASQUAD - Primeira Análise Sistêmica Quântica de Dados: Um Modelo Conceitual de Investigação da Sincronicidade, Percepção Multissensorial e Construção de Significados por Meio da Integração entre Cognição Humana, Teoria da Informação e Sistemas Complexos.
  - Autor: Rogério Gomes Dos Santos (@rogeriogs577 / rogeriogomes11@gmail.com).
  - Conceito Chave: Estudo da interpretação humana de eventos percebidos como significativos, coincidências simbólicas e padrões emergentes no cotidiano.
  - Origem & Ponto de Partida: Conceito de sincronicidade de Carl Gustav Jung + Ciência Cognitiva + Teoria da Informação + Sistemas Complexos + IA.
  - Os Seis Sentidos Integrados: Visão, Audição, Tato, Olfato, Paladar e o Sexto Sentido (compreendido como uma capacidade cognitiva de síntese baseada em memória, experiência, reconhecimento de padrões e inferência).
  - O Termo "Quântico": Não é uma aplicação direta da física quântica à consciência, mas uma metáfora epistemológica para a existência de múltiplas possibilidades interpretativas antes da definição de um significado final.
  - Comparação de Fluxo Informacional:
    * Computação Tradicional: Dados -> Processamento -> Informação -> Conhecimento -> Decisão
    * Modelo PASQUAD: Percepção -> Integração -> Contexto -> Interpretação -> Significado
  `;

  // Helper to extract IP
  const getClientIp = (req: express.Request): string => {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string' && forwarded) {
      return forwarded.split(',')[0].trim();
    }
    return req.socket.remoteAddress || '127.0.0.1';
  };

  // Helper token verify middleware
  const authMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (token === 'admin-pasquad-roger577-session') {
      return next();
    }
    return res.status(401).json({ error: 'Acesso não autorizado ao Painel Super Admin.' });
  };

  // API Health Endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "PASQUAD Video-Book" });
  });

  // Helper function to generate pasquad.zip with all project files and install-gerall.sh at root
  function generatePasquadZip(): Buffer {
    const zip = new AdmZip();
    const rootDir = process.cwd();

    // 1. Always ensure install-gerall.sh is at the root of the zip
    const installScriptPath = path.join(rootDir, "install-gerall.sh");
    if (fs.existsSync(installScriptPath)) {
      zip.addLocalFile(installScriptPath);
    } else {
      zip.addFile("install-gerall.sh", Buffer.from(INSTALL_GERALL_SCRIPT, "utf-8"));
    }

    // 2. Add all key project files and directories
    const itemsToAdd = [
      "src",
      "public",
      "package.json",
      "tsconfig.json",
      "tsconfig.node.json",
      "vite.config.ts",
      "server.ts",
      "README.md",
      "metadata.json",
      "index.html",
      ".env.example"
    ];

    for (const item of itemsToAdd) {
      const itemPath = path.join(rootDir, item);
      if (fs.existsSync(itemPath)) {
        const stat = fs.statSync(itemPath);
        if (stat.isDirectory()) {
          zip.addLocalFolder(itemPath, item);
        } else {
          zip.addLocalFile(itemPath);
        }
      }
    }

    return zip.toBuffer();
  }

  // Download Route for Project ZIP (pasquad.zip)
  app.get(["/pasquad.zip", "/api/download/pasquad.zip"], (req, res) => {
    try {
      const buffer = generatePasquadZip();
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", "attachment; filename=pasquad.zip");
      res.send(buffer);
    } catch (err) {
      console.error("Erro ao criar pasquad.zip:", err);
      res.status(500).json({ error: "Erro ao gerar o arquivo pasquad.zip." });
    }
  });

  // Download Routes for Debian 12 Deployment Shell Script
  app.get("/install-gerall.sh", (req, res) => {
    res.setHeader("Content-Type", "text/x-shellscript");
    res.setHeader("Content-Disposition", "attachment; filename=install-gerall.sh");
    res.send(INSTALL_GERALL_SCRIPT);
  });

  app.get("/deploy-debian12.sh", (req, res) => {
    res.setHeader("Content-Type", "text/x-shellscript");
    res.setHeader("Content-Disposition", "attachment; filename=install-gerall.sh");
    res.send(INSTALL_GERALL_SCRIPT);
  });

  // Public Comments Endpoint (Approved only)
  app.get("/api/comments/public", (req, res) => {
    const approved = commentsStore
      .filter((c) => c.status === "approved")
      .map((c) => ({
        id: c.id,
        nome: c.nome,
        sobrenome: c.sobrenome,
        comentario: c.comentario,
        createdAt: c.createdAt,
      }));
    res.json({ comments: approved });
  });

  // Visitor Submit Comment Endpoint
  app.post("/api/comments", (req, res) => {
    try {
      const { nome, sobrenome, dataNascimento, email, telefone, comentario } = req.body;
      const clientIp = getClientIp(req);

      if (!nome || !sobrenome || !dataNascimento || !email || !telefone || !comentario) {
        return res.status(400).json({
          error: "Todos os campos (Nome, Sobrenome, Data de Nascimento, E-mail, Telefone e Comentário) são obrigatórios.",
        });
      }

      const newComment: VisitorComment = {
        id: "cm-" + Date.now() + "-" + Math.random().toString(36).substr(2, 4),
        nome: nome.trim(),
        sobrenome: sobrenome.trim(),
        dataNascimento,
        email: email.trim(),
        telefone: telefone.trim(),
        comentario: comentario.trim(),
        status: "pending",
        ip: clientIp,
        createdAt: new Date().toLocaleString("pt-BR"),
      };

      commentsStore.unshift(newComment);
      saveComments(commentsStore);

      return res.json({
        success: true,
        message: "Comentário enviado com sucesso! Seus dados foram registrados e o comentário está aguardando aprovação do Super Admin.",
      });
    } catch (err: any) {
      return res.status(500).json({ error: "Erro ao registrar comentário." });
    }
  });

  // Super Admin Login Endpoint with Firewall IP Lockout (3 strikes)
  app.post("/api/admin/login", (req, res) => {
    const { email, password } = req.body;
    const ip = getClientIp(req);

    // Check if IP is currently blocked
    const ipRecord = securityStore.failedIps[ip];
    if (ipRecord && ipRecord.blocked) {
      // Record blocked attempt
      const blockedLog: SecurityAttemptLog = {
        id: "log-" + Date.now(),
        ip,
        emailAttempted: email || "desconhecido",
        status: "blocked_attempt",
        timestamp: new Date().toLocaleString("pt-BR"),
        attemptsCount: ipRecord.failedCount,
      };
      securityStore.logs.unshift(blockedLog);
      saveSecurityData(securityStore);

      return res.status(403).json({
        error: `🔥 FIREWALL SEGURANÇA PASQUAD: Seu IP (${ip}) foi BLOQUEADO por exceder o limite de 3 tentativas com senha incorreta. Entre em contato com o administrador do sistema para desbloqueio.`,
        isBlocked: true,
        ip,
      });
    }

    // Credentials check
    const SUPERADMIN_EMAIL = "roger577@ukbelol.space";
    const SUPERADMIN_PASS = "23300577@Teanro-2330";

    if (email === SUPERADMIN_EMAIL && password === SUPERADMIN_PASS) {
      // Reset failed counter on success
      securityStore.failedIps[ip] = {
        ip,
        failedCount: 0,
        blocked: false,
        lastAttempt: new Date().toLocaleString("pt-BR"),
      };

      const successLog: SecurityAttemptLog = {
        id: "log-" + Date.now(),
        ip,
        emailAttempted: email,
        status: "success",
        timestamp: new Date().toLocaleString("pt-BR"),
        attemptsCount: 0,
      };
      securityStore.logs.unshift(successLog);
      saveSecurityData(securityStore);

      return res.json({
        success: true,
        token: "admin-pasquad-roger577-session",
        user: { email: SUPERADMIN_EMAIL, role: "superadmin" },
      });
    }

    // Handle failed login
    const currentCount = (ipRecord?.failedCount || 0) + 1;
    const isNowBlocked = currentCount >= 3;

    securityStore.failedIps[ip] = {
      ip,
      failedCount: currentCount,
      blocked: isNowBlocked,
      lastAttempt: new Date().toLocaleString("pt-BR"),
    };

    const failLog: SecurityAttemptLog = {
      id: "log-" + Date.now(),
      ip,
      emailAttempted: email || "em branco",
      status: "failed",
      timestamp: new Date().toLocaleString("pt-BR"),
      attemptsCount: currentCount,
    };
    securityStore.logs.unshift(failLog);
    saveSecurityData(securityStore);

    if (isNowBlocked) {
      return res.status(403).json({
        error: `🚨 SEGURANÇA DISPARADA: Você errou a senha 3 vezes. Seu IP (${ip}) foi BLOQUEADO automaticamente pelo Firewall.`,
        isBlocked: true,
        attemptsLeft: 0,
        ip,
      });
    }

    return res.status(401).json({
      error: `Credenciais incorretas! Tentativa ${currentCount} de 3. Se errar 3 vezes, seu IP será bloqueado automaticamente.`,
      attemptsLeft: 3 - currentCount,
      isBlocked: false,
    });
  });

  // Admin GET All Comments
  app.get("/api/admin/comments", authMiddleware, (req, res) => {
    res.json({ comments: commentsStore });
  });

  // Admin Update Comment Status (approve / reject)
  app.patch("/api/admin/comments/:id", authMiddleware, (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const comment = commentsStore.find((c) => c.id === id);
    if (!comment) {
      return res.status(404).json({ error: "Comentário não encontrado." });
    }
    if (status && ["pending", "approved", "rejected"].includes(status)) {
      comment.status = status;
      saveComments(commentsStore);
      return res.json({ success: true, comment });
    }
    return res.status(400).json({ error: "Status inválido." });
  });

  // Admin Delete Comment
  app.delete("/api/admin/comments/:id", authMiddleware, (req, res) => {
    const { id } = req.params;
    commentsStore = commentsStore.filter((c) => c.id !== id);
    saveComments(commentsStore);
    res.json({ success: true, message: "Comentário excluído." });
  });

  // Admin Get Security Logs & Blocked IPs
  app.get("/api/admin/security", authMiddleware, (req, res) => {
    res.json({
      failedIps: securityStore.failedIps,
      logs: securityStore.logs.slice(0, 100),
    });
  });

  // Admin Unblock IP
  app.post("/api/admin/unblock-ip", authMiddleware, (req, res) => {
    const { ip } = req.body;
    if (securityStore.failedIps[ip]) {
      securityStore.failedIps[ip] = {
        ip,
        failedCount: 0,
        blocked: false,
        lastAttempt: new Date().toLocaleString("pt-BR"),
      };
      saveSecurityData(securityStore);
      return res.json({ success: true, message: `IP ${ip} desbloqueado com sucesso.` });
    }
    return res.status(404).json({ error: "IP não encontrado na lista de registros." });
  });

  // API Gemini Chat/Explain Endpoint
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { message, history = [], currentSection = "" } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Mensagem é obrigatória." });
      }

      const ai = getGenAI();

      const systemInstruction = `${PASQUAD_CONTEXT}
      Instruções para a resposta:
      - Responda em Português do Brasil com tom acadêmico, acessível, profundo e didático.
      - Se o usuário perguntar sobre o PASQUAD, Jung, Sincronicidade, Teoria da Informação, os 6 Sentidos ou a Monografia de Rogério Gomes Dos Santos, ofereça explicações fundamentadas na tese.
      - Seção atual sendo lida no video-book pelo usuário: ${currentSection || "Visão Geral"}.
      - Mantenha respostas bem formatadas em Markdown com tópicos claros.`;

      const formattedHistory = history.map((item: any) => ({
        role: item.role === "user" ? "user" : "model",
        parts: [{ text: item.content }],
      }));

      const contents = [
        ...formattedHistory,
        { role: "user", parts: [{ text: message }] },
      ];

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      return res.json({ response: response.text });
    } catch (error: any) {
      console.error("Erro na API Gemini:", error);
      return res.status(500).json({
        error: error.message || "Falha ao processar requisição com a IA Gemini.",
      });
    }
  });

  // API Gemini Quiz Generator
  app.post("/api/gemini/quiz", async (req, res) => {
    try {
      const ai = getGenAI();
      const prompt = `Gere 3 perguntas de múltipla escolha para testar o conhecimento do leitor sobre a tese PASQUAD (Primeira Análise Sistêmica Quântica de Dados).
      Retorne APENAS um JSON válido no seguinte formato:
      [
        {
          "question": "Pergunta aqui",
          "options": ["A) Opção 1", "B) Opção 2", "C) Opção 3", "D) Opção 4"],
          "correctIndex": 0,
          "explanation": "Explicação detalhada baseada no texto do PASQUAD."
        }
      ]`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          systemInstruction: PASQUAD_CONTEXT,
        },
      });

      const quizData = JSON.parse(response.text || "[]");
      return res.json({ quiz: quizData });
    } catch (error: any) {
      console.error("Erro ao gerar quiz:", error);
      return res.status(500).json({ error: "Não foi possível gerar o quiz." });
    }
  });

  // Vite Middleware for Dev / Static Files for Prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`PASQUAD Video-Book Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

